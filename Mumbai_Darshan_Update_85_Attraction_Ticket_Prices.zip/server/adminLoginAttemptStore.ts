export type AdminLoginAttempt = { count: number; resetAt: number; blockedUntil: number };

/** Bounded process-local store for Admin login throttling state. */
export function createAdminLoginAttemptStore(maxEntries = 5000, pruneEvery = 256) {
  const entries = new Map<string, AdminLoginAttempt>();
  let callsSincePrune = 0;

  const pruneExpired = (now: number) => {
    for (const [key, attempt] of entries) {
      if (attempt.resetAt <= now && attempt.blockedUntil <= now) entries.delete(key);
    }
  };

  return {
    getOrCreate(ip: string, now = Date.now()): AdminLoginAttempt | null {
      callsSincePrune += 1;
      if (callsSincePrune >= pruneEvery || entries.size >= maxEntries) {
        pruneExpired(now);
        callsSincePrune = 0;
      }
      const existing = entries.get(ip);
      if (existing) return existing;
      if (entries.size >= maxEntries) return null;
      const created = { count: 0, resetAt: now + 15 * 60 * 1000, blockedUntil: 0 };
      entries.set(ip, created);
      return created;
    },
    delete(ip: string): boolean {
      return entries.delete(ip);
    },
    size(): number {
      return entries.size;
    }
  };
}
