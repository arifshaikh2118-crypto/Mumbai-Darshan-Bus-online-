export type RateLimitEntry = { count: number; resetAt: number };

/**
 * Bounded in-memory limiter for public endpoints.
 * Expired keys are pruned periodically and before admitting a new key at capacity.
 * When the map is full of active keys, new keys fail closed instead of growing memory.
 */
export function createBoundedRateLimiter(maxEntries = 5000, pruneEvery = 256) {
  const entries = new Map<string, RateLimitEntry>();
  let callsSincePrune = 0;

  const pruneExpired = (now: number) => {
    for (const [key, entry] of entries) {
      if (entry.resetAt <= now) entries.delete(key);
    }
  };

  return {
    allow(key: string, limit: number, windowMs: number, now = Date.now()): boolean {
      callsSincePrune += 1;
      if (callsSincePrune >= pruneEvery || entries.size >= maxEntries) {
        pruneExpired(now);
        callsSincePrune = 0;
      }

      const current = entries.get(key);
      if (!current || current.resetAt <= now) {
        if (!current && entries.size >= maxEntries) return false;
        entries.set(key, { count: 1, resetAt: now + windowMs });
        return true;
      }

      if (current.count >= limit) return false;
      current.count += 1;
      return true;
    },
    size(): number {
      return entries.size;
    }
  };
}
