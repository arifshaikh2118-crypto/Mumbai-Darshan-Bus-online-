export type BookingIdRequestValidation = {
  valid: boolean;
  error?: string;
  customerName?: string;
  cleanMobile?: string;
  travelDate?: string;
  routeId?: string;
  packageId?: string;
};

/** Validate the legacy booking-ID endpoint without relying on browser input constraints. */
export function validateBookingIdRequest(body: any, now: Date = new Date()): BookingIdRequestValidation {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return { valid: false, error: 'Booking details are required.' };
  }

  const customerName = typeof body.customerName === 'string' ? body.customerName.trim() : '';
  const cleanMobile = String(body.customerMobile || '').replace(/\D/g, '');
  const travelDate = typeof body.travelDate === 'string' ? body.travelDate : '';
  const routeId = typeof body.routeId === 'string' ? body.routeId.trim() : '';
  const packageId = typeof body.packageId === 'string' ? body.packageId.trim() : '';

  if (!customerName || customerName.length > 100) {
    return { valid: false, error: 'Customer name is required (maximum 100 characters).' };
  }
  if (!/^\d{10}$/.test(cleanMobile)) {
    return { valid: false, error: 'Mobile number must be exactly 10 digits.' };
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(travelDate)) {
    return { valid: false, error: 'Travel date must use YYYY-MM-DD format.' };
  }

  const [year, month, day] = travelDate.split('-').map(Number);
  const selectedDate = new Date(year, month - 1, day);
  if (
    selectedDate.getFullYear() !== year ||
    selectedDate.getMonth() !== month - 1 ||
    selectedDate.getDate() !== day
  ) {
    return { valid: false, error: 'Travel date is not a valid calendar date.' };
  }

  const localToday = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  if (travelDate < localToday) {
    return { valid: false, error: 'Travel date cannot be in the past.' };
  }
  if (!routeId || routeId.length > 80 || !packageId || packageId.length > 80) {
    return { valid: false, error: 'Valid route and package are required.' };
  }

  return { valid: true, customerName, cleanMobile, travelDate, routeId, packageId };
}

export function localBookingDateCode(now: Date = new Date()): string {
  return `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
}
