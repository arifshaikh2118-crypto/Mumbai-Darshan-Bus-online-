# Update 76 — Deep Project Audit, Server-Owned Sync & SEO Discovery

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 75 — English Language Guard Expansion  
**Release status:** INCOMPLETE — do not deploy to production.

## 1. Work completed

### A. Public booking and rental sync no longer depends on browser-local webhook settings

The previous flow required `BookingForm` to read `googleSheetsWebhookUrl` and `autoSyncGoogleSheets` from browser `localStorage` before submitting a booking. Rental sync also read the webhook URL from browser storage. A fresh customer device would not have those Admin-local settings, even when the server environment was correctly configured.

Changes:
- `BookingForm` now calls the server proxy without requiring browser-local webhook settings.
- Booking and rental sync helpers no longer accept/read a browser-provided Apps Script URL.
- `/api/sync-sheets` selects the Apps Script endpoint exclusively from server-side `GOOGLE_APPS_SCRIPT_URL`.
- The public proxy still enforces the explicit action allowlist, 64 KB payload limit, URL validation, timeout and per-IP/action throttling.
- Missing server configuration fails closed with HTTP 503; it does not silently save or confirm a booking.
- The Admin backend screen no longer asks the Admin to paste a webhook URL or toggle browser-local auto-sync. It explains that the endpoint and secrets belong in the hosting provider's private environment.
- The Admin connection test now checks the server-configured endpoint and no longer falls back to a browser `no-cors` request.
- Garage-address editing remains local as before; this update does not claim it is Sheets-backed.

### B. SEO discovery assets restored/added

- Added `public/robots.txt` with crawl permission and the canonical sitemap location.
- Added `public/sitemap.xml` containing the current canonical homepage only. The application uses client-side page state rather than distinct crawlable page URLs, so non-existent routes were not invented.
- Added canonical URL, robots index/follow directive, Open Graph URL and Twitter title/description metadata to `index.html`.
- Vite copies `public/` assets into the `dist/` build output; this still needs confirmation from a successful production build.

### C. Deep release-readiness checks added

- Added `validation/test_server_owned_public_sync.cjs` (11 assertions).
- Added `validation/test_public_seo_assets.cjs` (9 assertions).
- Added `validation/test_release_readiness_audit.cjs` (17 assertions) so known blockers remain visible rather than being mistaken for completed work.
- Updated existing booking retry, public sync rate-limit and Admin security contract tests to reflect the server-owned endpoint.

## 2. Deep audit findings — work still required

### P0 — Express API is not connected to Firebase Hosting

- `server.ts` contains the Express API used by booking submission, lookup, cancellation, Admin login, protected data and Admin mutations.
- Current `firebase.json` serves the Vite `dist` folder and rewrites all paths to `/index.html`.
- There is no `/api/**` rewrite to a verified Cloud Run service or another backend host.
- Firebase Hosting by itself will not start `server.ts`. A static-only deployment would render the frontend but its API calls would fail.

**Required before deployment:** owner/developer must confirm the backend host, project/service ID, region, runtime/build command and private environment variables. Do not invent a Cloud Run target or alter DNS.

### P0 — Live Google Sheets / Apps Script staging is not verified

- The source includes an Apps Script handler and exact schema manifest, but no live staging spreadsheet/deployment has been tested in this work session.
- `GOOGLE_APPS_SCRIPT_URL`, `ADMIN_API_SECRET`, `ADMIN_PASSCODE` and `ADMIN_SESSION_SECRET` must be configured only in the backend/Apps Script secret stores.
- The live 17-tab workbook, active `AdminUsers` roster, email authorization and all data-write/read paths remain unverified.

**Required before deployment:** owner-approved isolated staging setup and end-to-end tests. No live spreadsheet or Apps Script was accessed or changed in Update 76.

### P1 — Public website configuration is still browser-local, not fully Sheets-driven

The customer website still reads routes, packages, offers, pickup points, tour points, public settings, local rental packages and outstation rates through `StorageService` backed by `localStorage` and `INITIAL_*` defaults. The Admin Operational Sheets Manager writes to Google Sheets, but public pages are not hydrated from those sheet rows.

Confirmed examples:
- `BookingForm.tsx`: routes, packages, offers and pickup points.
- `PricingPackagesPage.tsx` and `PickupTimingsTable.tsx`: route/package/pickup data.
- `CarRentalPanel.tsx`: local rental packages and outstation rates.
- `TourPointsGrid.tsx` and `PhotoGallery.tsx`: local tour/gallery data.
- `AdminLayout.tsx`: legacy route/package/pickup/settings views also continue to use local storage.

The approved schema does not currently contain all fields needed to reproduce the public configuration safely:
- `PickupPoints` has only `Route`, `Pickup Point`, `Sort Order`, `Active`; it lacks pickup time, landmark, reporting time and map URL.
- `PackageOptions` has seven columns and lacks `isAC`, `hasLunch` and package description fields.
- The approved 17-tab manifest does not include a dedicated local/outstation rental-pricing tab or group-booking enquiry tab.

**Required before implementation:** approve the exact schema additions/mapping or formally approve a JSON configuration format in an existing safe settings structure. Do not expose `ADMIN_GET_DATA` publicly; it contains customer records, payments, cancellations and operational/admin information.

### P1 — Group booking form is local-only

`GroupBookingPage.tsx` creates a group enquiry in browser `localStorage` and displays “Group Booking Request Submitted”. There is no matching Express endpoint or approved group-enquiry sheet in the 17-tab schema. The displayed success is therefore only a local-device save, not a server/Sheets submission.

**Required:** either approve a dedicated group-enquiry schema and protected/public API flow, or change the page to an explicit enquiry handoff (for example, user-initiated WhatsApp) before advertising it as a submitted request. No schema was added without approval.

### P1 — Online payment is not active

- The customer booking receipt explicitly says the online payment gateway is not activated and no payment has been collected.
- The booking is saved as `Payment Pending` / `Pending Verification`; it is not a confirmed ticket.
- PhonePe/payment gateway integration and automated refunds remain deferred by owner instruction.

**Required:** activate only after merchant account/credentials and payment callback staging are approved. Do not treat the current booking acknowledgement as a paid ticket.

### P1 — Email and notification delivery are not live-verified

- Customer/owner booking email notifications depend on trusted payment verification and controlled Apps Script configuration.
- Live email testing and triggers are intentionally disabled/deferred.
- Rental enquiry remains inquiry-only and must not send owner/customer email; manual WhatsApp follow-up is the approved workflow.

**Required:** test booking emails in isolated staging after the owner confirms recipient settings. Do not enable triggers or send real emails during local audit.

### P2 — Dependency lockfile and full build are missing

- `package-lock.json` is absent.
- `bun.lock` is zero bytes.
- `node_modules` is absent.
- `tsc --noEmit` cannot start a semantic project check because `vite/client` type definitions are unavailable.
- `npm run build` was not run because Vite dependencies are not installed.

**Required:** generate and review a real lockfile on a network-enabled build runner, run clean `npm ci`, then `npm run lint` and `npm run build`.

### P2 — Browser E2E and Preview verification remain pending

- No browser E2E was run.
- `PREVIEW.html` was not refreshed; Preview refresh remains a separate approval-gated action.
- No mobile real-device test, deployed API test, payment test or live email test was performed.

### P2 — Dynamic content and runtime language need review

- Static English source guard covers 35 source/HTML files and passes.
- Text entered later into Google Sheets is not covered by the source scan.
- Group-booking, rental-pricing, pickup and website-content rows need an English review in the staging workbook before public exposure.

## 3. Validation performed

| Check | Result |
|---|---:|
| Main dependency-free offline runner | **43/43 PASS** |
| New server-owned sync assertions | 11 PASS |
| New SEO assertions | 9 PASS |
| New release-readiness assertions | 17 PASS |
| TypeScript/TSX syntax transpilation | **33 files, 0 syntax errors** |
| Apps Script syntax | PASS |
| Static English-copy scan | **35 files PASS** |
| JSON configuration parse | **6/6 PASS** |
| Semantic TypeScript check | ATTEMPTED — blocked because `vite/client` type definitions are unavailable |
| Vite production build | ATTEMPTED — blocked because `vite` is not installed (`vite: not found`) |
| Browser E2E | NOT RUN |
| Live Sheets / Apps Script staging | NOT RUN |
| Production deployment | NOT performed |

## 4. Safety and scope

- No Google Sheets, Apps Script deployment, Firebase Hosting, Cloud Run, DNS, email, PhonePe, GitHub or Preview action was performed.
- No live customer data was accessed or modified.
- No approved sheet/tab/header was changed.
- No pricing, route prices, booking advance, guide/toll, attraction, rental or refund business rule was changed.
- All new UI copy and documentation in this update are English.

## 5. Conclusion

Update 76 fixes the browser-local webhook dependency, improves the secure server-owned sync flow, restores public SEO discovery files and adds a deep release-readiness audit. The project remains **INCOMPLETE / NOT production-ready**. The next critical dependencies are backend hosting confirmation, isolated Sheets/Apps Script staging, public configuration migration/schema approval, and the missing group-booking persistence decision.
