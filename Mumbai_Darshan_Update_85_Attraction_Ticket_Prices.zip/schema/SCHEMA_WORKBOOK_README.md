# Mumbai Darshan Bus Online — 17-tab Schema Workbook

This blank workbook was created for the project from the owner's read-only 17-tab schema audit snapshot recorded in `FINAL_AUDIT_REPORT.md` (10 November 2026).

- 17 worksheets
- 139 exact header cells
- No customer/business records or sample personal data
- First row contains the schema headers; panes are frozen and filters enabled
- The `PackageOptions` schema uses `Price INR` as the expected header. The audit notes `Regular Price INR` as a legacy alternative only if that is what the original approved workbook actually uses; do not rename without owner approval.

## Important status
This file is a **schema template/reference workbook**, not a live Google Sheet and not a populated database. It was reconstructed from the read-only schema audit snapshot because the original `Google app script codegx.xlsx` file was not found in the current working files/library. It may be reconciled against the original workbook during the later Google Sheets setup phase if needed. Its absence does not block the current local source-work phase. Until an explicit schema revision is approved, code must not silently alter the 17 tabs or their headers.

## Automatic Google Sheets setup rule
The owner will not manually create a blank Google Sheet, tabs, or headings. At final setup, the completed standalone Apps Script must create a new staging spreadsheet with `SpreadsheetApp.create()`, create exactly these approved tabs/headers, save the spreadsheet ID in Script Properties, and use `SpreadsheetApp.openById()` on later runs. No production spreadsheet may be written to.


## Update 17 — Apps Script alignment
The Apps Script `Code.gs` now carries the same 17-tab/139-header manifest and uses exact header validation before runtime writes. The standalone `setupDatabase()` creates the spreadsheet automatically once and stores `SPREADSHEET_ID`; subsequent runs reopen the same spreadsheet. This function has only been tested with local mocks in this package, not against Google Apps Script or Google Sheets. Do not run it until final project setup is authorized.
