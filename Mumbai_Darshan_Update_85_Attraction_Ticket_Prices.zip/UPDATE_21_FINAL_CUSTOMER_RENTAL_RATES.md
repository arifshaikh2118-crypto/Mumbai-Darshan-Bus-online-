# Update 21 — Final Customer-Facing Rental Rates Only

Last updated: 11 November 2026

## Owner clarification

Supplier rates are not needed in the application. The owner already has their supplier arrangements and has added the required ₹5 to the applicable rates. The website must use the resulting final customer-facing prices only. It must not retain, calculate, display, or manage a separate supplier rate, supplier cost, or margin.

## Completed

- Renamed local rental `proposedCustomerPrice` to `customerPrice`.
- Renamed outstation `proposedCustomerPerKm` to `customerPerKm` and `proposedCustomerDaPerDay` to `customerDaPerDay`.
- All 16 existing outstation customer KM rates and DA values were retained exactly; no additional ₹5 was applied in this update, so there is no double markup.
- Existing local package customer prices were retained exactly.
- Added a one-time browser-storage compatibility migration: older saved records using the previous property names are converted to the final customer-rate field names without changing numeric values. The legacy property names are removed from the saved records after migration.
- Car rental quote calculations and display now read final customer-facing rate fields only.
- Removed the rental profitability wording from Admin Reports.
- Simplified the Rental Enquiries notice to customer enquiry/status/WhatsApp follow-up only.
- Corrected Apps Script deployment documentation: `UPDATE_RENTAL_STATUS` updates enquiry status only.
- No supplier rate, supplier cost, supplier contact, or margin feature is being built for this rental workflow.
- The approved rental enquiry sheet remains exactly 19 columns; no tab or column changes.

## Verification

- `node google-apps-script/tests/test_customer_rate_model.cjs`: PASS.
- `node google-apps-script/tests/test_rental_enquiry_policy.cjs`: PASS.
- `node google-apps-script/tests/test_schema_alignment.cjs`: PASS.
- `node google-apps-script/tests/test_admin_security.cjs`: PASS.
- All 16 outstation customer-rate entries remain in initial data: PASS.
- Legacy customer-rate property migration preserves numeric values: static verification PASS.
- No new ₹5 markup applied during this update: PASS (existing customer rates are unchanged).
- Full Vite production build and full `tsc --noEmit`: not run; project dependencies are not installed in this working environment.
- No live Google Sheet, Apps Script deployment, GitHub commit, Preview publish, or production deployment performed.

## Files changed

- `src/types/index.ts`
- `src/data/initialData.ts`
- `src/services/storage.ts`
- `src/components/CarRentalPanel.tsx`
- `src/components/admin/AdminRentalsTab.tsx`
- `src/components/admin/AdminReportsTab.tsx`
- `google-apps-script/Code.gs`
- `google-apps-script/DEPLOYMENT_GUIDE.md`
- `google-apps-script/tests/test_customer_rate_model.cjs`
- `UPDATE_20_RENTAL_ENQUIRY_ONLY_WORKFLOW.md`
- `PROJECT_INDEX.md`
