# Update 82 — Public Contact Details & Pickup Catalogue Guardrails

**Date:** 21 November 2026  
**Source baseline:** Update 81  
**Status:** Local source fixes complete; live verification remains deferred.

## 1. Audit findings

### A. Public contact phone was not fully settings-driven
The configured business phone already existed in `Settings` / `INITIAL_SETTINGS`, and most contact components used it. Three public/admin messages still hardcoded the old phone:
- About Us support statement.
- Footer bottom-bar helpline.
- Admin rental enquiry WhatsApp follow-up template.

A future phone change in Admin settings could therefore leave those messages showing the old number.

### B. Pickup counts were hardcoded in customer content
- Pickup landing page showed a fixed total and fixed per-route counts.
- Footer route links repeated fixed counts.
- The pickup catalogue is the authoritative local list and its active status is synchronized from the approved `PickupPoints` Sheet.

### C. Admin PickupPoints CRUD could break public configuration refresh
The approved Sheet has exactly four columns: `Route`, `Pickup Point`, `Sort Order`, `Active`. Public configuration synchronization deliberately requires an exact match against the website's 71-row pickup catalogue. The generic Admin CRUD editor nevertheless allowed adding/deleting rows and editing Sort Order. Those actions could cause the entire public config refresh to fail closed, including otherwise valid package and rental prices.

The Sheet does not contain pickup time, reporting time, landmark or Google Maps URL. Those details remain in the website's local pickup catalogue.

## 2. Implemented fixes

- About Us now reads the phone from `settings.businessPhone`.
- Footer helpline now reads the phone from `settings.businessPhone`.
- Admin rental WhatsApp follow-up template now reads the configured business phone from `StorageService.getSettings()`.
- Removed static per-route pickup counts from Footer links.
- Pickup landing page total and route-wise counts now derive from the active pickup catalogue.
- In Admin → Operational Sheets → Pickup Points:
  - Add Record is disabled.
  - Delete is disabled.
  - Route, Pickup Point and Sort Order are read-only.
  - Only Active / Inactive can be changed.
  - An explicit warning explains the exact-match rule and which pickup details are not in the Sheet.
- Approved PickupPoints schema remains unchanged: `['Route','Pickup Point','Sort Order','Active']`.

## 3. Why pickup edits are restricted

This is a protective guardrail, not a permanent limitation. Until the Sheet schema and website catalogue are updated together, adding/deleting/renaming/reordering a pickup can cause the public configuration endpoint to reject the complete configuration.

Recommended future improvement (not performed): after explicit owner approval, design a coordinated PickupPoints schema revision with a stable pickup ID plus time, reporting time, landmark and Maps URL, then update Apps Script, Admin editor, server validation, public sync and customer UI together. No new columns were added in Update 82.

## 4. Validation

- Offline validation runner: **49/49 PASS**.
- Full Update 43 validation suite: **PASS**.
- New public content/pickup guardrail test: **12 assertions PASS**.
- TypeScript/TSX syntax transpilation: **32 files, 0 syntax errors**.
- Apps Script syntax: PASS.
- Existing English-copy guard: 36 source files PASS.
- Approved schema: **17 tabs / 139 headers unchanged**.
- ZIP integrity: PASS.

Not performed:
- Full semantic `tsc --noEmit`: dependencies are not installed; `vite/client` is unavailable.
- Vite production build: dependencies are not installed.
- Browser E2E / real-device mobile testing.
- Live Google Sheets read/write or Apps Script deployment.

## 5. Owner action / recommendation

No manual action is required now. Continue to keep the current 17-tab / 139-header schema unchanged. At the approved final setup stage, the one-time Apps Script setup should create the spreadsheet automatically.

Before enabling live pickup management beyond Active/Inactive, approve a coordinated PickupPoints schema expansion. Do not manually add columns or rows.

## 6. Deferred items

No Google Sheet was created, no Apps Script deployed, no live service changed, no PhonePe/payment integration, no GitHub/network action, no Preview refresh, no hosting/DNS or production deployment.

**Project remains incomplete and is not production-ready.**
