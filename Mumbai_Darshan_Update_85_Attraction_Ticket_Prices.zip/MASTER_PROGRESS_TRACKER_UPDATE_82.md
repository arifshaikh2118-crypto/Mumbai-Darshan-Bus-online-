# Mumbai Darshan Bus Online — Master Progress Tracker
## Update 82 — Public Contact Details & Pickup Catalogue Guardrails

**Date:** 21 November 2026  
**Source baseline:** Update 81

## Completed in Update 82
- [x] Audited public phone references and found stale hardcoded numbers in About Us, Footer and Admin rental WhatsApp template.
- [x] Replaced those three references with configured `businessPhone`.
- [x] Removed static pickup counts from Footer links.
- [x] Made pickup landing page total and route-wise counts derive from the active local pickup catalogue.
- [x] Identified that Admin PickupPoints Add/Delete/Sort Order changes could break exact-match public configuration synchronization.
- [x] Disabled Add/Delete for PickupPoints and locked Route, Pickup Point and Sort Order during editing; Active/Inactive remains editable.
- [x] Added Admin warning explaining exact-match rule and local-only pickup time/reporting time/landmark/Maps URL.
- [x] Added regression test for dynamic contact details, dynamic pickup counts, pickup CRUD guardrails and unchanged schema.
- [x] Preserved approved schema: **17 tabs / 139 headers**, PickupPoints remains four columns.

## Validation
| Check | Result |
|---|---:|
| Offline validation runner | **49/49 PASS** |
| Full Update 43 validation suite | PASS |
| New regression test | **12 assertions PASS** |
| TypeScript/TSX syntax transpilation | **32 files / 0 errors** |
| Apps Script syntax | PASS |
| English-copy guard | **36 source files PASS** |
| Approved schema | **17 tabs / 139 headers unchanged** |
| ZIP integrity | PASS |
| Full semantic TypeScript check | Pending — missing dependencies / `vite/client` |
| Vite production build | Pending — dependencies not installed |
| Browser/mobile E2E | Pending |
| Live Sheets / Apps Script | Not run; owner-deferred |

## Important PickupPoints limitation
The approved PickupPoints tab contains only `Route`, `Pickup Point`, `Sort Order`, `Active`. The customer pickup timetable's time, reporting time, landmark and Google Maps URL remain in the website catalogue. Public sync requires exact match to the existing 71-point catalogue. Therefore only Active/Inactive may be edited through this Admin Sheet editor until a coordinated schema/catalogue update is approved.

## Recommended next step
If the owner wants pickup timings, landmarks and Maps links to be managed from Google Sheets, approve a coordinated PickupPoints schema revision. Do not manually add columns/rows now.

## Remaining work
- [ ] Audit FAQ pickup timing examples and other operational promises against current owner-approved tour operations.
- [ ] Owner review of the source-derived rental rate card before live publication.
- [ ] Dependency installation and full semantic TypeScript / Vite build.
- [ ] Browser E2E and real mobile checks.
- [ ] Approved automatic Google Sheets setup and Apps Script deployment; no manual workbook creation.
- [ ] Live staging verification after explicit approval.
- [ ] PhonePe, GitHub, Preview refresh, hosting/DNS and production deployment remain deferred.

## Owner constraints preserved
- No manual Google Sheet creation; provide one automatic setup script at the approved stage.
- No unapproved schema changes.
- Keep Supabase until migration is fully tested and explicitly approved.
- Rental enquiries remain inquiry-only; no rental payment or email notifications.
- No live deployment or mutation without explicit approval.
- Deliver a fresh ZIP, Project Index, detailed report, changed-file list and tracker after each update.

**Overall status: INCOMPLETE / NOT production-ready. Do not deploy.**
