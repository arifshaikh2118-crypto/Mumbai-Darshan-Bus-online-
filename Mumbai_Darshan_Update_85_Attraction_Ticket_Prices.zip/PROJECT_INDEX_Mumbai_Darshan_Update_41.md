# Mumbai Darshan Bus Online — Master Progress Tracker

**Current package:** Update 41 — Network Build Workflow Hardening  
**Baseline:** Update 40 — Runtime Webhook Validation & Dependency Network Diagnosis  
**Date:** 20 November 2026

## Completed source work

- [x] Approved 17-tab / 139-header schema manifest and bootstrap source retained.
- [x] Booking server-side pricing/advance calculation and duplicate partial-write reconciliation gate retained.
- [x] Rental enquiry remains inquiry-only; no owner/customer rental email.
- [x] Admin session, secret-gated Apps Script actions and active AdminUsers roster retained.
- [x] Public lookup/cancellation privacy and throttling retained.
- [x] EmailLog, notifications, cancellation/refund review and Daily Reports source retained.
- [x] Update 36 protected Admin dispatch, public mutation lockdown, proxy allowlist and server-configured webhook URL fixes retained.
- [x] Update 37 Firebase guide corrected to explain Express API hosting requirement.
- [x] Update 38 added dependency-free offline validation runner.
- [x] Update 39 public Express proxy requires explicit allowed action; Apps Script rejects missing/blank action.
- [x] Update 40 runtime tests reject missing, blank and non-string actions; lock release and explicit PING_TEST verified.
- [x] Update 41 hardened manual GitHub Actions workflow: offline tests, npm install, lockfile verification, npm ci, lint, build and artifact uploads.
- [x] Update 41 added workflow static safety test and updated README.
- [x] `npm run test:offline` PASS, 11/11.
- [x] Workflow YAML parse PASS; key project JSON manifests PASS.

## Latest verification status

| Check | Result |
|---|---|
| Apps Script CJS regression suites | PASS, 9/9 |
| Apps Script `Code.gs` syntax | PASS |
| Runtime webhook explicit-action checks | PASS |
| CI workflow static safety test | PASS |
| Offline validation runner | PASS, 11/11 |
| Workflow YAML parse | PASS |
| Key JSON manifests | PASS, 4/4 |
| npm registry access | BLOCKED — DNS `EAI_AGAIN` |
| npm cache | No usable package cache entries |
| `package-lock.json` | MISSING |
| `bun.lock` | EMPTY, unusable |
| `node_modules` | ABSENT |
| `npm run lint` | BLOCKED — missing `vite/client` types |
| `npm run build` | BLOCKED — `vite: Permission denied` in local runtime; dependencies absent |
| GitHub Actions workflow | Updated but NOT committed or executed |
| Browser E2E | PENDING |
| Hosting architecture / API runtime | PENDING owner/developer confirmation |
| Google Sheets staging | PENDING owner approval |

## Remaining work before any external deployment

### P0 — Network-enabled build
- [ ] Owner/developer commits/pushes project source to intended GitHub repository.
- [ ] Manually run **Mumbai Darshan Network Build Validation** workflow.
- [ ] Verify npm install generates a valid package-lock.
- [ ] Verify clean `npm ci` passes.
- [ ] Verify `npm run lint` passes.
- [ ] Verify `npm run build` passes.
- [ ] Review uploaded lockfile and dist artifacts; record workflow URL and commit SHA.

### P0 — Hosting architecture and browser E2E
- [ ] Confirm hosting target for Express server.
- [ ] If Firebase Hosting + Cloud Run is approved, confirm actual service ID and region, then configure `/api/**` rewrite before SPA fallback.
- [ ] Verify `/api/*` reaches Express and Admin routes reject unauthenticated calls.
- [ ] Run browser E2E for booking submit/retry, rental inquiry, lookup, cancellation, Admin login/session expiry, status updates, email retry, refunds, reports and seven operational CRUD tabs.
- [ ] Test mobile booking flow and rental enquiry panel immediately below booking form.

### P1 — Google Sheets / Apps Script staging (owner approval only)
- [ ] Run `setupDatabase()` once against isolated staging.
- [ ] Confirm exact 17 tabs / 139 headers and approved seed data.
- [ ] Configure private server environment and Apps Script Script Property secrets.
- [ ] Test booking/payment-pending ledger writes, duplicate retries, rental inquiry-only writes, lookup/cancellation, Admin reads/mutations, EmailLog, notifications and daily reports.
- [ ] Test concurrency and throttling.
- [ ] Owner-approved controlled email test; only then decide on trigger installation.

### P2 — Later separately approved delivery
- [ ] GitHub source commit and Preview refresh after build/tests and approval.
- [ ] PhonePe integration after merchant credentials and server-side signature/status verification.
- [ ] Production Apps Script deployment, email activation, DNS/domain changes and website deployment only with explicit approval.

## Preserved business and safety rules

- No changes to approved sheet tabs/columns without permission.
- No supplier cost/rate/margin/private garage information in customer-facing code.
- No extra ₹5 rental-rate markup; approved customer rates remain unchanged.
- ₹200 advance is per booking, not per person.
- No automatic refund; PhonePe remains deferred.
- No rental enquiry emails; follow up via WhatsApp.
- No live Sheet, Apps Script, GitHub, Preview or production action without explicit approval.

**Overall: INCOMPLETE. Update 41 improves the manual network-enabled build workflow and passes 11/11 offline checks. Actual GitHub workflow execution, dependency install, full lint/build, browser E2E, hosting runtime and isolated live staging remain release blockers.**
