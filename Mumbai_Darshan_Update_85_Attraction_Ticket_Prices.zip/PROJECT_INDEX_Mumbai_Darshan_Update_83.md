# Mumbai Darshan Bus Online — Project Index
## Latest update: Update 83 (21 November 2026)

### Update 83 — Uniform Bus Fare, Pickup-Time and Booking-Copy Corrections
- Bhayandar East pickup confirmed at **6:15 AM**; booking no longer invents a generic 6:30 AM fallback.
- All four routes use the same standard rates: Non-AC ₹250, AC ₹350 per person.
- Existing lunch package differential retained: Non-AC + breakfast/lunch ₹450, AC + breakfast/lunch ₹550 per person.
- All route offers start OFF with zero discount; manual offer controls remain available.
- Apps Script bootstrap seeds the new rates, migrates only exact legacy Western/Central defaults, preserves custom Admin prices, and switches offers OFF once while retaining discount values for later manual activation.
- Local browser cache also migrates exact legacy defaults while preserving custom prices.
- Pricing-page offer status, FAQ payment-verification wording and no-seat-number Terms wording corrected.
- Approved schema remains 17 tabs / 139 headers.
- Offline validation 49/49 PASS; TypeScript/TSX syntax 32 files / 0 errors; Apps Script syntax PASS; English-copy guard 36 files PASS.
- Semantic TypeScript check and Vite build remain blocked by missing dependencies; browser/mobile and live Sheets checks remain pending.
- No live deployment or external mutation.

**Overall: LOCAL CORRECTIONS COMPLETE; INCOMPLETE / NOT production-ready. Do not deploy.**

See `UPDATE_83_PRICE_PICKUP_AND_BOOKING_COPY_CORRECTIONS.md`, `MASTER_PROGRESS_TRACKER_UPDATE_83.md`, `UPDATE_83_CHANGED_FILES.txt`, and validation result files.

---

## Previous update — Update 82
Public contact details and pickup catalogue guardrails. See `UPDATE_82_PUBLIC_CONTACT_AND_PICKUP_GUARDRAILS.md`.

## Previous update — Update 81
Centralized Local Darshan and Outstation rental pricing in protected Settings JSON without changing approved schema. See `UPDATE_81_RENTAL_PRICING_CENTRALIZED.md`.

## Previous update — Update 80
Public package prices, offers and pickup activation status synchronized through server-owned public configuration. See `UPDATE_80_PUBLIC_CONFIGURATION_SYNC.md`.
