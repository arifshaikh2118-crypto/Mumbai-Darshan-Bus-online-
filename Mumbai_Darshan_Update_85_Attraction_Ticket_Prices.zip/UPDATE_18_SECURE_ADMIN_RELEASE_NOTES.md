# Update 18 — Secure Admin Authentication & Protected Data Retrieval

## Security changes
- No hardcoded or fallback admin passcodes.
- Server-only passcode and three independent secret configuration values.
- Email must be authorized in the active `AdminUsers` sheet roster.
- HMAC-signed 30-minute sessions, signature checks and rate-limited login attempts.
- Protected `/api/admin/data` endpoint; no direct browser exposure of Apps Script service secret.
- Apps Script checks its private shared secret and active AdminUsers role before reading private sheets.
- Reads are logged in `activity_log`.

## Test results
- Apps Script schema/data harness: PASS.
- Admin security regression assertions: PASS.
- Apps Script syntax check: PASS.
- ZIP integrity check: pending packaging.
- Full frontend build: not run successfully because dependency installation timed out and `vite/client` types are unavailable.

## Not done
No hosting secrets configured, no AdminUsers live rows created, no real spreadsheet access, no Apps Script deployment, no GitHub commit, no preview update, and no production deployment. Admin UI data binding and authenticated status updates remain pending.

See `google-apps-script/SECURE_ADMIN_SETUP.md` for owner-controlled final setup.
