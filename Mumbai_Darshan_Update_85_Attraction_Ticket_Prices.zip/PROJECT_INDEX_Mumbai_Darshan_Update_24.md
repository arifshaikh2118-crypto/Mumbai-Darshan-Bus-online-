# Mumbai Darshan Bus Online — Master Progress Tracker (Update 24)

Date: 11 November 2026

**Current source milestone:** Update 24 — Admin Operational Sheets UI CRUD.

## Completed in Update 24
- Admin UI Add/Edit/Delete controls for seven approved operational tabs: `PickupPoints`, `PackageOptions`, `BookingDates`, `rental_vehicles`, `website_content`, `AttractionPoints`, `AttractionTickets`.
- Connected UI to authenticated server endpoints `/api/admin/operational/upsert` and `/api/admin/operational/delete`.
- Exact approved columns retained; required stable keys validated and locked during edits.
- Boolean, numeric and date inputs; delete confirmation; automatic protected-data refresh after successful mutation.
- No extra sheets/columns, no supplier rate/cost/margin/profit fields.

## Verification
- `test_schema_alignment.cjs` — PASS
- `test_admin_security.cjs` — PASS
- `test_rental_enquiry_policy.cjs` — PASS
- `test_customer_rate_model.cjs` — PASS
- `test_admin_operational_write_policy.cjs` — PASS
- `test_admin_operational_ui.cjs` — PASS
- TypeScript `transpileModule`: 26 TS/TSX files, 0 syntax diagnostics
- ZIP integrity — PASS
- Full `tsc --noEmit` / Vite production build — NOT VERIFIED; dependency installation timed out and `vite/client` types are unavailable.

## Pending / not done
1. Complete npm dependency installation in a network-enabled runner.
2. Run full lint/type-check and Vite production build.
3. Run real browser E2E create/edit/delete/refresh tests against staging Apps Script + Google Sheets for all seven tabs.
4. Verify activity_log entries and role permissions in staging.
5. Owner-approved final spreadsheet bootstrap and Apps Script deployment/secrets configuration.
6. GitHub commit, existing Preview refresh, and production deployment remain not performed.

## Safety / project constraints retained
- No live Google Sheet created or modified; Apps Script `setupDatabase()` not executed.
- No secrets exposed in browser code.
- No production deployment.
- Approved 17-tab / 139-column schema unchanged.
- Supplier rate/cost/margin/profit system not introduced; customer-facing final rates remain unchanged.
- Rental Enquiry remains enquiry-only with its approved 19 columns and WhatsApp follow-up; no email notification workflow added.

## Next action
Run dependency installation, lint and production build in the cloud runner, then perform staging browser E2E tests before any live setup.

---

# Update 25 — Build and Browser Validation Checkpoint

Last updated: 11 November 2026

## Completed in this checkpoint
- Re-ran all six Apps Script automated test suites: all PASS.
- Re-ran Apps Script syntax validation: PASS.
- Re-ran TypeScript/TSX syntax transpilation: 26 files, zero syntax diagnostics.
- Re-checked source ZIP integrity: PASS.
- Documented the exact build and browser-test blockers in `UPDATE_25_BUILD_AND_BROWSER_VALIDATION.md`.

## Blockers / pending
- Online npm dependency installation timed out; offline install cannot proceed because the npm cache lacks required packages, including `@google/genai`.
- `tsc --noEmit` cannot complete because installed project type packages such as `vite/client` are unavailable.
- Vite production build and browser UI tests remain unverified until dependencies are installed in a network-enabled runner.
- No staging Apps Script deployment or Google Sheet is available here, so actual seven-tab CRUD persistence and Activity Log verification remain pending.

## Explicitly not performed
- No Google Sheet creation or modification; no Apps Script deployment/execution; no secrets configured; no GitHub commit; no Preview update; no production deployment.

## Next steps
1. Install dependencies in a network-enabled build runner.
2. Run `npm run lint` and `npm run build`; fix and retest any errors.
3. Perform browser-based Add/Edit/Delete and refresh-persistence testing for all seven operational tabs.
4. Verify Activity Log and delete-key behavior against an approved staging spreadsheet.
5. After staging acceptance, update the existing Preview URL using the approved workflow; production deployment still requires explicit approval.

See `UPDATE_25_BUILD_AND_BROWSER_VALIDATION.md` for commands, exact results and limitations.
