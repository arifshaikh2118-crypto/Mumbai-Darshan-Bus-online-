# Update 14 — Admin Data Retrieval Security & Hosting Audit

Date: 11 November 2026

## Outcome
Read-only audit completed. No application source code, Google Sheets schema, Apps Script deployment, or live data was changed. Admin live-data retrieval is not implemented because the current hosting/authentication arrangement cannot safely expose customer booking and rental enquiry records yet.

## Confirmed findings
1. `src/components/admin/AdminLayout.tsx` loads bookings and rental enquiries from `StorageService.getBookings()` / `StorageService.getCarRentals()`. These methods read browser-local storage/sample records, not Google Sheets.
2. `google-apps-script/Code.gs` exposes `doGet` for health and customer booking lookup only. It has no Admin-only list/read action for Bookings or Rental Enquiry.
3. `server.ts` contains Express admin login and an in-memory token set, but it has unsafe built-in passcode fallbacks (`mumbai2026` and `admin123`). The token set has no enforced expiry despite returning an `expiresAt` value.
4. `AdminLayout.tsx` has a local fallback that accepts `mumbai2026` if server login cannot be reached. This is not a safe basis for exposing customer names, mobile numbers, email addresses, travel dates, or rental quotations.
5. `firebase.json` configures static Firebase Hosting only. It has no `/api/**` rewrite to a deployed Express backend or Firebase Function. Static Hosting will not execute Express routes in `server.ts` by itself.
6. The authoritative workbook `Google app script codegx.xlsx` was not available in current working files/library search. Project notes identify a 19-column Rental Enquiry reference, while this ZIP's `Code.gs` currently defines an 18-column Rental Enquiry header. This mismatch must not be silently altered.

## Why no code was changed
Adding a public Apps Script list action or calling it directly from browser JavaScript would expose private customer data. Adding a frontend fetch without a reachable authenticated server endpoint would not work on current Firebase static-hosting configuration. Guessing or changing the Rental Enquiry schema would violate workbook-preservation rules.

## Required prerequisites
1. Confirm the intended secure server runtime for `/api/admin/*` (for example, an already-authorized Express hosting target). Do not create or deploy a new production service without owner approval.
2. Confirm admin credentials are supplied only through server environment configuration; remove hardcoded passcode fallbacks and enforce token expiry before enabling private-data APIs.
3. Configure a server-only shared secret between Express and Apps Script using environment variables / Script Properties. Never put this secret in browser code, the workbook, or public ZIP configuration.
4. Make the authoritative `Google app script codegx.xlsx` workbook available so Rental Enquiry header mapping can be checked exactly. Do not add, rename, or delete any tab/column.
5. Then implement: authenticated server proxy → secret-verified Apps Script read action → dynamic header-based row mapping → Admin UI refresh. Return only fields the Admin UI needs.

## Verification performed
Inspected `firebase.json`, `package.json`, `server.ts`, `src/components/admin/AdminLayout.tsx`, `src/components/admin/AdminRentalsTab.tsx`, `src/services/storage.ts`, and `google-apps-script/Code.gs`. Confirmed local-storage data source, absence of Apps Script Admin list action, static Firebase Hosting configuration, hardcoded admin passcode fallbacks, and Rental Enquiry header mismatch (18 current Code.gs vs 19 noted in workbook reference).

No build, live Apps Script request, Google Sheets read/write, email, payment, GitHub update, Preview update, or production deployment was performed.

## Status
- Admin data retrieval: BLOCKED pending secure server runtime/auth configuration and exact workbook reference.
- Source code changes: none.
- Workbook/schema changes: none.
- GitHub upload/commit: not performed.
- Preview: remains on hold under agreed >50% milestone rule.
- Production deployment: not performed.

## Repeatable method used
1. Open latest source ZIP without modifying it.
2. Inspect Admin UI data-source calls and StorageService implementations.
3. Inspect Apps Script `doGet` / `doPost` actions and current sheet headers.
4. Inspect Express authentication and API proxy routes.
5. Inspect Firebase Hosting rewrites to determine whether `/api` routes can run.
6. Compare workbook column-count notes against current Apps Script headers.
7. Do not add a read endpoint until data access is authenticated end-to-end.
