# Mumbai Darshan Bus Online — Update 44
## Public Configuration Readiness & Schema Gap Audit
**Date:** 20 November 2026  
**Baseline:** Update 43 — Frontend API Contract & Operational Schema Audit  
**Status:** Local audit and regression guard completed. Public Sheets sync remains incomplete; not production-ready.

### What was checked
- Reviewed the customer booking form and its configuration reads.
- Reviewed `StorageService` getters and the seven operational-sheet UI configurations.
- Compared customer-facing configuration needs with the approved 17-tab / 139-header schema snapshot.
- Added `validation/test_public_config_readiness.cjs` to keep the discovered blockers visible in offline regression checks.

### Confirmed findings
1. `BookingForm.tsx` still reads routes, packages, offers and pickup points from `StorageService`; the getters read browser `localStorage` with `INITIAL_*` defaults.
2. `PickupPoints` contains only `Route`, `Pickup Point`, `Sort Order`, `Active`. The customer pickup model also uses time, landmark, reporting time and Google Maps URL. Those values cannot be reconstructed from this sheet without additional approved data.
3. `PackageOptions` contains `Package Key`, `Route Group`, `Label`, `Price INR`, `Offer Enabled`, `Offer Discount INR`, `Price Review Status`. It does not explicitly encode the booking model's `isAC`, `hasLunch`, or description fields. Package-key conventions must be confirmed before mapping.
4. The operational sheet manager does not currently expose the existing routes and extra-charge configuration as complete public data sources.
5. `schema/SCHEMA_SPEC.json` identifies itself as a reconstructed audit snapshot from the 10 November report, not a live workbook extraction. It must not be treated as confirmation of the current live sheet contents.
6. A Library search for the exact original workbook title `Google app script codegx.xlsx` did not locate that workbook; the returned title matches were unrelated image files.

### Safety decision — no unsafe implementation
No public endpoint or frontend hydration was added in this update. Doing so now would require inventing pickup timings/landmarks, guessing package-key semantics, or reading broader Admin data. Reusing `ADMIN_GET_DATA` is explicitly prohibited because it includes private operational/customer/payment datasets.

No schema columns/tabs were changed. No UI/content/pricing/business rules were changed. No live Google Sheet, Apps Script deployment, Firebase/Cloud Run hosting, GitHub, Preview, or production system was touched.

### Validation
- Offline regression runner: **15/15 PASS** (includes the new public-config readiness guard).
- TypeScript/TSX syntax transpilation: **29/29 PASS**, zero syntax errors (syntax-only; not a semantic type-check).
- Key JSON manifests: **4/4 PASS**.
- The new guard verifies the known schema gaps and confirms the booking form still uses localStorage/default-backed configuration.
- Existing Update 43 validation scope remains: Apps Script syntax, 29 TS/TSX syntax transpilation, 4 JSON manifests. These are not a substitute for semantic TypeScript checking, lint, production build or browser E2E.

### Remaining work before safe public sync
1. Obtain/reconcile the original current workbook headers and representative rows for `PickupPoints` and `PackageOptions`.
2. Confirm how package keys map to AC/non-AC and lunch/no-lunch, and confirm approved customer-visible pricing and offers.
3. Decide the approved source for pickup time, landmark, reporting time and map URL; do not silently add columns.
4. Confirm public data fields for route descriptions and extra charges.
5. Then implement a dedicated read-only public endpoint with an explicit field allowlist, private-tab exclusion tests, response validation, bounded caching and safe fallback.
6. Hydrate public components only after the mapping tests pass.
7. Test against isolated staging with owner approval before production cutover.

### Project status
**Not production-ready.** npm dependency installation remains blocked by the previously observed registry DNS failure; full lint/build, browser E2E, hosting target confirmation and staging tests remain pending. GitHub work remains deferred until all local project files and source work are complete, as instructed.
