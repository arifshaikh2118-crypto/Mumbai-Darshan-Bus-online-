# Mumbai Darshan Bus Online

Website and backend source for Mumbai Darshan Bus Online. The current project uses a React/Vite frontend, an Express server-side proxy, Google Apps Script, and an approved Google Sheets schema.

## Current status

**Development only — not production-ready.** Do not deploy, create the live spreadsheet, install Apps Script triggers, enable live email, activate PhonePe, or update the public Preview until the remaining release gates in `PROJECT_INDEX.md` are complete and the owner approves each external action.

## Run locally

Requirements: Node.js 22+ and npm.

```bash
npm install --legacy-peer-deps
npm run lint
npm run build
npm run dev
```

The full build/type-check has not yet been verified in this environment because npm registry DNS resolution failed (`EAI_AGAIN`). See the latest `PROJECT_INDEX.md` / update report for actual verification status.

## Offline source validation

Run the dependency-free Apps Script regression and syntax checks with:

```bash
npm run test:offline
```

This runs the bundled Apps Script CJS regression suites, runtime webhook action tests, Admin login-throttle/upstream-timeout policy checks, frontend-to-Express/Admin-to-Apps-Script API contract checks, operational-sheet UI/schema alignment checks, approved business-rule checks (pricing, advance, guide/toll and rental billing), public-configuration readiness checks, and network-runner workflow safety checks, and `google-apps-script/Code.gs` syntax using Node.js. It does **not** replace `npm run lint`, `npm run build`, browser E2E, or live Google Sheets/Apps Script staging.

The repository currently has no `package-lock.json`; the bundled `bun.lock` is empty. A reproducible dependency lockfile remains an open release task and must be generated and reviewed on a network-enabled runner. Do not treat an interrupted lockfile-generation attempt as success.

## Google Sheets schema

The authoritative in-repository manifest is `schema/SCHEMA_SPEC.json`, with a reconstructed blank workbook at `schema/Mumbai_Darshan_Schema_Workbook_17_Tabs.xlsx`. It contains exactly 17 approved tabs and 139 headers. The original `Google app script codegx.xlsx` binary was not available during reconstruction; see `schema/SCHEMA_WORKBOOK_README.md`. Do not add, remove, rename or reorder tabs/columns without explicit approval.

The owner does not manually create the spreadsheet or headings. Google Sheets setup and Apps Script deployment are deferred to a later phase. At that time, one complete Apps Script setup code will run `setupDatabase()` to create the spreadsheet and approved tabs automatically, validate the schema, and save the spreadsheet ID. This is not a blocker for current local source work.

## Security and workflow

- Public Sheets proxy is limited to booking, rental-enquiry and ping actions. Booking and rental clients send only the action payload; Express reads `GOOGLE_APPS_SCRIPT_URL` exclusively from the private server environment. No Apps Script URL is stored in browser settings.
- Admin mutations use signed server sessions plus the Apps Script secret and active `AdminUsers` roster.
- Public lookup/cancellation require Booking ID and registered mobile.
- Rental enquiries are inquiry-only; no rental enquiry emails or supplier pricing/cost data.
- Booking fare and advance are calculated server-side from approved `PackageOptions` data.
- Customer/owner confirmation email is deferred until trusted payment verification. `ENABLE_LIVE_EMAILS` remains false.
- `public/robots.txt` and `public/sitemap.xml` are included in the Vite public assets; the sitemap currently lists only the canonical homepage because internal SPA page states are not separate crawlable URLs.
- Customer-facing route/package/pickup/rental/tour/gallery configuration is not yet fully hydrated from Google Sheets. Group booking currently saves only to browser storage; see the latest deep audit before any public release.
- PhonePe is not integrated or activated; never fabricate a payment verification callback.

See `GOOGLE_APPS_SCRIPT_SETUP.md` and `google-apps-script/DEPLOYMENT_GUIDE.md` for the current setup and staging gates.


## Delivery sequencing

GitHub commits, pushes, Actions workflow execution, Preview refresh and production deployment are intentionally deferred until the complete project source files and remaining local work are finished. Do not start those external steps early.
