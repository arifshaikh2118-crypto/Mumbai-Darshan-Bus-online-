# Update 42 — Admin Login Throttle & Upstream Request Resilience

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 41 — Network Build Workflow Hardening  
**Release status:** INCOMPLETE — local source hardening and offline checks pass; dependency install, full type-check/build, browser E2E and staging remain pending.

## 1. Owner instruction applied

The owner clarified that GitHub work must wait until the complete project files and remaining local work are finished. Accordingly, Update 42 did **not** commit/push code, run GitHub Actions, refresh Preview, or deploy anything. GitHub-related work is explicitly deferred.

## 2. Work completed in Update 42

| # | Work item | Result |
|---|---|---|
| 1 | Audited Express Admin login lockout-window logic | Found stale attempt count could cause immediate re-lock after cooldown expiry |
| 2 | Reset expired login attempt window before counting the next failed attempt | Fixed |
| 3 | Preserved active lockout enforcement | Confirmed by regression policy test |
| 4 | Added a 30-second timeout to server-to-Apps-Script fetch calls | Added to all 3 upstream fetch paths |
| 5 | Added regression test for login throttle window and timeout configuration | PASS |
| 6 | Updated offline test runner to Update 42 | Completed |
| 7 | Updated README status and owner sequencing instruction | Completed |
| 8 | Ran dependency-free offline regression suite | PASS, 12/12 |
| 9 | Ran TypeScript/TSX syntax transpilation on all source files using installed global TypeScript | PASS, 29 files / 0 syntax errors |
| 10 | Updated Master Progress Tracker and packaged Update 42 ZIP | Completed; ZIP integrity verified |

## 3. Technical detail

### Admin login lockout window

The old sequence incremented a stale attempt counter before checking whether its 15-minute window had expired. A stale count of five could therefore trigger another lockout immediately after cooldown ended.

The route now:
1. Enforces an active `blockedUntil` lockout.
2. Resets count, reset timestamp and expired block state if the attempt window has elapsed.
3. Only then validates credentials and increments the failure count.

The regression policy test verifies:
- The fifth failure in an active window triggers a 15-minute lockout.
- Active lockout is still enforced.
- After the cooldown expires, the next failed attempt is counted as one and does not immediately re-lock the IP.

### Apps Script upstream timeout

All three server-to-server Apps Script fetch paths now use `AbortSignal.timeout(UPSTREAM_TIMEOUT_MS)` with a 30-second bound:
- Protected Admin requests.
- Public booking lookup/cancellation requests.
- Public booking/rental Sheets sync proxy.

This prevents upstream calls from waiting indefinitely. Timeout handling still returns through the existing error paths.

## 4. Verification evidence

| Check | Result |
|---|---|
| `npm run test:offline` | PASS, 12/12 |
| Apps Script CJS regression suites | PASS, 9/9 |
| Apps Script `Code.gs` syntax | PASS |
| Runtime webhook explicit-action checks | PASS |
| Admin login throttle policy regression | PASS |
| Three Apps Script fetch timeout guards | PASS |
| Network workflow static safety test | PASS |
| TypeScript/TSX syntax transpilation | PASS, 29 files, 0 syntax errors |
| Key JSON manifests | PASS, 4/4 |
| GitHub workflow execution | NOT RUN — deliberately deferred per owner instruction |

TypeScript syntax transpilation is a syntax-only check. It is not a semantic type-check and does not replace `npm run lint`.

## 5. Still not completed — exact reasons

| Work item | Status | Reason |
|---|---|---|
| Generate valid `package-lock.json` | Pending | npm registry DNS lookup previously failed with `EAI_AGAIN` for `registry.npmjs.org`; no lockfile is fabricated |
| Install dependencies / `npm ci` | Pending | No usable npm registry connection or cached packages in this runtime |
| Full TypeScript semantic check | Pending | `vite/client` type definitions are absent until dependencies are installed |
| Vite production build | Pending | Vite dependency is not installed in this runtime |
| Browser E2E | Pending | Requires installed app dependencies and a defined browser/staging test target |
| Express hosting/API route verification | Pending | Actual hosting target and Cloud Run service ID/region have not been confirmed |
| Google Sheets / Apps Script live staging | Pending | Requires isolated staging and explicit owner approval |
| GitHub commit/push/Actions | Deferred by owner | Must wait until all project files and remaining local work are complete |
| Preview refresh / production deployment | Pending | Requires owner approval after source/build/browser/staging gates |
| PhonePe | Deferred | Merchant credentials and server-side payment verification are not ready |

## 6. Next remaining local work

- [ ] Continue local source audit and close remaining code/documentation gaps without changing approved UI or business rules unnecessarily.
- [ ] Review all API payload mappings against Apps Script handlers and the exact 17-tab / 139-header schema.
- [ ] Expand dependency-free regression coverage where a real source-level defect is found.
- [ ] Keep the 30-second upstream timeout and lockout behavior covered by tests.
- [ ] Once local project files are complete, move to the separately approved GitHub/network-enabled build phase.
- [ ] After build success, complete browser E2E and isolated staging before any live deployment.

## 7. Safety confirmations

No GitHub commit/push or Actions workflow run occurred. No Preview refresh, production deployment, DNS change, Google Sheet mutation, Apps Script deployment, email send or PhonePe activation occurred. No approved pricing, booking advance, rental inquiry policy or sheet schema was changed.

**Conclusion:** Update 42 fixes an Admin login lockout-window edge case and bounds all three server-to-Apps-Script request paths to 30 seconds. The offline suite passes 12/12 and all 29 TypeScript/TSX files pass syntax transpilation. The project remains INCOMPLETE and is not production-ready.
