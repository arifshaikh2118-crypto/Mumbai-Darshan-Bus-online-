# Update 68 — Admin Booking & Payment Ledger Reconciliation

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 67 — Admin Cancellation & Refund Workflow Guardrails  
**Focus:** Read-only reconciliation of `Bookings` against `booking_payments` and trustworthy Admin dashboard collection totals.

## Audit finding

The Admin booking mapper previously inferred ₹200 / the full booking fare from the booking's `Payment Status` label when the linked payment ledger did not contain a positive verified amount. That could make the Admin dashboard display money as collected without corresponding verified ledger evidence. A booking status and a payment ledger are separate records; the label alone is not proof of receipt.

The Admin dashboard also displayed aggregate collected/outstanding figures but did not provide a structured comparison of booking rows against payment ledger rows.

## Changes made

1. **Ledger-only collected amount**
   - Admin `amountPaid` is now calculated only by summing positive verified payment-ledger rows linked to that Booking ID.
   - A booking status label such as `Advance Paid` or `Fully Paid` no longer acts as a fallback amount source.
   - Any disagreement is surfaced as a reconciliation finding instead of being hidden by an inferred amount.

2. **Read-only reconciliation service**
   - Added `buildBookingPaymentReconciliation_()` and included its result in the authenticated `ADMIN_GET_DATA` response.
   - Checks include missing ledger rows, orphan ledger rows, duplicate Booking IDs, multiple ledger rows for a booking, paid booking without verified ledger evidence, verified ledger with unpaid booking status, incomplete verified evidence, invalid amounts/statuses, duplicate payment IDs/transaction references, amount-mode mismatch, and verified amount above booking fare.
   - Output contains Booking IDs and issue details only; it does not add customer names, phone numbers or email addresses to findings.
   - Findings are capped at 250 in the API payload, with a truncation flag.
   - The helper performs no writes to either sheet and does not auto-correct any records.

3. **Admin dashboard panel**
   - Added `AdminPaymentReconciliationPanel` with counts, verified-ledger total, and individual findings.
   - Added a refresh action to reload the protected Admin data snapshot.
   - The panel clearly labels findings as manual-review flags, not automatic accounting adjustments.

4. **Regression tests**
   - Expanded Apps Script runtime tests for missing ledger, orphan ledger, paid-without-verified mismatch, duplicate ledger rows, duplicate payment IDs/references and over-booking verified amount.
   - Added `validation/test_admin_payment_reconciliation.cjs` with 18 source-contract assertions.

## Verification

- Offline validation runner: **35/35 PASS**.
- Admin payment reconciliation source-contract checks: **18 PASS**.
- Apps Script reconciliation runtime fixtures: **PASS** (included in schema alignment runtime test).
- TypeScript/TSX syntax transpilation: **36/36 PASS**, zero syntax diagnostics (syntax-only; not a semantic type-check).
- Apps Script `Code.gs` syntax: **PASS** (included in offline runner).
- JSON manifests/configuration: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full `npm run lint`, semantic type-check and `npm run build`: **not run**; project dependencies are not installed.
- Browser E2E and live Google Sheets / Apps Script tests: **not run**.

## Scope boundaries

- No sheet/tab/header/schema changes.
- No ledger row, booking row, amount, payment status or refund status was changed by this audit; reconciliation is read-only.
- No payment gateway integration or automatic refund capability was enabled.
- No pricing, rental enquiry or other business rules changed.
- No Google Sheet creation, Apps Script execution/deployment, GitHub commit/push, Preview refresh, live email, external mutation or production deployment.

**Overall status: INCOMPLETE / NOT production-ready.** The local Admin dashboard now has a read-only reconciliation view and no longer infers collected amounts from status labels. The actual live workbook still needs an owner-reviewed reconciliation run and manual resolution of any findings. Full build, browser E2E and deployment verification remain outstanding.
