# Update 61 — Booking server validation and optional email correction

**Date:** 20 November 2026  
**Baseline:** Update 60 — Attractions Selected on Bus Only  
**Scope:** Local customer booking source, Apps Script booking handler, regression tests and project tracker only.

## Deep-audit findings fixed

1. **Invented customer email value:** The booking form previously replaced an empty optional email with `<mobile>@mumbaidarshanbusonline.com`. The customer email field is optional, so this created a false address in the local booking object and Sheets payload. The form now sends an empty string when the customer does not provide an email. No fake email address is created.
2. **Passenger-count mismatch:** The customer form accepts 1–50 passengers, while Apps Script accepted up to 60. The server now enforces the same 1–50 limit.
3. **Insufficient server-side booking validation:** The Apps Script booking handler now validates customer name length (3–100), exactly 10 normalized mobile digits, optional email format/maximum length, strict real `YYYY-MM-DD` travel date, and rejects past dates using the Asia/Kolkata date. These checks run before booking/payment-ledger writes.

## Regression coverage added

- Optional email is accepted as blank and stored blank.
- Supplied customer email remains stored as supplied.
- 51 passengers are rejected server-side.
- Invalid mobile and malformed optional email are rejected.
- Past and impossible travel dates are rejected.
- Existing server-authoritative package pricing, advance calculation, attraction-on-bus-only rule, approved sheet schema, duplicate handling and payment-ledger safeguards remain covered.

## Verification

- Offline validation runner: **28/28 PASS**.
- TypeScript/TSX syntax transpilation: **31/31 PASS**, zero syntax diagnostics (syntax-only; not a semantic type-check).
- Apps Script syntax/runtime validation: **PASS** through the offline Apps Script test harness.
- JavaScript test-file syntax checks: **PASS**.
- JSON manifests/configuration: **6/6 PASS**.
- ZIP integrity: **PASS** (all archive entries tested).
- Full npm lint/build: not run; `node_modules` is not installed in this local project copy.
- Browser E2E: pending.
- Live Google Sheets/Apps Script integration: not tested; creation/setup/deployment remain deferred by owner instruction.

## Deep audit — work still outstanding

### Local / pre-release gates
- Full dependency installation, `npm run lint`, and production `npm run build` on a network-enabled/approved build runner.
- Browser E2E on desktop and mobile for booking submit/retry, meals, pickup route changes, rental enquiry, booking lookup/cancellation, Admin login/session expiry, booking/rental status updates, operational CRUD, email retry, refunds and reports.
- Confirm Express API hosting and `/api/**` routing target before release; current static Firebase Hosting alone does not run the Express API.
- Check final mobile layout, especially the rental enquiry panel placement directly below the booking form.

### Deferred Google Sheets / Apps Script phase (requires owner approval)
- Reconcile the reconstructed 17-tab / 139-header schema against the original workbook/source of truth before treating it as final.
- Use one approved Apps Script bootstrap to create the spreadsheet and approved tabs automatically; owner should not manually create a blank sheet.
- Configure server environment variables and Apps Script Script Properties, then test on isolated staging.
- Add a dedicated public read-only configuration endpoint and safe frontend hydration. Do not expose `ADMIN_GET_DATA`, Settings secrets, AdminUsers, bookings, payment references, supplier costs or private Admin data.
- Verify Admin operational edits flow through to customer-facing routes/packages/offers/pickup points/content after refresh.
- Exercise booking/payment-pending writes, duplicate retries, rental enquiry-only writes, lookup/cancellation, Admin reads/mutations, EmailLog, notifications, daily reports, concurrency and throttling.

### Separately approved integrations / delivery
- Payment gateway remains deferred until merchant credentials and a trusted server-side signature/status verification design are ready.
- GitHub commit/push and network build remain after local source work is complete.
- Preview refresh, Apps Script deployment, live email activation, DNS/domain changes and production deployment require explicit approval.

## Scope boundaries

No sheet creation, Apps Script execution/deployment, payment gateway, GitHub, Preview refresh, live email, DNS change or production deployment was performed. No approved tabs/columns, pricing, advance, guide/toll, meal, rental or attraction business rules were changed.

**Overall status: INCOMPLETE / NOT production-ready.** Update 61 improves local booking validation and data accuracy. The outstanding release and integration gates above remain open.
