# Update 52 — Rental local-date validation

**Date:** 20 November 2026  
**Scope:** Local frontend source only. No external integrations or deployment.

## Finding

`CarRentalPanel.tsx` derived both its default travel date and date-input minimum using `toISOString().slice(0, 10)`. `toISOString()` converts to UTC, so around midnight in India it can display the previous calendar day. The rental form also had no submit-time validation preventing a past or malformed date from being submitted.

## Changes

- Replaced UTC date formatting with shared `toLocalDateInputValue()` for the default date (two days ahead) and minimum date.
- Marked the rental date input as required.
- Added submit-time validation using `isTodayOrFutureLocalDate()`, rejecting missing, malformed, impossible and past dates.
- Added `validation/test_rental_local_date_validation.cjs`, which executes the actual TypeScript date helper under `Asia/Kolkata` and checks local midnight, yesterday, today, future and impossible-date cases.

## Verification

- Offline validation runner: **22/22 PASS**.
- TypeScript/TSX/JS/JSX syntax transpilation: **31/31 PASS** (syntax-only; not a semantic type-check).
- JSON manifests: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full npm lint/build: **not run**; dependencies are not installed locally.
- Browser E2E: **pending**.

## Scope and limitations

No UI redesign, pricing, rental business rules, schema, payment flow or external system was changed. Google Sheets setup, Apps Script execution/deployment, payment, GitHub, Preview refresh, live email and production deployment remain deferred under the owner's sequencing instruction.

**Project status remains INCOMPLETE and NOT production-ready.**
