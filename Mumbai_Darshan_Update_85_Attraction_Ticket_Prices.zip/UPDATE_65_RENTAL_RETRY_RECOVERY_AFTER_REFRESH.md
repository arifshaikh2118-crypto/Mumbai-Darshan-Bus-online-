# Update 65 — Rental enquiry retry recovery after page refresh

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 64 — Booking Retry Persistence Fail-Closed Hardening  
**Scope:** Local rental enquiry frontend/storage and offline regression tests only.

## Issue found

Booking retry now survives a page refresh, but rental enquiry retry still depended on `pendingEnquiry` React component state. If the customer submitted a rental enquiry and Google Sheets did not acknowledge the same enquiry ID, refreshing the page discarded the retry state. The customer could unintentionally submit a second rental enquiry with a new reference ID.

## Changes made

1. **Stable rental retry pointer**
   - Added versioned browser-local key `mdb_pending_rental_retry_v1`.
   - Only the Rental Enquiry ID is stored in the pointer; the existing local rental draft remains the source of enquiry details.
   - Added save, restore and guarded clear helpers.
   - Pointer save verifies the full enquiry exists in the local rental store and reads the saved ID back.

2. **Verify local rental draft**
   - `createCarRentalEnquiry()` now reads the newly saved draft back from the existing local rental store.
   - If the browser cannot persist the complete enquiry, it throws before the network sync is attempted.
   - The existing rental data sanitizer remains in place; no supplier cost, margin, customer quotation, or unsupported financial fields were added.

3. **Recover after refresh**
   - Car Rental Panel checks for an unresolved rental enquiry on mount.
   - If found, it displays the original reference ID, customer, mobile, date, rental type, vehicle, pickup, destination and passenger count.
   - Customer can retry the same enquiry ID without recreating the enquiry or relying on the now-empty form state.
   - Retry bypasses fresh-form validation only when an existing pending enquiry object has been restored.

4. **Fail closed and preserve enquiry-only policy**
   - Rental sync does not run unless the full local draft and retry pointer are persisted.
   - Pointer is cleared only after `syncRentalToGoogleSheets()` confirms the exact same Rental Enquiry ID.
   - Rental enquiries remain inquiry-only; no booking confirmation, customer/owner email notification, or payment action was added.
   - Reset-to-defaults now clears the pending booking and rental retry pointers alongside their local records.

5. **Regression coverage**
   - Added `validation/test_rental_retry_recovery.cjs` with 12 source-contract assertions for persistence, pointer read-back, restoration, same-ID retry, acknowledgement-only clearing and inquiry-only policy.

## Verification

- Offline validation runner: **31/31 PASS**.
- TypeScript/TSX syntax transpilation: **35/35 PASS**, zero syntax diagnostics (syntax-only; not a semantic type-check).
- Apps Script `Code.gs` syntax: **PASS** (unchanged source).
- JSON manifests/configuration: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full `npm run lint`, semantic type-check and `npm run build`: **not run**, because project dependencies are not installed in this local project folder.
- Browser refresh/retry E2E: **pending**.
- Live Google Sheets / Apps Script integration: **not tested**; setup and deployment remain deferred.

## Limitations and scope boundaries

- Retry recovery is browser-local. Clearing browser site data, switching device/browser, or disabling browser storage can prevent automatic recovery.
- If local storage cannot persist the enquiry and pointer, the enquiry flow now fails closed before network submission.
- No schema, tab, column, pricing, rental policy, or business rule was changed.
- No Google Sheet creation, Apps Script execution/deployment, PhonePe/payment gateway, GitHub commit/push, Preview refresh, live email, external mutation, or production deployment.

**Overall status: INCOMPLETE / NOT production-ready.** Rental retry-after-refresh is implemented and source-tested; browser E2E, full build and live integration remain outstanding.
