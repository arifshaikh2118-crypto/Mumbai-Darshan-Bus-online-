# Update 81 — Centralized Car Rental Pricing

**Date:** 21 November 2026  
**Source baseline:** Update 80  
**Status:** Local source implementation complete; live verification pending.

## 1. Recommended architecture selected

Keep the approved Google Sheets schema unchanged at **17 tabs / 139 headers**. Do not add a new tab or modify existing columns.

Store the validated customer-facing Local Darshan and Outstation pricing catalogue as JSON in the existing `Settings` key/value sheet under:

`PUBLIC_RENTAL_PRICING_JSON`

Why this is the safest choice:
- The existing `rental_vehicles` tab has only seven inventory-style columns and cannot represent the complete quote model.
- Local Darshan needs base package price, 12-hour/120-KM limits, extra-KM and extra-hour rates, plus active/published controls.
- Outstation needs per-KM rate, minimum KM/day, daily DA and Night DA.
- `Settings` already has a key/value structure, so one dedicated, validated value avoids changing the approved schema.
- The public API returns only the whitelisted rental pricing object, never the complete Settings sheet.
- Admin writes go through the authenticated server proxy and protected Apps Script Admin API.

## 2. Implemented

- Added Apps Script default catalogue and strict validation for **6 Local Darshan packages + 16 Outstation vehicle classes**.
- `setupDatabase()` seeds the JSON setting only when it is missing; reruns preserve an existing owner-edited value.
- Public `PUBLIC_GET_CONFIG` now includes the validated rental catalogue.
- Server `/api/public-config` validates the complete rental catalogue and keeps its existing short cache.
- Added authenticated `POST /api/admin/rental-pricing` and Apps Script `ADMIN_SAVE_RENTAL_PRICING`.
- Admin data returns only the validated rental catalogue, not general Settings values.
- Added Admin rate editor under **Private Fleet & Quotations → Customer Rental Pricing**.
- Admin can edit rates and limits, Active/Published flags, and save all rates together.
- Night DA is constrained to equal the regular daily DA.
- Customer Car Rental panel now displays only rates with both `active` and `published` set to true.
- Successful Admin save invalidates the server public-config cache.
- Updated setup/deployment guidance and validation tests.

## 3. Existing website default rates carried forward

These values are copied from the existing source catalogue. They have **not** been independently confirmed against current supplier costs or the owner's latest commercial rate card. Review before go-live.

### Local Darshan — 12 hours / 120 KM

| Vehicle | Package price | Extra KM | Extra hour |
|---|---:|---:|---:|
| Maruti Suzuki Dzire AC | ₹4,500 | ₹15 | ₹200 |
| Maruti Suzuki Ertiga AC | ₹5,500 | ₹18 | ₹250 |
| Force Tempo Traveller AC (17 Seater) | ₹9,500 | ₹25 | ₹400 |
| Force Tempo Traveller AC (20 Seater) | ₹11,500 | ₹28 | ₹450 |
| Luxury AC Bus (40 Seater) | ₹14,000 | ₹35 | ₹600 |
| Luxury AC Bus (49 Seater) | ₹17,500 | ₹40 | ₹700 |

Existing business rules remain: driver allowance and parking included; guide optional at ₹2,000 flat per booking/vehicle; toll and entry charges extra at actuals.

### Outstation — minimum 300 KM/day

| Vehicle class | Customer rate / KM | Daily DA | Night DA |
|---|---:|---:|---:|
| Dzire | ₹19 | ₹400 | ₹400 |
| Ertiga | ₹22 | ₹400 | ₹400 |
| Innova | ₹24 | ₹400 | ₹400 |
| Innova Crysta | ₹25 | ₹400 | ₹400 |
| Tavera | ₹23 | ₹400 | ₹400 |
| 13–14 Seater AC | ₹29 | ₹1,200 | ₹1,200 |
| 17 Seater AC | ₹31 | ₹1,300 | ₹1,300 |
| 17 Seater Non-AC | ₹28 | ₹1,300 | ₹1,300 |
| 20 Seater AC | ₹33 | ₹1,400 | ₹1,400 |
| 20 Seater Non-AC | ₹30 | ₹1,400 | ₹1,400 |
| 26 Seater AC | ₹41 | ₹1,600 | ₹1,600 |
| 26 Seater Non-AC | ₹36 | ₹1,600 | ₹1,600 |
| 32–35 Seater AC | ₹53 | ₹2,200 | ₹2,200 |
| 32–35 Seater Non-AC | ₹45 | ₹2,200 | ₹2,200 |
| 45–49 Seater AC | ₹63 | ₹2,500 | ₹2,500 |
| 45–49 Seater Non-AC | ₹54 | ₹2,500 | ₹2,500 |

Existing outstation rules remain: garage-to-garage KM, 300 KM/day minimum, driver allowance/DA-permit extra, parking/toll/border tax/entry extra at actuals. Additional Night DA after 11 PM equals the daily DA.

## 4. Validation

- Offline validation runner: **48/48 PASS**.
- Full Update 43 validation suite: **48/48 PASS**.
- Apps Script syntax: PASS.
- TypeScript/TSX syntax transpilation: **32 files, 0 syntax errors**.
- Server TypeScript syntax transpilation: PASS.
- Public configuration runtime: 9 assertions PASS.
- Public configuration synchronization: 23 assertions PASS.
- Rental pricing configuration: 15 assertions PASS.
- Schema alignment test confirms **17 tabs / 139 headers** remain unchanged.
- ZIP integrity: verified after packaging.

## 5. Not done / blockers

- Full semantic `tsc --noEmit` not run: `node_modules` is absent and `vite/client` is unavailable.
- Vite production build not run for the same missing-dependency reason.
- Browser E2E and real mobile-device testing not run.
- No Google Sheet was created, no Apps Script was deployed, and no live write/read was attempted.
- The copied rate defaults are source-derived, not owner-confirmed. They must be reviewed before live publication.
- Existing local/outstation prices are not represented in the old seven-column `rental_vehicles` tab; they now use the protected Settings JSON value.

## 6. What the owner should do

No manual Google Sheet creation is required. At the approved final setup stage, the one-time `setupDatabase()` function will create the spreadsheet automatically and seed the rental pricing record from these existing website defaults.

Before live launch:
1. Review the Local Darshan package prices and extra-KM/extra-hour charges above.
2. Review all 16 Outstation per-KM and DA rates.
3. Confirm the 300-KM/day minimum and Night DA rule.
4. After setup and secure deployment, use **Admin → Private Fleet & Quotations → Customer Rental Pricing** to correct or disable any rate.
5. Verify customer display on desktop and mobile before production launch.

Do not deploy this package yet. Keep PhonePe, live Sheets setup, Apps Script deployment, GitHub, Preview refresh, hosting/DNS and production deployment deferred until explicit approval.
