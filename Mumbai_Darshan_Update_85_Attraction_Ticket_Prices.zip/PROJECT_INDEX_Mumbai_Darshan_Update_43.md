# Mumbai Darshan Bus Online — Master Progress Tracker

**Current package:** Update 43 — Frontend API Contract & Operational Schema Audit  
**Baseline:** Update 42 — Admin Login Throttle & Upstream Request Resilience  
**Date:** 20 November 2026

## Owner sequencing instruction

- [x] GitHub work must wait until the complete project files and remaining local work are finished.
- [x] Update 43 did not commit/push code, run GitHub Actions, refresh Preview or deploy.
- [ ] GitHub/network-enabled build phase only after local source and project files are complete.

## Completed source work

- [x] Approved 17-tab / 139-header schema manifest and bootstrap source retained.
- [x] Booking server-side pricing/advance calculation and duplicate partial-write reconciliation gate retained.
- [x] Rental enquiry remains inquiry-only; no owner/customer rental email.
- [x] Admin session, secret-gated Apps Script actions and active AdminUsers roster retained.
- [x] Public lookup/cancellation privacy and throttling retained.
- [x] EmailLog, notifications, cancellation/refund review and Daily Reports source retained.
- [x] Update 36 protected Admin dispatch, public mutation lockdown, proxy allowlist and server-configured webhook URL fixes retained.
- [x] Update 37 Firebase guide corrected to explain Express API hosting requirement.
- [x] Update 38 added dependency-free offline validation runner.
- [x] Update 39 public Express proxy requires explicit allowed action; Apps Script rejects missing/blank action.
- [x] Update 40 runtime tests reject missing, blank and non-string actions; lock release and explicit PING_TEST verified.
- [x] Update 41 manual network build workflow definition added; execution deferred by owner instruction.
- [x] Update 42 fixed expired Admin login lockout-window reset order.
- [x] Update 42 added 30-second timeout to all 3 Apps Script fetch paths.
- [x] Update 43 verified all 13 frontend API paths have Express routes.
- [x] Update 43 verified 10 protected Admin routes use `requireAdmin`.
- [x] Update 43 verified all 10 Express Admin actions are dispatched in Apps Script.
- [x] Update 43 aligned all 7 Operational Sheets Manager UI configs with approved schema headers/keys.
- [x] Update 43 added API contract and operational UI schema regression tests.
- [x] `npm run test:offline` PASS, 14/14.
- [x] TypeScript/TSX syntax transpilation PASS, 29/29.
- [x] Key JSON manifests PASS, 4/4.

## Important migration gap — public configuration remains browser-local

**Not complete:** Admin operational edits are saved to Google Sheets, but customer-facing routes/packages/offers/pickup points/tour points are still read through `StorageService` from browser `localStorage` and `INITIAL_*` defaults. `BookingForm.tsx` uses those getters. The Admin Sheets manager refreshes Admin data only.

- [ ] Add a dedicated read-only public configuration endpoint.
- [ ] Explicitly allowlist public fields from operational tabs only.
- [ ] Never expose AdminUsers, Settings secrets, bookings, payment references, supplier costs or private Admin data.
- [ ] Add safe defaults, response validation and bounded cache.
- [ ] Hydrate public booking and content components from Sheets-backed public config.
- [ ] Ensure Admin changes become visible to public pages after a safe refresh.
- [ ] Add regression tests for privacy allowlist, schema mapping, fallback and cache behavior.
- [ ] Test against isolated staging before production cutover.

Do not reuse protected `ADMIN_GET_DATA` as a public endpoint.

## Latest verification status

| Check | Result |
|---|---|
| Apps Script CJS regression suites | PASS, 9/9 |
| Apps Script `Code.gs` syntax | PASS |
| Admin login throttle / upstream timeout regression | PASS |
| Frontend API path alignment | PASS, 13/13 |
| Protected Admin route middleware | PASS, 10/10 |
| Express-to-Apps Script Admin action dispatch | PASS, 10/10 |
| Operational UI schema alignment | PASS, 7/7 sheets |
| Offline validation runner | PASS, 14/14 |
| TypeScript/TSX syntax transpilation | PASS, 29/29 |
| Key JSON manifests | PASS, 4/4 |
| npm registry access | BLOCKED — DNS `EAI_AGAIN` |
| npm cache | No usable package cache entries |
| `package-lock.json` | MISSING |
| `bun.lock` | EMPTY, unusable |
| `node_modules` | ABSENT |
| Full `npm run lint` | PENDING — dependencies/types unavailable |
| `npm run build` | PENDING — dependencies unavailable |
| GitHub Actions workflow | NOT RUN — deferred by owner |
| Browser E2E | PENDING |
| Hosting architecture / API runtime | PENDING owner/developer confirmation |
| Google Sheets staging | PENDING owner approval |

## Remaining local work before GitHub

- [ ] Implement and test Sheets-backed public configuration endpoint and frontend hydration.
- [ ] Review customer-facing pricing, route, offer and pickup mapping against approved operational Sheets.
- [ ] Continue local source audit and close remaining code/documentation gaps.
- [ ] Preserve current UI, pricing, booking rules and approved schema unless owner approves changes.
- [ ] Complete all source/package files before GitHub activity.

## Later — network build, browser E2E and staging

### P0 — Network-enabled build (only after local files are complete)
- [ ] Owner/developer commits/pushes project source to intended GitHub repository.
- [ ] Manually run **Mumbai Darshan Network Build Validation** workflow.
- [ ] Verify npm install generates a valid package-lock.
- [ ] Verify clean `npm ci` passes.
- [ ] Verify `npm run lint` passes.
- [ ] Verify `npm run build` passes.
- [ ] Review uploaded lockfile and dist artifacts; record workflow URL and commit SHA.

### P0 — Hosting architecture and browser E2E
- [ ] Confirm hosting target for Express server.
- [ ] If Firebase Hosting + Cloud Run is approved, confirm actual service ID and region, then configure `/api/**` rewrite before SPA fallback.
- [ ] Verify `/api/*` reaches Express and Admin routes reject unauthenticated calls.
- [ ] Run browser E2E for booking submit/retry, rental inquiry, lookup, cancellation, Admin login/session expiry, status updates, email retry, refunds, reports and seven operational CRUD tabs.
- [ ] Test mobile booking flow and rental enquiry panel immediately below booking form.

### P1 — Google Sheets / Apps Script staging (owner approval only)
- [ ] Run `setupDatabase()` once against isolated staging.
- [ ] Confirm exact 17 tabs / 139 headers and approved seed data.
- [ ] Configure private server environment and Apps Script Script Property secrets.
- [ ] Test booking/payment-pending ledger writes, duplicate retries, rental inquiry-only writes, lookup/cancellation, Admin reads/mutations, EmailLog, notifications and daily reports.
- [ ] Test concurrency and throttling.
- [ ] Owner-approved controlled email test; only then decide on trigger installation.

### P2 — Later separately approved delivery
- [ ] Preview refresh after build/tests and approval.
- [ ] PhonePe integration after merchant credentials and server-side signature/status verification.
- [ ] Production Apps Script deployment, email activation, DNS/domain changes and website deployment only with explicit approval.

## Preserved business and safety rules

- No changes to approved sheet tabs/columns without permission.
- No supplier cost/rate/margin/private garage information in customer-facing code.
- No extra ₹5 rental-rate markup; approved customer rates remain unchanged.
- ₹200 advance is per booking, not per person.
- No automatic refund; PhonePe remains deferred.
- No rental enquiry emails; follow up via WhatsApp.
- No live Sheet, Apps Script, GitHub, Preview or production action without explicit approval.

**Overall: INCOMPLETE. Update 43 verifies frontend API routing, Admin authentication middleware, Apps Script dispatch and all 7 operational UI/schema mappings. Offline tests pass 14/14; 29 TypeScript/TSX files pass syntax transpilation. Critical remaining local task: public site configuration is still browser-local and needs a safe Sheets-backed public read API. GitHub work is deferred by owner instruction until local project files are complete.**
