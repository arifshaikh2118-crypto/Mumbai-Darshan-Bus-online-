# Mumbai Darshan Bus Online — Project Index / Master Progress Tracker
## Update 28 — Build Environment Diagnostic

**Date:** 11 November 2026  
**Base:** Update 27 source package  
**Scope:** Continue build and browser validation only; no UI/schema/business-rule changes.

### Verified PASS
- Six automated test suites via `node validation/run-offline-checks.cjs`.
- Apps Script syntax parsing.
- TypeScript/TSX syntax transpilation: 26 files, zero syntax diagnostics.
- Existing approved schema and rental policy checks remain green.

### Attempted but blocked
- `npm install --legacy-peer-deps --no-audit --no-fund`: timed out; no `node_modules` created.
- `tsc --noEmit`: blocked before project type-check because `vite/client` definitions are missing.
- Chromium local preview navigation: blocked by runtime policy (`ERR_BLOCKED_BY_ADMINISTRATOR`); no browser E2E result claimed.

### Update 29 — Network-enabled runner handoff
- Added a manual-only GitHub Actions workflow: `.github/workflows/network-build-validation.yml`.
- Added exact execution instructions: `validation/NETWORK_ENABLED_RUNNER_NOTE.md`.
- Workflow is configured for GitHub-hosted Ubuntu + Node.js 22 and runs dependency installation, full TypeScript check, Vite production build, then uploads `dist/` as a validation artifact.
- Workflow does not deploy or access live services.
- **Not yet committed or executed**; no network-enabled build PASS is claimed.

## Remaining work
1. Commit the new manual workflow to GitHub and run it on a network-enabled Node.js 22 runner.
2. Review/fix any `npm run lint` semantic TypeScript diagnostics.
3. Review/fix any `npm run build` Vite production build diagnostics.
4. Browser E2E for all seven operational Admin tabs (create/reload/edit/reload/delete/reload).
5. Dedicated staging Google Sheets persistence, session expiry, unauthorized rejection, schema validation, and Activity Log verification.
6. After passing staging tests, update the existing Preview URL as a separate approved milestone.
7. Production deployment only after explicit approval.

### Unchanged / protected
- 17 approved Google Sheets tabs / 139 headers.
- Rental Enquiry remains exactly 19 columns and inquiry-only.
- Customer-facing rental prices unchanged; no supplier cost/rate/margin/profit system added.
- No production data, UI, or business rules changed in this checkpoint.

### Not performed
- No Google Sheet created or modified.
- Apps Script `setupDatabase()` not run; no Apps Script deployment.
- No secrets or credentials configured/committed.
- No GitHub commit, existing Preview refresh, or production deployment.

**Next action:** Follow `validation/NETWORK_ENABLED_RUNNER_NOTE.md`: commit and manually run the GitHub Actions workflow, then record its actual run URL, commit SHA, and step results. After a passing build, create/approve a separate browser E2E and staging CRUD test plan. Do not mark these as complete until actual results are recorded.
