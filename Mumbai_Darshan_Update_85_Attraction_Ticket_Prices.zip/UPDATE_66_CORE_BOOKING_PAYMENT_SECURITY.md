# Update 66 — Core booking and payment callback security hardening

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 65  
**Focus:** Core booking/payment safety and Admin/public API security review. Rental enquiry retry work was not expanded.

## Why this update

The rental enquiry is an inquiry-only lead that is followed up manually on WhatsApp. This update therefore shifts effort to the more consequential bus-booking and payment records.

## Issue found in payment callback handling

The payment callback already required a server-held `PAYMENT_CALLBACK_SECRET`, a strict `providerVerified === true` flag, a matching booking ledger, an amount matching the approved fare/advance, and provider transaction identifiers not already assigned to another booking.

However, if a callback had written `Verified` into the payment ledger but failed before updating the corresponding booking row, a retry with a *different* payment event for that same booking could overwrite the existing verified ledger entry. That could destroy evidence of the first payment attempt.

## Changes made

1. **Constant-time callback secret comparison**
   - Replaced ordinary string equality for `PAYMENT_CALLBACK_SECRET` with the existing constant-time comparison helper.
   - Callback still requires the secret to be configured and supplied.

2. **Verified ledger idempotency**
   - If the payment ledger already contains a verified event for the booking, a retry may continue only when payment ID, transaction reference and amount all exactly match.
   - A different event returns `reconciliation_required` and leaves the existing verified ledger evidence untouched.
   - This supports recovery from a partial state transition without silently replacing the original verified transaction.

3. **Provider text safety**
   - Payment ID and transaction reference are length-bounded and written as literal cell text.
   - Provider label is also length-bounded and formula-safe.
   - Existing booking amount checks, duplicate cross-booking checks and strict boolean provider verification remain in place.

4. **Regression coverage**
   - Added `validation/test_payment_callback_idempotency_security.cjs` with 10 assertions.
   - Updated two existing regression fixtures to reflect the current validated rental input contract; no rental enquiry workflow or UI feature was added in this update.

## Security review — controls confirmed in source

- Public Sheets proxy accepts only the explicit public action allowlist; Admin actions are not accepted through that route.
- Public proxy payload is capped at 64 KB and rate-limited per action/IP in the server process.
- Public proxy is pinned to the server-configured Google Apps Script URL; browser-supplied URL must match exactly.
- Admin routes other than login require a signed, expiring Admin session.
- Admin Apps Script actions require the server-held shared secret and an active AdminUsers roster entry.
- Booking price is derived from approved PackageOptions data on the server, not trusted from browser-supplied totals.
- New bookings remain Payment Pending / Pending Verification until the trusted payment verification handler succeeds.
- Customer lookup requires Booking ID plus registered mobile and returns a minimal booking projection.

These are source-level confirmations, not a live penetration test.

## Verification

- Offline validation runner: **33/33 PASS**.
- New payment callback security assertions: **10 PASS**.
- TypeScript/TSX syntax transpilation: **35/35 PASS**, zero syntax diagnostics (syntax-only, not a semantic type-check).
- Apps Script `Code.gs` syntax: **PASS** (included in the offline runner).
- JSON manifests/configuration: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full `npm run lint`, semantic type-check and `npm run build`: **not run**; project dependencies are not installed.
- Browser E2E and live Google Sheets / Apps Script tests: **not run**.
- No live payment gateway callback was invoked or enabled.

## Scope boundaries

- PhonePe/payment gateway integration remains deferred. This update only hardens the existing server-side callback handler; it does not enable or claim live payments.
- No Sheet/tab/header/schema, pricing, booking UI, rental workflow, or business rule was changed.
- No Google Sheet creation, Apps Script execution/deployment, GitHub commit/push, Preview refresh, live email, external mutation, or production deployment.

**Overall status: INCOMPLETE / NOT production-ready.** The payment callback path is safer and regression-tested offline. Live gateway integration, browser E2E, full build and deployment verification remain pending.
