# Update 70 — Admin Financial Report Label Accuracy

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 69 — Admin Payment Reconciliation Payload Hardening  
**Focus:** Align Admin financial-report labels with the existing verified-ledger calculation and booking filter.

## Audit finding

The Admin Reports tab calculated `totalAdvanceCollected` by summing `amountPaid` across all active (non-cancelled) bookings. In the sheet-backed Admin flow, `amountPaid` is derived only from positive payment-ledger rows whose status is `verified`. That value can represent an advance or a full online payment, so the label **Online Advance Collected** was too narrow. The supporting text **From X confirmed bookings** was also inaccurate because the active report filter excludes cancelled bookings but does not require the booking status to be Confirmed.

## Changes made

1. Changed the report KPI label from **Online Advance Collected** to **Online Payments Collected**.
2. Changed its supporting text from **From X confirmed bookings** to **Across X non-cancelled bookings**.
3. Added `validation/test_admin_financial_reporting_contract.cjs` with 7 assertions covering:
   - sheet-backed `amountPaid` is calculated from linked `verified` ledger rows;
   - only positive finite amounts are summed;
   - the mapped `amountPaid` value feeds the report;
   - report wording accurately describes online payments and the non-cancelled booking filter.

## Verification

- Offline validation runner: **36/36 PASS**.
- Financial reporting contract checks: **7 PASS**.
- Admin reconciliation contract checks: **22 PASS**.
- TypeScript/TSX/JS/JSX syntax transpilation: **36/36 PASS**, zero syntax diagnostics (syntax-only; not a semantic type-check).
- Apps Script `Code.gs` syntax: **PASS** (included in the offline runner).
- JSON configuration/manifests: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full npm lint, semantic type-check and production build: **not run**; project dependencies are not installed.
- Browser E2E and live Google Sheets / Apps Script tests: **not run**.

## Scope boundaries

- No payment calculation, ledger status, booking status, report filtering, booking flow or business rule was changed; only inaccurate KPI wording was corrected.
- No sheet/tab/header/schema changes.
- No booking or payment ledger data was changed.
- No PhonePe/payment gateway activation or automatic refund.
- No live Google Sheets access, Apps Script execution/deployment, GitHub commit/push, Preview refresh, live email, external mutation or Firebase/production deployment.

**Overall status: INCOMPLETE / NOT production-ready.** Financial-report wording now matches the existing verified-ledger calculation and non-cancelled booking filter. Full build, browser E2E and live integration verification remain outstanding.
