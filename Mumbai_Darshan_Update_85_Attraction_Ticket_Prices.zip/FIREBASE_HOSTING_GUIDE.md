# Firebase Hosting + Express API Architecture Gate

**Project:** Mumbai Darshan Bus Online  
**Production domain:** `https://mumbaidarshanbusonline.com/`

## Current release status

**DO NOT DEPLOY.** The current application is not a static-only website. The React/Vite frontend uses an Express server (`server.ts`) for `/api/*` endpoints, including the Google Apps Script proxy and authenticated Admin routes.

The current `firebase.json` sends every path to `/index.html`. Firebase Hosting does not start `server.ts`, so deploying only Hosting assets would leave the API routes unavailable. A successful static Vite build alone is not sufficient for release.

No Firebase project, Cloud Run service ID, Cloud Run region, runtime environment variables, or approved backend deployment target is recorded in this source package. Do not invent these values or change DNS.

## Required architecture decision

Before any Preview refresh or production deployment, the owner/developer must confirm one of these:

1. **Firebase Hosting + Cloud Run (candidate, not configured):** deploy the Express application as a Cloud Run service, then add a Firebase Hosting rewrite for `/api/**` to that exact service ID and region. Keep the SPA fallback after the API rewrite.
2. **A host that runs the Express application:** host the frontend and Express API together, or configure an explicitly tested frontend-to-API origin and CORS/security policy.

Do not configure either option until the actual project/service identifiers, region, secrets, and deployment ownership are confirmed.

## Firebase Hosting rewrite shape — reference only

If (and only if) Firebase Hosting + Cloud Run is approved, the rewrite order should follow this shape. Replace both placeholders with verified values from the actual Cloud Run service; never deploy the placeholders.

```json
{
  "hosting": {
    "public": "dist",
    "rewrites": [
      {
        "source": "/api/**",
        "run": {
          "serviceId": "CONFIRMED_CLOUD_RUN_SERVICE_ID",
          "region": "CONFIRMED_CLOUD_RUN_REGION"
        }
      },
      {
        "source": "**",
        "destination": "/index.html"
      }
    ]
  }
}
```

This is an architecture example, not a deployable configuration. The API rewrite must precede the SPA fallback. Preserve and review the existing cache headers when the final configuration is prepared.

## Mandatory gates before Preview refresh

- [ ] Confirm the existing Firebase project ID and current Hosting site.
- [ ] Confirm whether Cloud Run is the approved Express runtime, or select another supported host.
- [ ] Confirm the actual Cloud Run service ID and region if Cloud Run is selected.
- [ ] Confirm Node runtime/buildpack or container configuration and a repeatable server build/start command.
- [ ] Configure server-only secrets in the hosting environment: `ADMIN_PASSCODE`, `ADMIN_SESSION_SECRET`, `ADMIN_API_SECRET`, `GOOGLE_APPS_SCRIPT_URL`; never place these in Vite/browser variables.
- [ ] Confirm the deployed Express process listens on the platform-provided `PORT`.
- [ ] Run clean dependency installation, `npm run lint`, and `npm run build`.
- [ ] Run browser E2E against the deployed Preview backend: public booking, rental inquiry, lookup, cancellation request, Admin login/session expiry, protected status updates, email retry, refund review, daily report, and all seven operational CRUD tabs.
- [ ] Verify mobile booking flow and that the rental enquiry panel remains immediately below the booking form.
- [ ] Verify API requests reach Express and that Admin routes reject unauthenticated requests.
- [ ] Only after all gates pass, obtain explicit owner approval to refresh the existing Preview URL.

## Production-domain and rollback safeguards

- Do not change DNS, custom-domain attachment, or MX/email records during development or Preview work.
- Do not disconnect or overwrite the currently live website while validating the replacement.
- Confirm the existing Firebase project, domain ownership, DNS records, and rollback target before any production change.
- Production deployment requires separate explicit owner approval after Preview verification.

## Current verification facts

Update 36 source audit confirms the current `firebase.json` is static Hosting configuration and does not route `/api/*` to Express. Build, browser E2E, backend hosting, live Google Sheets staging, Apps Script authorization, email delivery, PhonePe, GitHub publication, Preview refresh, and production deployment remain incomplete. See `PROJECT_INDEX_Mumbai_Darshan_Update_36.md` and `UPDATE_36_PRE_EXTERNAL_AUDIT_AND_FIXES.md`.
