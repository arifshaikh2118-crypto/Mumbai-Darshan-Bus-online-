# Mumbai Darshan Bus Online — Update 47
## Customer Text / Google Sheets Formula-Injection Hardening
**Date:** 20 November 2026  
**Baseline:** Update 46 — Booking Travel-Date Local Calendar Fix  
**Scope:** Local Apps Script source hardening and regression coverage only.

### Defect / risk addressed
Customer-controlled text from public booking and rental enquiry forms was written into Google Sheets with several fields passed directly to `appendRow()`. Text beginning with formula-trigger characters such as `=`, `+`, `-` or `@` could be interpreted as a spreadsheet formula rather than plain customer text. Public record IDs were also accepted without a strict format check in the write handlers.

### Fix applied
- Added shared `safeSheetText_(value, maxLength)` in `google-apps-script/Code.gs`.
- Formula-like public text is prefixed with a single quote so it is stored as literal cell text.
- Customer booking text fields (name, email, travel date, route, pickup point, package title and special request) are sanitized and length-bounded before the booking row is appended.
- Rental enquiry text fields (name, vehicle type, travel date, pickup/destination, trip type, special request, preferred vehicle, seating preferences, AC preference, duration and pickup time) are sanitized and length-bounded.
- Booking IDs and rental enquiry IDs must match the allowed 5–80 character alphanumeric/underscore/hyphen format before write processing.
- Existing approved 17-tab schema, exact column order, pricing authority, payment-pending status, no-email rental enquiry rule, UI and business rules remain unchanged.

### Regression coverage
Added `validation/test_sheets_formula_injection.cjs`. It executes the actual sanitizer helper and checks formula-like inputs, ordinary text, trimming, length limits, null handling, coverage of booking/rental text fields and public ID validation.

### Validation results
- Offline validation runner: **18/18 PASS** (including Apps Script syntax and all current regression checks).
- TypeScript/TSX syntax transpilation: **29/29 PASS**, zero syntax diagnostics. Syntax-only; not a semantic type-check.
- Key JSON manifests: **4/4 PASS**.
- ZIP archive integrity: **to be verified after packaging**.
- Full `npm run lint`, Vite production build and browser E2E: **pending**. Project dependencies are not installed; earlier npm registry access failed with DNS `EAI_AGAIN`.

### Not performed
No Google Sheet was created or modified. No Apps Script was deployed or executed. No payment/PhonePe integration, live email, GitHub commit/push/Actions, Preview refresh or production deployment was performed. These remain deferred under the owner's instructions.

### Status
Update 47 hardens public booking and rental enquiry text writes against spreadsheet formula interpretation. This is a local source change only and does not make the project production-ready.
