# Update 62 — Rental enquiry ID acknowledgement and customer-to-Admin workflow audit

**Date:** 20 November 2026  
**Baseline:** Update 61 — Booking server validation and optional email correction  
**Scope:** Local source and regression tests only. No UI redesign, schema change, live Sheet, Apps Script deployment, payment, GitHub, Preview refresh, email activation, or production deployment.

## 1. Confirmed defect found

The booking sync flow already required Apps Script to echo the exact submitted Booking ID before the customer could see the saved receipt. The rental enquiry flow accepted any `success` or `duplicate` status from the proxy without checking that Apps Script echoed the same Rental Enquiry ID.

That mismatch meant a malformed, stale, or unexpected backend response could be treated as proof that the current customer's rental enquiry had been saved, even if the returned record ID did not match the enquiry being submitted.

## 2. Fix applied

- Rental sync now reads `backendResponse.enquiryId`.
- It compares the returned ID with the submitted `rental.id` (case-insensitive, after trimming), matching the booking ID acknowledgement pattern.
- Both `success` and `duplicate` are accepted only when the exact same enquiry ID is echoed.
- Missing or mismatched IDs fail closed and return a clear retry/contact message.
- Duplicate success text explicitly says the same Rental Enquiry ID is already saved.
- The customer form retains its pending enquiry object on a failed acknowledgement, so a retry in the same active form session uses the same reference ID.
- Apps Script already returns `enquiryId` for both new and duplicate rental records; no Apps Script change was needed.

## 3. Customer-to-Admin workflow audit — source findings

| Workflow | Source-level result | Remaining validation |
|---|---|---|
| Customer bus booking | Stable Booking ID is sent; server-side fare and passenger validation exist; booking receipt waits for exact echoed ID; payment remains pending | Browser E2E for valid submit, rejected sync, retry, refresh/re-entry and duplicate response |
| Rental enquiry | Inquiry-only record; no rental email notifications; WhatsApp follow-up; Update 62 now requires exact echoed Enquiry ID | Browser E2E for local/outstation enquiry, same-ID retry and duplicate acknowledgement |
| Booking lookup | Requires Booking ID + registered mobile; response UI shows limited fields | Browser E2E for valid/invalid credentials, not-found and throttling; confirm no PII leakage |
| Cancellation request | Requires Booking ID + mobile + reason; public throttling and duplicate-safe Apps Script handler exist | Browser E2E for duplicate request, rate-limit and Admin review |
| Admin login/data | Signed expiring session, active roster check and protected Admin data endpoint exist | Browser E2E for login, refresh, expiry, storage failure and unauthorized access |
| Admin booking/rental status | Protected server routes call authenticated Apps Script actions; local state updates only after backend success | Browser E2E for all allowed status transitions and rejected/expired session |
| Admin operational CRUD | Seven approved operational tabs have schema-checked write/delete paths | Browser E2E for create/edit/delete, validation, refresh and exact schema mapping |

## 4. Additional risk retained as an explicit test item

A booking retry draft is held in React component state (`pendingBooking`). The booking row itself is also saved in browser storage, but the pending-draft pointer is not restored after a page reload. Therefore, a customer who reloads after a failed sync may not automatically resume the same Booking ID. This update does not change the recovery UX because restoring the complete multi-step booking form safely requires a separate, deliberate design and testing pass; do not silently create a new booking ID or pretend the old draft is recovered.

## 5. Verification

- Dependency-free offline validation runner: **29/29 PASS** (includes 8 new rental-ID acknowledgement assertions).
- TypeScript/TSX syntax transpilation: **35/35 PASS**, zero syntax diagnostics. This is syntax-only, not semantic type-checking.
- Apps Script syntax: **PASS** (no Apps Script source change in this update).
- ZIP integrity: **PASS**.
- Full `npm run lint` / semantic TypeScript check: not run; project dependencies are not installed locally.
- Vite production build: not run; dependencies are not installed locally.
- Browser E2E: pending; no browser automation runtime is available in this local-only pass.
- Live Google Sheets/Apps Script integration: not tested; sheet creation and deployment remain deferred by owner instruction.

## 6. No external actions

No Google Sheet creation, Apps Script execution/deployment, PhonePe/payment integration, GitHub commit/push, GitHub Actions, Preview refresh, live email, or production deployment was performed.

**Overall status: INCOMPLETE / NOT production-ready.** Update 62 closes the rental identity-acknowledgement gap in local source. Browser E2E, refresh-safe booking retry, clean dependency install, semantic lint/build, hosting architecture confirmation, and later approved staging remain open.
