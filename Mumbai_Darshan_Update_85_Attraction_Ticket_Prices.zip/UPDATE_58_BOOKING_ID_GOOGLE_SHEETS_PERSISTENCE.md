# Update 58 — Booking ID persistence in Google Sheets

**Date:** 20 November 2026  
**Scope:** Local project source, Google Apps Script source, and regression tests only. No live Google Sheet or Apps Script deployment was touched.

## What the source audit found

The booking form already generated a stable Booking ID, sent it as `bookingId` with the `NEW_BOOKING` request, and the Apps Script handler already placed that value in column 2 (`Booking ID`) of the approved 21-column `Bookings` sheet.

However, the frontend accepted a generic `success` or `duplicate` response without verifying that Apps Script echoed the exact same Booking ID. Also, the Apps Script booking handler could leave a booking-only row if the payment-ledger write failed after the booking row had been appended. The booking write path also needed to avoid reacquiring the ScriptLock already held by `doPost`.

## Changes made

1. **Booking ID confirmation**
   - Frontend still reuses one stable ID while retrying the same pending booking.
   - After `NEW_BOOKING`, frontend now requires Apps Script to return the exact same `bookingId` before it marks the booking synced or displays the receipt.
   - A missing or mismatched ID keeps the booking unconfirmed and tells the customer not to pay.

2. **Google Sheets write safety**
   - Apps Script validates both the `Bookings` and `booking_payments` tabs against the approved schema before writing either row.
   - Booking ID is stored explicitly in column 2 of `Bookings` and echoed back in the response.
   - Booking writes are serialized with the ScriptLock. The handler reuses the lock when called from `doPost` (which already holds it) and acquires it only for direct/internal calls, avoiding recursive lock acquisition.
   - If the pending payment-ledger append fails after the booking row is written, the handler attempts to roll back the just-added booking row. If rollback cannot be confirmed, it returns `reconciliation_required`, never success.
   - Duplicate retry behavior remains fail-closed if an existing booking has no matching payment-ledger row; no payment amount is guessed.

3. **Regression coverage**
   - Added a frontend/source-contract test for sending, echo-checking, and receipt gating on the same Booking ID.
   - Expanded Apps Script runtime tests to verify the ID is saved in column 2 and returned, missing/mismatched payment-ledger schema prevents a booking-only save, payment-ledger write failure rolls back the booking row, and a webhook booking does not recursively reacquire the ScriptLock.

## Verification

- Offline validation runner: **28/28 PASS**.
- TypeScript/TSX syntax transpilation: **34/34 PASS**, zero syntax diagnostics (syntax-only, not semantic type-check).
- Apps Script `Code.gs` syntax: **PASS**.
- JSON manifests/configuration: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full npm lint/build: **not run**; project dependencies are not installed locally.
- Browser E2E: **pending**.
- Live Google Sheets/Apps Script integration: **not tested**, because sheet creation and Apps Script execution/deployment remain deferred by owner instruction.

## Important status

This update makes the source flow require confirmation that the exact Booking ID was saved in Google Sheets before showing the booking receipt. It does **not** mean a live spreadsheet has been created or tested yet. At the later setup phase, the owner will run the one complete Apps Script bootstrap that automatically creates the spreadsheet and approved tabs; the owner does not need to create a blank sheet manually.

No payment integration, GitHub action, Preview refresh, live email, Apps Script deployment, Google Sheet mutation, or production deployment was performed. Existing approved 17-tab / 139-header schema, booking prices, ₹200 advance, UI and business rules were preserved.

**Overall project status: INCOMPLETE / NOT production-ready.**
