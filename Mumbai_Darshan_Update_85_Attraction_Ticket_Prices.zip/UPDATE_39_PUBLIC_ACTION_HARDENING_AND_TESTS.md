# Update 39 — Explicit Public Action Validation & Regression Hardening

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 38 — Offline Validation Runner & Dependency Readiness Audit  
**Release status:** INCOMPLETE — source-level security hardening completed; full frontend build and external staging remain blocked.

## 1. What work was completed in Update 39

| # | Work item | Result |
|---|---|---|
| 1 | Audited public `/api/sync-sheets` action handling | Found missing/empty action was implicitly treated as `NEW_BOOKING` |
| 2 | Hardened Express public proxy | Now requires `payload.action` to be an explicit string in the allowlist; no implicit booking fallback |
| 3 | Hardened Apps Script `doPost` entry point | Now rejects missing/blank action instead of defaulting to `NEW_BOOKING` |
| 4 | Extended Admin security regression test | Added static assertions for explicit action validation in Express and Apps Script |
| 5 | Added Update 39 offline validation runner | Added `validation/run-update39-checks.mjs` |
| 6 | Updated `npm run test:offline` | Now invokes the Update 39 runner |
| 7 | Updated README | Documents the new runner and its limitations |
| 8 | Re-ran offline validation | PASS, 9/9 checks |
| 9 | Parsed key JSON manifests | PASS for package.json, firebase.json, appsscript.json and schema manifest |
| 10 | Updated Master Progress Tracker and packaged Update 39 ZIP | Completed; ZIP integrity verified |

## 2. What was not completed — and why

| # | Work item | Status | Exact reason |
|---|---|---|---|
| 1 | Generate npm `package-lock.json` | Not completed | Network-enabled `npm install --package-lock-only --ignore-scripts --no-audit --no-fund --legacy-peer-deps` attempt timed out in the execution environment. No lockfile was produced. |
| 2 | Install dependencies | Not completed | `node_modules` is absent and the npm registry resolution/install attempt did not finish. |
| 3 | Full TypeScript lint/type-check | Not completed | `tsc --noEmit` stops because `vite/client` type definitions are missing. |
| 4 | Vite production build | Not completed | Vite and project dependencies are not installed. |
| 5 | Browser E2E | Not completed | No browser E2E runner/current built bundle is available in this environment. |
| 6 | Live Firebase/Express backend routing | Not completed | Actual approved hosting target, Cloud Run service ID and region are not present in the project; must not be guessed. |
| 7 | Google Sheets/Apps Script staging | Not completed | Requires isolated staging and explicit owner approval. No external service was contacted. |
| 8 | GitHub, Preview, production, DNS, PhonePe and live email | Not completed | These remain separately approved release steps; none were authorized or performed. |

## 3. What work remains

### P0 — Dependency and build readiness
- [ ] Generate a valid `package-lock.json` on a network-enabled runner.
- [ ] Review the lockfile and install reproducibly with `npm ci`.
- [ ] Pass `npm run lint`.
- [ ] Pass `npm run build`.
- [ ] Fix all semantic TypeScript/build errors.

### P0 — Hosting and browser verification
- [ ] Confirm the approved Express hosting platform.
- [ ] If Firebase Hosting + Cloud Run is selected, confirm real service ID and region and configure `/api/**` rewrite before SPA fallback.
- [ ] Verify `/api/*` reaches Express.
- [ ] Run browser E2E for booking, rental enquiry, lookup, cancellation, Admin authentication/session expiry, protected status updates, email retry, refunds, daily reports and all seven operational CRUD tabs.
- [ ] Verify mobile booking flow and rental enquiry panel position.

### P1 — Isolated staging (owner approval required)
- [ ] Run `setupDatabase()` once against isolated staging.
- [ ] Verify 17 approved tabs / 139 headers and seed data.
- [ ] Configure private server secrets and Apps Script properties.
- [ ] Test booking writes, duplicate retries, inquiry-only rentals, lookup/cancellation, Admin APIs, EmailLog, notifications, daily reports, concurrency and throttling.
- [ ] Controlled email test only after explicit approval.

### P2 — Later separately approved delivery
- [ ] GitHub commit.
- [ ] Refresh existing Preview after backend and browser tests pass.
- [ ] PhonePe integration after merchant credentials and server-side verification are ready.
- [ ] Production Apps Script deployment, email activation, DNS/domain changes and website deployment only with explicit approval.

## 4. Verification evidence

- `npm run test:offline`: PASS, 9/9.
- Apps Script CJS suites: PASS, 8/8.
- Apps Script `Code.gs` syntax: PASS.
- JSON parse checks: PASS for package.json, firebase.json, appsscript.json and schema manifest.
- Public proxy explicit-action regression assertion: PASS.
- Apps Script missing/blank action regression assertions: PASS.
- `package-lock.json`: missing.
- `bun.lock`: 0 bytes, unusable.
- Dependency installation / lockfile generation: timed out.
- Full `npm run lint`: BLOCKED by missing `vite/client`.
- `npm run build`: not run; dependencies unavailable.
- Browser E2E and external staging: not run.

## 5. Safety confirmations

No Google Sheet was created or modified. No Apps Script deployment or authorization occurred. No email was sent. PhonePe was not activated. No GitHub commit, Preview refresh, production deployment or DNS change occurred.

**Conclusion:** Update 39 closes an explicit-action validation gap at both the Express public proxy and Apps Script webhook entry point, with regression checks. The project remains incomplete and is not production-ready.
