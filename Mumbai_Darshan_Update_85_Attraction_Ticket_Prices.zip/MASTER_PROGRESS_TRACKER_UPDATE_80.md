# Mumbai Darshan Bus Online — Master Progress Tracker
## Update 80 — Public Configuration Synchronization

**Date:** 21 November 2026  
**Source baseline:** Update 79  
**Current source package:** Update 80

## 1. Update 80 completed locally

- [x] Added read-only Express endpoint `GET /api/public-config`.
- [x] Added bounded per-IP rate limiting and 30-second server-side cache.
- [x] Added explicit Apps Script `PUBLIC_GET_CONFIG` action.
- [x] Public response allowlists only approved PackageOptions and PickupPoints fields; private tabs are not included.
- [x] Validates all 16 route/package price combinations, duplicate keys, integer prices, discount bounds and approved review status.
- [x] Normalizes route group names to the approved four route IDs.
- [x] Added browser-side schema validation and atomic application of the full price matrix.
- [x] Synchronizes package-specific route offers from the approved PackageOptions rows.
- [x] Synchronizes active/inactive flags for matching existing pickup points.
- [x] Booking Form and Pricing page now use package-specific Sheet offers when available.
- [x] App waits for the initial refresh attempt before mounting customer pages; on refresh failure, local fallback remains and a warning is shown.
- [x] Added public config static/runtime tests and updated readiness/release regression tests.
- [x] Updated detailed report, Project Index, and this tracker.

## 2. Validation

| Check | Result |
|---|---:|
| Offline runner | **47/47 PASS** |
| Public config endpoint/hydration contract | **23 assertions PASS** |
| Apps Script public config runtime | **9 assertions PASS** |
| TypeScript/TSX syntax transpilation | **35/35, 0 syntax errors** |
| JavaScript syntax | **PASS** |
| JSON parsing | **6/6 PASS** |
| Apps Script syntax | **PASS** |
| English-copy guard | **35 files PASS** |
| Full semantic `tsc --noEmit` | Blocked: missing `vite/client`; no `node_modules` |
| Vite build | Not run: dependencies absent |
| Browser E2E / mobile device | Not run |
| Live Apps Script / Sheets | Not run; owner-deferred |

## 3. Current public configuration coverage

| Data | Local source implementation | Limitation / live status |
|---|---|---|
| 16 route/package base prices | Implemented from PackageOptions | Live not tested |
| Package-specific offers | Implemented from PackageOptions | Live not tested |
| Existing pickup active flags | Implemented from PickupPoints | Match requires same route + name + sort order |
| Pickup times / landmarks / reporting / Maps URLs | Not synchronized | Not present in approved PickupPoints schema |
| New or renamed pickup stops | Not synchronized | Existing local content remains; schema lacks richer identity fields |
| Route activation/descriptions | Not synchronized | No approved Routes tab |
| Local rental rates | Not synchronized | Still local/default-backed |
| Outstation rental customer rates | Not synchronized | Still local/default-backed |
| Private Settings / AdminUsers | Not exposed | Intentionally excluded |

## 4. Remaining work and why

### P0 — Complete public configuration coverage
- [ ] Design approved public rental-rate data for Local Darshan and Outstation; expose customer rates only, never supplier cost/margin.
- [ ] Resolve missing pickup metadata/new pickup-stop representation. Do not expand or alter approved schema without owner approval.
- [ ] Decide source for route activation/descriptions and public business settings/WhatsApp number without exposing private Settings data.
- Reason: the current approved schema contains only PackageOptions and basic PickupPoints columns for public configuration; rental and richer pickup details are not fully represented.

### P1 — Build and browser validation
- [ ] Install dependencies from a reviewed lockfile on a network-enabled runner.
- [ ] Run semantic TypeScript check and Vite production build.
- [ ] Run browser E2E for all booking steps, price/offer changes, pickup activation, local/outstation rental, retry after refresh, duplicate acknowledgement and Admin view.
- [ ] Test mobile real-device behavior.
- Reason: no `node_modules`; `vite/client` type definitions unavailable.

### P2 — Owner-deferred live phase
- [ ] After approval, provide one Apps Script setup code to automatically create the workbook and approved schema; owner will not manually create Sheets.
- [ ] Configure secrets and deploy Apps Script only after approval.
- [ ] Configure backend hosting and `/api/**` routing only after approval.
- [ ] Test public config + booking + payment ledger + rental enquiry against a staging workbook.
- [ ] Do not activate live email until explicitly approved.

### P3 — Later delivery
- [ ] GitHub work after all local source tasks and audits are complete.
- [ ] Preview refresh, hosting/backend deployment, DNS and production deployment only after explicit approval.
- [ ] PhonePe/payment gateway only after merchant credentials and secure verification are ready.

## 5. Owner instructions preserved

- Do not remove Supabase until migration is fully tested and explicitly approved.
- No Google Sheet setup, Apps Script deployment, Preview refresh, GitHub, backend/hosting deployment, DNS or production deployment without explicit approval.
- No schema tab/header/column mutation without permission.
- Rental enquiry remains inquiry-only; no rental customer/owner email and no rental payment.
- PhonePe/payment integration remains deferred.
- Deliver updated ZIP, Project Index, detailed report and tracker after each completed local task.

## 6. Overall status

**Update 80 local source implementation is complete for the approved 16 package/route prices, package-specific offers and existing pickup active flags. Full public configuration is still partial. Project remains INCOMPLETE / NOT production-ready. Do not deploy.**
