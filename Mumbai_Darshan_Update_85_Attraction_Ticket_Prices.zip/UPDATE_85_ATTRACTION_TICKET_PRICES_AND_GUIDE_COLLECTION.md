# Update 85 — Attraction Ticket Prices & On-Bus Guide Collection

**Date:** 21 November 2026  
**Source baseline:** Update 84 — Public Content Accuracy & Attraction Collection Corrections  
**Scope:** Local source correction only. No live deployment or external service mutation.

## 1. Owner clarification — ₹165 Bollywood Museum ticket is retained

The owner explicitly reconfirmed that Bollywood Museum entry ticket is **₹165 per person**. This is the approved current listed rate and must not be removed, rounded, estimated, or replaced with “confirm at venue”. It remains owner-controlled and changes only when the owner updates the rate in Admin.

This clarification supersedes the Bollywood Museum tariff-removal decision recorded in Update 84. The current source catalogue retains `bollywood_museum.amount = 165` and the tour point retains `entryFee = 165`.

## 2. Six published rates now appear on the homepage

The homepage now contains a dedicated **Entry Tickets & Charges / Attraction Tickets & Charges** section, following the legacy live-site section pattern. It renders the six owner-listed charges in this order:

| Charge | Current rate | Collection rule |
|---|---:|---|
| Gateway of India Boat Ride | ₹210/person | Optional; Tour Guide collects on bus if customer chooses it |
| Prince of Wales Museum | ₹200/person | Optional; Tour Guide collects on bus if customer chooses it |
| Orama 11D Magic Show | ₹220/person | Optional; Tour Guide collects on bus if customer chooses it |
| Bollywood Museum | **₹165/person** | Optional; Tour Guide collects on bus if customer chooses it |
| Bandra–Worli Sea Link Toll | ₹10/person | Compulsory; Tour Guide collects on bus |
| Guide Charge | ₹50/person | Compulsory; Tour Guide collects on bus |

All six prices are per person. No attraction ticket, guide charge or Sea Link toll is added to the online bus package fare or ₹200 booking advance.

## 3. Customer-facing price source is Admin-controlled

- The homepage ticket list reads the six records from `StorageService.getExtraCharges()` rather than duplicating hardcoded amounts.
- The dedicated Attraction Tickets & Charges page renders every active priced optional ticket and all active compulsory charges from the same stored data.
- The route-pricing page's optional attraction list now uses the same stored rates.
- FAQ answers for the boat ride, guide charge and Sea Link toll read the current stored rates and no longer direct customers to a non-existent Step 5 attraction selector or venue-counter payment.
- Landmark cards direct customers to the central Attraction Tickets & Charges list instead of repeating static ticket prices that could become stale.
- Existing Admin **Change Rate** controls remain the way the owner changes a rate. The existing `StorageService.updateExtraCharge()` persistence path is retained; no new schema or external API is introduced.

## 4. Collection policy

- Optional attraction visits are decided after boarding. If the customer chooses an attraction, the Tour Guide collects its listed ticket amount inside the bus. If the customer skips it, no optional ticket charge is due.
- Guide Charge and Sea Link Toll are compulsory and collected separately by the Tour Guide inside the bus.
- These amounts are not part of the bus package fare, not part of the ₹200 advance and not collected through the website payment gateway.
- The booking summary continues to calculate compulsory guide/toll amounts from the current stored rates while keeping them outside the online booking total.

## 5. Files changed

- `src/App.tsx`
- `src/components/AttractionChargesPage.tsx`
- `src/components/BookingForm.tsx`
- `src/components/FAQPage.tsx`
- `src/components/Footer.tsx`
- `src/components/PricingPackagesPage.tsx`
- `src/components/TourPointsGrid.tsx`
- `src/components/admin/AdminLayout.tsx`
- `src/data/initialData.ts`
- `validation/test_public_content_accuracy_update84.cjs` (updated to assert the owner-confirmed ₹165 rate and dynamic public rate source)
- `validation/test_attraction_ticket_display_collection_update85.cjs`
- Project Index, Master Progress Tracker, validation results and this report

## 6. Validation

| Check | Result |
|---|---:|
| `npm run test:offline` | **51/51 PASS** |
| Update 85 attraction ticket / collection regression | **29 assertions PASS** |
| Public content / Bollywood ₹165 regression | **11 assertions PASS** |
| TypeScript / TSX / JS syntax transpilation | **33 files / 0 syntax errors** |
| Apps Script syntax | **PASS** (included in offline runner) |
| English-copy guard | **36 source files PASS** |
| JSON configuration parse | **6/6 PASS** |
| Static duplicate attraction prices in customer components | **None found** |
| Semantic `npm run lint` | **BLOCKED** — missing `vite/client` type definitions (`TS2688`) |
| `npm run build` | **BLOCKED** — Vite is not installed (`vite: not found`) |
| Browser / real-device mobile E2E | Not run |
| Live website / Sheets / Apps Script | Not changed or deployed |

## 7. Preserved business rules and deployment boundary

- Bus package prices remain Western/Central and Harbour/Kalyan as owner-approved in Update 83; offers remain OFF by default.
- Bhayandar East remains 6:15 AM pickup, with 6:00 AM reporting.
- ₹200 advance remains per booking, not per passenger.
- No attraction fees, guide fee or Sea Link toll were added to the online package total.
- Approved schema remains 17 tabs / 139 headers; no tab or column changed.
- Supabase remains in place pending full migration tests and explicit owner approval.
- No Google Sheet write/setup, Apps Script deployment, PhonePe/payment integration, GitHub, Preview refresh, Firebase Hosting, DNS, email activation or production deployment was performed.

**Overall status: Local Update 85 complete. Project remains INCOMPLETE / NOT production-ready. Do not deploy.**
