# Update 31 Release Notes

Completed in source: the four critical handler gaps identified by Update 30 — secure booking lookup, EmailLog, booking notifications/email retry, and cancellation/refund review.

- Booking lookup: POST only; Booking ID + registered mobile; rate-limited; minimal masked response; localStorage lookup removed.
- EmailLog: exact six-column append path for booking emails, retry, test email and daily report attempts.
- Notifications: exact eight-column idempotent lifecycle records; paid-booking emails only after trusted payment verification; Admin retry route and UI.
- Cancellation/refund: public verified request, duplicate prevention, verified-paid review cap, Admin status UI/API and manual-refund confirmation.

All seven automated test suites pass. Apps Script syntax passes. TypeScript/TSX syntax transpilation passes for 30 files.

Still pending: full type-check (`vite/client` dependency missing), Vite build (`vite` executable missing), browser E2E, live Apps Script/Sheets persistence and authorized MailApp delivery test. No new tabs/columns; no Google Sheet creation, deployment, GitHub commit, Preview update or production deployment.
