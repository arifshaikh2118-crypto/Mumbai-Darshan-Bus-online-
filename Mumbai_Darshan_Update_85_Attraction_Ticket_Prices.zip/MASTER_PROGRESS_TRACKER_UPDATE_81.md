# Mumbai Darshan Bus Online — Master Progress Tracker
## Update 81 — Centralized Local Darshan & Outstation Pricing

**Date:** 21 November 2026  
**Source baseline:** Update 80  
**Current source package:** Update 81

## 1. Completed in Update 81

- [x] Audited current `rental_vehicles` schema and found its seven fields cannot represent all quote components.
- [x] Chose a no-schema-change design: use existing `Settings` key/value row `PUBLIC_RENTAL_PRICING_JSON`.
- [x] Preserved exact approved schema: **17 tabs / 139 headers**.
- [x] Added defaults for six Local Darshan packages and sixteen Outstation vehicle classes, copied from current website source.
- [x] Added Apps Script validation for IDs, required labels, numeric values, flags, complete catalogue counts and Night DA = daily DA.
- [x] Added setup seeding only when the Settings key is missing; existing owner-edited values are preserved on rerun.
- [x] Added rental rates to the whitelisted public configuration response without exposing general Settings values.
- [x] Added server validation and authenticated Admin save endpoint.
- [x] Added Apps Script `ADMIN_SAVE_RENTAL_PRICING` handler with active Admin roster and private API secret checks.
- [x] Added Admin rental pricing editor under Private Fleet & Quotations.
- [x] Added Active + Published gating to customer-facing local and outstation vehicle lists.
- [x] Invalidated the public configuration cache after successful Admin save.
- [x] Added rental pricing runtime/config tests and updated setup/deployment documentation.

## 2. Validation

| Check | Result |
|---|---:|
| Offline validation runner | **48/48 PASS** |
| Full Update 43 validation suite | **48/48 PASS** |
| Rental pricing configuration tests | **15 assertions PASS** |
| Public configuration runtime | **9 assertions PASS** |
| Public configuration synchronization | **23 assertions PASS** |
| Apps Script syntax | PASS |
| TypeScript/TSX syntax transpilation | **32 files / 0 syntax errors** |
| Server TypeScript syntax transpilation | PASS |
| Exact approved schema | **17 tabs / 139 headers unchanged** |
| ZIP integrity | PASS |
| Full semantic `tsc --noEmit` | Not run: `node_modules` / `vite/client` missing |
| Vite production build | Not run: dependencies missing |
| Browser E2E / real mobile device | Not run |
| Live Sheets / Apps Script | Not run; owner-deferred |

## 3. Rental rates carried forward from current source

### Local Darshan (12 hours / 120 KM)
- Dzire AC ₹4,500; extra KM ₹15; extra hour ₹200.
- Ertiga AC ₹5,500; extra KM ₹18; extra hour ₹250.
- 17 Seater AC Tempo Traveller ₹9,500; extra KM ₹25; extra hour ₹400.
- 20 Seater AC Tempo Traveller ₹11,500; extra KM ₹28; extra hour ₹450.
- 40 Seater Luxury AC Bus ₹14,000; extra KM ₹35; extra hour ₹600.
- 49 Seater Luxury AC Bus ₹17,500; extra KM ₹40; extra hour ₹700.

### Outstation (300 KM/day minimum)
- Dzire ₹19/KM; Ertiga ₹22/KM; Innova ₹24/KM; Innova Crysta ₹25/KM; Tavera ₹23/KM; each with ₹400 daily DA.
- 13–14 Seater AC ₹29/KM, DA ₹1,200.
- 17 Seater AC ₹31/KM, Non-AC ₹28/KM; DA ₹1,300.
- 20 Seater AC ₹33/KM, Non-AC ₹30/KM; DA ₹1,400.
- 26 Seater AC ₹41/KM, Non-AC ₹36/KM; DA ₹1,600.
- 32–35 Seater AC ₹53/KM, Non-AC ₹45/KM; DA ₹2,200.
- 45–49 Seater AC ₹63/KM, Non-AC ₹54/KM; DA ₹2,500.
- Night DA is enforced equal to daily DA.

**Important:** These are the values already present in website source, not newly approved commercial rates. Owner review remains required before live publication.

## 4. Remaining work

### P0 — Public configuration follow-through
- [ ] Review source-derived Local Darshan and Outstation rates against the current owner rate card.
- [ ] Once owner approves the rates, create the Google Sheet automatically via the approved one-time setup function.
- [ ] Configure secrets and deploy Apps Script only after explicit approval.
- [ ] Verify Admin save → Settings JSON → public config → customer UI end-to-end in staging.
- [ ] Verify Active/Published off hides a vehicle and turning both on restores it.

### P1 — Build and browser validation
- [ ] Install dependencies on an approved network-enabled runner.
- [ ] Run full `tsc --noEmit` and Vite production build.
- [ ] Browser E2E for Local Darshan and Outstation rate editing, saving, cache invalidation and customer display.
- [ ] Real mobile-device checks for rental calculator layout and quotation display.

### P2 — Other remaining public configuration
- [ ] Pickup timing, landmark and Maps URLs are not in approved PickupPoints schema; review source/owner schema before extending.
- [ ] Public route activation/descriptions and other website settings remain to be audited.
- [ ] No unapproved sheet tabs/columns should be added.

### P3 — Owner-deferred
- [ ] Google Sheets setup / Apps Script deployment only after approval; provide one automatic setup code, no manual workbook creation.
- [ ] PhonePe/payment gateway deferred.
- [ ] GitHub only after local work is complete.
- [ ] Preview refresh, hosting/backend deployment, DNS and production deployment only after explicit approval.

## 5. Owner instructions preserved

- No manual Google Sheet creation.
- Keep existing schema at 17 tabs / 139 headers; no new tab/column was added in Update 81.
- Preserve Supabase until migration is fully tested and explicitly approved.
- Rental enquiries remain inquiry-only; no rental emails or rental payments.
- Keep PhonePe deferred.
- Do not deploy or mutate live services without explicit approval.
- Continue delivering a fresh complete ZIP, Project Index, detailed report, changed-file list and Master Progress Tracker after each update.

## 6. Overall status

**Update 81 local source implementation and offline validation are complete. Project remains INCOMPLETE / NOT production-ready. Do not deploy.**
