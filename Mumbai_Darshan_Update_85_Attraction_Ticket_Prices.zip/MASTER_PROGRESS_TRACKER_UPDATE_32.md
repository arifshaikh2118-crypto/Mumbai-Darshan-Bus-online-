# Mumbai Darshan Bus Online — Master Progress Tracker
## Update 32 — Daily Reports workflow implemented

**Date:** 11 November 2026  
**Source baseline:** Update 31  
**Current source package:** Update 32  
**Important:** Source implementation and local automated tests do not mean live Apps Script/Google Sheets operation or deployment.

## 1. Completed in source (cumulative)

| Workstream | Source status | Local tests | Live verification |
|---|---|---|---|
| 17-tab / 139-header approved schema | Complete | PASS | Pending |
| Booking 21-column write and payment ledger | Complete | PASS | Pending |
| Rental enquiry 19-column inquiry-only flow | Complete | PASS | Pending |
| Secure Admin login/session and protected APIs | Complete | PASS | Pending |
| Seven operational sheets Add/Edit/Delete | Complete | PASS | Pending |
| Final customer rental rates (existing +₹5 preserved) | Complete | PASS | Pending |
| Booking lookup privacy/security | Complete | PASS | Pending |
| EmailLog six-column workflow | Complete | PASS | Pending |
| Booking notifications and retry workflow | Complete | PASS | Pending |
| Cancellation/refund review workflow | Complete | PASS | Pending |
| Daily Reports eight-column aggregation | Complete | PASS | Pending |

## 2. Update 32 — Daily Reports details
- Added `ADMIN_GENERATE_DAILY_REPORT` with Apps Script secret and active `AdminUsers` authorization.
- Added authenticated server endpoint `POST /api/admin/reports/daily/generate`.
- Added Admin date picker and Generate Daily Report control. Manual generation writes the report only; it does not send an email.
- Exact eight approved columns retained: `report_date, total_bookings, confirmed_bookings, cancelled_bookings, total_customers, total_revenue, pending_payments, created_at`.
- Counts bookings by booking-created timestamp in Asia/Kolkata. Confirmed includes Confirmed/Completed; cancellations count Cancelled. Unique customers use distinct registered mobile numbers.
- Revenue includes only Verified/Paid/Success payment ledger rows, grouped by `verified_at` date.
- Pending payments count booking rows with Payment Pending/Pending Verification/Pending statuses.
- Upsert by report date prevents duplicate daily rows.
- Scheduled owner email contains aggregate metrics only (no customer PII); when live emails are disabled, the email is skipped and logged in EmailLog.
- `setupDailyReportTrigger()` is present but has NOT been run.

## 3. Cumulative local verification
- [x] Eight automated CJS test suites pass, including new `test_daily_reports.cjs`.
- [x] Schema harness validates exact 17 tabs / 139 headers and the new report aggregation/upsert rules.
- [x] Apps Script syntax check (`node --check` on temporary `.js` copy): PASS.
- [x] TypeScript/TSX syntax-only transpilation from Update 31 baseline was previously recorded as PASS; this update's full type-check is still blocked.
- [x] No schema tabs or columns added.
- [x] Rental Enquiry remains 19 columns and inquiry-only; no supplier cost/rate/margin fields.

## 4. Remaining work — exact list and order

### P0 — Remaining backend audit and reliability
- [ ] Review all remaining Apps Script handlers for duplicate writes, partial failures, locking, input validation and consistent Activity Log outcomes.
- [ ] Review EmailLog/notification failure recovery and scheduled trigger behavior in a controlled staging environment.
- [ ] Verify Daily Reports totals against actual staging Sheets records and confirm business interpretation of revenue/date cut-off.

### P1 — Build and browser validation (network runner remains deferred)
- [ ] Full `npm run lint` / `tsc --noEmit`; currently blocked by missing `vite/client` dependency.
- [ ] Vite production build; currently blocked because `vite` is not installed.
- [ ] Browser E2E for booking lookup privacy, rate limits and cancellation request.
- [ ] Admin browser tests for EmailLog, notifications, retries, refund review and daily report generation.
- [ ] Browser CRUD tests for all seven operational tabs.

### P2 — Staging Google Sheets / Apps Script
- [ ] Owner-approved final/staging stage: run `setupDatabase()` once; owner does not manually create a spreadsheet.
- [ ] Configure server-only `ADMIN_API_SECRET`, `ADMIN_PASSCODE`, `ADMIN_SESSION_SECRET`, Apps Script properties and Web App URL.
- [ ] Verify real booking, payment, rental enquiry, lookup, cancellation, EmailLog, notifications and Daily Reports rows.
- [ ] Verify exact 17 tabs / 139 headers remain intact.
- [ ] Install daily report trigger only after owner approval and email configuration.
- [ ] Perform controlled email delivery test only after explicit owner approval.

### P3 — Later delivery milestones
- [ ] Network-enabled GitHub runner workflow (owner deferred this for now).
- [ ] GitHub source commit after approval.
- [ ] Update existing Preview URL only after successful build/browser validation.
- [ ] PhonePe integration after merchant credentials and secure provider verification are ready.
- [ ] Final production deployment only after owner approval.

## 5. Safety and unchanged decisions
- Do not create, rename or delete approved schema tabs/columns without owner approval.
- Do not run `setupDatabase()` or deploy Apps Script until owner-approved staging/final setup.
- No scheduled trigger has been installed.
- Live email remains controlled by `ENABLE_LIVE_EMAILS`; no real email sent in this update.
- No automatic refund; PhonePe remains deferred.
- Rental enquiries remain inquiry-only; no customer/owner rental enquiry email.
- No supplier rate, cost, margin, profit or supplier-private workflow.
- Existing customer rental rates remain unchanged; do not add another ₹5.
- No GitHub, Preview or production update in this task.

## 6. Overall status

**Daily Reports is now implemented in source and passes local automated tests.** The next source task is the remaining Apps Script handler audit/reliability review. The project is still not live-ready until full type-check/build, browser E2E, staging Sheets tests, secure configuration and owner-approved deployment steps are completed.
