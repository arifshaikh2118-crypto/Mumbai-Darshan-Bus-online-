# Mumbai Darshan Bus Online — Project Index
## Latest update: Update 80 (21 November 2026)

### Update 80 — Public Configuration Synchronization
- Added server-owned read-only `GET /api/public-config` with bounded rate limiting and a 30-second server cache.
- Added Apps Script `PUBLIC_GET_CONFIG` allowlisted read from the approved `PackageOptions` and `PickupPoints` tabs only.
- Validates the complete 16-row route/package matrix, unique combinations, positive integer prices, discount bounds and approved review status.
- Browser hydration updates package base prices and package-specific offers, plus active flags for matching existing pickup stops.
- Booking Form and Pricing page now apply per-package/per-route offers from Sheet configuration.
- Initial customer pages wait for refresh attempt; if unavailable, local fallback remains and a visible warning is shown.
- Offline runner: **47/47 PASS**; config contract: **23 assertions PASS**; Apps Script config runtime: **9 assertions PASS**; TS/TSX syntax 35/35; Apps Script syntax PASS; English guard 35 files PASS.
- Full `tsc --noEmit` blocked by missing `vite/client`; Vite build and browser/mobile tests not run.
- **Partial scope only:** richer pickup metadata/new stops, route activation/descriptions, public business settings, local rental rates and outstation customer rates remain unsynchronized. Live Apps Script/Sheets not tested.
- No schema change, live Sheet creation, Apps Script deployment, PhonePe, GitHub, Preview refresh, hosting/DNS/production deployment.

**Overall: INCOMPLETE / NOT production-ready. Do not deploy.** See `UPDATE_80_PUBLIC_CONFIGURATION_SYNC.md` and `MASTER_PROGRESS_TRACKER_UPDATE_80.md`.

---

# Latest update — Update 79 (21 November 2026)

## Booking Form & Car Rental workflow audit / fix
- Found a critical Rental Enquiry integration defect: the browser payload omitted mandatory `rentalType`, so Apps Script rejected both Local Darshan and Outstation enquiries. Added the missing field without changing the approved 19-column schema.
- Improved Booking ID and Rental Enquiry ID collision resistance using Web Crypto UUID tokens (timestamped fallback retained); retries continue to reuse the original ID.
- Added rental client-side validation matching Apps Script limits for name, mobile, passengers, days, night DA, date, pickup and destination.
- Audited booking pricing, ₹200 advance per booking, separate ₹50/person guide and ₹10/person Sea Link toll, server-authoritative package price, booking/payment-ledger pairing, rollback, retry and duplicate acknowledgement.
- Verified local rental quote, outstation garage-to-garage distance / 300-KM-per-day minimum / DA calculation, Admin rental data mapping, authenticated status updates and WhatsApp follow-up.
- Added `validation/test_rental_submission_contract.cjs` (13 assertions) and expanded Apps Script rental runtime coverage to 29 assertions.
- Validation: **45/45 offline checks PASS**; TS/TSX syntax **36 files / 0 errors**; Apps Script syntax PASS; English-copy guard **35 files PASS**; ZIP integrity PASS.
- Full semantic `tsc --noEmit` remains blocked by missing `vite/client` because `node_modules` is absent. Vite build and browser/mobile E2E were not run.
- Public configuration remains browser-storage/default-backed. Customer-displayed route/package/offer prices and rental rates are not yet proven synchronized with the authoritative Sheets data; this is a known deferred blocker.
- No Google Sheet setup, Apps Script deployment, live writes, PhonePe, GitHub, Preview refresh, hosting/DNS/production deployment or schema change.

**Overall: INCOMPLETE / NOT production-ready. Do not deploy.** See `UPDATE_79_BOOKING_RENTAL_AUDIT_AND_FIX.md` and `MASTER_PROGRESS_TRACKER_UPDATE_79.md`.

---

# Previous update — Update 78 (21 November 2026)

## Customer enquiry handoff correction
- Group Booking and Contact Us no longer display false local-only submission success. Both now prepare explicit WhatsApp handoffs and clearly state the customer must press Send.
- Removed fake group reference / callback promise and unsupported five-minute Contact Us reply promise.
- Added `validation/test_customer_enquiry_whatsapp_handoff.cjs` (14 assertions).
- Offline validation: 44/44 PASS; TS/TSX syntax 32 files / 0 errors; Apps Script syntax PASS; English-copy guard 35 files PASS.
- Group enquiries are not saved server-side; no approved group-enquiry schema/API exists.
- No schema, pricing, payment, deployment or external service changes.

**Overall: INCOMPLETE / NOT production-ready. Do not deploy.**
