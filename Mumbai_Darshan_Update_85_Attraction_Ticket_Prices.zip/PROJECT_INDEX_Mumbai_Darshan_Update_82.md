# Mumbai Darshan Bus Online — Project Index
## Latest update: Update 82 (21 November 2026)

### Update 82 — Public Contact Details & Pickup Catalogue Guardrails
- Public About Us, Footer and Admin rental WhatsApp follow-up now use the configured business phone instead of hardcoded copies.
- Footer pickup route labels no longer display stale fixed counts.
- Pickup landing page total and route-wise counts derive from the active pickup catalogue.
- Admin PickupPoints Add/Delete/Route/Name/Sort Order mutations are guarded because the public config requires exact matching with the website's existing 71-point catalogue.
- Only Active/Inactive can be changed in the PickupPoints Sheet editor; warning explains that time, reporting time, landmark and Maps URL remain local website catalogue fields.
- Approved schema remains unchanged: 17 tabs / 139 headers.
- Offline validation 49/49 PASS; Update 43 validation suite PASS; new regression test 12 assertions PASS; TS/TSX syntax 32 files / 0 errors; Apps Script syntax PASS; English-copy guard 36 files PASS.
- Full semantic TypeScript check, Vite build, browser/mobile testing and live Sheets/Apps Script verification remain pending.
- No live deployment, Sheet creation, Apps Script deployment, PhonePe, GitHub, Preview refresh, hosting/DNS or production deployment.

**Overall: INCOMPLETE / NOT production-ready. Do not deploy.**

See `UPDATE_82_PUBLIC_CONTACT_AND_PICKUP_GUARDRAILS.md`, `MASTER_PROGRESS_TRACKER_UPDATE_82.md`, and `UPDATE_82_CHANGED_FILES.txt`.

---

## Previous update — Update 81
Centralized Local Darshan and Outstation rental pricing in protected Settings JSON without changing approved schema.

See `UPDATE_81_RENTAL_PRICING_CENTRALIZED.md`.

## Previous update — Update 80
Public package prices, offers and pickup activation status synchronized through server-owned public configuration.

See `UPDATE_80_PUBLIC_CONFIGURATION_SYNC.md`.
