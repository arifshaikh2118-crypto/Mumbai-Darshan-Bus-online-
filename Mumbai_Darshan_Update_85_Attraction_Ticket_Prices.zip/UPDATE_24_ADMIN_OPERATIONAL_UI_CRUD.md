# Update 24 — Admin Operational Sheets UI CRUD

Date: 11 November 2026

## Completed in source
- Added `OperationalSheetsManager` to the authenticated Admin Google Sheets section.
- Added Add, Edit and Delete controls for the seven already-approved editable tabs: `PickupPoints`, `PackageOptions`, `BookingDates`, `rental_vehicles`, `website_content`, `AttractionPoints`, and `AttractionTickets`.
- Each editor uses the exact existing approved column names; no sheet, tab, or column was added or renamed.
- Create/update requests call `/api/admin/operational/upsert` with the current Admin bearer session. Delete requests call `/api/admin/operational/delete` with the same session.
- Required stable keys are validated; keys are locked while editing existing rows to prevent accidental duplicate-row creation when the backend upsert matches on those keys.
- Boolean fields use explicit Yes/No controls; numeric fields use numeric inputs; travel dates use date inputs.
- Delete requires a confirmation prompt. After a successful write/delete, the UI refreshes protected Admin data from the backend.
- No browser-side Apps Script secret, supplier rate/cost, margin, or profit fields were added.
- `AdminUsers`, `Settings`, booking/payment/cancellation ledgers, rental enquiries, email logs, notifications, activity logs and reports remain outside generic editing.

## Verification performed
- Existing `test_schema_alignment.cjs`: PASS.
- Existing `test_admin_security.cjs`: PASS.
- Existing `test_rental_enquiry_policy.cjs`: PASS.
- Existing `test_customer_rate_model.cjs`: PASS.
- Existing `test_admin_operational_write_policy.cjs`: PASS.
- New `test_admin_operational_ui.cjs`: PASS (seven sheet configs, authenticated endpoints, stable key protection, refresh wiring, no supplier/margin fields).
- TypeScript compiler `transpileModule` syntax check: 26 TS/TSX files, 0 syntax diagnostics.
- Apps Script schema/security/write policy tests all pass.
- Full `tsc --noEmit` and Vite production build remain unverified: dependency installation (`npm install --legacy-peer-deps --no-audit --no-fund`) timed out, and `vite/client` types are unavailable without installed dependencies.
- ZIP integrity checked after packaging.

## Not performed / remaining
- No live Google Apps Script execution or Google Sheets read/write test.
- No production/staging spreadsheet created; `setupDatabase()` was not run.
- No real browser E2E test or save-refresh persistence test against a deployed Apps Script backend.
- No live secrets configured, Apps Script deployment, GitHub commit, Preview refresh, or production website deployment.

## Next steps
1. Complete dependency installation in a network-enabled/cloud runner; run `npm run lint` and `npm run build`.
2. Run browser E2E tests against a staging Apps Script deployment: create, edit, delete, refresh, verify persisted rows and activity_log entries for all seven tabs.
3. Review field-level business validation and permission/role rules before enabling live writes.
4. At the owner-approved final setup stage, configure server and Apps Script secrets, run the spreadsheet bootstrap once, and validate staging writes before live use.
