# Update 34 — Apps Script Reliability & Security Fixes

**Date:** 11 November 2026  
**Baseline:** Update 33 Final Handler Audit  
**Scope:** Resolve H1, H2, M1 and M2 findings in the existing Apps Script source; add regression coverage. No live services were invoked.

## Fixes implemented

### H1 — Privacy-safe Activity Log
- `doPost()` no longer serializes complete handler results into `activity_log.details`.
- Webhook log entries now contain only action, status, safe record identifier and a small aggregate summary (e.g. dataset count or report date).
- Error logging no longer writes raw exception text into the general activity log.
- Regression test injects customer name, phone, email and transaction reference into a simulated Admin result and verifies none appear in the activity summary.

### H2 — Server-authoritative booking fare and advance
- `handleNewBooking()` ignores browser-supplied `onlineBookingFare`, `grandTotal`, `amountInr`, `amount` and `advancePayable` as pricing authority.
- Fare is calculated from the exact package key + normalized route group in the approved `PackageOptions` sheet.
- Valid package keys are `non_ac_no_lunch`, `ac_no_lunch`, `non_ac_lunch`, `ac_lunch`; passenger count must be an integer from 1 to 60.
- Food counts must be non-negative integers. Lunch packages require food selections to sum to passenger count; non-lunch packages reject food selections.
- Advance is server-calculated as ₹200 per booking (capped at the fare); full-payment mode uses the complete calculated fare.
- When `PackageOptions` is empty during the already-owner-approved `setupDatabase()` bootstrap, the script seeds 16 approved route/package rows using the existing approved prices: Western/Central ₹200/₹300/₹400/₹500 and Harbour/Kalyan–Dombivli ₹250/₹350/₹450/₹550. Offers are OFF by default and each route/package row remains independently editable in the existing sheet.
- No tab or column was added or renamed. Existing populated PackageOptions data is not overwritten.

### M1 — Safe duplicate retry behavior
- If a booking exists and its payment ledger row exists, duplicate retry leaves it unchanged.
- If the booking exists but the ledger row is missing, handler returns `reconciliation_required`; it does not invent an advance or full-payment amount.
- Reason: the approved 21-column booking tab does not persist payment mode/advance separately. The missing original intent cannot be safely recovered from that tab. Admin reconciliation is safer than a guessed financial record.

### M2 — Serialized public attempt limiter
- Confirmed and documented the global `ScriptLock` acquired by `doPost()` before action dispatch and held until the handler completes.
- Public lookup/cancellation counters use CacheService read/check/write only inside that serialized webhook path; concurrent webhook requests cannot race the increment.
- Hashed identifier keys and TTL remain; no raw mobile or booking identifier is stored in the cache key.
- Regression checks assert the global lock is acquired before dispatch and the limiter's read/check/write sequence remains in place.

## Tests and verification
- All 8 existing CJS test suites pass after the fixes.
- `test_schema_alignment.cjs` now additionally covers seeded route/package pricing, browser fare/advance tampering, unknown package rejection, duplicate ledger partial-failure reconciliation, privacy-safe Activity Log summaries, limiter threshold and the serialized lock contract.
- Apps Script `Code.gs` syntax check via `node --check` on a temporary `.js` copy: PASS.
- Approved workbook schema remains exactly 17 tabs / 139 headers; `PackageOptions` remains 7 columns; no new tabs/columns.
- ZIP integrity check: PASS.

## Not performed / not claimed
- No `setupDatabase()` execution against a real spreadsheet; the setup seeding behavior was exercised only in the local mocked test harness.
- No Google Apps Script deployment, live Sheets write, live parallel-request load test, MailApp delivery, trigger installation, payment callback, PhonePe integration, website deployment, GitHub commit, or Preview URL update.
- Full Vite build / full TypeScript type-check and browser E2E remain separate release gates.

## Release status
**Source fixes complete; NOT production-ready yet.** Before live use, run the owner-approved isolated staging setup and verify PackageOptions seeding, pricing/offer parity with the customer booking UI, webhook concurrency under Apps Script, and real Sheets persistence. Keep PhonePe and live payment callbacks disabled until that verification and explicit owner approval.
