**Superseded pricing note (Update 85):** The owner explicitly reconfirmed Bollywood Museum entry at ₹165/person. Update 85 restores and retains this exact rate and supersedes the Update 84 decision to remove it from public copy. Current customer-facing rates are controlled manually in Admin.

# Update 84 — Public Content Accuracy & Attraction Collection Corrections

**Date:** 21 November 2026  
**Source baseline:** Update 83 — Uniform Bus Fare, Pickup-Time and Booking-Copy Corrections  
**Scope:** Local source audit and corrections only. No live deployment or external service mutation.

## 1. Corrections completed

### Sightseeing halt count
- The underlying 44-point catalogue contains **11 BUS_HALT** records and **33 NO_HALT** records.
- Updated the Places Covered summary from the stale 10 / 34 split to **11 / 33** so the public summary matches the actual catalogue.
- Individual landmark halt statuses were not changed.

### Bollywood Museum tariff accuracy
- The old ₹165 figure was presented as a current price in multiple public locations even though the site had no current venue verification date.
- Public Attraction Charges and Pricing pages now say **Confirm at venue** instead of presenting ₹165 as a current tariff.
- The initial tour-point record no longer publishes a fixed entry fee; it instructs staff to confirm the current venue tariff before quoting or collecting.
- The seeded extra-charge record now marks the tariff as not confirmed and carries a venue-verification notice.
- Added a narrowly scoped local-storage migration that removes only the exact old seeded ₹165 record (matching its old seed description). Custom Admin-edited prices/descriptions are preserved.

### Admin attraction collection recorder
- The tour guide offline collection form now accepts the actual per-person amount collected for each attraction on that tour.
- Per-attraction totals and the overall cash total use the entered rates rather than hardcoded ₹210 / ₹200 / ₹220 / ₹165 multipliers.
- Historical saved collection records are unchanged; their stored totals remain as originally recorded.

### Refund processing wording
- Corrected the policy page to describe the current manual UPI refund process and the published estimate of **5–7 working days after approval**.
- Removed claims about card/net-banking gateway refunds and an automatic SMS/email dispatch, which do not match the currently configured manual-payment workflow.
- The cancellation slab values themselves were not changed.

## 2. Owner-approved settings preserved

- All four pickup routes retain Non-AC ₹250 and AC ₹350 per person; lunch packages remain ₹450 / ₹550.
- Route offers remain OFF by default and future manual activation remains available.
- Bhayandar East remains **6:15 AM** pickup with 6:00 AM reporting.
- ₹200 advance per booking, ₹50/person shared-tour guide charge, ₹10/person Sea Link toll, meal choices, rental rules and inquiry-only rental workflow remain unchanged.
- Approved schema remains **17 tabs / 139 headers**.

## 3. Files changed

- `src/components/TourPointsGrid.tsx`
- `src/components/AttractionChargesPage.tsx`
- `src/components/PricingPackagesPage.tsx`
- `src/components/admin/AdminReportsTab.tsx`
- `src/components/LegalPoliciesPage.tsx`
- `src/data/initialData.ts`
- `src/services/storage.ts`
- `validation/test_public_content_accuracy_update84.cjs`
- `PROJECT_INDEX.md`
- `PROJECT_INDEX_Mumbai_Darshan_Update_84.md`
- `MASTER_PROGRESS_TRACKER_UPDATE_84.md`
- `UPDATE_84_PUBLIC_CONTENT_ACCURACY_AND_ATTRACTION_AUDIT.md`
- `UPDATE_84_CHANGED_FILES.txt`
- `UPDATE_84_FULL_VALIDATION_RESULTS.txt`

## 4. Validation

| Check | Result |
|---|---:|
| `npm run test:offline` | **50/50 PASS** |
| Update 84 public-content regression test | **11 assertions PASS** |
| TypeScript / TSX syntax transpilation | **32 files / 0 errors** |
| Apps Script syntax | **PASS** |
| English-copy guard | **36 files PASS** |
| JSON configuration parse | **6/6 PASS** |
| ZIP integrity | **PASS** |
| Semantic `npm run lint` | **BLOCKED** — missing `vite/client` type definitions (`TS2688`) |
| `npm run build` | **BLOCKED** — Vite is not installed (`vite: not found`) |
| Browser / real-device mobile E2E | Not run |
| Live website / Sheets / Apps Script | Not touched |

## 5. Remaining cautions

- Venue ticket tariffs other than the fixed tour fare should be verified with the venue before being represented as current. The Bollywood Museum ₹165 amount is no longer published as a confirmed current price.
- Existing historical offline attraction logs remain unchanged; new logs record the actual per-tour amounts entered by Admin.
- The refund slab values remain as previously published in the source. Only payment-channel and processing wording was corrected.
- Full semantic type-check, production build and browser/mobile E2E still require a dependency-complete environment.

## 6. Deployment boundary

No Firebase Hosting deployment, Preview refresh, DNS change, GitHub push, Google Sheet write, Apps Script deployment, PhonePe/payment gateway activation, live email, or production data change was performed. This is a local source ZIP only.

**Overall status: Local corrections complete for this update; project remains INCOMPLETE / NOT production-ready. Do not deploy.**
