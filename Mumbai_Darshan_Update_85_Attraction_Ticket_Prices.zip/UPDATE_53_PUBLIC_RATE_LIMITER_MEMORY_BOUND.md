# Update 53 — Public API rate-limiter memory bound

**Date:** 20 November 2026  
**Scope:** Local Express server source and offline regression tests only.

## Finding

The public booking lookup and cancellation endpoints used an in-memory `Map` keyed by action and client IP. Expired entries were ignored when the same key returned, but never removed when a client did not return. A stream of unique IP keys could therefore make the map grow for the lifetime of the server process.

## Changes

- Added `server/publicRateLimiter.ts` with a bounded in-memory limiter.
- Expired keys are pruned periodically (every 256 calls) and before admission when the map reaches capacity.
- The map is capped at 5,000 active keys. If it is full of unexpired keys, new keys fail closed rather than increasing memory use.
- Existing lookup and cancellation limits remain unchanged: 10 attempts per IP per 10 minutes for lookup, and 4 attempts per IP per hour for cancellation at the Express layer. Apps Script's independent per-booking limits remain unchanged.
- Action/IP key separation is preserved; lookup and cancellation do not share a bucket.
- Added `validation/test_public_rate_limiter_bounded.cjs` to execute the actual TypeScript helper and verify limits, independent action buckets, capacity, expiry cleanup and periodic pruning.

## Verification

- Offline validation runner: **23/23 PASS**.
- TypeScript/TSX/JS/JSX syntax transpilation: **33/33 PASS** (syntax-only; not a semantic type-check).
- JSON manifests: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full npm lint/build: **not run**; project dependencies are not installed in this workspace.
- Browser E2E: **pending**.

## Scope and limitations

The limiter remains in-memory and process-local. It resets on server restart and is not a distributed limiter across multiple server instances. The 5,000-key cap bounds memory for this process; when full of active keys, new unique keys are denied until entries expire and are pruned. A shared persistent limiter can be considered in a later infrastructure phase if multi-instance hosting is selected.

No customer UI, pricing, booking/rental business rule, approved 17-tab/139-header schema, Google Sheets, Apps Script deployment, payment, GitHub, Preview refresh, live email or production deployment was changed. All deferred external work remains deferred under the owner's sequencing instruction.

**Project status: INCOMPLETE / NOT production-ready.**
