# Mumbai Darshan Bus Online — Update 48
## Cancellation Reason / Google Sheets Formula-Injection Hardening
**Date:** 20 November 2026  
**Baseline:** Update 47 — Customer Text / Google Sheets Formula-Injection Hardening  
**Scope:** Local Apps Script source hardening and regression coverage only.

### Audit finding
The Update 47 sanitizer covered booking and rental enquiry writes, but the cancellation workflow also appends a customer-provided reason to `Booking Cancellations`. The public cancellation handler and authenticated Admin cancellation handler were still writing the reason directly. A formula-like reason could therefore be interpreted by Google Sheets.

### Fix applied
- Public cancellation request reason now passes through the shared `safeSheetText_()` helper with a 500-character limit.
- Authenticated Admin cancellation reason uses the same sanitizer and limit.
- No tab, header, data mapping, cancellation status, verified-payment calculation, refund workflow or notification behavior was changed.
- No UI or customer-facing wording was changed.

### Regression coverage
- Extended `validation/test_sheets_formula_injection.cjs` to assert both public and Admin cancellation reasons use the shared sanitizer.
- Existing helper tests continue to cover `=`, `+`, `-`, `@`, whitespace trimming, ordinary text, null values and maximum length.

### Validation results
- Offline validation runner: **18/18 PASS** (including Apps Script syntax and all regression checks).
- TypeScript/TSX syntax transpilation: **31/31 PASS**, zero syntax diagnostics. Syntax-only; not a semantic type-check.
- ZIP archive integrity: **PASS** after packaging.
- Full `npm run lint`, Vite production build and browser E2E: **pending**. Project dependencies are not installed; earlier npm registry access failed with DNS `EAI_AGAIN`.

### Not performed
No Google Sheet was created or modified. No Apps Script was deployed or executed. No payment/PhonePe integration, live email, GitHub commit/push/Actions, Preview refresh or production deployment was performed. These remain deferred under the owner's instructions.

### Status
Update 48 closes the cancellation-reason gap left after Update 47. This is a local source change only and does not make the project production-ready.
