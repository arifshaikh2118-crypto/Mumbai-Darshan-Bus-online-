# Update 54 — Admin login attempt store bounded

**Date:** 20 November 2026  
**Scope:** Local Express server source and offline regression tests only.

## Finding

Update 53 bounded the public lookup/cancellation limiter, but a separate `adminLoginAttempts` Map in the Admin login route still retained one entry per IP indefinitely. A large number of unique IPs could grow that Map for the lifetime of the server process.

## Changes

- Added `server/adminLoginAttemptStore.ts` with a bounded process-local store.
- Replaced the raw Admin login Map with `createAdminLoginAttemptStore(5000, 256)`.
- Expired records are pruned periodically (every 256 store calls) and before admission when the store reaches capacity. Records are retained while either the 15-minute attempt window or lockout period remains active.
- The store is capped at 5,000 entries. When full of active records, a new IP fails closed with HTTP 429 rather than growing memory. Existing IPs can still access their lockout state.
- Existing policy is unchanged: five failed attempts trigger a 15-minute lockout; expired windows reset before counting a new failure; successful login clears the IP entry.
- Added `validation/test_admin_login_attempt_store_bounded.cjs`, which executes the actual TypeScript helper and checks capacity, fail-closed admission, active lockout retention, expiry cleanup, periodic pruning and successful-login deletion.

## Verification

- Offline validation runner: **24/24 PASS**.
- Frontend TypeScript/TSX syntax transpilation: **30/30 PASS** (syntax-only).
- Server TypeScript syntax transpilation: **3/3 PASS** (`server.ts` plus both server helpers; syntax-only).
- JSON manifests: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full npm lint/build: **not run**; dependencies are not installed in this workspace.
- Browser E2E: **pending**.

## Scope and limitations

The store remains process-local/in-memory and resets on server restart. It is not a distributed limiter across multiple server instances. This update does not change the five-attempt/15-minute lockout policy, Admin credentials, session signing, UI, approved schema, APIs, Google Sheets, Apps Script, payment, GitHub, Preview, live email or production deployment.

**Project status: INCOMPLETE / NOT production-ready.**
