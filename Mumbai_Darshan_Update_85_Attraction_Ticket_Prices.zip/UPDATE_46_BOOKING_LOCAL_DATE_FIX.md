# Mumbai Darshan Bus Online — Update 46
## Booking Travel-Date Local Calendar Fix
**Date:** 20 November 2026  
**Baseline:** Update 45 — Rental Billing Rules & Local-First Workflow  
**Scope:** Local source audit and regression test only.

### Defect found
The booking form generated its default travel date and the date picker's minimum date with `Date.toISOString().slice(0, 10)`. `toISOString()` converts the value to UTC before formatting. In India, local midnight is still the previous UTC calendar day, so this could display or enforce the wrong date around day boundaries. The default “tomorrow” value could therefore appear as today.

### Fix applied
- Added `src/services/date.ts` with `toLocalDateInputValue(date)`.
- The helper formats year, month and day from the visitor's local calendar date (`getFullYear`, `getMonth`, `getDate`) without UTC conversion.
- Updated `BookingForm.tsx` so both the default tomorrow date and date-picker minimum use the helper.
- No booking schema, API contract, pricing, route, content, visual layout, payment or Google Sheets logic changed.

### Regression coverage
Added `validation/test_booking_local_date.cjs` with seven assertions covering both call sites, absence of UTC slicing in the booking form, local date fields, and an India-midnight example demonstrating the UTC/local date mismatch.

### Validation results
- Offline validation runner: **17/17 PASS** (includes Apps Script syntax and all regression checks).
- TypeScript/TSX syntax transpilation: **29/29 PASS**, zero syntax diagnostics. This is syntax-only, not a semantic type-check.
- Key JSON manifests: **4/4 PASS**.
- ZIP archive integrity: **PASS** after packaging.
- Full `npm run lint`, Vite production build and browser E2E: **not run / still pending**, because project dependencies are not installed and network package installation has previously failed.

### Deferred by owner instruction
No Google Sheet creation/modification, Apps Script deployment/execution, payment/PhonePe integration, live email, GitHub commit/push/Actions, Preview refresh or production deployment was performed. GitHub remains deferred until local source work is complete.

### Status
This update closes one confirmed booking-date defect. It does not make the project production-ready. Continue the remaining local audit before GitHub and later approved integrations.
