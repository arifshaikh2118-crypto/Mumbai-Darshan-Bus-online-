# Mumbai Darshan Bus Online — Master Progress Tracker

**Current package:** Update 36 — Deep Pre-External-Setup Cross-Check & Source Fixes  
**Baseline:** Update 35 Controlled Verification  
**Date:** 11 November 2026

## Completed source work

- [x] Approved 17-tab / 139-header schema manifest and bootstrap source retained.
- [x] Booking server-side pricing/advance calculation and duplicate partial-write reconciliation gate retained.
- [x] Rental enquiry remains inquiry-only; no owner/customer rental email.
- [x] Admin session, secret-gated Apps Script actions and active AdminUsers roster retained.
- [x] Public lookup/cancellation privacy and throttling retained.
- [x] EmailLog, notifications, cancellation/refund review and Daily Reports source retained.
- [x] Update 33 reliability findings fixed in Update 34 and offline verified in Update 35.
- [x] Update 36: all five protected Admin Apps Script actions now dispatch through `handleAdminApiAction_`.
- [x] Update 36: legacy public booking/rental status mutation actions fail closed.
- [x] Update 36: public `/api/sync-sheets` proxy restricted to booking, rental enquiry and ping actions.
- [x] Update 36: public proxy pinned to exact server-side `GOOGLE_APPS_SCRIPT_URL`.
- [x] Update 36: email retry and booking/rental status helper calls use authenticated Admin endpoints.
- [x] Update 36: website email-test control no longer attempts disabled public `TEST_EMAIL` action.
- [x] Update 36: current setup/deployment guides and `.env.example` refreshed; obsolete instructions superseded.

## Update 36 verification

| Check | Result |
|---|---|
| 8 Apps Script CJS suites | PASS 8/8 |
| Apps Script syntax | PASS |
| TypeScript/TSX syntax transpilation | PASS, 29 files / 0 syntax diagnostics |
| Schema regression | PASS, 17 tabs / 139 headers |
| ZIP integrity | PASS |
| Full `npm run lint` | PENDING — dependency installation timed out |
| Vite production build | PENDING — dependencies unavailable |
| Browser E2E | PENDING |
| Google Sheets staging | PENDING — owner-approved setup required |
| Apps Script live concurrency | PENDING |

## Remaining work before any external deployment

### P0 — Frontend build/runtime
- [ ] Run clean `npm install --legacy-peer-deps --no-audit --no-fund` on network-enabled runner.
- [ ] Pass `npm run lint` and `npm run build`.
- [ ] Resolve all semantic TypeScript/build errors; syntax-only transpilation is not a substitute.
- [ ] Run browser E2E for booking submit/retry, rental inquiry, lookup, cancellation, Admin login/session expiry, Admin status updates, email retry, refunds, daily report and all seven operational CRUD tabs.
- [ ] Test mobile booking flow and verify the rental enquiry panel remains immediately below the booking form.

### P0 — Hosting architecture
- [ ] Choose/confirm where the Express server runs. Current `firebase.json` is static-only and does not route `/api/*` to Express.
- [ ] If Firebase Hosting is retained, configure an explicitly approved Cloud Run backend rewrite using the actual service ID and region; do not guess values.
- [ ] Verify the existing Preview architecture can reach the protected backend before refreshing the same Preview URL.

### P1 — Google Sheets / Apps Script staging (owner approval only)
- [ ] Run `setupDatabase()` once against an isolated staging project; owner does not manually create a spreadsheet or headings.
- [ ] Confirm exact 17 tabs / 139 headers and 16 route/package rows with offers OFF.
- [ ] Configure private server environment and Apps Script Script Property secrets.
- [ ] Test real booking/payment-pending ledger writes, duplicate retries, rental inquiry-only writes, lookup/cancellation, Admin reads/mutations, EmailLog, notifications and daily reports.
- [ ] Test concurrent requests and limiter behavior against live Apps Script.
- [ ] Owner-approved controlled email test; only then decide on trigger installation.

### P2 — Later separately approved delivery
- [ ] GitHub source commit after build/tests and approval.
- [ ] Refresh the existing PageShare Preview URL only after backend connectivity and browser E2E pass; do not create a new site.
- [ ] PhonePe provider integration after merchant credentials and server-side signature/status verification.
- [ ] Production Apps Script deployment, email activation and website deployment only with explicit approval.

## Preserved rules

- No changes to approved sheet tabs/columns without permission.
- No supplier cost/rate/margin/private garage information in customer-facing code.
- No extra ₹5 rental-rate markup; approved customer rates remain as-is.
- ₹200 advance is per booking, not per person.
- No automatic refund; PhonePe remains deferred.
- No rental enquiry emails; follow up via WhatsApp.
- No live Sheet, Apps Script, GitHub, Preview or production action has been executed in Update 36.

**Overall:** Source-level preflight corrections are complete. Build, browser, hosting architecture and isolated live staging remain release blockers. Not production-ready.
