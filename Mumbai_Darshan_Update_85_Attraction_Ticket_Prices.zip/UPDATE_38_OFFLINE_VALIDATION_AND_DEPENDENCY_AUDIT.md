# Update 38 — Offline Validation Runner & Dependency Readiness Audit

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 37 — Release-Gate Continuation & Hosting Architecture Correction  
**Release status:** INCOMPLETE — this update improves repeatable offline checks; it does not complete the website or approve deployment.

## 1. Work completed in Update 38

| # | Work item | Result |
|---|---|---|
| 1 | Re-ran all eight bundled Apps Script CJS regression suites | PASS, 8/8 |
| 2 | Checked `google-apps-script/Code.gs` syntax with Node.js | PASS |
| 3 | Added dependency-free `validation/run-update38-checks.mjs` runner | Completed |
| 4 | Added `npm run test:offline` script | Completed |
| 5 | Documented the scope and limitations of offline checks in README | Completed |
| 6 | Audited dependency lockfiles | Finding recorded: no `package-lock.json`; `bun.lock` is empty |
| 7 | Ran the new offline runner end-to-end | PASS, 9/9 |
| 8 | Updated Master Progress Tracker and packaged Update 38 ZIP | Completed; ZIP integrity verified |

## 2. What was not completed — and why

| # | Work item | Status | Exact reason |
|---|---|---|---|
| 1 | Generate a valid npm dependency lockfile | Not completed | `npm install --package-lock-only --ignore-scripts --no-audit --no-fund --legacy-peer-deps` did not finish before the execution environment interrupted it. No `package-lock.json` was created. The existing `bun.lock` is zero bytes and is not a usable lockfile. |
| 2 | Install project dependencies | Not completed | `node_modules` is absent. Earlier full installation attempts timed out; the current environment did not complete lockfile resolution either. |
| 3 | Full TypeScript lint/type-check | Not completed | `tsc --noEmit` fails before checking project code because `vite/client` type definitions are unavailable without installed dependencies. |
| 4 | Vite production build | Not completed | Vite and its project dependencies are not installed in this working copy. |
| 5 | Browser E2E | Not completed | No browser E2E runner is available in this environment; no current production bundle exists to test. |
| 6 | Express hosting target and `/api/**` connectivity | Not completed | Actual approved hosting target, Cloud Run service ID and region are not supplied in the project. |
| 7 | Google Sheets / Apps Script live staging | Not completed | Requires an isolated staging project and explicit owner approval; no external service was contacted. |
| 8 | GitHub, Preview, production, DNS, PhonePe and live email | Not completed | These remain separately approved later-stage actions. No such action was authorized or performed. |

## 3. What remains to be done

### P0 — Dependency and build readiness
- [ ] On a network-enabled runner, generate and commit a valid `package-lock.json` using the approved npm install flags.
- [ ] Review the lockfile and verify it is non-empty and reproducible.
- [ ] Run `npm ci` (or the explicitly approved install workflow) from the lockfile.
- [ ] Pass `npm run lint`.
- [ ] Pass `npm run build`.
- [ ] Fix all semantic TypeScript and build errors.

### P0 — Hosting and browser verification
- [ ] Confirm the approved Express hosting platform.
- [ ] If Firebase Hosting + Cloud Run is selected, confirm the real Cloud Run service ID and region and configure the API rewrite before SPA fallback.
- [ ] Verify `/api/*` reaches Express.
- [ ] Run browser E2E for booking, rental enquiry, lookup, cancellation, Admin authentication/session expiry, protected mutations, email retry, refunds, reports and seven operational CRUD tabs.
- [ ] Verify mobile booking flow and rental enquiry panel position.

### P1 — Isolated staging (owner approval required)
- [ ] Run `setupDatabase()` once in isolated staging.
- [ ] Verify approved 17-tab / 139-header schema and seed data.
- [ ] Configure private secrets and Apps Script properties.
- [ ] Test writes, duplicate retries, inquiry-only rentals, lookup/cancellation, Admin APIs, notifications, EmailLog, reports, concurrency and throttling.
- [ ] Controlled email test only after explicit approval.

### P2 — Later separately approved delivery
- [ ] GitHub commit.
- [ ] Existing Preview refresh after API and browser tests pass.
- [ ] PhonePe integration after merchant credentials and server-side verification are ready.
- [ ] Production Apps Script, email activation, DNS and website deployment only with explicit approval.

## 4. How to run the new offline checks

From the project root:

```bash
npm run test:offline
```

This invokes the Node.js runner directly and does not require `node_modules`. It executes the eight bundled Apps Script CJS suites and checks `Code.gs` syntax. It does **not** replace frontend lint, production build, browser E2E, or live staging.

## 5. Safety confirmations

No Google Sheet was created or modified. No Apps Script deployment or authorization occurred. No email was sent. PhonePe was not activated. No GitHub commit, Preview refresh, production deployment or DNS change occurred.

## 6. Verification evidence

- Offline runner: PASS, 9/9 checks.
- Eight Apps Script CJS suites: PASS, 8/8.
- Apps Script `Code.gs` syntax: PASS.
- Lockfile audit: `package-lock.json` absent; `bun.lock` is empty.
- Lockfile generation attempt: interrupted before completion; no lockfile output.
- Full TypeScript check: BLOCKED by missing `vite/client`.
- Vite build and browser E2E: not run.

**Conclusion:** Update 38 adds repeatable dependency-free validation and documents a newly confirmed lockfile blocker. The project remains incomplete and is not production-ready.
