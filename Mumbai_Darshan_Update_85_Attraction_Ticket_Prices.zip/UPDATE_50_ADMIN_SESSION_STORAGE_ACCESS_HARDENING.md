# Update 50 — Admin session-storage access hardening

**Date:** 20 November 2026  
**Scope:** Local source-only Admin security/resilience fix.

## Finding

Update 49 made the login write fail closed when `sessionStorage.setItem()` throws. A follow-up audit found direct `sessionStorage.getItem()` and `removeItem()` calls still existed in Admin startup revalidation, data loading, daily report generation, status actions, operational sheet edits, rental/cancellation actions, notifications, and logout. If browser storage access itself throws, these paths could raise uncaught errors instead of failing cleanly.

## Changes

- Added `src/services/adminSession.ts` with guarded `readAdminSessionToken()`, `storeAdminSession()`, and `clearAdminSession()` helpers.
- Token writes are verified by reading the token back before login is considered successful.
- Token reads return `null` on storage exceptions; callers therefore send no token and remain unauthorized.
- Session cleanup is best-effort and never throws into the UI.
- Replaced direct storage access throughout AdminLayout and all Admin action panels with the guarded helper.
- Updated the Update 49 regression test to assert the helper-based fail-closed flow and added `validation/test_admin_session_storage_access_fail_closed.cjs`.

## Validation

- Offline validation runner: **20/20 PASS**.
- TypeScript/TSX syntax transpilation: **30/30 PASS** (syntax-only; not a semantic type-check).
- Direct `sessionStorage` access is now isolated to the guarded helper service.
- Full npm lint/build and browser E2E remain pending because dependencies are not installed and network-enabled validation remains deferred.

## Not changed / not performed

- No UI layout, copy, prices, booking rules, rental rules, schema headers, API routes, or Apps Script logic changed.
- No Google Sheet creation/modification, Apps Script deployment, payment integration, email activation, GitHub operation, Preview refresh, or live deployment performed.
- Project remains **not production-ready** until full build/lint, browser E2E, hosting architecture confirmation, and later approved integration testing are complete.
