# Update 19 — Admin Google Sheets Integration

## Implemented
- Protected admin dataset retrieval now feeds the booking and rental enquiry panels after authentication.
- Booking status and rental enquiry status changes use signed-session Express endpoints and private-secret Apps Script actions.
- Apps Script re-checks active AdminUsers role and validates exact status values before changing the approved sheet cell. An unpaid booking cannot be marked Confirmed or Completed; payment must first be Advance Paid or Fully Paid.
- Activity log entries are created for the changes.
- Removed the default passcode hint from the login screen.
- Rental quotation/supplier-cost writes are intentionally blocked because those fields do not exist in the approved rental_enquiry schema.

## Validation
- Apps Script schema and workflow harness: PASS.
- Admin security regression harness: PASS.
- TypeScript syntax transpilation: PASS for changed TSX/server files.
- Full dependency-based typecheck/build: NOT VERIFIED because npm dependency installation timed out and `vite/client` was unavailable.

## Not performed
No live Apps Script deployment, Google Sheets access, credential configuration, GitHub commit, Preview refresh, or production deployment.
