# Update 63 — Booking retry recovery after page refresh

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 62 — Rental Enquiry ID Acknowledgement  
**Scope:** Local frontend/storage source and offline regression test only.

## Issue found

Update 62 confirmed the rental enquiry ID, but the customer booking retry reference was held only in React component state. If a customer submitted a booking, Google Sheets acknowledgement failed, and the page was refreshed, the component state was lost. The customer could not resume the exact same pending booking from the refreshed page.

## Changes made

1. **Stable retry pointer**
   - Added a versioned browser-storage key `mdb_pending_booking_retry_v1`.
   - Store only the pending Booking ID in that key; the existing local booking record remains the source for the booking details.
   - Added guarded helpers to save, restore and clear the pending ID.
   - Restore ignores missing local records and records already marked `syncedToGoogleSheets`.

2. **Recovery after refresh**
   - Booking form checks for an unresolved pending Booking ID on mount.
   - When found, it opens a dedicated recovery view with the original Booking ID, customer, travel date, route, pickup, package, passenger count and stored fare/advance/balance.
   - Customer can retry the same booking without rebuilding the original form state.
   - The retry path bypasses fresh-form validation only when an existing pending booking object has been restored; it reuses that exact object and does not call `createBooking()` again.

3. **Clear only after acknowledgement**
   - The retry pointer is saved before the Sheets sync request.
   - It is cleared only after the backend returns an accepted success/duplicate response with the exact matching Booking ID.
   - Clear operation checks the ID before deleting, so it cannot accidentally remove a different pending reference.
   - Existing fail-closed booking acknowledgement and payment-pending status behavior remain in place.

4. **Regression coverage**
   - Added `validation/test_booking_retry_recovery.cjs` with 12 source-contract assertions for pointer persistence, restore behavior, stale/synced pointer cleanup, same-ID retry, no new booking creation, and clear-after-acknowledgement.

## Verification

- Offline validation runner: **30/30 PASS**.
- TypeScript/TSX syntax transpilation: **35/35 PASS**, zero syntax diagnostics (syntax-only; not a semantic type-check).
- Apps Script syntax: **PASS** (unchanged source).
- JSON manifests/configuration: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full `npm run lint` / semantic type-check and `npm run build`: **not run**, because `node_modules` is not installed in this local project folder.
- Browser E2E and actual browser refresh/retry testing: **pending**.
- Live Google Sheets / Apps Script integration: **not tested**; setup and deployment remain deferred.

## Scope boundaries

- No Google Sheet creation, Apps Script deployment/execution, payment gateway, PhonePe, GitHub commit/push, Preview refresh, live email, or production deployment.
- No change to approved 17-tab / 139-header schema, booking fare, ₹200 advance rule, route/package pricing, attraction selection-on-bus rule, rental policy, or Admin access policy.
- The pointer is browser-local. Clearing browser site data, using another device/browser, or local storage being unavailable can still prevent automatic recovery; customers should retain the displayed Booking ID. Cross-device recovery requires the later server-backed Sheets lookup flow.

**Overall status: INCOMPLETE / NOT production-ready.** Local retry-after-refresh recovery is implemented and source-tested, but browser E2E, full build, and live integration remain outstanding.
