# Update 23 — Secure Admin Operational Write APIs

## Completed in source
- Added server-proxied, authenticated Admin API routes for operational record upsert and delete.
- Added Apps Script actions that independently verify the server-side `ADMIN_API_SECRET` and active `AdminUsers` roster before every write.
- Editable tabs are allowlisted to: `PickupPoints`, `PackageOptions`, `BookingDates`, `rental_vehicles`, `website_content`, `AttractionPoints`, and `AttractionTickets`.
- Every write validates the exact existing approved headers via `getRequiredSheet_`; unknown columns, unapproved tabs, missing keys and schema mismatch fail closed.
- Upsert updates an existing matching record or appends a new record using only approved columns. Delete requires the complete stable key for that tab.
- Every create/update/delete attempt that succeeds is recorded in `activity_log`.
- `AdminUsers`, `Settings`, booking/payment/cancellation/rental enquiry ledgers, `EmailLog`, notifications, activity log, and daily reports remain non-editable through these generic endpoints.
- No supplier price/cost/margin fields, no extra sheets, and no schema changes.

## Verification performed
- Existing schema alignment test: PASS.
- Existing Admin security test: PASS.
- Existing Rental Enquiry policy test: PASS.
- Existing final customer-rate model test: PASS.
- New Admin operational write policy static test: PASS.
- Apps Script `Code.gs` JavaScript syntax check: PASS.
- ZIP integrity: checked after packaging.

## Not completed / not verified
- Admin UI forms/buttons for create/edit/delete are not yet wired to these new endpoints. The APIs are implemented; this update does not claim end-to-end UI CRUD.
- Full TypeScript type-check and Vite production build not run because dependencies are not installed in the workspace.
- No live Google Apps Script execution, Google Sheets read/write, Apps Script deployment, live secrets configuration, GitHub commit, Preview refresh, or production deployment.
- No deletion or mutation of actual user data was performed.

## Next work
1. Build Admin UI editors for the seven allowlisted tabs and connect them to the authenticated endpoints.
2. Add browser-level tests for create/edit/delete and refresh persistence.
3. Complete full dependency installation, TypeScript check, Vite production build, and browser QA.
4. At the owner-approved final setup stage, configure secrets and run the Apps Script bootstrap against the intended new spreadsheet; test staging writes before any live use.
