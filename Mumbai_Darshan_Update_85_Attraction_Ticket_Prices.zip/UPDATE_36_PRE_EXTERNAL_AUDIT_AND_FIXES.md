# Update 36 — Deep Pre-External-Setup Cross-Check & Source Fixes

**Date:** 11 November 2026  
**Baseline:** Update 35 Controlled Verification  
**Scope:** Review and repair source-level issues that should be completed before Google Sheets setup, Apps Script deployment, GitHub publishing or Preview refresh. No external service was contacted.

## Findings discovered and fixed

### P0 — Admin Apps Script actions were not wired into `doPost`
The Express server already called the protected Apps Script actions for booking status, rental status, email retry, cancellation creation and refund status, and `handleAdminApiAction_` implemented them. However, the `doPost` switch did not route those five `ADMIN_*` actions to the protected handler. The server-side routes would therefore receive `Unknown action` rather than execute the intended Admin operation.

**Fix:** Added all five action cases to the authenticated Admin dispatch branch. The shared secret and active `AdminUsers` checks remain mandatory inside `handleAdminApiAction_`.

### P0 — Public webhook allowed legacy Admin mutation actions
`doPost` previously routed `UPDATE_BOOKING_STATUS` and `UPDATE_RENTAL_STATUS` directly to their old handlers, bypassing the new authenticated Admin API path.

**Fix:** Both public actions now fail closed with instructions to use the authenticated Admin API. The server public proxy accepts only `NEW_BOOKING`, `NEW_RENTAL_ENQUIRY`, `CAR_RENTAL`, and `PING_TEST`.

### P0 — Generic Sheets proxy accepted caller-selected Apps Script deployment URLs
The public `/api/sync-sheets` route accepted a webhook URL from the request body. Although hostname/path validation existed, callers could choose any Apps Script deployment under the permitted hostname.

**Fix:** Proxy requests must now match the exact server-side `GOOGLE_APPS_SCRIPT_URL`; URL validation is applied to that server-configured value. Arbitrary request-selected Apps Script URLs are rejected.

### P1 — Admin email retry still used the disabled public action
The Admin UI's retry control called `RETRY_EMAILS` through the public proxy, while Apps Script intentionally rejected public retry actions.

**Fix:** `StorageService.retryBookingEmail` now calls the authenticated `/api/admin/bookings/retry-emails` route with the current Admin bearer token. The Admin UI supplies the token. Booking/rental status helper methods were also moved to their protected Admin routes.

### P1 — Website email-test control contradicted the security policy
The UI attempted to send `TEST_EMAIL` through the public webhook even though public email tests are disabled.

**Fix:** The control now explains that the controlled email test is owner-run from the Apps Script editor at the approved final stage. No email was sent.

### P1 — Setup documentation was materially stale
The older deployment instructions described 24/25 tabs, legacy tab names, built-in passcodes, public Admin mutations, GET lookup, and public email testing. Those steps no longer matched the 17-tab schema or security architecture.

**Fix:** Replaced the current Apps Script deployment and setup guides and refreshed README and `.env.example`. Historical audit files remain in the package as historical records; the current guide explicitly supersedes them.

## Verification completed

- All 8 existing Apps Script CJS suites: PASS.
- Apps Script `Code.gs` Node syntax check: PASS.
- TypeScript/TSX syntax transpilation: 29 source files, 0 syntax diagnostics.
- ZIP integrity: PASS.
- Existing schema test confirms 17 tabs / 139 headers and approved 7-column `PackageOptions` structure.
- Added static regression assertions for protected Admin dispatch, disabled public mutations, public proxy action allowlist and server-configured webhook URL matching; `test_admin_security.cjs` passes.

## Remaining blockers — do not mark complete

1. `npm install --legacy-peer-deps --no-audit --no-fund` timed out in this environment. `node_modules` is not available; therefore full `npm run lint` and `npm run build` remain unverified.
2. No browser E2E runner or current built React bundle is available here. Admin/browser flows and mobile layout remain to be tested.
3. `firebase.json` is static Hosting configuration only and rewrites all routes to `index.html`; it does not route `/api/*` to the Express server. Before any Firebase Preview/production deployment, the hosting architecture must explicitly connect the Express API (for example via an approved Cloud Run backend and Firebase Hosting rewrite) or choose a host that runs the Express server. A service ID/region must not be guessed.
4. Real Google Sheets staging, Apps Script Web App execution, ScriptLock concurrency, EmailLog delivery, trigger behavior and `PackageOptions` seed verification remain pending owner-approved staging.
5. The original `Google app script codegx.xlsx` binary remains unavailable; the bundled workbook is a reconstructed reference from the schema audit snapshot.
6. GitHub source commit, existing Preview refresh, PhonePe, email activation, trigger installation and production deployment remain later, separately approved steps.

## Safety confirmations

- No Google Sheet was created or modified.
- `setupDatabase()` and `setupDailyReportTrigger()` were not run.
- No Apps Script deployment or authorization was performed.
- No email was sent; `ENABLE_LIVE_EMAILS` was not changed.
- No PhonePe/payment gateway or refund action was activated.
- No GitHub commit, Preview publication or production deployment was performed.
- Existing Update 35 ZIP was preserved; Update 36 is a new package.

**Release status: source-level route/security fixes complete; NOT production-ready.**
