# Update 56 — JSON request body size hardening

**Date:** 20 November 2026  
**Scope:** Local Express server source and offline regression coverage only.

## Finding

The Express application parsed JSON request bodies with a 10 MB limit. The public `/api/sync-sheets` route applied a stricter 64 KB serialized payload check, but only after Express had already parsed the body. An oversized request could therefore consume parser memory before the route rejected it.

## Changes

- Reduced the global `express.json()` limit from 10 MB to **256 KB**.
- Kept the public Sheets sync proxy's stricter **64 KB** payload limit unchanged.
- Added post-route Express error middleware that returns JSON HTTP **413** for oversized request bodies and JSON HTTP **400** for malformed JSON.
- Added `validation/test_json_body_size_limit.cjs` to guard the parser limit, removal of the old 10 MB setting, and both error responses/middleware placement.

## Verification

- Offline validation runner: **26/26 PASS**.
- TypeScript/TSX/server helper syntax transpilation: **33/33 PASS**, zero syntax diagnostics.
- JSON manifests: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full npm lint/build: **not run** because project `node_modules` is absent.
- Browser E2E: **pending**.

## Scope and limitations

No UI, pricing, booking/rental business rule, approved Google Sheets schema, Apps Script source/deployment, payment flow, GitHub workflow execution, Preview refresh, live email, DNS or production deployment was changed. No external system was touched.

The 256 KB limit is an application-level parser safeguard. It does not replace reverse-proxy/load-balancer request limits, and the existing per-IP rate limiters remain process-local rather than distributed.

**Project status remains INCOMPLETE and NOT production-ready.**
