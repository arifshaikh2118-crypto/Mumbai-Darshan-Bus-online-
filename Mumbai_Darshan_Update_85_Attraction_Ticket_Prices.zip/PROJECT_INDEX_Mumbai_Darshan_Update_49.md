# Latest update — Update 50 (20 November 2026)

## Admin session-storage access now fails closed across the UI
- Update 49 made login fail closed if session storage writes fail. Update 50 extended protection to every Admin session-storage read and cleanup path.
- Added `src/services/adminSession.ts` with guarded token read, verified token write, and best-effort cleanup helpers. Admin startup revalidation, protected data load, report/status actions, operational editor, rentals, cancellations, notifications and logout now use these helpers.
- Added `validation/test_admin_session_storage_access_fail_closed.cjs` and updated the Update 49 regression test to validate helper-based login.
- Offline validation: **20/20 PASS**. TypeScript/TSX syntax transpilation: **30/30 PASS**. ZIP integrity: **PASS**.
- No UI layout, pricing, business rule, schema, API, payment or external integration change.
- Full npm lint/build and browser E2E remain pending; project is not production-ready.
- Google Sheets, Apps Script deployment, payment, live email, GitHub and production deployment remain deferred by owner instruction.


# Mumbai Darshan Bus Online — Master Progress Tracker

**Current package:** Update 50 — Admin Session Storage Access Hardening  
**Baseline:** Update 49 — Admin Session Storage Fail-Closed Fix  
**Date:** 20 November 2026

## Owner sequencing instruction

- [x] GitHub work must wait until the complete project files and remaining local work are finished.
- [x] Updates 44–45 did not commit/push code, run GitHub Actions, refresh Preview or deploy.
- [x] Google Sheets creation/setup, Apps Script deployment, payment integration and all live deployment are deferred by owner instruction.
- [x] Owner will not manually create a Google Sheet; the later complete Apps Script setup code must create the spreadsheet and approved tabs automatically.
- [ ] GitHub/network-enabled build phase only after local source and project files are complete.

## Completed source work

- [x] Approved 17-tab / 139-header schema manifest and bootstrap source retained.
- [x] Booking server-side pricing/advance calculation and duplicate partial-write reconciliation gate retained.
- [x] Rental enquiry remains inquiry-only; no owner/customer rental email.
- [x] Admin session, secret-gated Apps Script actions and active AdminUsers roster retained.
- [x] Public lookup/cancellation privacy and throttling retained.
- [x] EmailLog, notifications, cancellation/refund review and Daily Reports source retained.
- [x] Update 36 protected Admin dispatch, public mutation lockdown, proxy allowlist and server-configured webhook URL fixes retained.
- [x] Update 37 Firebase guide corrected to explain Express API hosting requirement.
- [x] Update 38 added dependency-free offline validation runner.
- [x] Update 39 public Express proxy requires explicit allowed action; Apps Script rejects missing/blank action.
- [x] Update 40 runtime tests reject missing, blank and non-string actions; lock release and explicit PING_TEST verified.
- [x] Update 41 manual network build workflow definition added; execution deferred by owner instruction.
- [x] Update 42 fixed expired Admin login lockout-window reset order.
- [x] Update 42 added 30-second timeout to all 3 Apps Script fetch paths.
- [x] Update 43 verified all 13 frontend API paths have Express routes.
- [x] Update 43 verified 10 protected Admin routes use `requireAdmin`.
- [x] Update 43 verified all 10 Express Admin actions are dispatched in Apps Script.
- [x] Update 43 aligned all 7 Operational Sheets Manager UI configs with approved schema headers/keys.
- [x] Update 44 added a regression guard that detects missing public configuration fields before any public sync implementation is attempted.
- [x] Update 45 corrected outstation billing copy: driver allowance / DA-permit is extra; parking, toll, border tax and entry charges are extra at actuals.
- [x] Update 45 added an optional local tour-guide request at ₹2,000 flat per booking/vehicle, not per passenger; it is included in the estimate and recorded in the existing special-requirements field.
- [x] Update 43 added API contract and operational UI schema regression tests.
- [x] Update 49: Admin login fails closed if sessionStorage cannot persist the signed token; partial keys are cleared best-effort and an actionable error is shown.
- [x] Update 50: all Admin token reads, writes, and cleanup are routed through guarded session helpers; stored token is read back before login success.
- [x] `npm run test:offline` equivalent offline runner PASS, 20/20 (Update 50).
- [x] TypeScript/TSX syntax transpilation PASS, 30/30 (Update 50).
- [x] Key JSON manifests PASS, 4/4.

## Deferred integration item — public configuration remains browser-local

**Deferred by owner instruction — not part of the current local-only phase:** Admin operational edits are intended to be saved to Google Sheets, while customer-facing routes/packages/offers/pickup points/tour points currently read through `StorageService` from browser `localStorage` and `INITIAL_*` defaults. `BookingForm.tsx` uses those getters. This public config API/hydration work will be done in the later Google Sheets / Apps Script phase; it is not a blocker for current local source work.

- [ ] Add a dedicated read-only public configuration endpoint.
- [ ] Explicitly allowlist public fields from operational tabs only.
- [ ] Never expose AdminUsers, Settings secrets, bookings, payment references, supplier costs or private Admin data.
- [ ] Add safe defaults, response validation and bounded cache.
- [ ] Hydrate public booking and content components from Sheets-backed public config.
- [ ] Ensure Admin changes become visible to public pages after a safe refresh.
- [x] Add regression guard for current public-config schema readiness; full endpoint/privacy/cache tests remain pending until the endpoint is designed.
- [ ] Test against isolated staging before production cutover.

Do not reuse protected `ADMIN_GET_DATA` as a public endpoint.

## Update 44 — public configuration readiness audit

The current approved schema does not fully describe the data model consumed by the customer-facing booking UI:

- `PickupPoints` has only `Route`, `Pickup Point`, `Sort Order`, `Active`; the frontend pickup model also consumes time, landmark, reporting time and map URL.
- `PackageOptions` has package key, route group, label, price and offer fields, but no explicit `isAC`, `hasLunch`, or package description fields used by the booking model.
- The operational tabs do not provide the existing route descriptions or all customer-facing extra-charge configuration.
- The frontend `BookingForm` still reads routes, packages, offers and pickup points from `StorageService` / browser localStorage and initial defaults.
- The 17-tab schema manifest is explicitly a reconstructed audit snapshot, not a live workbook read. A Library title search for the original `Google app script codegx.xlsx` did not locate it; it must be reconciled with the original workbook before final mapping.

**Safety decision:** no public endpoint and no frontend hydration were added in Update 44. Mapping incomplete fields to invented values, exposing `ADMIN_GET_DATA`, or exposing raw private tabs would be unsafe. No sheet, column, live data, UI, deployment, or GitHub workflow was changed.

A new offline readiness test locks in these findings so the later integration does not silently claim Sheets-backed public configuration is complete. The owner has clarified that no Google Sheet should be manually created and this integration is deferred.

## Latest verification status

| Check | Result |
|---|---|
| Apps Script CJS regression suites | PASS, 9/9 |
| Apps Script `Code.gs` syntax | PASS |
| Admin login throttle / upstream timeout regression | PASS |
| Frontend API path alignment | PASS, 13/13 |
| Protected Admin route middleware | PASS, 10/10 |
| Express-to-Apps Script Admin action dispatch | PASS, 10/10 |
| Operational UI schema alignment | PASS, 7/7 sheets |
| Offline validation runner | PASS, 18/18 (Update 47) |
| TypeScript/TSX syntax transpilation | PASS, 29/29 (rechecked Update 45) |
| Key JSON manifests | PASS, 4/4 (rechecked Update 45) |
| npm registry access | BLOCKED — DNS `EAI_AGAIN` |
| npm cache | No usable package cache entries |
| `package-lock.json` | MISSING |
| `bun.lock` | EMPTY, unusable |
| `node_modules` | ABSENT |
| Full `npm run lint` | PENDING — dependencies/types unavailable |
| `npm run build` | PENDING — dependencies unavailable |
| GitHub Actions workflow | NOT RUN — deferred by owner |
| Browser E2E | PENDING |
| Hosting architecture / API runtime | PENDING owner/developer confirmation |
| Google Sheets staging | PENDING owner approval |

## Latest local source update — Update 47 (20 November 2026)

- Added Apps Script `safeSheetText_()` to store public customer text as literal Google Sheets cell text rather than allowing formula-like values to be interpreted as formulas.
- Applied sanitization and maximum lengths to public booking and rental enquiry text fields.
- Added strict format validation for booking and rental enquiry IDs.
- Added `validation/test_sheets_formula_injection.cjs`; it exercises the actual sanitizer helper and checks field coverage and ID validation.
- Offline validation now passes **18/18**; TypeScript/TSX syntax transpilation **29/29**; JSON manifests **4/4**.
- No UI, approved pricing, booking rules, schema headers, external services or deployment settings changed.
- No Google Sheet / Apps Script / payment / GitHub / Preview / production action performed.

## Latest local source update — Update 48 (20 November 2026)

- Audit found public and Admin cancellation reasons still went directly into `Booking Cancellations` via `appendRow()` after Update 47.
- Both cancellation handlers now use `safeSheetText_()` with a 500-character limit.
- Regression test covers both public and Admin cancellation write paths.
- Offline validation at Update 48: **18/18 PASS**; TypeScript/TSX syntax transpilation: **31/31 PASS**; ZIP integrity: **PASS**.
- No workbook, deployment, payment, UI, pricing, business-rule, GitHub or external service was changed.

## Remaining local work before GitHub

- [ ] Continue source-level audit of customer booking, rental, Admin, privacy/security and responsive UI flows. (Updates 46–50 fixed local-date formatting, customer/cancellation text formula safety, and Admin session-storage fail-closed handling across all Admin access paths.)
- [ ] Add regression tests for approved business rules and close any confirmed source-level defects.
- [ ] Reconcile README, setup guides, update reports and project tracker with the owner-approved local-first sequence.
- [ ] Preserve approved UI, pricing, booking rules and schema except for explicitly authorized business-rule corrections.
- [ ] Complete all source/package files and local validation before GitHub activity.

Google Sheets / Apps Script public configuration API, sheet bootstrap run, deployment, payment integration and live email are explicitly deferred to a later phase; they are not current local blockers.

## Later — network build, browser E2E and staging

### P0 — Network-enabled build (only after local files are complete)
- [ ] Owner/developer commits/pushes project source to intended GitHub repository.
- [ ] Manually run **Mumbai Darshan Network Build Validation** workflow.
- [ ] Verify npm install generates a valid package-lock.
- [ ] Verify clean `npm ci` passes.
- [ ] Verify `npm run lint` passes.
- [ ] Verify `npm run build` passes.
- [ ] Review uploaded lockfile and dist artifacts; record workflow URL and commit SHA.

### P0 — Hosting architecture and browser E2E
- [ ] Confirm hosting target for Express server.
- [ ] If Firebase Hosting + Cloud Run is approved, confirm actual service ID and region, then configure `/api/**` rewrite before SPA fallback.
- [ ] Verify `/api/*` reaches Express and Admin routes reject unauthenticated calls.
- [ ] Run browser E2E for booking submit/retry, rental inquiry, lookup, cancellation, Admin login/session expiry, status updates, email retry, refunds, reports and seven operational CRUD tabs.
- [ ] Test mobile booking flow and rental enquiry panel immediately below booking form.

### P1 — Later Google Sheets / Apps Script staging (owner approval only; no manual sheet creation)
- [ ] Provide/run one complete Apps Script setup code using `setupDatabase()` to create the spreadsheet and approved tabs automatically.
- [ ] Confirm exact 17 tabs / 139 headers and approved seed data.
- [ ] Configure private server environment and Apps Script Script Property secrets.
- [ ] Test booking/payment-pending ledger writes, duplicate retries, rental inquiry-only writes, lookup/cancellation, Admin reads/mutations, EmailLog, notifications and daily reports.
- [ ] Test concurrency and throttling.
- [ ] Owner-approved controlled email test; only then decide on trigger installation.

### P2 — Later separately approved integration and delivery
- [ ] Add the dedicated public configuration read endpoint and safe frontend hydration; keep private Admin/customer/payment data excluded.
- [ ] Complete payment integration only after merchant credentials and approved server-side verification design are available.

### P3 — Later separately approved delivery
- [ ] Preview refresh after build/tests and approval.
- [ ] PhonePe integration after merchant credentials and server-side signature/status verification.
- [ ] Production Apps Script deployment, email activation, DNS/domain changes and website deployment only with explicit approval.

## Preserved business and safety rules

- No changes to approved sheet tabs/columns without permission.
- No supplier cost/rate/margin/private garage information in customer-facing code.
- No extra ₹5 rental-rate markup; approved customer rates remain unchanged.
- ₹200 advance is per booking, not per person.
- No automatic refund; PhonePe remains deferred.
- No rental enquiry emails; follow up via WhatsApp.
- No live Sheet, Apps Script, GitHub, Preview or production action without explicit approval.

**Overall: INCOMPLETE. Updates 46–49 add the local-date correction, Sheets text formula-safety coverage, cancellation reason hardening, and Admin session-storage fail-closed behavior. Latest offline validation passes 19/19; 29 source files pass syntax transpilation. Critical remaining local task: continue source audit and complete local project files. Public Sheets-backed configuration hydration, GitHub, network build, browser E2E and deployment remain deferred to the approved later phases.**


## Update 49 — Admin session-storage fail-closed fix

- Admin login previously swallowed `sessionStorage` write errors and still marked the UI authenticated. This could show an authenticated Admin shell without a usable stored token.
- Login now clears any partial keys best-effort, displays a clear browser-storage error, and returns before setting authenticated state.
- Added a regression test for the failure path.
- Offline validation: **19/19 PASS**; TS/JS/TSX/JSX syntax transpilation: **29/29 PASS**.
- No external actions or integrations performed. Full npm lint/build and browser E2E remain pending.


## Update 50 — Admin session-storage access hardening

- Follow-up audit found direct `sessionStorage.getItem()` / `removeItem()` calls remained in Admin startup, protected data loading, report/status actions, operational editor, rental/cancellation actions, notifications and logout.
- Added guarded helpers in `src/services/adminSession.ts`; all Admin UI token access now uses them. Token persistence is verified by reading the token back.
- Storage read exceptions return no token; cleanup is best-effort and does not throw.
- Offline validation: **20/20 PASS**; TypeScript/TSX syntax transpilation: **30/30 PASS**; ZIP integrity: **PASS**.
- No UI/business rules/schema/API/integration changes; no external actions performed.

**Overall: INCOMPLETE. Update 50 extends Admin session-storage fail-closed handling to every Admin path. Full npm lint/build and browser E2E remain pending; Google Sheets, Apps Script deployment, payment, GitHub and production deployment remain deferred.**
