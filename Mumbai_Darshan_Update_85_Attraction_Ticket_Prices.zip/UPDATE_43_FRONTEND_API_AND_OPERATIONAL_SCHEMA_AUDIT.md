# Update 43 — Frontend API Contract & Operational Schema Audit

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 42 — Admin Login Throttle & Upstream Request Resilience  
**Release status:** INCOMPLETE — API and operational-sheet contracts are statically aligned; public-site configuration is still not fully migrated to Google Sheets.

## 1. Owner instruction applied

The owner instructed that GitHub work must wait until the complete project files and remaining local work are finished. Update 43 is local-only:
- No GitHub commit or push.
- No GitHub Actions run.
- No Preview refresh or deployment.
- No live Sheets, Apps Script, DNS, email or PhonePe action.

## 2. Work completed

| # | Work item | Result |
|---|---|---|
| 1 | Enumerated frontend `/api/**` calls and Express route declarations | 13 frontend paths checked |
| 2 | Verified every frontend API path has a matching Express route | PASS |
| 3 | Verified protected Admin routes use `requireAdmin` | 10 protected routes PASS; public login excluded as intended |
| 4 | Compared Express `callAppsScriptAdmin()` action names with Apps Script `doPost` dispatch | 10/10 actions PASS |
| 5 | Verified public proxy allowlist actions are also present in Apps Script dispatch | NEW_BOOKING, NEW_RENTAL_ENQUIRY, CAR_RENTAL, PING_TEST PASS |
| 6 | Compared all 7 Operational Sheets Manager configurations with approved schema tab/header names | PASS |
| 7 | Verified UI required fields and delete keys are consistent with each sheet's approved stable key | PASS |
| 8 | Added `validation/test_api_contract_alignment.cjs` | Completed |
| 9 | Added `validation/test_operational_ui_schema_alignment.cjs` | Completed |
| 10 | Updated `npm run test:offline` to Update 43 runner | Completed |
| 11 | Updated README and network workflow static test reference | Completed |
| 12 | Ran full dependency-free suite | PASS, 14/14 |
| 13 | Transpiled all TypeScript/TSX source files with installed global TypeScript | PASS, 29 files / 0 syntax errors |
| 14 | Parsed key JSON manifests | PASS, 4/4 |
| 15 | Updated Master Progress Tracker and built Update 43 ZIP | Completed; ZIP integrity verified |

## 3. Important remaining gap discovered — public configuration is not yet Sheets-driven

The Admin Operational Sheets Manager writes approved configuration changes to Google Sheets through authenticated Admin endpoints. However, the customer-facing booking UI still reads its route/package/offer/pickup configuration through browser-side `StorageService` getters backed by `localStorage` and `INITIAL_*` defaults.

Confirmed source paths:
- `StorageService.getRoutes()` reads `KEYS.ROUTES` / `INITIAL_ROUTES`.
- `StorageService.getPackages()` reads `KEYS.PACKAGES` / `INITIAL_PACKAGES`.
- `StorageService.getOffers()` reads `KEYS.OFFERS` / `INITIAL_OFFERS`.
- `StorageService.getPickupPoints()` reads `KEYS.PICKUP_POINTS` / `INITIAL_PICKUP_POINTS`.
- `StorageService.getTourPoints()` reads `KEYS.TOUR_POINTS` / `INITIAL_TOUR_POINTS`.
- `BookingForm.tsx` reads routes, packages, offers and pickup points through those getters.
- `OperationalSheetsManager.tsx` saves to Sheets and refreshes Admin data; it does not currently hydrate the public site's StorageService from the Sheets records.

**Effect:** An Admin edit saved to the Google Sheets operational tabs is not proven to appear in the customer booking form or public sightseeing/pickup pages. This means the Sheets migration is not complete for operational configuration.

### Safe next implementation required
- [ ] Design a dedicated read-only public configuration API in Express + Apps Script.
- [ ] Expose only explicitly approved public fields from the operational tabs; never return AdminUsers, Settings secrets, bookings, payment references, supplier costs or private Admin data.
- [ ] Add strict response validation, safe defaults and bounded caching.
- [ ] Hydrate the customer-facing app from the public configuration endpoint while preserving existing approved defaults if the service is unavailable.
- [ ] Ensure Admin edits refresh the authoritative Sheet data and that the public site reads the latest approved configuration.
- [ ] Add tests for the public response allowlist, no private fields, schema mapping, fallback behavior and cache expiry.
- [ ] Test against isolated staging before any production cutover.

This was documented rather than changed in Update 43 because exposing a public configuration endpoint requires a carefully bounded field allowlist and integration tests. Reusing the protected `ADMIN_GET_DATA` endpoint publicly would expose private customer/Admin data and is not acceptable.

## 4. Verification evidence

| Check | Result |
|---|---|
| Apps Script CJS regression suites | PASS, 9/9 |
| Apps Script `Code.gs` syntax | PASS |
| Admin login throttle and upstream timeout regression | PASS |
| Frontend-to-Express API path alignment | PASS, 13/13 |
| Protected Admin route middleware | PASS, 10/10 |
| Express-to-Apps Script Admin action dispatch | PASS, 10/10 |
| Operational UI schema alignment | PASS, 7/7 sheets |
| Offline validation runner | PASS, 14/14 |
| TypeScript/TSX syntax transpilation | PASS, 29 files / 0 syntax errors |
| Key JSON manifests | PASS, 4/4 |
| Full semantic TypeScript check | PENDING — dependencies are not installed |
| Vite production build | PENDING — dependencies are not installed |
| Browser E2E | PENDING |
| Live Sheets/Apps Script staging | PENDING owner approval |

Syntax transpilation is not a semantic type-check and does not replace `npm run lint`.

## 5. Other outstanding release gates

- [ ] Generate a real package-lock on a network-enabled environment; local registry DNS previously failed with `EAI_AGAIN`.
- [ ] Install dependencies and run clean `npm ci`.
- [ ] Run full semantic type-check and Vite build.
- [ ] Define browser E2E with an isolated staging API/spreadsheet.
- [ ] Confirm actual Express hosting target and Cloud Run service ID/region if applicable.
- [ ] Verify Firebase `/api/**` routing reaches Express before SPA fallback.
- [ ] Complete isolated staging for booking, rental enquiry, cancellation, Admin operations, notifications and reporting.
- [ ] Complete public configuration Sheets migration described above.

## 6. Safety and business-rule confirmations

No approved UI, prices, routes, booking advance, rental inquiry policy, supplier privacy rules or 17-tab / 139-header schema were changed. No live services or production data were accessed or modified.

**Conclusion:** Update 43 establishes source-level API and operational schema alignment and expands offline validation to 14/14. It also identifies a key migration gap: customer-facing configuration remains browser-local rather than being read from the operational Sheets. The project remains INCOMPLETE and is not production-ready.
