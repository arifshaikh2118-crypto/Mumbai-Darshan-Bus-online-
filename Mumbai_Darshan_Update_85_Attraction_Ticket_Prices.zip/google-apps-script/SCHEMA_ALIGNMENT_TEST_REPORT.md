# Apps Script Schema Alignment — Local Mock Test Report

Date: 11 November 2026

## Test scope
Executed `node tests/test_schema_alignment.cjs` with mocked `SpreadsheetApp`, `PropertiesService`, `LockService`, `MailApp`, and `Utilities`.

## Result
PASS — verified:
- Apps Script `DATABASE_SCHEMA` matches `schema/SCHEMA_SPEC.json` exactly.
- First `setupDatabase()` creates one spreadsheet automatically when `SPREADSHEET_ID` is absent.
- Setup creates exactly 17 approved tabs and 139 header cells.
- Second setup reopens the same spreadsheet; no duplicate spreadsheet is created.
- Booking writes exactly 21 values to `booking`.
- Initial payment ledger writes exactly 9 values to `booking_payments`, with Pending status and no fabricated transaction reference.
- Rental enquiry writes exactly 19 values to `rental_enquiry`.
- Repeated rental enquiry ID is idempotent and does not append a second row.
- Booking retry repairs a missing pending payment-ledger row after a simulated partial write.
- Known production/retired spreadsheet IDs are rejected before openById.
- Quote/supplier-cost fields absent from the approved rental schema are rejected.
- Public Admin status mutations fail closed until authenticated Admin access exists.
- Public Admin booking/rental status mutation actions fail closed pending secure admin authentication.
- Incorrect payment callback secret is rejected.
- Verified payment writes to the correct payment ledger fields and updates booking payment/booking statuses.
- No extra tabs are created by runtime handlers.

## Not tested
- Actual Google Apps Script runtime or Google Sheets service.
- Real spreadsheet creation in Google Drive.
- Live email sending.
- PhonePe/payment provider callback or server-side provider verification.
- Browser/frontend integration, Firebase build, deployment, or production.

These are local mock tests only; they do not prove live Google service behavior.


## Update 19 – Secure Admin dashboard integration

- Added server-proxied authenticated endpoints for booking and rental enquiry status changes.
- Added Apps Script protected actions `ADMIN_UPDATE_BOOKING_STATUS` and `ADMIN_UPDATE_RENTAL_STATUS`; both re-check the private API secret and active `AdminUsers` roster before changing exact approved sheet columns.
- Admin dashboard fetches bookings, rental enquiries, payments and cancellations from protected `/api/admin/data`; booking and rental panels now use sheet-backed records instead of sample localStorage records after authentication.
- Booking and rental status updates carry the signed Admin session token; direct public webhook status actions remain disabled.
- Rental quotation/supplier-cost editing is intentionally non-writing because those fields do not exist in the approved 19-column `rental_enquiry` schema. No columns were invented.
- Browser UI no longer displays any default passcode hint.
- Build/lint could not be run in this environment because project dependencies were not present and dependency installation timed out; static/runtime Apps Script tests are recorded separately.
