# Update 32 — Daily Reports Workflow

## Implemented in source
- Added secure Admin action `ADMIN_GENERATE_DAILY_REPORT` behind the Apps Script server secret and active `AdminUsers` roster check.
- Added authenticated Node server endpoint `POST /api/admin/reports/daily/generate`.
- Added Admin UI date selector and **Generate Daily Report** action; manual generation saves the report only and does not send email.
- Aggregates the approved `daily_reports` fields: report date, total bookings created that day, confirmed/completed bookings, cancelled bookings, unique customers by registered mobile, verified revenue, pending payments, and original creation timestamp.
- Revenue is based only on verified payment ledger records and the `verified_at` date (not an unverified booking amount or payment-initiation timestamp).
- Upserts by `report_date`, so rerunning the same date updates one row rather than adding duplicates.
- Scheduled owner report uses aggregate metrics only; it excludes customer names, phone numbers, email addresses and transaction references.
- Scheduled email is skipped and logged when `ENABLE_LIVE_EMAILS` is off. Email attempts use the existing exact six-column `EmailLog`.
- Existing `setupDailyReportTrigger()` remains an owner-approved manual setup step; no trigger was installed or executed.

## Schema preserved
`daily_reports` remains exactly 8 columns: `report_date, total_bookings, confirmed_bookings, cancelled_bookings, total_customers, total_revenue, pending_payments, created_at`. No new tab or column.

## Local verification
- `test_daily_reports.cjs`: PASS.
- `test_schema_alignment.cjs`: PASS, including aggregation values, verified revenue, date upsert idempotency, invalid date rejection, active Admin authorization and no PII in returned report.
- All eight CJS suites: PASS.
- Apps Script syntax (`node --check`): PASS.
- Full TypeScript check and Vite build remain blocked by missing `vite/client` and `vite` dependencies in this environment.
- No browser E2E, live Google Sheets, Apps Script deployment, trigger installation or real MailApp delivery test performed.

## Next work
1. Review remaining Apps Script handlers for idempotency and failure recovery.
2. Complete TypeScript/Vite build and browser tests when dependencies are available.
3. Run owner-approved staging setup and verify real Sheets persistence.
4. Install the daily trigger only after owner approval and secure email configuration.
