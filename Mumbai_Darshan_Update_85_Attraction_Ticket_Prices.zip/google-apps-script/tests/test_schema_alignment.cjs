const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
class Range {
  constructor(sh,r,c,nr=1,nc=1){this.sh=sh;this.r=r;this.c=c;this.nr=nr;this.nc=nc;}
  getValue(){return this.sh.rows[this.r-1]?.[this.c-1]??'';}
  getValues(){return Array.from({length:this.nr},(_,i)=>Array.from({length:this.nc},(_,j)=>this.sh.rows[this.r-1+i]?.[this.c-1+j]??''));}
  getDisplayValues(){return Array.from({length:this.nr},(_,i)=>Array.from({length:this.nc},(_,j)=>String(this.sh.rows[this.r-1+i]?.[this.c-1+j]??'')));}
  setValues(vals){vals.forEach((row,i)=>{this.sh.rows[this.r-1+i]=this.sh.rows[this.r-1+i]||[];row.forEach((v,j)=>this.sh.rows[this.r-1+i][this.c-1+j]=v);});return this;}
  setValue(v){this.sh.rows[this.r-1]=this.sh.rows[this.r-1]||[];this.sh.rows[this.r-1][this.c-1]=v;return this;}
  setBackground(){return this;} setFontColor(){return this;} setFontWeight(){return this;}
}
class Sheet {
  constructor(name){this.name=name;this.rows=[];}
  getName(){return this.name;} setName(n){this.name=n;}
  getLastRow(){return this.rows.length;}
  getLastColumn(){return Math.max(0,...this.rows.map(r=>r.length));}
  getRange(r,c,nr=1,nc=1){return new Range(this,r,c,nr,nc);}
  getDataRange(){return new Range(this,1,1,this.getLastRow(),this.getLastColumn());}
  appendRow(row){if(this.failNextAppend){this.failNextAppend=false;throw new Error('mock append failure');}this.rows.push(row.slice());}
  deleteRow(row){this.rows.splice(row-1,1);}
  setFrozenRows(){} clear(){this.rows=[];}
}
class Spreadsheet {
  constructor(id){this.id=id;this.sheets=[new Sheet('Sheet1')];}
  getId(){return this.id;} getSheets(){return this.sheets;}
  getSheetByName(n){return this.sheets.find(s=>s.name===n)||null;}
  insertSheet(n){const s=new Sheet(n);this.sheets.push(s);return s;}
}
let props={}; let cacheValues={}; let spreadsheet=null; let creates=0; let uuidCounter=0; let scriptLockHeld=false; let scriptLockWaits=0;
const ctx={
  console, Logger:{log(){}},
  PropertiesService:{getScriptProperties(){return {getProperty:k=>props[k]||null,setProperty:(k,v)=>props[k]=v};}},
  SpreadsheetApp:{create(){creates++;spreadsheet=new Spreadsheet('mock-sheet-id');return spreadsheet;},openById(id){assert.equal(id,'mock-sheet-id');return spreadsheet;}},
  LockService:{getScriptLock(){return {waitLock(){scriptLockWaits++;scriptLockHeld=true;},tryLock(){if(scriptLockHeld)return false;scriptLockHeld=true;return true;},hasLock(){return scriptLockHeld;},releaseLock(){scriptLockHeld=false;}};}},
  Utilities:{formatDate(date, zone, pattern){const d=new Date(date);return pattern==='yyyy-MM-dd'?d.toISOString().slice(0,10):'20261111';},getUuid(){return 'uuid-test-' + (++uuidCounter);},computeDigest(){return [1,2,3];},DigestAlgorithm:{SHA_256:'SHA_256'},base64EncodeWebSafe(){return 'testdigest'}},
  CacheService:{getScriptCache(){return {get(k){return cacheValues[k]||null;},put(k,v){cacheValues[k]=v;}};}},
  MailApp:{getRemainingDailyQuota(){return 100;},sendEmail(){throw new Error('email should be disabled in tests');}},
  ScriptApp:{getProjectTriggers(){return [];},newTrigger(){return {timeBased(){return this;},everyDays(){return this;},atHour(){return this;},inTimezone(){return this;},create(){}};}},
  ContentService:{createTextOutput(v){return {text:v,setMimeType(){return this;}};},MimeType:{JSON:'json'}},
  Date, Math, JSON, Object, String, Number, isFinite, Error, Array
};
vm.createContext(ctx);
const path = require('path');
const spec = JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', 'schema', 'SCHEMA_SPEC.json'), 'utf8'));
const code=fs.readFileSync(path.join(__dirname, '..', 'Code.gs'),'utf8');
vm.runInContext(code,ctx);
assert.deepStrictEqual(JSON.parse(JSON.stringify(ctx.DATABASE_SCHEMA)), spec.tabs, 'Apps Script schema manifest must exactly match workbook JSON');
const setup=ctx.setupDatabase();
assert.equal(setup.ok,true); assert.equal(setup.tabCount,17); assert.equal(setup.headerCount,139); assert.equal(creates,1);
assert.equal(spreadsheet.getSheets().length,17);
const seededPackages=spreadsheet.getSheetByName('PackageOptions');
assert.equal(seededPackages.rows.length,17,'setup seeds 16 approved route/package prices');
const expectedRoutePrices = { western: [250,350,450,550], central: [250,350,450,550], harbour: [250,350,450,550], kalyan_dombivli: [250,350,450,550] };
const normalizeTestRoute = value => {
  const text = String(value || '').toLowerCase().replace(/[–—]/g,'-');
  if (text.includes('western')) return 'western';
  if (text.includes('central')) return 'central';
  if (text.includes('harbour') || text.includes('harbor')) return 'harbour';
  if (text.includes('kalyan') || text.includes('dombiv')) return 'kalyan_dombivli';
  return '';
};
for (const [route, prices] of Object.entries(expectedRoutePrices)) {
  const rows = seededPackages.rows.slice(1).filter(row => normalizeTestRoute(row[1]) === route);
  assert.equal(rows.length, 4, 'all four package rows must be seeded for ' + route);
  for (let i = 0; i < 4; i++) {
    const row = rows.find(item => String(item[0]) === ['non_ac_no_lunch','ac_no_lunch','non_ac_lunch','ac_lunch'][i]);
    assert.ok(row, 'missing package row for ' + route + ' / ' + i);
    assert.equal(row[3], prices[i], 'incorrect seeded fare for ' + route + ' / ' + row[0]);
    assert.equal(row[4], false, 'offers must start OFF');
    assert.equal(row[5], 0, 'seeded offer discount must start at zero');
  }
}
assert.equal(seededPackages.rows[1][4],false);
const westernNonAcRow = seededPackages.rows.slice(1).find(row => row[0] === 'non_ac_no_lunch' && normalizeTestRoute(row[1]) === 'western');
const centralNonAcRow = seededPackages.rows.slice(1).find(row => row[0] === 'non_ac_no_lunch' && normalizeTestRoute(row[1]) === 'central');
// Simulate an existing sheet with the exact legacy default and a separately customized price.
westernNonAcRow[3] = 200; westernNonAcRow[4] = true; westernNonAcRow[5] = 50;
centralNonAcRow[3] = 275; centralNonAcRow[4] = true; centralNonAcRow[5] = 25;
const harbourNonAcRow = seededPackages.rows.slice(1).find(row => row[0] === 'non_ac_no_lunch' && normalizeTestRoute(row[1]) === 'harbour');
harbourNonAcRow[4] = true; harbourNonAcRow[5] = 50;
props.PACKAGE_PRICE_POLICY_UPDATE_83 = null; // Simulate first run of the one-time migration against an existing sheet.
ctx.setupDatabase();
assert.equal(westernNonAcRow[3],250,'setup must migrate an exact legacy default to the current fare');
assert.equal(westernNonAcRow[4],false,'migrated legacy default must have offer switched OFF');
assert.equal(westernNonAcRow[5],50,'migrated legacy default must retain its discount for later manual activation');
assert.equal(centralNonAcRow[3],275,'custom Admin pricing must be preserved by the migration');
assert.equal(centralNonAcRow[4],false,'all active offers must be switched OFF for the current pricing policy');
assert.equal(centralNonAcRow[5],25,'custom offer discount must be preserved for later manual activation');
assert.equal(harbourNonAcRow[3],250,'already-current Harbour fare must remain unchanged');
assert.equal(harbourNonAcRow[4],false,'active Harbour offer must also be switched OFF');
assert.equal(harbourNonAcRow[5],50,'Harbour offer discount must be retained for later manual activation');
assert.equal(ctx.getApprovedPackagePrice_('non_ac_no_lunch','western').price,250,'current Western non-AC fare must be ₹250 with offers OFF');
westernNonAcRow[4] = true; westernNonAcRow[5] = 50;
assert.equal(ctx.getApprovedPackagePrice_('non_ac_no_lunch','western').price,200,'an Admin-enabled ₹50 route offer must still apply when deliberately switched ON');
ctx.setupDatabase();
assert.equal(westernNonAcRow[4],true,'a later deliberate Admin offer activation must survive repeat setup after one-time migration');
westernNonAcRow[4] = false; westernNonAcRow[5] = 50;
const seededRentalPricing=ctx.readRentalPricingSetting_();
assert.equal(seededRentalPricing.localPackages.length,6,'setup seeds six local rental packages inside existing Settings key/value rows');
assert.equal(seededRentalPricing.outstationRates.length,16,'setup seeds sixteen outstation rates inside existing Settings key/value rows');
// Exact header mismatch must fail closed and never auto-repair a populated tab.
const originalHeader=spreadsheet.getSheetByName('booking').rows[0][0];
spreadsheet.getSheetByName('booking').rows[0][0]='Wrong Header';
assert.throws(()=>ctx.getRequiredSheet_('booking'),/Schema mismatch/);
spreadsheet.getSheetByName('booking').rows[0][0]=originalHeader;
ctx.setupDatabase(); assert.equal(creates,1,'setup must not create a duplicate spreadsheet');
const booking=ctx.handleNewBooking({bookingId:'MDB-TEST-1',customerName:'Test',customerMobile:'9619975457',customerEmail:'test@example.com',travelDate:'2026-12-01',routeName:'Western',pickupPointName:'Borivali',packageId:'ac_no_lunch',packageTitle:'AC Bus',passengerCount:2,optionalAttractions:'Gateway Boat Ride (x2); Museum Entry (x2)',specialRequest:'Window seat request',onlineBookingFare:1,advancePayable:1});
assert.equal(booking.status,'success');
assert.equal(booking.bookingId,'MDB-TEST-1','Apps Script must return the exact persisted Booking ID');
const b=spreadsheet.getSheetByName('booking'); const p=spreadsheet.getSheetByName('booking_payments');
assert.equal(b.rows[1].length,21); assert.equal(b.rows[1][1],'MDB-TEST-1','Booking ID must be saved in Bookings column 2'); assert.equal(b.rows[1][16],'Payment Pending'); assert.equal(b.rows[1][17],'Pending Verification');
assert.equal(p.rows[1].length,9); assert.equal(p.rows[1][1],'MDB-TEST-1'); assert.equal(p.rows[1][3],200); assert.equal(p.rows[1][6],'Pending');
assert.equal(b.rows[1][14],700,'server-calculated AC fare must use the new ₹350 per-person rate and ignore browser-supplied total');
assert.equal(b.rows[1][4],'test@example.com','customer-provided email must be stored exactly');

assert.equal(String(b.rows[1][15]),'Window seat request','Special Request column must preserve only the customer-entered request and ignore client-supplied attraction selections');
assert.ok(!String(b.rows[1][15]).includes('Gateway Boat Ride'),'attraction choices must not be preselected or saved during online booking');
assert.equal(p.rows[1][3],200,'server-calculated advance must ignore browser-supplied advance');
// Both destination tabs are schema-checked before any booking row is written.
const paymentHeaderBefore=p.rows[0][0];
p.rows[0][0]='Wrong Payment Header';
const missingLedgerSchema=ctx.handleNewBooking({bookingId:'MDB-NO-LEDGER',customerName:'No Ledger',customerMobile:'9000000003',travelDate:'2026-12-06',routeName:'Western',packageId:'non_ac_no_lunch',passengerCount:1});
assert.equal(missingLedgerSchema.status,'error');
assert.equal(b.rows.some(row=>row[1]==='MDB-NO-LEDGER'),false,'schema mismatch in payment ledger must prevent booking-only save');
p.rows[0][0]=paymentHeaderBefore;

assert.equal(ctx.handleNewBooking({bookingId:'MDB-BAD-PKG',routeName:'Western',packageId:'AC',passengerCount:1,onlineBookingFare:300}).status,'error');
// Simulate a partial write (booking row persisted but pending payment ledger did not), then retry.
const secondBooking=ctx.handleNewBooking({bookingId:'MDB-TEST-2',customerName:'Retry',customerMobile:'9000000000',travelDate:'2026-12-03',routeName:'Central',packageId:'non_ac_no_lunch',packageTitle:'Non AC',passengerCount:1,onlineBookingFare:250});
assert.equal(secondBooking.status,'success');
p.rows=p.rows.filter(row=>row[1]!=='MDB-TEST-2');
assert.equal(ctx.handleNewBooking({bookingId:'MDB-TEST-2'}).status,'reconciliation_required');
assert.equal(p.rows.filter(row=>row[1]==='MDB-TEST-2').length,0,'retry must not guess the original advance/full payment amount');
const enq=ctx.handleRentalEnquiry({id:'REN-1',customerName:'Renter',customerMobile:'9876543210',vehicleType:'Car',travelDate:'2026-12-02',pickupLocation:'Borivali',destination:'Pune',tripType:'Outstation',rentalType:'outstation',persons:4,days:2,preferredCarModel:'Ertiga',acPreference:'AC'});
assert.equal(enq.status,'success');
const r=spreadsheet.getSheetByName('rental_enquiry'); assert.equal(r.rows[1].length,19); assert.equal(r.rows[1][0],'REN-1'); assert.equal(r.rows[1][11],'New');
assert.equal(ctx.handleRentalEnquiry({id:'REN-1',customerName:'Renter',customerMobile:'9876543210',vehicleType:'Car',travelDate:'2026-12-02',pickupLocation:'Borivali',destination:'Pune',tripType:'Outstation',rentalType:'outstation',persons:4,days:2}).status,'duplicate'); assert.equal(r.rows.length,2);
assert.equal(ctx.handleRentalStatusUpdate({enquiryId:'REN-1',quotedPrice:1000}).status,'error');
assert.equal(ctx.handleRentalStatusUpdate({enquiryId:'REN-1',status:'Contacted'}).status,'error'); assert.equal(r.rows[1][11],'New');
// A forged/untrusted payment callback is rejected; verified payment changes the exact 9/21-column records.
assert.equal(ctx.handleVerifiedPayment({bookingId:'MDB-TEST-1',paymentId:'P-1',transactionRef:'TX-1',amount:200,providerVerified:true,callbackSecret:'wrong'}).status,'error');
props.PAYMENT_CALLBACK_SECRET='secret';
const verified=ctx.handleVerifiedPayment({bookingId:'MDB-TEST-1',paymentId:'P-1',transactionRef:'TX-1',amount:200,providerVerified:true,callbackSecret:'secret',provider:'Test Gateway'});
assert.equal(verified.status,'success'); assert.equal(b.rows[1][16],'Advance Paid'); assert.equal(b.rows[1][17],'Confirmed'); assert.equal(p.rows[1][5],'TX-1'); assert.equal(p.rows[1][6],'Verified');
assert.equal(spreadsheet.getSheets().length,17,'no runtime action may create extra tabs');
assert.equal(ctx.handleBookingStatusUpdate({bookingId:'MDB-TEST-1',bookingStatus:'Cancelled'}).status,'error');
// Secure admin API requires the private server secret and an active AdminUsers roster row.
props.ADMIN_API_SECRET='server-only-secret';
const adminSheet=spreadsheet.getSheetByName('AdminUsers');
adminSheet.appendRow(['owner@example.com','owner',true,new Date(),new Date()]);
assert.equal(ctx.handleAdminApiAction_('ADMIN_AUTH_CHECK',{adminEmail:'owner@example.com',adminApiSecret:'wrong'}).status,'error');
assert.equal(ctx.handleAdminApiAction_('ADMIN_AUTH_CHECK',{adminEmail:'blocked@example.com',adminApiSecret:'server-only-secret'}).authorized,false);
const adminAuth=ctx.handleAdminApiAction_('ADMIN_AUTH_CHECK',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret'});
assert.equal(adminAuth.authorized,true); assert.equal(adminAuth.role,'owner');
const adminData=ctx.handleAdminApiAction_('ADMIN_GET_DATA',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret'});
assert.equal(adminData.status,'success'); assert.equal(adminData.data.bookings.length,2); assert.equal(adminData.data.rentalEnquiries.length,1);
assert.equal(adminData.data.rentalPricing.localPackages.length,6,'Admin receives the public rental rate catalogue without exposing all Settings values');
assert.equal(adminData.data.rentalPricing.outstationRates.length,16);
for (const key of ['pickupPoints','packageOptions','bookingDates','rentalVehicles','emailLog','notifications','activityLog','dailyReports','websiteContent','attractionPoints','attractionTickets']) assert.ok(Array.isArray(adminData.data[key]), 'Admin API must return protected operational dataset: '+key);
assert.equal(Object.prototype.hasOwnProperty.call(adminData.data,'adminUsers'),false,'AdminUsers roster must never be exposed');
assert.equal(Object.prototype.hasOwnProperty.call(adminData.data,'settings'),false,'Settings values must never be exposed through the generic Admin data endpoint');
const updatedRentalPricing=JSON.parse(JSON.stringify(adminData.data.rentalPricing));
updatedRentalPricing.localPackages[0].customerPrice=4600;
const rentalPricingSave=ctx.handleAdminApiAction_('ADMIN_SAVE_RENTAL_PRICING',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',rentalPricing:updatedRentalPricing});
assert.equal(rentalPricingSave.status,'success','authorized Admin may update only validated public rental pricing');
assert.equal(ctx.readRentalPricingSetting_().localPackages[0].customerPrice,4600,'rental price is persisted in the existing Settings key/value row');
const badRentalPricing=JSON.parse(JSON.stringify(updatedRentalPricing)); badRentalPricing.outstationRates[0].nightDaRate=999;
assert.equal(ctx.handleAdminApiAction_('ADMIN_SAVE_RENTAL_PRICING',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',rentalPricing:badRentalPricing}).status,'error','invalid Night DA mismatch must be rejected');
assert.equal(ctx.readRentalPricingSetting_().localPackages[0].customerPrice,4600,'invalid update must not overwrite the last valid rate catalogue');
// Public lookup requires both exact Booking ID and registered mobile, returns minimal masked data.
const publicLookup=ctx.handlePublicBookingLookup_({bookingId:'MDB-TEST-1',mobile:'9619975457'});
assert.equal(publicLookup.status,'success'); assert.equal(publicLookup.booking.bookingId,'MDB-TEST-1');
assert.equal(publicLookup.booking.customerName,'T***');
assert.equal(Object.prototype.hasOwnProperty.call(publicLookup.booking,'customerEmail'),false);
assert.equal(ctx.handlePublicBookingLookup_({bookingId:'MDB-TEST-1'}).status,'error');
assert.equal(ctx.handlePublicBookingLookup_({bookingId:'MDB-TEST-1',mobile:'9000000000'}).status,'not_found');
// Customer cancellation request writes only the approved 8-column ledger and computes verified paid amount.
const cancelReq=ctx.handlePublicCancellationRequest_({bookingId:'MDB-TEST-1',mobile:'9619975457',reason:'Travel plan changed'});
assert.equal(cancelReq.status,'success'); assert.equal(cancelReq.refundReviewAmount,200);
const cancellationSheet=spreadsheet.getSheetByName('booking_cancellations');
assert.equal(cancellationSheet.rows[1].length,8); assert.equal(cancellationSheet.rows[1][6],'Pending Review');
assert.equal(ctx.handlePublicCancellationRequest_({bookingId:'MDB-TEST-1',mobile:'9619975457',reason:'Again cancel'}).status,'duplicate');
// Authenticated Admin can create/review a cancellation; marking refunded requires explicit manual confirmation.
const adminCancel=ctx.handleAdminApiAction_('ADMIN_CREATE_CANCELLATION',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',bookingId:'MDB-TEST-2',reason:'Owner requested cancellation'});
assert.equal(adminCancel.status,'success');
const cancellationId=cancellationSheet.rows[2][0];
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_REFUND_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',cancellationId,refundStatus:'Refunded'}).status,'error');
const zeroValueRefund=ctx.handleAdminApiAction_('ADMIN_UPDATE_REFUND_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',cancellationId,refundStatus:'Refunded',manualRefundConfirmed:true});
assert.equal(zeroValueRefund.status,'error','zero verified payment cannot be marked refunded'); assert.equal(cancellationSheet.rows[2][6],'Pending Review');
// EmailLog and booking_notifications receive exact-schema records after verified payment dispatch.
const third=ctx.handleNewBooking({bookingId:'MDB-TEST-3',customerName:'Mail Test',customerMobile:'9888888888',customerEmail:'mail@example.com',travelDate:'2026-12-05',routeName:'Western',pickupPointName:'Borivali',packageId:'ac_no_lunch',packageTitle:'AC Bus',passengerCount:1,onlineBookingFare:300,advancePayable:200});
assert.equal(third.status,'success');
const settings=spreadsheet.getSheetByName('Settings'); let emailSettingRow=settings.rows.findIndex(row=>row[0]==='ENABLE_LIVE_EMAILS'); if(emailSettingRow<0) settings.appendRow(['ENABLE_LIVE_EMAILS',true,'test switch',new Date()]); else settings.rows[emailSettingRow][1]=true;
const mailPayment=ctx.handleVerifiedPayment({bookingId:'MDB-TEST-3',paymentId:'P-3',transactionRef:'TX-3',amount:200,providerVerified:true,callbackSecret:'secret',provider:'Test Gateway'});
assert.equal(mailPayment.status,'success');
const paidAdminCancel=ctx.handleAdminApiAction_('ADMIN_CREATE_CANCELLATION',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',bookingId:'MDB-TEST-3',reason:'Paid booking cancellation review'});
assert.equal(paidAdminCancel.status,'success'); assert.equal(paidAdminCancel.refundReviewAmount,200);
const paidCancellationId=cancellationSheet.rows[3][0];
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_REFUND_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',cancellationId:paidCancellationId,refundStatus:'Refunded',manualRefundConfirmed:true}).status,'error','refund cannot skip approval');
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_REFUND_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',cancellationId:paidCancellationId,refundStatus:'Approved'}).status,'success');
assert.equal(b.rows[3][17],'Cancelled','approved cancellation must cancel the booking');
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_REFUND_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',cancellationId:paidCancellationId,refundStatus:'Pending Review'}).status,'error','approved cancellation cannot be moved backwards');
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_REFUND_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',cancellationId:paidCancellationId,refundStatus:'Refunded'}).status,'error','manual refund confirmation is mandatory');
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_REFUND_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',cancellationId:paidCancellationId,refundStatus:'Refunded',manualRefundConfirmed:true}).status,'success');
assert.equal(cancellationSheet.rows[3][6],'Refunded');
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_REFUND_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',cancellationId:paidCancellationId,refundStatus:'Approved'}).status,'error','refunded is terminal');
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_REFUND_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',cancellationId:paidCancellationId,refundStatus:'Refunded'}).status,'success','same terminal state retry is idempotent');
const emailLog=spreadsheet.getSheetByName('EmailLog'); const notifications=spreadsheet.getSheetByName('booking_notifications');
assert.equal(emailLog.rows.length,3,'customer and owner email attempts must be logged');
assert.equal(emailLog.rows[1].length,6); assert.equal(emailLog.rows[1][4],'Failed');
assert.equal(notifications.rows.length,9,'booking and cancellation lifecycle notifications must be recorded idempotently');
assert.equal(notifications.rows[1].length,8); assert.equal(notifications.rows[6][5],'Failed');
const bookingAdminUpdate=ctx.handleAdminApiAction_('ADMIN_UPDATE_BOOKING_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',bookingId:'MDB-TEST-1',bookingStatus:'Cancelled'});
assert.equal(bookingAdminUpdate.status,'error','direct cancellation must use the auditable cancellation/refund workflow'); assert.equal(b.rows[1][17],'Confirmed');
const rentalAdminUpdate=ctx.handleAdminApiAction_('ADMIN_UPDATE_RENTAL_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',enquiryId:'REN-1',status:'Contacted'});
assert.equal(rentalAdminUpdate.status,'success'); assert.equal(r.rows[1][11],'Contacted');
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_BOOKING_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',bookingId:'MDB-TEST-1',bookingStatus:'Made Up'}).status,'error');
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_BOOKING_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',bookingId:'MDB-TEST-2',bookingStatus:'Confirmed'}).status,'error','unpaid booking cannot be admin-confirmed');
// A forged paid label without a verified ledger must not allow Admin confirmation.
b.rows[2][16]='Advance Paid';
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_BOOKING_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',bookingId:'MDB-TEST-2',bookingStatus:'Confirmed'}).status,'error','booking payment label alone is not proof of a verified payment');
b.rows[2][16]='Payment Pending';
// Verified payment evidence must be complete and unique before Admin completion.
const verifiedLedgerRow=p.rows.find(row=>row[1]==='MDB-TEST-1' && row[6]==='Verified');
const originalTransactionRef=verifiedLedgerRow[5];
verifiedLedgerRow[5]='';
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_BOOKING_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',bookingId:'MDB-TEST-1',bookingStatus:'Completed'}).status,'error','missing transaction reference blocks Admin completion');
verifiedLedgerRow[5]=originalTransactionRef;
p.appendRow(verifiedLedgerRow.slice());
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_BOOKING_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',bookingId:'MDB-TEST-1',bookingStatus:'Completed'}).status,'error','multiple ledger rows block Admin completion');
p.rows.pop();
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_BOOKING_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',bookingId:'MDB-TEST-1',bookingStatus:'Completed'}).status,'success','complete verified ledger evidence permits Admin completion');
assert.equal(b.rows[1][17],'Completed');
// Duplicate Booking IDs fail closed rather than updating the first matching row.
b.appendRow(b.rows[1].slice());
assert.equal(ctx.handleAdminApiAction_('ADMIN_UPDATE_BOOKING_STATUS',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',bookingId:'MDB-TEST-1',bookingStatus:'Confirmed'}).status,'error','duplicate Booking IDs must block Admin status changes');
b.rows.pop();
// Read-only booking/payment reconciliation flags missing, orphan, multiple and inconsistent ledger records.
const reconciliation=JSON.parse(JSON.stringify(ctx.buildBookingPaymentReconciliation_([
  {'Booking ID':'REC-1','Payment Status':'Advance Paid','Booking Status':'Confirmed','Amount INR':600},
  {'Booking ID':'REC-2','Payment Status':'Advance Paid','Booking Status':'Confirmed','Amount INR':400},
  {'Booking ID':'REC-3','Payment Status':'Payment Pending','Booking Status':'Pending Verification','Amount INR':200}
],[
  {booking_id:'REC-1',payment_id:'PAY-REC-1',amount:200,payment_method:'Advance ₹200 per booking',transaction_reference:'TX-REC-1',payment_status:'Verified',verified_at:'2026-11-11T10:00:00.000Z'},
  {booking_id:'REC-2',payment_id:'PAY-REC-2',amount:200,payment_method:'Advance ₹200 per booking',transaction_reference:'TX-REC-2',payment_status:'Pending',verified_at:''},
  {booking_id:'ORPHAN-REC',payment_id:'PAY-ORPHAN',amount:50,payment_method:'Advance',transaction_reference:'TX-ORPHAN',payment_status:'Pending',verified_at:''}
])));
assert.equal(reconciliation.summary.totalBookings,3);
assert.equal(reconciliation.summary.totalLedgerRows,3);
assert.equal(reconciliation.summary.missingLedger,1);
assert.equal(reconciliation.summary.orphanLedgerRows,1);
assert.equal(reconciliation.summary.bookingLedgerMismatches,2);
assert.equal(reconciliation.summary.verifiedOnlineAmount,200);
assert.ok(reconciliation.findings.some(f=>f.code==='BOOKING_MARKED_PAID_WITHOUT_VERIFIED_LEDGER'));
assert.ok(reconciliation.findings.some(f=>f.code==='MISSING_LEDGER'));
assert.ok(reconciliation.findings.some(f=>f.code==='ORPHAN_LEDGER_ROW'));
const duplicateLedgerAudit=JSON.parse(JSON.stringify(ctx.buildBookingPaymentReconciliation_([
  {'Booking ID':'REC-DUP','Payment Status':'Fully Paid','Booking Status':'Confirmed','Amount INR':300}
],[
  {booking_id:'REC-DUP',payment_id:'PAY-DUP',amount:300,payment_method:'Full Booking Amount',transaction_reference:'TX-DUP',payment_status:'Verified',verified_at:'2026-11-11T10:00:00.000Z'},
  {booking_id:'REC-DUP',payment_id:'PAY-DUP',amount:300,payment_method:'Full Booking Amount',transaction_reference:'TX-DUP',payment_status:'Verified',verified_at:'2026-11-11T10:00:00.000Z'}
])));
assert.equal(duplicateLedgerAudit.summary.multipleLedgerBookings,1);
assert.equal(duplicateLedgerAudit.summary.duplicatePaymentReferences,2);
assert.equal(duplicateLedgerAudit.summary.verifiedAmountOverBooking,1);
assert.ok(duplicateLedgerAudit.findings.some(f=>f.code==='DUPLICATE_TRANSACTION_REFERENCE'));
assert.ok(duplicateLedgerAudit.findings.some(f=>f.code==='DUPLICATE_PAYMENT_ID'));

// Admin GET_DATA must carry the reconciliation snapshot; report stays PII-free,
// handles empty sheets, and caps retained findings and serialized payload size.
assert.ok(adminData.data.paymentReconciliation && adminData.data.paymentReconciliation.summary,
  'authenticated ADMIN_GET_DATA must include paymentReconciliation');
assert.ok(Array.isArray(adminData.data.paymentReconciliation.findings));
const emptyAudit=JSON.parse(JSON.stringify(ctx.buildBookingPaymentReconciliation_([],[])));
assert.equal(emptyAudit.summary.totalBookings,0);
assert.equal(emptyAudit.summary.totalLedgerRows,0);
assert.equal(emptyAudit.summary.issueCount,0);
assert.equal(emptyAudit.findings.length,0);
assert.equal(emptyAudit.findingsTruncated,false);
const privateAudit=JSON.parse(JSON.stringify(ctx.buildBookingPaymentReconciliation_([
  {'Booking ID':'REC-PRIVATE','Name':'Secret Customer Name','Phone':'9876543210','Customer Email':'secret@example.com','Payment Status':'Advance Paid','Booking Status':'Pending Verification','Amount INR':500}
],[
  {booking_id:'REC-PRIVATE',payment_id:'PAY-PRIVATE',amount:200,payment_method:'Advance',transaction_reference:'TX-PRIVATE',payment_status:'Pending',verified_at:'',customer_name:'Secret Customer Name',mobile:'9876543210',email:'secret@example.com'}
])));
const privateAuditJson=JSON.stringify(privateAudit);
for (const secret of ['Secret Customer Name','9876543210','secret@example.com','TX-PRIVATE','PAY-PRIVATE'])
  assert.equal(privateAuditJson.includes(secret),false,'reconciliation must not expose customer or payment identifiers: '+secret);
const noisyBookings=Array.from({length:260},(_,i)=>({'Booking ID':'REC-NOISE-'+i,'Payment Status':'Advance Paid','Booking Status':'Pending Verification','Amount INR':200}));
const cappedAudit=JSON.parse(JSON.stringify(ctx.buildBookingPaymentReconciliation_(noisyBookings,[])));
assert.equal(cappedAudit.summary.issueCount,520,'all issues must be counted even when findings are capped');
assert.equal(cappedAudit.findings.length,250,'only first 250 findings may be retained in memory/output');
assert.equal(cappedAudit.findingsTruncated,true);
assert.equal(cappedAudit.summary.cleanBookings,0,'clean booking count must use all findings, not only retained display rows');

// Daily report aggregation uses exact approved 8-column schema, verified collections only, and idempotent date upsert.
const dailyDate='2026-11-11';
for (let i=1;i<b.rows.length;i++) b.rows[i][0]=new Date(dailyDate+'T10:00:00.000Z');
for (let i=1;i<p.rows.length;i++) { p.rows[i][7]=new Date(dailyDate+'T11:00:00.000Z'); p.rows[i][8]=new Date(dailyDate+'T12:00:00.000Z'); }
const dailyReport=ctx.handleAdminApiAction_('ADMIN_GENERATE_DAILY_REPORT',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',reportDate:dailyDate});
assert.equal(dailyReport.status,'success');
assert.equal(dailyReport.report.report_date,dailyDate);
assert.equal(dailyReport.report.total_bookings,3);
assert.equal(dailyReport.report.confirmed_bookings,1);
assert.equal(dailyReport.report.cancelled_bookings,1);
assert.equal(dailyReport.report.total_customers,3);
assert.equal(dailyReport.report.total_revenue,400);
assert.equal(dailyReport.report.pending_payments,1);
const dailySheet=spreadsheet.getSheetByName('daily_reports');
assert.equal(dailySheet.rows[1].length,8);
assert.equal(dailySheet.rows.length,2);
ctx.handleAdminApiAction_('ADMIN_GENERATE_DAILY_REPORT',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',reportDate:dailyDate});
assert.equal(dailySheet.rows.length,2,'daily report generation must update same date row, not duplicate it');
const noEmailBooking=ctx.handleNewBooking({bookingId:'MDB-NO-EMAIL',customerName:'No Email',customerMobile:'9000000011',travelDate:'2026-12-07',routeName:'Western',pickupPointName:'Borivali',packageId:'non_ac_no_lunch',passengerCount:1});
assert.equal(noEmailBooking.status,'success','email must remain optional');
assert.equal(b.rows[2][4],'','blank customer email must remain blank, not become a fabricated address');
assert.equal(ctx.handleNewBooking({bookingId:'MDB-51-PAX',customerName:'Too Many',customerMobile:'9000000012',travelDate:'2026-12-07',routeName:'Western',packageId:'non_ac_no_lunch',passengerCount:51}).status,'error','server passenger cap must match the 50-person customer form cap');
assert.equal(ctx.handleNewBooking({bookingId:'MDB-BAD-MOBILE',customerName:'Bad Mobile',customerMobile:'123',travelDate:'2026-12-07',routeName:'Western',packageId:'non_ac_no_lunch',passengerCount:1}).status,'error','invalid customer mobile must be rejected server-side');
assert.equal(ctx.handleNewBooking({bookingId:'MDB-BAD-EMAIL',customerName:'Bad Email',customerMobile:'9000000013',customerEmail:'not-an-email',travelDate:'2026-12-07',routeName:'Western',packageId:'non_ac_no_lunch',passengerCount:1}).status,'error','invalid optional email must be rejected server-side');
assert.equal(ctx.handleNewBooking({bookingId:'MDB-PAST-DATE',customerName:'Past Date',customerMobile:'9000000014',travelDate:'2020-01-01',routeName:'Western',packageId:'non_ac_no_lunch',passengerCount:1}).status,'error','past travel dates must be rejected server-side');
assert.equal(ctx.handleNewBooking({bookingId:'MDB-INVALID-DATE',customerName:'Invalid Date',customerMobile:'9000000015',travelDate:'2026-02-30',routeName:'Western',packageId:'non_ac_no_lunch',passengerCount:1}).status,'error','impossible travel dates must be rejected server-side');

assert.equal(ctx.handleAdminApiAction_('ADMIN_GENERATE_DAILY_REPORT',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret',reportDate:'11/11/2026'}).status,'error');
assert.equal(ctx.handleAdminApiAction_('ADMIN_GENERATE_DAILY_REPORT',{adminEmail:'blocked@example.com',adminApiSecret:'server-only-secret',reportDate:dailyDate}).authorized,false);
assert.equal(JSON.stringify(dailyReport.report).includes('9888888888'),false,'daily report must not include customer PII');
adminSheet.rows[1][2]=false;
assert.equal(ctx.handleAdminApiAction_('ADMIN_GET_DATA',{adminEmail:'owner@example.com',adminApiSecret:'server-only-secret'}).authorized,false,'deactivated admin must be denied');

// Safe webhook activity summaries must never serialize Admin data/PII.
const sensitiveAdminResult={status:'success',data:{bookings:[{Name:'Secret Name',Phone:'9876543210','Customer Email':'secret@example.com'}],payments:[{transaction_reference:'TX-SECRET'}]}};
const safeLog=ctx.safeActivitySummary_('ADMIN_GET_DATA',sensitiveAdminResult);
for (const secret of ['Secret Name','9876543210','secret@example.com','TX-SECRET']) assert.equal(safeLog.includes(secret),false);
assert.equal(safeLog,'action=ADMIN_GET_DATA; status=success; datasets=2');
assert.match(code,/var lock = LockService\.getScriptLock\(\);[\s\S]*?var acquired = lock\.tryLock\(15000\);[\s\S]*?switch \(action\)/,'doPost must acquire the global ScriptLock before dispatching actions');
assert.match(code,/cache\.get\(key\)[\s\S]*?cache\.put\(key, String\(count \+ 1\), ttlSeconds\)/,'public limiter counter must remain a read/check/write under the webhook lock');
// Hashed persistent limiter counter: exact cap, then deny; expiry resets.
assert.equal(ctx.consumePublicAttempt_('test','same-key',2,60),true);
assert.equal(ctx.consumePublicAttempt_('test','same-key',2,60),true);
assert.equal(ctx.consumePublicAttempt_('test','same-key',2,60),false);

// If the payment ledger append fails during a fresh booking, the Bookings row
// must be rolled back and the ID must remain reusable for a clean retry.
p.failNextAppend=true;
const rolledBack=ctx.handleNewBooking({bookingId:'MDB-ROLLBACK-1',customerName:'Rollback',customerMobile:'9000000001',travelDate:'2026-12-04',routeName:'Western',packageId:'non_ac_no_lunch',passengerCount:1});
assert.equal(rolledBack.status,'error');
assert.equal(b.rows.some(row=>row[1]==='MDB-ROLLBACK-1'),false,'partial booking row must be rolled back when payment ledger write fails');
assert.equal(ctx.handleNewBooking({bookingId:'MDB-ROLLBACK-1',customerName:'Retry',customerMobile:'9000000001',travelDate:'2026-12-04',routeName:'Western',packageId:'non_ac_no_lunch',passengerCount:1}).status,'success','same ID can be retried after a confirmed rollback');

// The public webhook already owns the ScriptLock; NEW_BOOKING must reuse it
// rather than recursively waiting on the same lock.
const waitsBeforeWebhookBooking=scriptLockWaits;
const webhookSave=ctx.doPost({postData:{contents:JSON.stringify({action:'NEW_BOOKING',bookingId:'MDB-WEBHOOK-1',customerName:'Webhook',customerMobile:'9000000002',travelDate:'2026-12-05',routeName:'Central',packageId:'ac_no_lunch',passengerCount:1})}});
const webhookSaveBody=JSON.parse(webhookSave.text);
assert.equal(webhookSaveBody.status,'success');
assert.equal(webhookSaveBody.bookingId,'MDB-WEBHOOK-1');
assert.equal(b.rows.find(row=>row[1]==='MDB-WEBHOOK-1')[1],'MDB-WEBHOOK-1','webhook booking ID must persist in Bookings column 2');
assert.equal(scriptLockWaits,waitsBeforeWebhookBooking,'NEW_BOOKING webhook must not recursively wait for its already-held ScriptLock');

console.log('PASS: Code.gs schema equals JSON/workbook manifest; bootstrap creates 17 tabs/139 headers and is idempotent; exact header mismatch fails closed; booking/payment/rental mappings; partial booking retry fails closed for Admin reconciliation when ledger is missing; public Admin mutations fail closed; payment verification; Admin API secret, active AdminUsers roster, protected data retrieval, authenticated booking/rental status updates, invalid status rejection, unpaid-confirmation block, deactivation and activity logging; no extra tabs.');
