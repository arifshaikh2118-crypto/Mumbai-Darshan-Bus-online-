const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '../..');
const ui = fs.readFileSync(path.join(root, 'src/components/admin/OperationalSheetsManager.tsx'), 'utf8');
const layout = fs.readFileSync(path.join(root, 'src/components/admin/AdminLayout.tsx'), 'utf8');
const expected = ['pickupPoints','packageOptions','bookingDates','rentalVehicles','websiteContent','attractionPoints','attractionTickets'];
const checks = [
  ['All seven approved sheets have Admin editor configs', expected.every(k => ui.includes(`key: '${k}'`))],
  ['Create/edit calls authenticated upsert endpoint', ui.includes("'/api/admin/operational/upsert'") && ui.includes('Authorization:')],
  ['Delete calls authenticated delete endpoint', ui.includes("'/api/admin/operational/delete'") && ui.includes('window.confirm')],
  ['Editor uses approved exact column lists', ui.includes('headers: [') && ui.includes('config.headers.forEach')],
  ['Required stable keys are validated and locked on edit', ui.includes('config.required') && ui.includes('disabled className')],
  ['UI refreshes from protected Admin data after write', ui.includes('onRefresh();')],
  ['Admin Sheets section mounts the editor', layout.includes('<OperationalSheetsManager data={adminSheetData}')],
  ['No supplier cost or margin fields added', !/supplier_cost|supplier_rate|gross_margin|profit_margin/i.test(ui)]
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) failed++; }
if (failed) process.exit(1);
