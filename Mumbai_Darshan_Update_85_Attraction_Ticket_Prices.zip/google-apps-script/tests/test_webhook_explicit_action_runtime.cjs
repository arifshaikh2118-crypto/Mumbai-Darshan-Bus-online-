const fs = require('fs');
const vm = require('vm');
const assert = require('assert');

const gas = fs.readFileSync('google-apps-script/Code.gs', 'utf8');
const match = gas.match(/function doPost\(e\) \{[\s\S]*?\n\}/);
assert.ok(match, 'doPost function must exist');

let released = 0;
let activityLogs = 0;
const sandbox = {
  LockService: {
    getScriptLock: () => ({
      tryLock: () => true,
      releaseLock: () => { released += 1; }
    })
  },
  createJsonResponse: (body, status) => ({ body, status }),
  Utilities: {
    formatDate: () => '2026-11-20 10:00:00'
  },
  logActivity: () => { activityLogs += 1; },
  safeActivityRecordId_: () => 'General',
  safeActivitySummary_: () => 'safe summary',
  handleNewBooking: () => { throw new Error('Missing action must never reach booking handler'); }
};

vm.createContext(sandbox);
vm.runInContext(match[0], sandbox);
const doPost = sandbox.doPost;

for (const [label, payload] of [
  ['missing action', { customerName: 'Test' }],
  ['blank action', { action: '   ', customerName: 'Test' }],
  ['non-string action', { action: 123, customerName: 'Test' }]
]) {
  const beforeReleased = released;
  const result = doPost({ postData: { contents: JSON.stringify(payload) } });
  assert.strictEqual(result.status, 400, `${label} must return HTTP 400`);
  assert.strictEqual(result.body.status, 'error', `${label} must fail closed`);
  assert.strictEqual(result.body.message, 'An explicit action is required.');
  assert.strictEqual(released, beforeReleased + 1, 'Script lock must be released on rejected request');
}
assert.strictEqual(activityLogs, 0, 'Rejected requests must not enter action handlers or activity success logging');

const ping = doPost({ postData: { contents: JSON.stringify({ action: 'PING_TEST' }) } });
assert.strictEqual(ping.body.status, 'success', 'An explicit allowed action must still work');
assert.strictEqual(activityLogs, 1, 'Explicit allowed action should continue through normal activity logging');

console.log('PASS Runtime webhook checks: missing, blank and non-string actions rejected; lock released; explicit PING_TEST still works.');
