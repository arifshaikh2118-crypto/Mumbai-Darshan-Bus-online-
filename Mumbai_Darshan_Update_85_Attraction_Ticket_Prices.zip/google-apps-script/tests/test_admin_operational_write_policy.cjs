const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '../..');
const gs = fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');
const checks = [
  ['Admin write actions routed through protected handler', gs.includes("case 'ADMIN_UPSERT_OPERATIONAL_RECORD'") && gs.includes("case 'ADMIN_DELETE_OPERATIONAL_RECORD'")],
  ['Only seven approved operational tabs editable', ['pickupPoints','packageOptions','bookingDates','rentalVehicles','websiteContent','attractionPoints','attractionTickets'].every(k => gs.includes(k))],
  ['Sensitive/configuration and ledger tabs not in editable allowlist', !/adminUsers\s*:\s*\{\s*sheet/.test(gs) && !/settings\s*:\s*\{\s*sheet/.test(gs)],
  ['Exact approved schema headers enforced before writes', gs.includes('getRequiredSheet_(spec.sheet)') && gs.includes('allowedHeaders.indexOf(k) === -1')],
  ['Unknown fields rejected', gs.includes('Unknown or empty fields. Approved schema was not changed.')],
  ['Activity log records create/update/delete', gs.includes('ADMIN_OPERATIONAL_RECORD_UPDATED') && gs.includes('ADMIN_OPERATIONAL_RECORD_CREATED') && gs.includes('ADMIN_OPERATIONAL_RECORD_DELETED')],
  ['Server routes require Admin session', server.includes("'/api/admin/operational/upsert', requireAdmin") && server.includes("'/api/admin/operational/delete', requireAdmin")],
  ['No browser-side admin API secret added', !/ADMIN_API_SECRET\s*=/.test(fs.readFileSync(path.join(root, 'src/components/admin/AdminLayout.tsx'), 'utf8'))]
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) failed++; }
if (failed) process.exit(1);
