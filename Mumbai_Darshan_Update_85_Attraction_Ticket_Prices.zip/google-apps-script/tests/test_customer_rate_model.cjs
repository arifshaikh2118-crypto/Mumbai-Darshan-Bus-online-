const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '../..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

const types = read('src/types/index.ts');
const initial = read('src/data/initialData.ts');
const storage = read('src/services/storage.ts');
const panel = read('src/components/CarRentalPanel.tsx');
const rentals = read('src/components/admin/AdminRentalsTab.tsx');
const reports = read('src/components/admin/AdminReportsTab.tsx');

if (!types.includes('customerPerKm: number;') || !types.includes('customerDaPerDay: number;') || !types.includes('customerPrice: number;')) {
  throw new Error('Final customer-facing rental rate fields are missing from the types.');
}
if (types.includes('supplierRate') || types.includes('supplierCost') || types.includes('grossMargin')) {
  throw new Error('Supplier or margin field found in active TypeScript data model.');
}
if (!initial.includes('customerPerKm: 19') || !initial.includes('customerPerKm: 63') || !initial.includes('customerDaPerDay: 2500')) {
  throw new Error('Existing final customer prices were not preserved.');
}
if ((initial.match(/customerPerKm:\s*\d+/g) || []).length !== 16) {
  throw new Error('Expected all 16 existing outstation customer-rate records to remain.');
}
if (!storage.includes('customerPerKm: rest.customerPerKm ?? proposedCustomerPerKm') || !storage.includes('delete legacy names via destructuring')) {
  // The first clause confirms a compatibility migration. The second is intentionally
  // not required: legacy fields are destructured and therefore removed from saved data.
  if (!storage.includes('customerPerKm: rest.customerPerKm ?? proposedCustomerPerKm')) {
    throw new Error('Legacy customer-rate migration does not preserve existing values.');
  }
}
if (!panel.includes('.customerPerKm') || !panel.includes('.customerDaPerDay') || !panel.includes('.customerPrice')) {
  throw new Error('Customer-facing rental calculator does not use final customer-rate fields.');
}
if (rentals.includes('supplier cost') || rentals.includes('supplier rate') || rentals.includes('margin')) {
  throw new Error('Supplier or margin concepts remain in the rental enquiry UI.');
}
if (reports.includes('rental profitability')) {
  throw new Error('Reports UI still advertises rental profitability.');
}
console.log('PASS: rental pricing uses final customer-facing rates only; all 16 outstation rates and local prices retained; old browser rate records migrate without changing numeric values; no supplier-rate/cost/margin UI.');
