const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '../..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const ui = read('src/components/admin/AdminRentalsTab.tsx');
const types = read('src/types/index.ts');
const layout = read('src/components/admin/AdminLayout.tsx');
const storage = read('src/services/storage.ts');
const panel = read('src/components/CarRentalPanel.tsx');
const server = read('server.ts');
const gas = read('google-apps-script/Code.gs');
const expected = ['New', 'Contacted', 'Quote Sent', 'Follow-up', 'Confirmed', 'Not Interested', 'Cancelled'];
for (const status of expected) {
  for (const [name, source] of [['UI', ui], ['Server', server], ['Apps Script', gas]]) {
    if (!source.includes(`'${status}'`)) throw new Error(`${name} missing rental status ${status}`);
  }
}
for (const [name, source] of [['Admin UI', ui], ['Browser types', types], ['Admin reports', read('src/components/admin/AdminReportsTab.tsx')], ['Rental form', panel]]) {
  for (const forbidden of ['supplierCost', 'supplierPerKm', 'supplierDaPerDay', 'customerQuotation', 'grossMargin']) {
    if (source.includes(forbidden)) throw new Error(`${name} still contains restricted field ${forbidden}`);
  }
}
if (!layout.includes('tempoTravellerSeatingCapacity') || !layout.includes('rentalDuration') || !layout.includes('acPreference')) throw new Error('Admin mapping does not include all approved rental fields');
if (!storage.includes("status: 'New'")) throw new Error('New rental enquiry does not default to New');
if (!storage.includes('approvedInquiryFields')) throw new Error('Legacy browser rental records are not scrubbed');
const syncBlock = storage.slice(storage.indexOf('static async syncRentalToGoogleSheets'), storage.indexOf('// Group Enquiries'));
for (const forbidden of ['customerEmail:', 'customerQuotation:', 'supplierCost:', 'grossMargin:', 'garageRouteSummary:']) if (syncBlock.includes(forbidden)) throw new Error(`Rental sync payload includes unsupported/private field ${forbidden}`);
if (panel.includes('customerEmail')) throw new Error('Rental form still collects email not present in the approved schema');
if (!ui.includes('WhatsApp follow-up') || ui.includes('Send WhatsApp Quote')) throw new Error('WhatsApp enquiry-only follow-up is not correctly presented');
console.log('PASS: rental enquiry-only policy — approved status workflow, full schema field mapping, no supplier/quotation/margin data in browser source, legacy local data scrub, and manual WhatsApp follow-up.');
