# Mumbai Darshan Bus Online — Controlled Apps Script Setup Guide

**Current release gate: DEFERRED — no Apps Script or Google Sheets work is required in the current local-only phase. NOT READY for live deployment.** This guide replaces earlier instructions that referred to a 24/25-tab schema, a built-in Admin passcode, public Admin mutations, GET booking lookup, and browser-triggered email tests. Those instructions are obsolete and must not be followed.

## Before setup

1. Finish local source audit, local regression tests, documentation and package files. Network build/browser/staging checks will be scheduled in the later integration phase.
2. Obtain explicit owner approval before the later staging phase. The owner will not create a spreadsheet, tabs or headings manually; the supplied Apps Script bootstrap will create them automatically.
3. Keep PhonePe/payment gateway disabled. Do not fabricate `PAYMENT_VERIFIED` callbacks.
4. Do not enable live customer/owner email or install scheduled triggers during initial staging.

## Database bootstrap (only after staging approval)

- Open the Apps Script project and paste the complete current `google-apps-script/Code.gs`.
- Confirm `appsscript.json` uses `Asia/Kolkata`, V8 and the intended web-app access model.
- Run `setupDatabase()` exactly once for the isolated staging project. It creates the spreadsheet automatically, stores `SPREADSHEET_ID`, validates the approved schema and seeds the 16 package/route rows only when `PackageOptions` is empty.
- Expected schema: exactly **17 tabs / 139 headers**. Do not manually add, rename or delete tabs/columns. Do not run setup against production or an existing unrelated spreadsheet.

## Server-side configuration

Configure only in the hosting provider's private server environment:

- `GOOGLE_APPS_SCRIPT_URL`: the exact deployed HTTPS `/macros/s/{deployment-id}/exec` URL.
- `ADMIN_PASSCODE`: a new strong admin passphrase.
- `ADMIN_SESSION_SECRET`: independent random secret (32+ bytes recommended).
- `ADMIN_API_SECRET`: independent random secret, also stored in Apps Script Script Properties under the same name.

Never use `VITE_` variables for secrets. Never put secrets in browser code, `Settings`, workbook cells, ZIP documentation or GitHub. The AdminUsers roster must contain the authorized lowercase email with role `admin` or `owner` and `Active=TRUE`.

## Public and Admin routes

- Public Sheets proxy permits only `NEW_BOOKING`, `NEW_RENTAL_ENQUIRY` / `CAR_RENTAL`, and `PING_TEST`, and only to the server-configured Apps Script URL.
- Public booking lookup and cancellation use dedicated POST endpoints and require Booking ID plus registered mobile; lookup data is masked/minimal.
- Admin reads and mutations use authenticated Express endpoints and the server-to-server Apps Script secret plus active `AdminUsers` roster.
- Direct public `UPDATE_BOOKING_STATUS`, `UPDATE_RENTAL_STATUS`, `RETRY_EMAILS`, and `TEST_EMAIL` actions are disabled. Do not use old direct webhook instructions.
- `PAYMENT_VERIFIED` is reserved for a future secure provider integration. It must never be called by browser JavaScript.

## Controlled staging test sequence

1. Verify `GET /api/admin/verify` and Admin roster authorization.
2. Create one clearly labelled test booking and verify one `booking` row plus one pending `booking_payments` row.
3. Verify forged browser totals are ignored and server-side route/package pricing is used.
4. Verify duplicate retry does not create another booking or payment ledger row.
5. Verify a rental enquiry writes only to `rental_enquiry` and sends no owner/customer email.
6. Verify lookup requires both factors and exposes no email/full mobile/special request.
7. Verify public cancellation and Admin refund review; no automatic refund occurs.
8. Exercise the seven approved operational-sheet CRUD screens using disposable rows only.
9. Verify EmailLog, notification idempotency and Daily Reports against the actual staging rows.
10. Test concurrency/rate limiting and inspect Apps Script executions and `activity_log` for safe summaries only.

Do not send live email until the owner explicitly approves a controlled recipient test. `runEmailConnectionTest()` is owner-run in the Apps Script editor; the public website webhook cannot invoke it. Do not install `setupDailyReportTrigger()` until the owner approves the schedule and recipient.

## Release gates

- `npm run lint` and `npm run build` pass in a clean network-enabled runner.
- Browser E2E passes against staging for booking, rental, lookup, cancellation, Admin authentication, seven operational CRUD tabs, email retry/refund controls and reports.
- Exact 17-tab/139-header schema and package pricing are confirmed in the staging spreadsheet.
- Secrets are configured privately; no secrets appear in source, browser bundle or repository.
- Owner separately approves GitHub commit, existing Preview refresh, Apps Script production deployment, email activation, payment gateway and final production deployment.

### Rental customer rates
- The approved 17-tab / 139-header schema is unchanged. Local Darshan and Outstation rates are stored in the existing `Settings` sheet under `PUBLIC_RENTAL_PRICING_JSON`.
- The one-time `setupDatabase()` seed uses the existing website's six Local Darshan packages and sixteen Outstation classes. An authorized Admin can update these through the Private Fleet & Quotations panel.
- Before production use, the owner must review all rates, 12-hour/120-KM local limits, 300-KM/day outstation minimum, daily DA and Night DA. Night DA must equal the daily DA.
