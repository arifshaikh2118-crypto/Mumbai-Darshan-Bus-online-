# Secure Admin Authentication & Data Retrieval (Update 18)

This feature is fail-closed. The browser never receives `ADMIN_API_SECRET`; the Express server holds it and calls the Apps Script web app. Apps Script checks the secret and the `AdminUsers` sheet before returning private records.

## Required server environment variables

Set these only in the hosting provider's server-side environment (never in Vite `VITE_*` variables, source code, browser storage, or a public settings sheet):

- `ADMIN_PASSCODE`: a new, long, random passphrase. Do not reuse any old passcode.
- `ADMIN_SESSION_SECRET`: a separate random secret (32+ random bytes recommended) used to sign 30-minute session tokens.
- `ADMIN_API_SECRET`: a third independent random secret shared with Apps Script Script Properties.
- `GOOGLE_APPS_SCRIPT_URL`: the deployed Apps Script `/exec` URL.

The server intentionally refuses Admin login if any variable is missing. There is no built-in passcode or offline fallback. Login attempts are rate-limited per IP (five failures trigger a 15-minute block).

## Apps Script configuration

In the Apps Script project, open **Project Settings → Script Properties** and add:

- Property: `ADMIN_API_SECRET`
- Value: exactly the same secret as the server's `ADMIN_API_SECRET`

Do not add it to `Code.gs`, `appsscript.json`, the workbook, or website settings. Deploy a new Web App version after updating `Code.gs`; keep the deployment access needed by the server-to-server proxy.

## Authorize Admin accounts

In the approved `AdminUsers` tab, add one row per authorized user:

- `Email`: exact Google/account email in lowercase
- `Role`: `admin` or `owner`
- `Active`: `TRUE`
- `created_at`, `updated_at`: timestamps

Only active `admin` and `owner` rows pass the roster check. The server checks the email against this sheet at login; changing a row to inactive blocks the next login. Existing issued sessions expire within 30 minutes.

## API behavior

- `POST /api/admin/login`: requires email and passcode; checks the AdminUsers roster through Apps Script; returns a signed 30-minute bearer token.
- `GET /api/admin/verify`: validates the signed token.
- `GET /api/admin/data`: requires the bearer token; returns booking, rental enquiry, payment ledger and cancellation records from schema-validated tabs. Each read is logged in `activity_log` with the admin email.

The frontend does not trust `sessionStorage` flags. It verifies the bearer token with the server on load, and removes invalid/expired tokens. Logout clears the token. Do not expose the Apps Script shared secret or call privileged Apps Script actions directly from browser code.

## Important limitations

This source update does not configure hosting secrets, add AdminUsers rows, deploy Apps Script, create a spreadsheet, or verify a live Google account. Those require owner-controlled accounts and an approved final setup. The existing admin dashboard still contains legacy local-storage views; switching every dashboard tab to live Google Sheets data and enabling authenticated status mutations are separate integration steps. Until then, this update provides the secure login gate and protected server-side retrieval API, not a claim that every Admin screen is already live-backed.
