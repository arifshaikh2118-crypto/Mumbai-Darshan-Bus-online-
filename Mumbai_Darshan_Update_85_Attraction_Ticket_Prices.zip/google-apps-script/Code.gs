/**
 * =========================================================================
 * MUMBAI DARSHAN BUS ONLINE - AUTHORITATIVE GOOGLE APPS SCRIPT ENGINE
 * =========================================================================
 * Production Domain: https://mumbaidarshanbusonline.com
 * Official Business Phone: 9619975457 | Email: mumbaidarshanbooking@gmail.com
 * Registered Office: 110, Sai Krupa Chawl, Bansi Nagar, W. E. Highway,
 *                   Kulupwadi, Borivali East, Mumbai, Maharashtra 400066.
 * 
 * Schema alignment: 17 approved tabs / 139 headers from the project schema workbook.
 * Runtime writes require exact header validation; runtime requests never create tabs.
 * Standalone setupDatabase() creates the spreadsheet automatically at final setup.
 * Rental enquiries remain inquiry-only and never trigger emails or payment calls.
 * Payment status is promoted only by a trusted server-side verified callback.
 */

// Standalone Apps Script: spreadsheet is resolved lazily from Script Properties.
// Never depend on an already-open/active Google Sheet.
var PROTECTED_SPREADSHEET_IDS = [
  '1KhIkqROzfTIv95z3b5CJHNOh4iCh9gLHYGPMEg4WfiE', // production: reference-only
  '1mkYtyCsUygqex7eNWJDB9_3JBlOPPf6_v8z1-uV9318'  // retired staging: never reuse
];

function getSpreadsheet_() {
  var id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (!id) throw new Error('Database is not initialized. Run setupDatabase() at the approved final setup stage.');
  if (PROTECTED_SPREADSHEET_IDS.indexOf(id) !== -1) throw new Error('Configured spreadsheet ID is protected/retired. This project will not access it.');
  return SpreadsheetApp.openById(id);
}

var BUSINESS_CONFIG = {
  NAME: 'Mumbai Darshan Bus Online',
  DOMAIN: 'https://mumbaidarshanbusonline.com',
  PHONE: '9619975457',
  EMAIL: 'mumbaidarshanbooking@gmail.com',
  ADDRESS: '110, Sai Krupa Chawl, Bansi Nagar, W. E. Highway, Kulupwadi, Borivali East, Mumbai, Maharashtra 400066.',
  HOURS: '6:00 AM – 10:30 PM (Daily)'
};

// SAFETY SWITCH:
// Live automated emails are kept disabled until the account owner explicitly
// enables them in the 'Settings' sheet under key 'ENABLE_LIVE_EMAILS' = true.
var DEFAULT_LIVE_EMAILS_ACTIVE = false;

var SHEET_NAMES = {
  SETTINGS: 'Settings',
  BOOKINGS: 'booking',
  RENTAL_ENQUIRY: 'rental_enquiry',
  RENTAL_VEHICLES: 'rental_vehicles',
  BOOKING_DATES: 'BookingDates',
  PACKAGE_OPTIONS: 'PackageOptions',
  PICKUP_POINTS: 'PickupPoints',
  ADMIN_USERS: 'AdminUsers',
  EMAIL_LOG: 'EmailLog',
  BOOKING_PAYMENTS: 'booking_payments',
  BOOKING_CANCELLATIONS: 'booking_cancellations',
  BOOKING_NOTIFICATIONS: 'booking_notifications',
  ACTIVITY_LOG: 'activity_log',
  DAILY_REPORTS: 'daily_reports',
  WEBSITE_CONTENT: 'website_content',
  ATTRACTION_POINTS: 'AttractionPoints',
  ATTRACTION_TICKETS: 'AttractionTickets'
};

// Exact 17-tab / 139-header schema transcribed from the audited owner schema snapshot.
// Do not add, rename, reorder, or remove a tab/column without owner approval.
var DATABASE_SCHEMA = {
  booking: ['Timestamp','Booking ID','Name','Phone','Customer Email','Travel Date','Pickup Route','Pickup Point','Package Key','Package Name','Persons','Veg Biryani Persons','Butter Paneer Persons','Veg Thali Persons','Amount INR','Special Request','Payment Status','Booking Status','Customer Email Status','Owner Email Status','Last Error'],
  rental_enquiry: ['id','customer_name','mobile','vehicle_type','travel_date','pickup_location','destination','trip_type','persons','days','special_request','status','created_at','preferred_car_model','tempo_traveller_seating_capacity','other_seating_capacity','ac_preference','rental_duration','pickup_time'],
  rental_vehicles: ['vehicle_id','vehicle_name','vehicle_type','seating_capacity','price_per_day','status','description'],
  PickupPoints: ['Route','Pickup Point','Sort Order','Active'],
  PackageOptions: ['Package Key','Route Group','Label','Price INR','Offer Enabled','Offer Discount INR','Price Review Status'],
  Settings: ['setting_key','setting_value','description','updated_at'],
  BookingDates: ['Travel Date','Capacity Override','Closed','Close Time'],
  AdminUsers: ['Email','Role','Active','created_at','updated_at'],
  EmailLog: ['Timestamp','Booking ID','Recipient Type','Recipient','Status','Error'],
  booking_notifications: ['notification_id','booking_id','recipient','notification_type','message','status','created_at','sent_at'],
  booking_payments: ['payment_id','booking_id','customer_name','amount','payment_method','transaction_reference','payment_status','created_at','verified_at'],
  booking_cancellations: ['cancellation_id','booking_id','customer_name','mobile','cancellation_reason','refund_amount','refund_status','cancelled_at'],
  activity_log: ['log_id','user_email','action','details','record_type','record_id','created_at'],
  daily_reports: ['report_date','total_bookings','confirmed_bookings','cancelled_bookings','total_customers','total_revenue','pending_payments','created_at'],
  website_content: ['content_id','section','title','content','image_url','status','display_order','updated_at'],
  AttractionPoints: ['Point Number','Point Name','Description','Halt Status','Entry Fee','Fee Unit','Active','Sort Order'],
  AttractionTickets: ['Icon','Attraction Name','Price INR','Unit','Active','Sort Order']
};

var BOOKINGS_COLUMNS = DATABASE_SCHEMA.booking;


// Exact 21 columns mandated for 'Bookings' sheet
var BOOKINGS_COLUMNS = [
  'Timestamp',
  'Booking ID',
  'Name',
  'Phone',
  'Customer Email',
  'Travel Date',
  'Pickup Route',
  'Pickup Point',
  'Package Key',
  'Package Name',
  'Persons',
  'Veg Biryani Persons',
  'Butter Paneer Persons',
  'Veg Thali Persons',
  'Amount INR',
  'Special Request',
  'Payment Status',
  'Booking Status',
  'Customer Email Status',
  'Owner Email Status',
  'Last Error'
];

/**
 * Handle incoming Webhook POST requests
 */
function doPost(e) {
  var lock = LockService.getScriptLock();
  // Wait up to 15 seconds to acquire lock for safe concurrent operations
  var acquired = lock.tryLock(15000);
  if (!acquired) {
    return createJsonResponse({
      status: 'error',
      message: 'Server busy. Could not acquire lock for concurrent write.'
    }, 429);
  }

  try {
    if (!e || !e.postData || !e.postData.contents) {
      return createJsonResponse({ status: 'error', message: 'No payload received' }, 400);
    }

    var data = JSON.parse(e.postData.contents);
    var action = data && typeof data.action === 'string' ? data.action.trim() : '';
    if (!action) {
      return createJsonResponse({ status: 'error', message: 'An explicit action is required.' }, 400);
    }
    var result = {};

    switch (action) {
      case 'NEW_BOOKING':
        result = handleNewBooking(data);
        break;
      case 'NEW_RENTAL_ENQUIRY':
      case 'CAR_RENTAL':
        result = handleRentalEnquiry(data);
        break;
      case 'UPDATE_BOOKING_STATUS':
        result = { status: 'error', message: 'Direct booking status updates are disabled. Use the authenticated Admin API.' };
        break;
      case 'PAYMENT_VERIFIED':
        result = handleVerifiedPayment(data);
        break;
      case 'PUBLIC_BOOKING_LOOKUP':
        result = handlePublicBookingLookup_(data);
        break;
      case 'PUBLIC_GET_CONFIG':
        result = handlePublicGetConfig_();
        break;
      case 'PUBLIC_CANCELLATION_REQUEST':
        result = handlePublicCancellationRequest_(data);
        break;
      case 'UPDATE_RENTAL_STATUS':
        result = { status: 'error', message: 'Direct rental status updates are disabled. Use the authenticated Admin API.' };
        break;
      case 'OFFLINE_ATTRACTION_COLLECTION':
        result = { status: 'error', message: 'Offline attraction collection is not part of the approved 17-tab workbook schema. No data was written.' };
        break;
      case 'RETRY_EMAILS':
      case 'TEST_EMAIL':
        result = { status: 'error', message: 'Email retry/test actions are disabled on the public webhook until secure admin authorization is implemented.' };
        break;
      case 'ADMIN_AUTH_CHECK':
      case 'ADMIN_GET_DATA':
      case 'ADMIN_UPSERT_OPERATIONAL_RECORD':
      case 'ADMIN_DELETE_OPERATIONAL_RECORD':
      case 'ADMIN_GENERATE_DAILY_REPORT':
      case 'ADMIN_UPDATE_BOOKING_STATUS':
      case 'ADMIN_UPDATE_RENTAL_STATUS':
      case 'ADMIN_RETRY_BOOKING_EMAILS':
      case 'ADMIN_CREATE_CANCELLATION':
      case 'ADMIN_UPDATE_REFUND_STATUS':
      case 'ADMIN_SAVE_RENTAL_PRICING':
        result = handleAdminApiAction_(action, data);
        break;
      case 'PING_TEST':
        result = {
          status: 'success',
          message: 'Google Apps Script Webhook is active and healthy.',
          databaseName: 'Mumbai Darshan Bus Online - Database',
          timestamp: Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd HH:mm:ss')
        };
        break;
      default:
        result = { status: 'error', message: 'Unknown action: ' + action };
    }

    // Never copy full handler responses into the general activity log: Admin_GET_DATA contains PII and payment references.
    logActivity('WEBHOOK_' + action, safeActivityRecordId_(data, result), safeActivitySummary_(action, result));
    return createJsonResponse(result, 200);

  } catch (err) {
    logActivity('ERROR', 'System', 'Webhook processing failed; details withheld from general activity log.');
    return createJsonResponse({ status: 'error', message: err.toString() }, 500);
  } finally {
    lock.releaseLock();
  }
}

function safeActivityRecordId_(data, result) {
  var id = data && (data.id || data.bookingId) || result && (result.bookingId || result.enquiryId || result.cancellationId) || 'General';
  return String(id).slice(0, 100);
}
function safeActivitySummary_(action, result) {
  var status = result && result.status ? String(result.status) : 'unknown';
  var summary = 'action=' + String(action || 'unknown').slice(0, 60) + '; status=' + status.slice(0, 30);
  if (result && result.status === 'success') {
    if (result.data && typeof result.data === 'object') summary += '; datasets=' + Object.keys(result.data).length;
    else if (result.report) summary += '; report_date=' + String(result.report.report_date || '').slice(0, 10);
    else if (result.bookingId) summary += '; booking_created';
  }
  return summary.slice(0, 250);
}

/**
 * Public read-only configuration response. Exposes only approved customer-facing
 * fields from PackageOptions and PickupPoints; never returns Settings, AdminUsers,
 * bookings, customer records, or private operational tabs.
 */
function defaultRentalPricing_() {
  return {
    localPackages: [
      { id:'loc_dzire', vehicleName:'Maruti Suzuki Dzire AC', seating:'4 Seater', durationHours:12, includedKm:120, customerPrice:4500, extraKmRate:15, extraHourRate:200, tollIncluded:false, parkingIncluded:true, driverBhattaIncluded:true, tourGuideIncluded:false, published:true, active:true },
      { id:'loc_ertiga', vehicleName:'Maruti Suzuki Ertiga AC', seating:'7 Seater', durationHours:12, includedKm:120, customerPrice:5500, extraKmRate:18, extraHourRate:250, tollIncluded:false, parkingIncluded:true, driverBhattaIncluded:true, tourGuideIncluded:false, published:true, active:true },
      { id:'loc_traveller_17', vehicleName:'Force Tempo Traveller AC (17 Seater)', seating:'17 Seater', durationHours:12, includedKm:120, customerPrice:9500, extraKmRate:25, extraHourRate:400, tollIncluded:false, parkingIncluded:true, driverBhattaIncluded:true, tourGuideIncluded:false, published:true, active:true },
      { id:'loc_traveller_20', vehicleName:'Force Tempo Traveller AC (20 Seater)', seating:'20 Seater', durationHours:12, includedKm:120, customerPrice:11500, extraKmRate:28, extraHourRate:450, tollIncluded:false, parkingIncluded:true, driverBhattaIncluded:true, tourGuideIncluded:false, published:true, active:true },
      { id:'loc_bus_40', vehicleName:'Luxury AC Bus (40 Seater)', seating:'40 Seater', durationHours:12, includedKm:120, customerPrice:14000, extraKmRate:35, extraHourRate:600, tollIncluded:false, parkingIncluded:true, driverBhattaIncluded:true, tourGuideIncluded:false, published:true, active:true },
      { id:'loc_bus_49', vehicleName:'Luxury AC Bus (49 Seater)', seating:'49 Seater', durationHours:12, includedKm:120, customerPrice:17500, extraKmRate:40, extraHourRate:700, tollIncluded:false, parkingIncluded:true, driverBhattaIncluded:true, tourGuideIncluded:false, published:true, active:true }
    ],
    outstationRates: [
      { id:'out_dzire', vehicleName:'Dzire', category:'Car', seating:'4 Seater', isAC:true, customerPerKm:19, customerDaPerDay:400, minKmPerDay:300, nightDaRate:400, published:true, active:true },
      { id:'out_ertiga', vehicleName:'Ertiga', category:'Car', seating:'7 Seater', isAC:true, customerPerKm:22, customerDaPerDay:400, minKmPerDay:300, nightDaRate:400, published:true, active:true },
      { id:'out_innova', vehicleName:'Innova', category:'Car', seating:'7 Seater', isAC:true, customerPerKm:24, customerDaPerDay:400, minKmPerDay:300, nightDaRate:400, published:true, active:true },
      { id:'out_innova_crysta', vehicleName:'Innova Crysta', category:'Car', seating:'7 Seater', isAC:true, customerPerKm:25, customerDaPerDay:400, minKmPerDay:300, nightDaRate:400, published:true, active:true },
      { id:'out_tavera', vehicleName:'Tavera', category:'Car', seating:'8 Seater', isAC:true, customerPerKm:23, customerDaPerDay:400, minKmPerDay:300, nightDaRate:400, published:true, active:true },
      { id:'out_13_ac', vehicleName:'13–14 Seater AC', category:'13-14 Seater', seating:'13-14 Pax', isAC:true, customerPerKm:29, customerDaPerDay:1200, minKmPerDay:300, nightDaRate:1200, published:true, active:true },
      { id:'out_17_ac', vehicleName:'17 Seater AC', category:'17 Seater', seating:'17 Pax', isAC:true, customerPerKm:31, customerDaPerDay:1300, minKmPerDay:300, nightDaRate:1300, published:true, active:true },
      { id:'out_17_nonac', vehicleName:'17 Seater Non-AC', category:'17 Seater', seating:'17 Pax', isAC:false, customerPerKm:28, customerDaPerDay:1300, minKmPerDay:300, nightDaRate:1300, published:true, active:true },
      { id:'out_20_ac', vehicleName:'20 Seater AC', category:'20 Seater', seating:'20 Pax', isAC:true, customerPerKm:33, customerDaPerDay:1400, minKmPerDay:300, nightDaRate:1400, published:true, active:true },
      { id:'out_20_nonac', vehicleName:'20 Seater Non-AC', category:'20 Seater', seating:'20 Pax', isAC:false, customerPerKm:30, customerDaPerDay:1400, minKmPerDay:300, nightDaRate:1400, published:true, active:true },
      { id:'out_26_ac', vehicleName:'26 Seater AC', category:'26 Seater', seating:'26 Pax', isAC:true, customerPerKm:41, customerDaPerDay:1600, minKmPerDay:300, nightDaRate:1600, published:true, active:true },
      { id:'out_26_nonac', vehicleName:'26 Seater Non-AC', category:'26 Seater', seating:'26 Pax', isAC:false, customerPerKm:36, customerDaPerDay:1600, minKmPerDay:300, nightDaRate:1600, published:true, active:true },
      { id:'out_35_ac', vehicleName:'32–35 Seater AC', category:'32-35 Seater', seating:'32-35 Pax', isAC:true, customerPerKm:53, customerDaPerDay:2200, minKmPerDay:300, nightDaRate:2200, published:true, active:true },
      { id:'out_35_nonac', vehicleName:'32–35 Seater Non-AC', category:'32-35 Seater', seating:'32-35 Pax', isAC:false, customerPerKm:45, customerDaPerDay:2200, minKmPerDay:300, nightDaRate:2200, published:true, active:true },
      { id:'out_49_ac', vehicleName:'45–49 Seater AC', category:'45-49 Seater', seating:'45-49 Pax', isAC:true, customerPerKm:63, customerDaPerDay:2500, minKmPerDay:300, nightDaRate:2500, published:true, active:true },
      { id:'out_49_nonac', vehicleName:'45–49 Seater Non-AC', category:'45-49 Seater', seating:'45-49 Pax', isAC:false, customerPerKm:54, customerDaPerDay:2500, minKmPerDay:300, nightDaRate:2500, published:true, active:true }
    ]
  };
}

function validateRentalPricing_(pricing) {
  if (!pricing || typeof pricing !== 'object' || !Array.isArray(pricing.localPackages) || !Array.isArray(pricing.outstationRates) || pricing.localPackages.length !== 6 || pricing.outstationRates.length !== 16) throw new Error('Rental pricing must contain all 6 local packages and 16 outstation vehicle rates.');
  var ids = {};
  pricing.localPackages.forEach(function(r) {
    if (!r || !/^loc_[a-z0-9_]+$/.test(String(r.id || '')) || ids[r.id]) throw new Error('Invalid or duplicate local rental ID.');
    ids[r.id] = true;
    ['durationHours','includedKm','customerPrice','extraKmRate','extraHourRate'].forEach(function(k) { if (!Number.isSafeInteger(Number(r[k])) || Number(r[k]) < 0) throw new Error('Invalid local rental amount or limit: ' + k); });
    if (!String(r.vehicleName || '').trim() || !String(r.seating || '').trim() || Number(r.durationHours) < 1 || Number(r.includedKm) < 1 || Number(r.customerPrice) < 1) throw new Error('Local rental name, seating, duration, included KM and customer price are required.');
    ['published','active','tollIncluded','parkingIncluded','driverBhattaIncluded','tourGuideIncluded'].forEach(function(k) { if (typeof r[k] !== 'boolean') throw new Error('Invalid local rental flag: ' + k); });
  });
  pricing.outstationRates.forEach(function(r) {
    if (!r || !/^out_[a-z0-9_]+$/.test(String(r.id || '')) || ids[r.id]) throw new Error('Invalid or duplicate outstation rate ID.');
    ids[r.id] = true;
    ['customerPerKm','customerDaPerDay','minKmPerDay','nightDaRate'].forEach(function(k) { if (!Number.isSafeInteger(Number(r[k])) || Number(r[k]) < 0) throw new Error('Invalid outstation amount or limit: ' + k); });
    if (!String(r.vehicleName || '').trim() || !String(r.category || '').trim() || !String(r.seating || '').trim() || Number(r.customerPerKm) < 1 || Number(r.minKmPerDay) < 1) throw new Error('Outstation vehicle name, category, seating, per-KM rate and minimum KM are required.');
    ['published','active','isAC'].forEach(function(k) { if (typeof r[k] !== 'boolean') throw new Error('Invalid outstation flag: ' + k); });
    if (Number(r.nightDaRate) !== Number(r.customerDaPerDay)) throw new Error('Night DA must equal the regular daily DA under the approved rental rule.');
  });
  return { localPackages: pricing.localPackages, outstationRates: pricing.outstationRates };
}

function readRentalPricingSetting_() {
  var sheet = getRequiredSheet_(SHEET_NAMES.SETTINGS);
  var values = sheet.getDataRange().getValues();
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][0] || '').trim() === 'PUBLIC_RENTAL_PRICING_JSON') {
      try { return validateRentalPricing_(JSON.parse(String(values[i][1] || ''))); }
      catch (err) { throw new Error('Public rental pricing configuration is invalid: ' + String(err.message || err)); }
    }
  }
  throw new Error('Public rental pricing configuration is not initialized.');
}

function saveRentalPricingSetting_(pricing) {
  var valid = validateRentalPricing_(pricing);
  var sheet = getRequiredSheet_(SHEET_NAMES.SETTINGS);
  var values = sheet.getDataRange().getValues();
  var serialized = JSON.stringify(valid);
  if (serialized.length > 45000) throw new Error('Rental pricing configuration exceeds the safe Settings cell size.');
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][0] || '').trim() === 'PUBLIC_RENTAL_PRICING_JSON') {
      sheet.getRange(i + 1, 2).setValue(serialized);
      sheet.getRange(i + 1, 4).setValue(new Date());
      return valid;
    }
  }
  sheet.appendRow(['PUBLIC_RENTAL_PRICING_JSON', serialized, 'Public customer-facing Local Darshan and Outstation rate catalogue', new Date()]);
  return valid;
}

function handlePublicGetConfig_() {
  var packageRows = rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.PACKAGE_OPTIONS));
  var pickupRows = rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.PICKUP_POINTS));
  var rentalPricing = readRentalPricingSetting_();
  var allowedRoutes = { western: true, central: true, harbour: true, kalyan_dombivli: true };
  var allowedPackages = { non_ac_no_lunch: true, ac_no_lunch: true, non_ac_lunch: true, ac_lunch: true };
  var packages = packageRows.map(function(row) {
    var route = normalizeRouteGroup_(row['Route Group']);
    var key = String(row['Package Key'] || '').trim().toLowerCase();
    var price = Number(row['Price INR']);
    var discount = Number(row['Offer Discount INR'] || 0);
    var review = String(row['Price Review Status'] || '').trim().toLowerCase();
    if (!allowedRoutes[route] || !allowedPackages[key] || !Number.isSafeInteger(price) || price <= 0 ||
        !Number.isSafeInteger(discount) || discount < 0 || discount >= price || (review && review !== 'approved')) return null;
    return {
      packageKey: key,
      routeGroup: route,
      label: String(row['Label'] || '').slice(0, 100),
      priceINR: price,
      offerEnabled: row['Offer Enabled'] === true || String(row['Offer Enabled']).trim().toLowerCase() === 'true' || String(row['Offer Enabled']).trim() === '1',
      offerDiscountINR: discount,
      priceReviewStatus: String(row['Price Review Status'] || '').slice(0, 40)
    };
  }).filter(function(row) { return row !== null; });
  var pickupSeen = {};
  var pickups = pickupRows.map(function(row) {
    var route = normalizeRouteGroup_(row['Route']);
    var name = String(row['Pickup Point'] || '').trim().slice(0, 120);
    var order = Number(row['Sort Order']);
    if (!allowedRoutes[route] || !name || !Number.isSafeInteger(order) || order < 0) return null;
    var pickupKey = route + '|' + name.toLowerCase() + '|' + order;
    if (pickupSeen[pickupKey]) return null;
    pickupSeen[pickupKey] = true;
    var activeValue = String(row['Active']).trim().toLowerCase();
    return { route: route, name: name, sortOrder: order, active: row['Active'] === true || activeValue === 'true' || activeValue === 'yes' || activeValue === '1' };
  }).filter(function(row) { return row !== null; });
  if (packages.length !== 16 || pickups.length !== pickupRows.length || pickups.length < 1) {
    return { status: 'error', message: 'Public configuration is incomplete or contains invalid rows.' };
  }
  var seen = {};
  packages.forEach(function(row) {
    var key = row.packageKey + '|' + row.routeGroup;
    if (seen[key]) throw new Error('Duplicate PackageOptions route/package combination.');
    seen[key] = true;
  });
  if (Object.keys(seen).length !== 16) return { status: 'error', message: 'All 16 route/package prices must be configured.' };
  return { status: 'success', config: { version: 1, generatedAt: new Date().toISOString(), packages: packages, pickupPoints: pickups, rentalPricing: rentalPricing } };
}

/**
 * Handle GET requests for booking lookup or health check
 */
function doGet(e) {
  try {
    var params = e ? e.parameter : {};
    var action = params.action || 'health';

    if (action === 'lookup') {
      // Booking lookup must use POST with BOTH booking ID and registered mobile.
      // GET query-string lookup is disabled to prevent ID-only enumeration and PII in URLs/logs.
      return createJsonResponse({ status: 'error', message: 'Use the secure booking lookup form with Booking ID and registered mobile.' });
    }

    return createJsonResponse({
      status: 'active',
      business: BUSINESS_CONFIG.NAME,
      service: 'Google Sheets Database & Email Engine',
      version: '4.0.0',
      timestamp: Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd HH:mm:ss')
    });

  } catch (err) {
    return createJsonResponse({ status: 'error', message: err.toString() });
  }
}

/**
 * Private admin API. Requests are accepted only from the trusted server proxy
 * using a Script Property secret and an active AdminUsers roster entry.
 * Never place ADMIN_API_SECRET in browser code or website settings.
 */
function handleAdminApiAction_(action, data) {
  var expectedSecret = PropertiesService.getScriptProperties().getProperty('ADMIN_API_SECRET') || '';
  var suppliedSecret = String(data.adminApiSecret || '');
  if (!expectedSecret || !suppliedSecret || expectedSecret.length !== suppliedSecret.length ||
      !constantTimeEquals_(expectedSecret, suppliedSecret)) {
    return { status: 'error', message: 'Unauthorized admin service request.' };
  }
  var email = String(data.adminEmail || '').trim().toLowerCase();
  if (!email || email.length > 254) return { status: 'error', message: 'Admin email is required.' };
  var admins = getRequiredSheet_(SHEET_NAMES.ADMIN_USERS).getDataRange().getValues();
  var authorizedRole = '';
  for (var i = 1; i < admins.length; i++) {
    var rowEmail = String(admins[i][0] || '').trim().toLowerCase();
    var role = String(admins[i][1] || '').trim().toLowerCase();
    var active = String(admins[i][2] || '').trim().toLowerCase();
    if (rowEmail === email && (active === 'true' || active === 'yes' || active === '1') &&
        ['admin', 'owner'].indexOf(role) !== -1) { authorizedRole = role; break; }
  }
  if (!authorizedRole) return { status: 'success', authorized: false, message: 'Admin is not active or role is not permitted.' };
  if (action === 'ADMIN_AUTH_CHECK') {
    logAdminActivity_(email, 'ADMIN_LOGIN_AUTHORIZED', 'Admin roster authorization passed');
    return { status: 'success', authorized: true, role: authorizedRole };
  }
  if (action === 'ADMIN_GENERATE_DAILY_REPORT') {
    try {
      var requestedDate = String(data.reportDate || '').trim();
      var report = generateDailyReport_(requestedDate || Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd'));
      logAdminActivity_(email, 'ADMIN_DAILY_REPORT_GENERATED', report.report_date + ' / bookings=' + report.total_bookings);
      return { status: 'success', report: report, message: 'Daily report saved to daily_reports. No email was sent by this manual action.' };
    } catch (reportError) { return { status: 'error', message: String(reportError.message || reportError) }; }
  }
  if (action === 'ADMIN_GET_DATA') {
    var bookings = rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.BOOKINGS));
    var rentals = rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.RENTAL_ENQUIRY));
    var payments = rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.BOOKING_PAYMENTS));
    var cancellations = rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.BOOKING_CANCELLATIONS));
    var paymentReconciliation = buildBookingPaymentReconciliation_(bookings, payments);
    var adminRentalPricing;
    try { adminRentalPricing = readRentalPricingSetting_(); }
    catch (rentalPricingReadError) { adminRentalPricing = defaultRentalPricing_(); }
    // Read-only operational datasets from the approved 17-tab schema.
    // AdminUsers and Settings are deliberately excluded: they may contain access/configuration data.
    var operational = {
      pickupPoints: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.PICKUP_POINTS)),
      packageOptions: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.PACKAGE_OPTIONS)),
      bookingDates: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.BOOKING_DATES)),
      rentalVehicles: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.RENTAL_VEHICLES)),
      emailLog: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.EMAIL_LOG)),
      notifications: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.BOOKING_NOTIFICATIONS)),
      activityLog: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.ACTIVITY_LOG)),
      dailyReports: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.DAILY_REPORTS)),
      websiteContent: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.WEBSITE_CONTENT)),
      attractionPoints: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.ATTRACTION_POINTS)),
      attractionTickets: rowsAsObjects_(getRequiredSheet_(SHEET_NAMES.ATTRACTION_TICKETS)),
      rentalPricing: adminRentalPricing
    };
    logAdminActivity_(email, 'ADMIN_DATA_READ', 'Read protected booking, rental and all approved operational datasets');
    return { status: 'success', authorized: true, data: {
      bookings: bookings, rentalEnquiries: rentals, payments: payments, cancellations: cancellations,
      paymentReconciliation: paymentReconciliation,
      ...operational
    } };
  }
  if (action === 'ADMIN_SAVE_RENTAL_PRICING') {
    try {
      var savedRentalPricing = saveRentalPricingSetting_(data.rentalPricing);
      logAdminActivity_(email, 'ADMIN_RENTAL_PRICING_UPDATED', 'Saved 6 local packages and 16 outstation rates to Settings');
      return { status: 'success', message: 'Rental customer rates saved securely to Settings.', rentalPricing: savedRentalPricing };
    } catch (rentalPricingError) { return { status: 'error', message: String(rentalPricingError.message || rentalPricingError) }; }
  }
  if (action === 'ADMIN_UPSERT_OPERATIONAL_RECORD') {
    var spec = getAdminEditableSheetSpec_(String(data.sheetKey || ''));
    if (!spec) return { status: 'error', message: 'This sheet is read-only or not approved for Admin editing.' };
    var record = data.record;
    if (!record || typeof record !== 'object' || Array.isArray(record)) return { status: 'error', message: 'A record object is required.' };
    var allowedHeaders = DATABASE_SCHEMA[spec.sheet];
    var suppliedKeys = Object.keys(record);
    if (!suppliedKeys.length || suppliedKeys.some(function(k) { return allowedHeaders.indexOf(k) === -1; })) return { status: 'error', message: 'Unknown or empty fields. Approved schema was not changed.' };
    if (spec.required.some(function(k) { return record[k] === undefined || String(record[k]).trim() === ''; })) return { status: 'error', message: 'Required key fields are missing.' };
    var sh = getRequiredSheet_(spec.sheet);
    var values = sh.getDataRange().getValues();
    var keyIndex = allowedHeaders.indexOf(spec.key);
    var matchRow = -1;
    for (var r = 1; r < values.length; r++) {
      var matches = spec.required.every(function(k) { return String(values[r][allowedHeaders.indexOf(k)] || '').trim().toLowerCase() === String(record[k] || '').trim().toLowerCase(); });
      if (matches) { matchRow = r + 1; break; }
    }
    var output = matchRow > 0 ? values[matchRow - 1].slice(0, allowedHeaders.length) : allowedHeaders.map(function() { return ''; });
    suppliedKeys.forEach(function(k) { var idx = allowedHeaders.indexOf(k); output[idx] = record[k]; });
    if (matchRow > 0) sh.getRange(matchRow, 1, 1, allowedHeaders.length).setValues([output]);
    else sh.appendRow(output);
    logAdminActivity_(email, matchRow > 0 ? 'ADMIN_OPERATIONAL_RECORD_UPDATED' : 'ADMIN_OPERATIONAL_RECORD_CREATED', spec.sheet + ' / ' + spec.required.map(function(k) { return record[k]; }).join(' / '));
    return { status: 'success', message: matchRow > 0 ? 'Record updated.' : 'Record created.', sheet: spec.sheet, created: matchRow < 0 };
  }
  if (action === 'ADMIN_DELETE_OPERATIONAL_RECORD') {
    var deleteSpec = getAdminEditableSheetSpec_(String(data.sheetKey || ''));
    if (!deleteSpec) return { status: 'error', message: 'This sheet is read-only or not approved for Admin editing.' };
    var keyValues = data.key;
    if (!keyValues || typeof keyValues !== 'object' || deleteSpec.required.some(function(k) { return keyValues[k] === undefined || String(keyValues[k]).trim() === ''; })) return { status: 'error', message: 'Complete record key is required.' };
    var deleteSheet = getRequiredSheet_(deleteSpec.sheet);
    var deleteRows = deleteSheet.getDataRange().getValues();
    var deleteRow = -1;
    for (var dr = 1; dr < deleteRows.length; dr++) {
      if (deleteSpec.required.every(function(k) { var ix = DATABASE_SCHEMA[deleteSpec.sheet].indexOf(k); return String(deleteRows[dr][ix] || '').trim().toLowerCase() === String(keyValues[k] || '').trim().toLowerCase(); })) { deleteRow = dr + 1; break; }
    }
    if (deleteRow < 0) return { status: 'error', message: 'Record not found.' };
    deleteSheet.deleteRow(deleteRow);
    logAdminActivity_(email, 'ADMIN_OPERATIONAL_RECORD_DELETED', deleteSpec.sheet + ' / ' + deleteSpec.required.map(function(k) { return keyValues[k]; }).join(' / '));
    return { status: 'success', message: 'Record deleted.', sheet: deleteSpec.sheet };
  }
  if (action === 'ADMIN_UPDATE_BOOKING_STATUS') {
    var bookingId = String(data.bookingId || '').trim();
    var bookingStatus = String(data.bookingStatus || '').trim();
    var allowedBooking = ['Confirmed', 'Pending Verification', 'Completed'];
    if (!bookingId || bookingStatus === 'Cancelled' || allowedBooking.indexOf(bookingStatus) === -1) {
      return { status: 'error', message: bookingStatus === 'Cancelled'
        ? 'Direct cancellation is disabled. Create a cancellation review record so verified payments and refunds remain auditable.'
        : 'Invalid booking ID or status.' };
    }
    var bookingSheet = getRequiredSheet_(SHEET_NAMES.BOOKINGS);
    var bookingValues = bookingSheet.getDataRange().getValues();
    var bookingRow = -1;
    var bookingMatches = 0;
    for (var bi = 1; bi < bookingValues.length; bi++) {
      if (String(bookingValues[bi][1] || '').trim().toUpperCase() === bookingId.toUpperCase()) {
        bookingMatches++;
        if (bookingRow < 0) bookingRow = bi + 1;
      }
    }
    if (bookingMatches === 0) return { status: 'error', message: 'Booking not found.' };
    if (bookingMatches !== 1) return { status: 'error', message: 'Duplicate Booking ID detected. Resolve the duplicate record before changing booking status.' };

    if (bookingStatus === 'Confirmed' || bookingStatus === 'Completed') {
      var bookingData = bookingValues[bookingRow - 1];
      var currentPaymentStatus = String(bookingData[16] || '').trim();
      if (['Advance Paid', 'Fully Paid'].indexOf(currentPaymentStatus) === -1) {
        return { status: 'error', message: 'Booking cannot be confirmed or completed until payment is verified in the payment ledger.' };
      }
      var paymentSheet = getRequiredSheet_(SHEET_NAMES.BOOKING_PAYMENTS);
      var paymentValues = paymentSheet.getDataRange().getValues();
      var bookingPaymentRows = [];
      for (var pi = 1; pi < paymentValues.length; pi++) {
        if (String(paymentValues[pi][1] || '').trim().toUpperCase() === bookingId.toUpperCase()) bookingPaymentRows.push(paymentValues[pi]);
      }
      if (bookingPaymentRows.length !== 1) {
        return { status: 'error', message: bookingPaymentRows.length > 1
          ? 'Multiple payment ledger rows exist for this booking. Admin reconciliation is required before confirmation.'
          : 'Booking cannot be confirmed or completed without one verified payment ledger record.' };
      }
      var verifiedPayment = bookingPaymentRows[0];
      if (String(verifiedPayment[6] || '').trim().toLowerCase() !== 'verified') {
        return { status: 'error', message: 'Booking cannot be confirmed or completed until its payment ledger row is verified.' };
      }
      var verifiedAmount = Number(verifiedPayment[3]);
      var bookingFare = Number(bookingData[14]);
      if (!String(verifiedPayment[0] || '').trim() || !String(verifiedPayment[5] || '').trim() || !verifiedPayment[8] || !isFinite(verifiedAmount) || verifiedAmount <= 0 || !isFinite(bookingFare) || bookingFare <= 0 || verifiedAmount > bookingFare + 0.009) {
        return { status: 'error', message: 'Verified payment ledger evidence is incomplete or outside the booking fare. Admin reconciliation is required.' };
      }
      var paymentMode = String(verifiedPayment[4] || '').toLowerCase();
      var expectedAmount = paymentMode.indexOf('full') !== -1 ? bookingFare : Math.min(200, bookingFare);
      if (Math.abs(verifiedAmount - expectedAmount) > 0.009) {
        return { status: 'error', message: 'Verified payment amount does not match the stored advance/full payment mode. Admin reconciliation is required.' };
      }
    }
    bookingSheet.getRange(bookingRow, 18).setValue(bookingStatus);
    logAdminActivity_(email, 'ADMIN_BOOKING_STATUS_UPDATED', bookingId + ' => ' + bookingStatus);
    return { status: 'success', message: 'Booking status updated.', bookingId: bookingId, bookingStatus: bookingStatus };
  }
  if (action === 'ADMIN_CREATE_CANCELLATION') {
    return createAdminCancellation_(email, data);
  }
  if (action === 'ADMIN_RETRY_BOOKING_EMAILS') {
    var retryBookingId = String(data.bookingId || '').trim();
    if (!retryBookingId) return { status: 'error', message: 'Booking ID is required.' };
    var retryResult = retryFailedEmails(retryBookingId);
    logAdminActivity_(email, 'ADMIN_BOOKING_EMAIL_RETRY', retryBookingId + ' => ' + JSON.stringify(retryResult));
    return retryResult;
  }
  if (action === 'ADMIN_UPDATE_REFUND_STATUS') {
    return updateAdminRefundStatus_(email, data);
  }
  if (action === 'ADMIN_UPDATE_RENTAL_STATUS') {
    var enquiryId = String(data.enquiryId || '').trim();
    var rentalStatus = String(data.status || '').trim();
    var allowedRental = ['New', 'Contacted', 'Quote Sent', 'Follow-up', 'Confirmed', 'Not Interested', 'Cancelled'];
    if (!enquiryId || allowedRental.indexOf(rentalStatus) === -1) return { status: 'error', message: 'Invalid rental enquiry ID or status.' };
    var rentalSheet = getRequiredSheet_(SHEET_NAMES.RENTAL_ENQUIRY);
    var rentalValues = rentalSheet.getDataRange().getValues();
    var rentalRow = -1;
    for (var ri = 1; ri < rentalValues.length; ri++) if (String(rentalValues[ri][0]).trim().toUpperCase() === enquiryId.toUpperCase()) { rentalRow = ri + 1; break; }
    if (rentalRow < 0) return { status: 'error', message: 'Rental enquiry not found.' };
    rentalSheet.getRange(rentalRow, 12).setValue(rentalStatus);
    logAdminActivity_(email, 'ADMIN_RENTAL_STATUS_UPDATED', enquiryId + ' => ' + rentalStatus);
    return { status: 'success', message: 'Rental enquiry status updated.', enquiryId: enquiryId, rentalStatus: rentalStatus };
  }
  return { status: 'error', message: 'Unsupported admin action.' };
}

// Only operational configuration/content tabs are editable. Logs, reports,
// AdminUsers, Settings, bookings, payments and rental enquiries stay protected.
function getAdminEditableSheetSpec_(key) {
  var specs = {
    pickupPoints: { sheet: SHEET_NAMES.PICKUP_POINTS, key: 'Pickup Point', required: ['Route', 'Pickup Point'] },
    packageOptions: { sheet: SHEET_NAMES.PACKAGE_OPTIONS, key: 'Package Key', required: ['Package Key'] },
    bookingDates: { sheet: SHEET_NAMES.BOOKING_DATES, key: 'Travel Date', required: ['Travel Date'] },
    rentalVehicles: { sheet: SHEET_NAMES.RENTAL_VEHICLES, key: 'vehicle_id', required: ['vehicle_id'] },
    websiteContent: { sheet: SHEET_NAMES.WEBSITE_CONTENT, key: 'content_id', required: ['content_id'] },
    attractionPoints: { sheet: SHEET_NAMES.ATTRACTION_POINTS, key: 'Point Number', required: ['Point Number'] },
    attractionTickets: { sheet: SHEET_NAMES.ATTRACTION_TICKETS, key: 'Attraction Name', required: ['Attraction Name'] }
  };
  return specs[key] || null;
}

function rowsAsObjects_(sheet) {
  var values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  var headers = values[0].map(function(h) { return String(h); });
  return values.slice(1).filter(function(row) { return row.some(function(v) { return v !== '' && v !== null; }); }).map(function(row) {
    var item = {};
    headers.forEach(function(header, index) {
      var value = row[index];
      item[header] = value instanceof Date ? value.toISOString() : value;
    });
    return item;
  });
}

/**
 * Read-only reconciliation of the approved Bookings and booking_payments tabs.
 * Does not write to either sheet. Findings are operational flags, not proof of
 * fraud or a command to alter balances. One ledger row per booking is the
 * currently implemented booking/payment model.
 */
function buildBookingPaymentReconciliation_(bookingRecords, paymentRecords) {
  var bookingMap = Object.create(null);
  var paymentMap = Object.create(null);
  var findings = [];
  var findingCount = 0;
  var findingsByBooking = Object.create(null);
  var summary = {
    totalBookings: bookingRecords.length,
    totalLedgerRows: paymentRecords.length,
    matchedBookings: 0,
    missingLedger: 0,
    orphanLedgerRows: 0,
    multipleLedgerBookings: 0,
    bookingLedgerMismatches: 0,
    invalidLedgerRows: 0,
    duplicatePaymentReferences: 0,
    verifiedAmountOverBooking: 0,
    cleanBookings: 0,
    issueCount: 0,
    verifiedOnlineAmount: 0
  };

  function addFinding(code, bookingId, detail, expected, recorded) {
    var safeBookingId = String(bookingId || 'UNKNOWN').slice(0, 80);
    findingCount++;
    if (safeBookingId !== 'UNKNOWN') findingsByBooking[safeBookingId.toLowerCase()] = true;
    // Keep memory bounded as well as the serialized response. The summary
    // still counts every finding, while the UI receives the first 250 only.
    if (findings.length < 250) findings.push({
      code: code,
      bookingId: safeBookingId,
      detail: String(detail || '').slice(0, 220),
      expectedAmount: expected === undefined ? null : expected,
      recordedAmount: recorded === undefined ? null : recorded
    });
  }

  bookingRecords.forEach(function(booking) {
    var id = String(booking['Booking ID'] || '').trim().toLowerCase();
    if (!id) {
      addFinding('BOOKING_ID_MISSING', 'UNKNOWN', 'Booking row has no Booking ID.');
      return;
    }
    if (bookingMap[id]) {
      addFinding('DUPLICATE_BOOKING_ID', booking['Booking ID'], 'More than one Bookings row uses this Booking ID.');
    } else bookingMap[id] = booking;
  });

  paymentRecords.forEach(function(payment) {
    var bookingId = String(payment.booking_id || '').trim().toLowerCase();
    if (!bookingId || !bookingMap[bookingId]) {
      summary.orphanLedgerRows++;
      addFinding('ORPHAN_LEDGER_ROW', payment.booking_id, 'Payment ledger row does not match an existing booking.');
    } else {
      if (!paymentMap[bookingId]) paymentMap[bookingId] = [];
      paymentMap[bookingId].push(payment);
    }

    var status = String(payment.payment_status || '').trim().toLowerCase();
    var amount = Number(payment.amount);
    if (!isFinite(amount) || amount <= 0) {
      summary.invalidLedgerRows++;
      addFinding('INVALID_LEDGER_AMOUNT', payment.booking_id, 'Ledger amount is missing, non-numeric or not positive.', undefined, amount);
    }
    if (['pending', 'verified', 'paid', 'success', 'failed', 'rejected'].indexOf(status) === -1) {
      summary.invalidLedgerRows++;
      addFinding('UNKNOWN_LEDGER_STATUS', payment.booking_id, 'Payment ledger status is not recognized: ' + status);
    }
    if (status === 'verified' || status === 'paid' || status === 'success') {
      summary.verifiedOnlineAmount += isFinite(amount) && amount > 0 ? amount : 0;
      if (!String(payment.payment_id || '').trim() || !String(payment.transaction_reference || '').trim() || !payment.verified_at) {
        summary.invalidLedgerRows++;
        addFinding('VERIFIED_EVIDENCE_INCOMPLETE', payment.booking_id, 'Verified ledger row is missing payment ID, transaction reference or verified timestamp.');
      }
    }
  });

  var uniqueRefs = Object.create(null);
  var uniquePaymentIds = Object.create(null);
  paymentRecords.forEach(function(payment) {
    var status = String(payment.payment_status || '').trim().toLowerCase();
    if (['verified', 'paid', 'success'].indexOf(status) === -1) return;
    var ref = String(payment.transaction_reference || '').trim();
    var pid = String(payment.payment_id || '').trim();
    if (ref) {
      var refKey = ref.toLowerCase();
      if (uniqueRefs[refKey]) {
        summary.duplicatePaymentReferences++;
        addFinding('DUPLICATE_TRANSACTION_REFERENCE', payment.booking_id, 'Transaction reference is reused by more than one verified ledger row.');
      } else uniqueRefs[refKey] = true;
    }
    if (pid) {
      var pidKey = pid.toLowerCase();
      if (uniquePaymentIds[pidKey]) {
        summary.duplicatePaymentReferences++;
        addFinding('DUPLICATE_PAYMENT_ID', payment.booking_id, 'Payment ID is reused by more than one verified ledger row.');
      } else uniquePaymentIds[pidKey] = true;
    }
  });

  bookingRecords.forEach(function(booking) {
    var id = String(booking['Booking ID'] || '').trim();
    var key = id.toLowerCase();
    if (!key) return;
    var rows = paymentMap[key] || [];
    var paymentStatus = String(booking['Payment Status'] || '').trim().toLowerCase();
    var bookingStatus = String(booking['Booking Status'] || '').trim().toLowerCase();
    var bookingAmount = Number(booking['Amount INR'] || 0);

    if (!rows.length) {
      summary.missingLedger++;
      addFinding('MISSING_LEDGER', id, 'Booking has no linked payment ledger row.');
      if (paymentStatus === 'advance paid' || paymentStatus === 'fully paid') {
        summary.bookingLedgerMismatches++;
        addFinding('BOOKING_MARKED_PAID_WITHOUT_LEDGER', id, 'Booking says paid but no payment ledger row exists.');
      }
      return;
    }
    summary.matchedBookings++;
    if (rows.length > 1) {
      summary.multipleLedgerBookings++;
      addFinding('MULTIPLE_LEDGER_ROWS', id, 'More than one payment ledger row exists; current callback model expects one row per booking.');
    }

    var verifiedRows = rows.filter(function(row) {
      var st = String(row.payment_status || '').trim().toLowerCase();
      return ['verified', 'paid', 'success'].indexOf(st) !== -1;
    });
    var verifiedTotal = verifiedRows.reduce(function(sum, row) {
      var amount = Number(row.amount);
      return sum + (isFinite(amount) && amount > 0 ? amount : 0);
    }, 0);
    if ((paymentStatus === 'advance paid' || paymentStatus === 'fully paid') && !verifiedRows.length) {
      summary.bookingLedgerMismatches++;
      addFinding('BOOKING_MARKED_PAID_WITHOUT_VERIFIED_LEDGER', id, 'Booking payment status is paid but no verified ledger row exists.');
    }
    if (verifiedRows.length && paymentStatus !== 'advance paid' && paymentStatus !== 'fully paid') {
      summary.bookingLedgerMismatches++;
      addFinding('VERIFIED_LEDGER_BOOKING_NOT_PAID', id, 'Verified payment exists but the booking payment status is not marked paid.');
    }
    if (verifiedTotal > bookingAmount + 0.009) {
      summary.verifiedAmountOverBooking++;
      addFinding('VERIFIED_AMOUNT_EXCEEDS_BOOKING', id, 'Verified online amount exceeds the booking fare.', bookingAmount, verifiedTotal);
    }
    if (verifiedRows.length === 1) {
      var mode = String(verifiedRows[0].payment_method || '').toLowerCase();
      var expected = mode.indexOf('full') !== -1 ? bookingAmount : Math.min(200, bookingAmount);
      var actual = Number(verifiedRows[0].amount);
      if (isFinite(expected) && Math.abs(actual - expected) > 0.009) {
        summary.bookingLedgerMismatches++;
        addFinding('VERIFIED_AMOUNT_MODE_MISMATCH', id, 'Verified amount does not match the stored advance/full payment mode.', expected, actual);
      }
    }
    if ((bookingStatus === 'confirmed' || bookingStatus === 'completed') && !verifiedRows.length) {
      summary.bookingLedgerMismatches++;
      addFinding('CONFIRMED_WITHOUT_VERIFIED_PAYMENT', id, 'Booking is confirmed/completed but no verified online payment ledger row exists.');
    }
  });

  summary.issueCount = findingCount;
  summary.cleanBookings = Math.max(0, summary.totalBookings - Object.keys(findingsByBooking).filter(function(id) { return !!bookingMap[id]; }).length);
  return { generatedAt: new Date().toISOString(), summary: summary, findings: findings, findingsTruncated: findingCount > 250 };
}

function constantTimeEquals_(a, b) {
  a = String(a); b = String(b);
  var diff = a.length ^ b.length;
  var max = Math.max(a.length, b.length);
  for (var i = 0; i < max; i++) diff |= (a.charCodeAt(i % (a.length || 1)) || 0) ^ (b.charCodeAt(i % (b.length || 1)) || 0);
  return diff === 0;
}

function logAdminActivity_(email, action, details) {
  try {
    getRequiredSheet_(SHEET_NAMES.ACTIVITY_LOG).appendRow(['LOG-' + Utilities.getUuid(), email, action, details, 'admin', email, new Date()]);
  } catch (e) {}
}

function normalizeRouteGroup_(route) {
  var value = String(route || '').toLowerCase().replace(/[–—]/g, '-').replace(/\s+/g, ' ').trim();
  if (value.indexOf('western') !== -1) return 'western';
  if (value.indexOf('central') !== -1) return 'central';
  if (value.indexOf('harbour') !== -1 || value.indexOf('harbor') !== -1) return 'harbour';
  if (value.indexOf('kalyan') !== -1 || value.indexOf('dombiv') !== -1) return 'kalyan_dombivli';
  return '';
}
function getApprovedPackagePrice_(packageKey, routeKey) {
  var allowed = ['non_ac_no_lunch', 'ac_no_lunch', 'non_ac_lunch', 'ac_lunch'];
  if (allowed.indexOf(packageKey) === -1 || !routeKey) return null;
  var sh = getRequiredSheet_(SHEET_NAMES.PACKAGE_OPTIONS);
  var rows = sh.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    var key = String(rows[i][0] || '').trim().toLowerCase();
    var route = normalizeRouteGroup_(rows[i][1]);
    var price = Number(rows[i][3]);
    var review = String(rows[i][6] || '').trim().toLowerCase();
    if (key === packageKey && route === routeKey && isFinite(price) && price > 0 && (!review || review === 'approved')) {
      var enabled = String(rows[i][4] || '').trim().toLowerCase();
      var discount = Number(rows[i][5] || 0);
      if (!isFinite(discount) || discount < 0 || discount >= price) return null;
      return { price: price - ((enabled === 'true' || enabled === 'yes' || enabled === '1') ? discount : 0) };
    }
  }
  return null;
}

/** Store untrusted public text as literal cell text, never as a Sheets formula. */
function safeSheetText_(value, maxLength) {
  var text = String(value == null ? '' : value).trim().slice(0, maxLength || 500);
  // Prefix a single quote when the first non-space character could start a formula.
  if (/^[\s]*[=+\-@]/.test(text)) return "'" + text;
  return text;
}

/**
 * Inserts new bus booking into 'Bookings' sheet (Exact 21 columns)
 * and dispatches emails if enabled.
 */
/**
 * Serialize booking writes so duplicate checks, the Bookings row and its pending
 * payment-ledger row cannot race against another submission with the same ID.
 * A booking is acknowledged only after BOTH approved sheet rows are persisted.
 */
function handleNewBooking(b) {
  var lock = LockService.getScriptLock();
  var lockAcquired = false;
  try {
    // doPost already holds the ScriptLock for webhook dispatch. Direct/internal
    // calls acquire it here; never attempt to acquire the same lock recursively.
    if (!lock.hasLock()) {
      lock.waitLock(30000);
      lockAcquired = true;
    }
    return handleNewBookingLocked_(b);
  } catch (bookingWriteError) {
    return { status: 'error', bookingId: String(b && (b.bookingId || b.id) || ''), message: 'Booking could not be fully saved to Google Sheets: ' + String(bookingWriteError.message || bookingWriteError) };
  } finally {
    if (lockAcquired) {
      try { lock.releaseLock(); } catch (releaseError) { Logger.log('Booking lock release failed: ' + releaseError); }
    }
  }
}

function handleNewBookingLocked_(b) {
  var sheet = getRequiredSheet_(SHEET_NAMES.BOOKINGS);
  // Validate both destination tabs before the first write, so a missing or
  // mismatched payment ledger can never leave a booking-only partial record.
  var paySheet = getRequiredSheet_(SHEET_NAMES.BOOKING_PAYMENTS);

  var bId = String(b.bookingId || b.id || '').trim();
  if (!bId) {
    bId = 'MDB-' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyyMMdd') + '-' + Math.floor(1000 + Math.random() * 9000);
  }
  if (!/^[A-Za-z0-9_-]{5,80}$/.test(bId)) return { status: 'error', message: 'Booking ID format is invalid.' };

  // Duplicate Check
  var existingData = sheet.getDataRange().getValues();
  for (var i = 1; i < existingData.length; i++) {
    if (String(existingData[i][1]).trim().toLowerCase() === String(bId).trim().toLowerCase()) {
      // The approved 9-column payment ledger stores the original amount/mode. If it is
      // missing, the original payment intent cannot be reconstructed safely from the
      // 21-column booking row. Never guess an advance/full amount on retry.
      var duplicatePaySheet = getRequiredSheet_(SHEET_NAMES.BOOKING_PAYMENTS);
      var duplicatePayments = duplicatePaySheet.getDataRange().getValues();
      var hasLedger = duplicatePayments.slice(1).some(function(row) { return String(row[1] || '').trim().toLowerCase() === String(bId).trim().toLowerCase(); });
      if (!hasLedger) return { status: 'reconciliation_required', bookingId: bId, message: 'Booking exists but its payment ledger is missing. No amount was guessed; Admin reconciliation is required.' };
      return { status: 'duplicate', bookingId: bId, message: 'Booking ID already exists. Existing payment ledger was left unchanged.' };
    }
  }

  // Pricing authority is the approved PackageOptions sheet, never browser-supplied totals.
  var customerName = String(b.customerName || b.name || '').trim();
  var customerMobile = String(b.customerMobile || b.phone || '').replace(/\D/g, '').slice(-10);
  var customerEmail = String(b.customerEmail || b.email || '').trim();
  var travelDate = String(b.travelDate || '').trim();
  if (customerName.length < 3 || customerName.length > 100) return { status: 'error', message: 'Customer name must be between 3 and 100 characters.' };
  if (!/^\d{10}$/.test(customerMobile)) return { status: 'error', message: 'A valid 10-digit customer mobile number is required.' };
  if (customerEmail && (customerEmail.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail))) return { status: 'error', message: 'Customer email is invalid.' };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(travelDate)) return { status: 'error', message: 'Travel date must use YYYY-MM-DD.' };
  var parsedTravelDate = new Date(travelDate + 'T00:00:00Z');
  if (isNaN(parsedTravelDate.getTime()) || parsedTravelDate.toISOString().slice(0, 10) !== travelDate) return { status: 'error', message: 'Travel date is invalid.' };
  var todayIst = Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd');
  if (travelDate < todayIst) return { status: 'error', message: 'Travel date cannot be in the past.' };

  var persons = Number(b.passengerCount || b.passengers || b.persons || 0);
  if (!isFinite(persons) || Math.floor(persons) !== persons || persons < 1 || persons > 50) return { status: 'error', message: 'Passenger count must be between 1 and 50.' };
  var packageKey = String(b.packageId || b.packageKey || '').trim().toLowerCase();
  var routeKey = normalizeRouteGroup_(b.routeName || b.route || '');
  var packagePrice = getApprovedPackagePrice_(packageKey, routeKey);
  if (!packagePrice) return { status: 'error', message: 'Selected package is unavailable for this route. Please refresh and select an active package.' };
  var food = b.foodSelections || {};
  var biryani = Number(food.vegBiryani || b.vegBiryani || 0);
  var paneer = Number(food.butterPaneer || b.butterPaneer || 0);
  var thali = Number(food.vegThali || b.vegThali || 0);
  if ([biryani, paneer, thali].some(function(n) { return !isFinite(n) || Math.floor(n) !== n || n < 0; })) return { status: 'error', message: 'Food selection counts are invalid.' };
  var hasLunch = packageKey === 'non_ac_lunch' || packageKey === 'ac_lunch';
  if ((!hasLunch && (biryani + paneer + thali !== 0)) || (hasLunch && biryani + paneer + thali !== persons)) return { status: 'error', message: 'Food selections must match the passenger count for the selected package.' };
  var onlineFare = packagePrice.price * persons;
  var paymentMode = String(b.paymentMode || 'advance').toLowerCase();
  if (paymentMode !== 'advance' && paymentMode !== 'full') return { status: 'error', message: 'Payment mode is invalid.' };
  var advancePayable = paymentMode === 'advance' ? Math.min(200, onlineFare) : onlineFare;

  // A newly submitted booking is never confirmed or emailed before verified payment.
  // Ignore any client-supplied paid/confirmed flags; only PAYMENT_VERIFIED can promote it.
  var paymentStatus = 'Payment Pending';
  var bookingStatus = 'Pending Verification';

  // Confirmation emails are deliberately deferred until a trusted server verifies payment.
  var custEmailStatus = 'Queued (Awaiting verified payment)';
  var ownerEmailStatus = 'Queued (Awaiting verified payment)';
  var lastError = '';

  // Customers do not select attractions during online booking. They decide
  // after boarding with the Tour Guide; only the customer's own special request
  // belongs in the existing Special Request column. Ignore legacy/client-sent
  // optionalAttractions fields so they cannot create a pre-selection record.
  var bookingSpecialRequest = String(b.specialRequest || '').trim().slice(0, 500);

  var row = [
    new Date(),                                                        // 1. Timestamp
    bId,                                                               // 2. Booking ID
    safeSheetText_(customerName, 100),                                // 3. Name
    "'" + customerMobile,                                          // 4. Phone
    safeSheetText_(customerEmail, 254),                                // 5. Customer Email
    safeSheetText_(b.travelDate || '', 10),                             // 6. Travel Date
    safeSheetText_(b.routeName || b.route || '', 80),                   // 7. Pickup Route
    safeSheetText_(b.pickupPointName || b.pickupPoint || '', 200),      // 8. Pickup Point
    packageKey,                                                        // 9. Package Key
    safeSheetText_(b.packageTitle || b.packageName || b.package || '', 120), // 10. Package Name
    persons,                                                           // 11. Persons
    biryani,                                                           // 12. Veg Biryani Persons
    paneer,                                                            // 13. Butter Paneer Persons
    thali,                                                             // 14. Veg Thali Persons
    onlineFare,                                                        // 15. Amount INR (Online Booking Fare)
    safeSheetText_(bookingSpecialRequest, 1000),                     // 16. Special Request
    paymentStatus,                                                     // 17. Payment Status
    bookingStatus,                                                     // 18. Booking Status
    custEmailStatus,                                                   // 19. Customer Email Status
    ownerEmailStatus,                                                  // 20. Owner Email Status
    lastError                                                          // 21. Last Error
  ];

  // The Booking ID is stored in column 2 of the approved 21-column Bookings tab.
  // Do not acknowledge the booking until the linked pending-payment row is saved too.
  var bookingRowNumber = sheet.getLastRow() + 1;
  sheet.appendRow(row);

  // Also log into booking_payments sheet with NO fake success.
  // Pending ledger row only; no transaction reference or paid amount is fabricated.
  try {
    paySheet.appendRow([
      'PAY-' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyyMMdd') + '-' + Math.floor(1000 + Math.random() * 9000),
      bId,
      safeSheetText_(b.customerName || b.name || '', 100),
      advancePayable,
      (paymentMode === 'full' ? 'Full Booking Amount' : 'Advance ₹200 per booking'),
      '',
      'Pending',
      new Date(),
      ''
    ]);
  } catch (paymentLedgerError) {
    // Roll back the just-added booking row while the script lock is still held.
    // If rollback itself fails, surface a reconciliation state instead of success.
    try {
      var savedBookingRow = sheet.getRange(bookingRowNumber, 2).getValue();
      if (String(savedBookingRow || '').trim().toLowerCase() === bId.toLowerCase()) {
        sheet.deleteRow(bookingRowNumber);
      } else {
        throw new Error('New booking row could not be located for rollback.');
      }
    } catch (rollbackError) {
      return { status: 'reconciliation_required', bookingId: bId, message: 'Booking ID was written but the pending payment ledger failed and automatic rollback could not be confirmed. Admin reconciliation is required.' };
    }
    return { status: 'error', bookingId: bId, message: 'Booking was not fully saved. The Bookings row was rolled back because the pending payment ledger could not be saved.' };
  }

  return {
    status: 'success',
    bookingId: bId,
    onlineBookingFare: onlineFare,
    advancePayable: advancePayable,
    customerEmailStatus: custEmailStatus,
    ownerEmailStatus: ownerEmailStatus,
    message: 'Booking saved successfully. Payment is pending; confirmation emails will be sent only after verified payment.'
  };
}

/**
 * Trusted payment confirmation handler.
 * Call ONLY from a secure server after independently verifying the provider's
 * server-to-server payment status/signature. Never call this action from browser code.
 * Configure Script Property PAYMENT_CALLBACK_SECRET before enabling a gateway.
 */
function handleVerifiedPayment(d) {
  var configuredSecret = PropertiesService.getScriptProperties().getProperty('PAYMENT_CALLBACK_SECRET');
  var suppliedCallbackSecret = String(d.callbackSecret || '');
  if (!configuredSecret || !suppliedCallbackSecret || !constantTimeEquals_(configuredSecret, suppliedCallbackSecret)) {
    return { status: 'error', message: 'Payment verification caller is not authorized.' };
  }
  var bookingId = String(d.bookingId || '').trim();
  var transactionRef = String(d.transactionRef || '').trim();
  var paymentId = String(d.paymentId || '').trim();
  var amount = Number(d.amount);
  if (!bookingId || !transactionRef || !paymentId || !isFinite(amount) || amount <= 0 || d.providerVerified !== true) {
    return { status: 'error', message: 'Verified payment details are incomplete or invalid.' };
  }

  var bookingSheet = getRequiredSheet_(SHEET_NAMES.BOOKINGS);
  var paymentSheet = getRequiredSheet_(SHEET_NAMES.BOOKING_PAYMENTS);
  var bookingRows = bookingSheet.getDataRange().getValues();
  var bookingRow = -1;
  var bookingMatches = 0;
  for (var i = 1; i < bookingRows.length; i++) {
    if (String(bookingRows[i][1] || '').trim().toLowerCase() === bookingId.toLowerCase()) {
      bookingMatches++;
      if (bookingRow < 0) bookingRow = i + 1;
    }
  }
  if (bookingMatches === 0) return { status: 'not_found', message: 'Booking ID not found.' };
  if (bookingMatches !== 1) return { status: 'reconciliation_required', message: 'Duplicate Booking ID detected. Payment callback was not applied; Admin reconciliation is required.' };

  var current = bookingRows[bookingRow - 1];
  var existingPaymentStatus = String(current[16] || '');
  if (existingPaymentStatus === 'Advance Paid' || existingPaymentStatus === 'Fully Paid') {
    return { status: 'duplicate', bookingId: bookingId, message: 'This booking is already marked as paid.' };
  }

  var onlineFare = Number(current[14] || 0);
  var paymentRows = paymentSheet.getDataRange().getValues();
  var paymentRow = -1;
  var paymentMatches = 0;
  var paymentMode = 'advance';
  for (var j = 1; j < paymentRows.length; j++) {
    if (String(paymentRows[j][1] || '').trim().toLowerCase() === bookingId.toLowerCase()) {
      paymentMatches++;
      if (paymentRow < 0) {
        paymentRow = j + 1;
        paymentMode = String(paymentRows[j][4] || '').toLowerCase().indexOf('full') !== -1 ? 'full' : 'advance';
      }
    }
  }
  if (paymentMatches === 0) return { status: 'error', message: 'Pending payment ledger row not found; booking was not confirmed.' };
  if (paymentMatches !== 1) return { status: 'reconciliation_required', message: 'Multiple payment ledger rows exist for this booking. Payment callback was not applied; Admin reconciliation is required.' };
  for (var k = 1; k < paymentRows.length; k++) {
    if (k + 1 !== paymentRow && (String(paymentRows[k][5] || '') === transactionRef || String(paymentRows[k][0] || '') === paymentId)) {
      return { status: 'error', message: 'Payment transaction reference or payment ID is already linked to another booking.' };
    }
  }

  var expectedAmount = paymentMode === 'full' ? onlineFare : Math.min(200, onlineFare);
  if (Math.round(amount * 100) !== Math.round(expectedAmount * 100)) {
    return { status: 'error', message: 'Verified payment amount does not match the booking amount due.' };
  }

  // Idempotent callback recovery: if a prior attempt wrote the verified ledger
  // but failed before updating the booking row, the exact same provider event may
  // finish the state transition. A different event must never overwrite that
  // already-verified ledger entry for this booking.
  var existingLedgerRow = paymentRows[paymentRow - 1];
  var existingLedgerStatus = String(existingLedgerRow[6] || '').trim().toLowerCase();
  if (existingLedgerStatus === 'verified') {
    var sameVerifiedEvent =
      String(existingLedgerRow[0] || '').trim() === paymentId &&
      String(existingLedgerRow[5] || '').trim() === transactionRef &&
      Math.round(Number(existingLedgerRow[3] || 0) * 100) === Math.round(amount * 100);
    if (!sameVerifiedEvent) {
      return { status: 'reconciliation_required', bookingId: bookingId, message: 'A different verified payment is already recorded for this booking. Existing ledger evidence was preserved; Admin reconciliation is required.' };
    }
  }

  var newPaymentStatus = paymentMode === 'full' ? 'Fully Paid' : 'Advance Paid';
  paymentSheet.getRange(paymentRow, 1).setValue(safeSheetText_(paymentId, 150));
  paymentSheet.getRange(paymentRow, 4).setValue(amount);
  paymentSheet.getRange(paymentRow, 5).setValue(safeSheetText_(d.provider || 'Online Payment Gateway', 80));
  paymentSheet.getRange(paymentRow, 6).setValue(safeSheetText_(transactionRef, 150));
  paymentSheet.getRange(paymentRow, 7).setValue('Verified');
  paymentSheet.getRange(paymentRow, 9).setValue(new Date());
  bookingSheet.getRange(bookingRow, 17).setValue(newPaymentStatus);
  bookingSheet.getRange(bookingRow, 18).setValue('Confirmed');

  var emailResult = dispatchPaidBookingEmails(bookingSheet, bookingRow, current, bookingId);
  return { status: 'success', bookingId: bookingId, paymentStatus: newPaymentStatus, bookingStatus: 'Confirmed', customerEmailStatus: emailResult.customerEmailStatus, ownerEmailStatus: emailResult.ownerEmailStatus, message: 'Payment verified. Booking confirmed; confirmation emails follow the live-email setting.' };
}

/** Send confirmation emails only after a verified payment state has been written. */
function dispatchPaidBookingEmails(sheet, rowNumber, bookingRowData, bookingId) {
  var customerRecipient = String(bookingRowData[4] || '').trim();
  var ownerRecipient = BUSINESS_CONFIG.EMAIL;
  var notificationMessage = 'Booking ' + bookingId + ' has been payment-verified and confirmed.';
  if (!checkLiveEmailsActive()) {
    upsertBookingNotification_(bookingId, customerRecipient || 'customer-email-missing', 'BOOKING_CONFIRMED_CUSTOMER_EMAIL', notificationMessage, 'Queued - Live emails disabled', '');
    upsertBookingNotification_(bookingId, ownerRecipient, 'BOOKING_CONFIRMED_OWNER_EMAIL', notificationMessage, 'Queued - Live emails disabled', '');
    sheet.getRange(rowNumber, 19).setValue('Queued (Live emails disabled)');
    sheet.getRange(rowNumber, 20).setValue('Queued (Live emails disabled)');
    return { customerEmailStatus: 'Queued (Live emails disabled)', ownerEmailStatus: 'Queued (Live emails disabled)' };
  }

  var bookingObj = {
    bookingId: bookingId,
    customerName: bookingRowData[2],
    customerMobile: bookingRowData[3],
    customerEmail: bookingRowData[4],
    travelDate: bookingRowData[5],
    routeName: bookingRowData[6],
    pickupPointName: bookingRowData[7],
    packageTitle: bookingRowData[9],
    passengerCount: bookingRowData[10],
    onlineBookingFare: bookingRowData[14],
    paymentStatus: sheet.getRange(rowNumber, 17).getValue()
  };
  upsertBookingNotification_(bookingId, customerRecipient || 'customer-email-missing', 'BOOKING_CONFIRMED_CUSTOMER_EMAIL', notificationMessage, 'Queued', '');
  upsertBookingNotification_(bookingId, ownerRecipient, 'BOOKING_CONFIRMED_OWNER_EMAIL', notificationMessage, 'Queued', '');
  var custRes = sendCustomerBookingEmail(bookingObj, bookingId);
  var ownerRes = sendOwnerBookingNotification(bookingObj, bookingId);
  upsertBookingNotification_(bookingId, customerRecipient || 'customer-email-missing', 'BOOKING_CONFIRMED_CUSTOMER_EMAIL', notificationMessage, custRes.status || 'Failed', custRes.status === 'Sent' ? new Date() : '');
  upsertBookingNotification_(bookingId, ownerRecipient, 'BOOKING_CONFIRMED_OWNER_EMAIL', notificationMessage, ownerRes.status || 'Failed', ownerRes.status === 'Sent' ? new Date() : '');
  sheet.getRange(rowNumber, 19).setValue(custRes.status);
  sheet.getRange(rowNumber, 20).setValue(ownerRes.status);
  sheet.getRange(rowNumber, 21).setValue((custRes.error || '') + ' ' + (ownerRes.error || ''));
  return { customerEmailStatus: custRes.status, ownerEmailStatus: ownerRes.status };
}

/**
 * Handle new Rental Enquiry (Rental Enquiry sheet)
 * RULE 3E: Do NOT send customer or owner emails for Rental Enquiries.
 * Save in Google Sheets. Use WhatsApp for follow-up.
 */
function handleRentalEnquiry(d) {
  // Validate customer input before opening or writing to the destination sheet.
  // Rental enquiries are inquiry-only; these checks do not create a booking or quote.
  var enqId = String(d.id || d.enquiryId || ('REN-' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyyMMdd') + '-' + Math.floor(100 + Math.random() * 900))).trim();
  if (!/^[A-Za-z0-9_-]{5,80}$/.test(enqId)) return { status: 'error', message: 'Enquiry ID format is invalid.' };

  var customerName = String(d.customerName || d.customer_name || '').trim();
  var rawMobile = String(d.customerMobile || d.mobile || d.phone || '').replace(/\D/g, '');
  var travelDate = String(d.travelDate || d.travel_date || '').trim();
  var pickupLocation = String(d.pickupLocation || d.pickup_location || '').trim();
  var destination = String(d.destination || '').trim();
  var rentalType = String(d.rentalType || '').trim().toLowerCase();
  var passengers = Number(d.passengerCount || d.persons || 0);
  var days = Number(d.daysCount || d.durationDays || d.days || 1);

  if (customerName.length < 3 || customerName.length > 100) return { status: 'error', message: 'Customer name must be between 3 and 100 characters.' };
  if (!/^\d{10}$/.test(rawMobile)) return { status: 'error', message: 'A valid 10-digit customer mobile number is required.' };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(travelDate)) return { status: 'error', message: 'Travel date must use YYYY-MM-DD.' };
  var parsedTravelDate = new Date(travelDate + 'T00:00:00Z');
  if (isNaN(parsedTravelDate.getTime()) || parsedTravelDate.toISOString().slice(0, 10) !== travelDate) return { status: 'error', message: 'Travel date is invalid.' };
  var todayIst = Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd');
  if (travelDate < todayIst) return { status: 'error', message: 'Travel date cannot be in the past.' };
  if (!pickupLocation || pickupLocation.length > 200) return { status: 'error', message: 'A pickup location of up to 200 characters is required.' };
  if (rentalType !== 'local_darshan' && rentalType !== 'outstation') return { status: 'error', message: 'Rental type must be Local Darshan or Outstation.' };
  if (rentalType === 'outstation' && (!destination || destination.length > 200)) return { status: 'error', message: 'A valid outstation destination of up to 200 characters is required.' };
  if (!isFinite(passengers) || Math.floor(passengers) !== passengers || passengers < 1 || passengers > 50) return { status: 'error', message: 'Passenger count must be between 1 and 50.' };
  if (!isFinite(days) || Math.floor(days) !== days || days < 1 || days > 30) return { status: 'error', message: 'Rental duration must be between 1 and 30 days.' };

  var sheet = getRequiredSheet_(SHEET_NAMES.RENTAL_ENQUIRY);
  var existingRows = sheet.getDataRange().getValues();
  for (var existingIndex = 1; existingIndex < existingRows.length; existingIndex++) {
    if (String(existingRows[existingIndex][0] || '').trim().toLowerCase() === enqId.toLowerCase()) {
      return { status: 'duplicate', enquiryId: enqId, message: 'This enquiry ID is already saved in Google Sheets.' };
    }
  }

  // Exact 19-column customer enquiry mapping. No quote, payment, or booking
  // confirmation data is part of this inquiry-only record.
  sheet.appendRow([
    enqId,
    safeSheetText_(customerName, 100),
    "'" + rawMobile,
    safeSheetText_(d.vehicleType || d.vehicle_type || '', 80),
    travelDate,
    safeSheetText_(pickupLocation, 200),
    safeSheetText_(destination, 200),
    safeSheetText_(d.tripType || d.trip_type || (rentalType === 'local_darshan' ? 'Local' : 'Outstation'), 40),
    passengers,
    days,
    safeSheetText_(d.specialRequirements || d.special_request || '', 1000),
    'New',
    new Date(),
    safeSheetText_(d.preferredCarModel || d.preferred_car_model || '', 100),
    safeSheetText_(d.tempoTravellerSeatingCapacity || d.tempo_traveller_seating_capacity || '', 40),
    safeSheetText_(d.otherSeatingCapacity || d.other_seating_capacity || '', 40),
    safeSheetText_(d.acPreference || d.ac_preference || '', 40),
    safeSheetText_(d.rentalDuration || d.rental_duration || '', 80),
    safeSheetText_(d.pickupTime || d.pickup_time || '', 40)
  ]);

  return {
    status: 'success',
    enquiryId: enqId,
    message: 'Rental enquiry saved. This is an enquiry only; vehicle availability and any booking require owner follow-up.'
  };
}

/**
 * Sends one controlled connection-test email to the configured business inbox.
 * This action requires the Apps Script owner to authorize MailApp once.
 */
function runEmailConnectionTest() {
  try {
    if (MailApp.getRemainingDailyQuota() <= 0) {
      appendEmailLog_('EMAIL-CONNECTION-TEST', 'Owner Test', BUSINESS_CONFIG.EMAIL, 'Failed', 'Gmail daily sending quota is exhausted.');
      return { status: 'error', message: 'Gmail daily sending quota is exhausted.' };
    }
    MailApp.sendEmail({
      to: BUSINESS_CONFIG.EMAIL,
      subject: 'Mumbai Darshan Bus Online - Email Connection Test',
      body: 'Email connection test successful.\n\nBusiness phone: ' + BUSINESS_CONFIG.PHONE + '\nBusiness email: ' + BUSINESS_CONFIG.EMAIL,
      name: BUSINESS_CONFIG.NAME
    });
    appendEmailLog_('EMAIL-CONNECTION-TEST', 'Owner Test', BUSINESS_CONFIG.EMAIL, 'Sent', '');
    return { status: 'success', message: 'Test email sent to ' + BUSINESS_CONFIG.EMAIL };
  } catch (err) {
    appendEmailLog_('EMAIL-CONNECTION-TEST', 'Owner Test', BUSINESS_CONFIG.EMAIL, 'Failed', String(err));
    return { status: 'error', message: 'Email test failed: ' + err.toString() };
  }
}

/**
 * Customer Booking Email Dispatcher
 */
function sendCustomerBookingEmail(b, bId) {
  var recipient = String(b.customerEmail || b.email || '').trim();
  var result;
  try { result = sendCustomerBookingEmailRaw_(b, bId); }
  catch (err) { result = { status: 'Failed', error: String(err) }; }
  appendEmailLog_(bId, 'Customer', recipient, result.status || 'Failed', result.error || '');
  return result;
}

function sendCustomerBookingEmailRaw_(b, bId) {
  try {
    var recipient = String(b.customerEmail || b.email || '').trim();
    if (!recipient || recipient.indexOf('@') === -1 || recipient.indexOf('@mumbaidarshanbusonline.com') !== -1) {
      return { status: 'Skipped (No valid customer email provided)' };
    }

    var quota = MailApp.getRemainingDailyQuota();
    if (quota <= 0) {
      return { status: 'Failed', error: 'Daily MailApp quota exceeded' };
    }

    var pax = Number(b.passengerCount || b.passengers || b.persons || 1);
    var onlineFare = Number(b.onlineBookingFare || b.grandTotal || b.amountInr || b.amount || 0);
    var advanceAmount = Number(b.advancePayable || (b.paymentMode === 'advance' ? 200 : onlineFare));
    var balanceOnBus = Math.max(0, onlineFare - advanceAmount);

    var guideFee = pax * 50;
    var tollFee = pax * 10;
    var totalToGuide = guideFee + tollFee;

    var subject = 'Booking Confirmed: Mumbai Darshan Bus - ' + bId + ' (' + (b.travelDate || '') + ')';

    var htmlBody = ''
      + '<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;background:#090a0f;color:#e2e8f0;padding:24px;border-radius:12px;border:1px solid #334155;">'
      + '<div style="text-align:center;border-bottom:1px solid #1e293b;padding-bottom:16px;margin-bottom:20px;">'
      + '  <h2 style="color:#f59e0b;margin:0 0 6px 0;font-size:22px;">' + BUSINESS_CONFIG.NAME + '</h2>'
      + '  <span style="color:#94a3b8;font-size:12px;">Official Booking Voucher & Reservation Confirmation</span>'
      + '</div>'
      + '<p style="font-size:14px;color:#f8fafc;">Dear <strong>' + (b.customerName || b.name || 'Traveler') + '</strong>,</p>'
      + '<p style="font-size:13px;line-height:1.6;color:#cbd5e1;">Your Mumbai Darshan Bus tour has been reserved successfully. Please carry a valid Government ID proof on the day of travel.</p>'
      + '<table style="width:100%;font-size:13px;border-collapse:collapse;margin:16px 0;background:#0f172a;border-radius:8px;overflow:hidden;">'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Booking ID:</td><td style="padding:10px 14px;font-weight:bold;color:#f59e0b;font-family:monospace;">' + bId + '</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Travel Date:</td><td style="padding:10px 14px;font-weight:bold;color:#fff;">' + (b.travelDate || '') + '</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Pickup Route:</td><td style="padding:10px 14px;color:#fff;">' + (b.routeName || b.route || '') + '</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Boarding Point:</td><td style="padding:10px 14px;color:#fff;">' + (b.pickupPointName || b.pickupPoint || '') + ' at <strong>' + (b.pickupTime || '') + '</strong> (Please report 15 mins prior)</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Package:</td><td style="padding:10px 14px;color:#fff;">' + (b.packageTitle || b.packageName || b.package || '') + ' (' + pax + ' Passengers)</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Online Bus Booking Fare:</td><td style="padding:10px 14px;font-weight:bold;color:#f59e0b;font-size:15px;">₹' + onlineFare + '</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Advance Payment Status:</td><td style="padding:10px 14px;color:#10b981;font-weight:bold;">₹200 per booking (' + (b.paymentStatus || 'Pending Verification') + ')</td></tr>'
      + '  <tr><td style="padding:10px 14px;color:#94a3b8;">Remaining Bus Balance (Payable on Bus):</td><td style="padding:10px 14px;font-weight:bold;color:#fcd34d;">₹' + balanceOnBus + '</td></tr>'
      + '</table>'
      + '<div style="background:#1e1b18;border:1px solid #78350f;border-radius:8px;padding:12px 14px;margin:16px 0;">'
      + '  <strong style="color:#f59e0b;font-size:13px;display:block;margin-bottom:6px;">PAYABLE DIRECTLY TO GUIDE INSIDE BUS (Mandatory Charges):</strong>'
      + '  <ul style="margin:0;padding-left:18px;font-size:12px;color:#e2e8f0;line-height:1.6;">'
      + '    <li>Guide Charge: ₹50/person — Payable directly to Guide inside the bus. (' + pax + ' × ₹50 = ₹' + guideFee + ')</li>'
      + '    <li>Sea Link Toll: ₹10/person — Payable directly to Guide inside the bus. (' + pax + ' × ₹10 = ₹' + tollFee + ')</li>'
      + '    <li><strong>Total payable directly to Guide: ₹60/person (' + pax + ' × ₹60 = ₹' + totalToGuide + ' inside bus).</strong></li>'
      + '  </ul>'
      + '  <span style="font-size:11px;color:#cbd5e1;display:block;margin-top:6px;">* Both charges will be collected directly by the Tour Guide inside the bus. They are NOT included in the online bus booking fare or the ₹200 advance.</span>'
      + '</div>'
      + '<div style="background:#064e3b;border:1px solid #059669;border-radius:8px;padding:12px 14px;margin:16px 0;font-size:12px;color:#d1fae5;line-height:1.5;">'
      + '  <strong>Meal Information:</strong> Breakfast and lunch are included in applicable packages. Breakfast will be served as Samosa or Kanda Poha, as decided by the operator. Drinking water bottles and juice are not included.'
      + '</div>'
      + '<div style="font-size:11px;color:#64748b;margin-top:20px;border-top:1px solid #1e293b;padding-top:12px;line-height:1.5;">'
      + '  <strong>Helpline:</strong> ' + BUSINESS_CONFIG.PHONE + ' | <strong>Email:</strong> ' + BUSINESS_CONFIG.EMAIL + '<br />'
      + '  <strong>Address:</strong> ' + BUSINESS_CONFIG.ADDRESS + '<br />'
      + '  Website: <a href="' + BUSINESS_CONFIG.DOMAIN + '" style="color:#f59e0b;">' + BUSINESS_CONFIG.DOMAIN + '</a>'
      + '</div>'
      + '</div>';

    var plainText = 'MUMBAI DARSHAN BUS ONLINE - BOOKING CONFIRMATION\n\n'
      + 'Booking ID: ' + bId + '\n'
      + 'Customer: ' + (b.customerName || b.name || '') + '\n'
      + 'Date of Travel: ' + (b.travelDate || '') + '\n'
      + 'Pickup: ' + (b.pickupPointName || b.pickupPoint || '') + ' (' + (b.pickupTime || '') + ')\n'
      + 'Package: ' + (b.packageTitle || b.packageName || b.package || '') + ' (' + pax + ' Persons)\n'
      + 'Online Bus Booking Fare: ₹' + onlineFare + '\n'
      + 'Advance Status: ₹200 per booking (' + (b.paymentStatus || 'Pending Verification') + ')\n'
      + 'Remaining Bus Balance: ₹' + balanceOnBus + ' (payable on bus)\n\n'
      + 'MANDATORY CHARGES (COLLECTED DIRECTLY BY GUIDE INSIDE BUS):\n'
      + '- Guide Charge: ₹50/person — Payable directly to Guide inside the bus.\n'
      + '- Sea Link Toll: ₹10/person — Payable directly to Guide inside the bus.\n'
      + '- Total payable directly to Guide: ₹60/person (₹' + totalToGuide + ' for ' + pax + ' passengers)\n'
      + 'These charges are collected separately inside the bus and are NOT included in the online fare.\n\n'
      + 'MEAL NOTICE:\n'
      + 'Breakfast and lunch are included in applicable packages. Breakfast will be served as Samosa or Kanda Poha, as decided by the operator. Drinking water bottles and juice are not included.\n\n'
      + 'Helpline: ' + BUSINESS_CONFIG.PHONE + ' | Email: ' + BUSINESS_CONFIG.EMAIL;

    MailApp.sendEmail({
      to: recipient,
      subject: subject,
      body: plainText,
      htmlBody: htmlBody,
      name: BUSINESS_CONFIG.NAME
    });

    return { status: 'Sent' };
  } catch (err) {
    return { status: 'Failed', error: err.toString() };
  }
}

/**
 * Owner Booking Notification Dispatcher
 */
function sendOwnerBookingNotification(b, bId) {
  var recipient = BUSINESS_CONFIG.EMAIL;
  var result;
  try { result = sendOwnerBookingNotificationRaw_(b, bId); }
  catch (err) { result = { status: 'Failed', error: String(err) }; }
  appendEmailLog_(bId, 'Owner', recipient, result.status || 'Failed', result.error || '');
  return result;
}

function sendOwnerBookingNotificationRaw_(b, bId) {
  try {
    var quota = MailApp.getRemainingDailyQuota();
    if (quota <= 0) {
      return { status: 'Failed', error: 'Daily MailApp quota exceeded' };
    }

    var pax = Number(b.passengerCount || b.passengers || b.persons || 1);
    var onlineFare = Number(b.onlineBookingFare || b.grandTotal || b.amountInr || b.amount || 0);
    var advanceAmount = Number(b.advancePayable || (b.paymentMode === 'advance' ? 200 : onlineFare));
    var balanceOnBus = Math.max(0, onlineFare - advanceAmount);

    var guideFee = pax * 50;
    var tollFee = pax * 10;
    var totalToGuide = guideFee + tollFee;

    var subject = 'New Booking Alert: ' + bId + ' - ' + (b.customerName || b.name || '') + ' (' + pax + ' Pax) - ' + (b.travelDate || '');

    var plainText = 'NEW BOOKING RECEIVED - MUMBAI DARSHAN BUS ONLINE\n\n'
      + 'Booking ID: ' + bId + '\n'
      + 'Customer: ' + (b.customerName || b.name || '') + '\n'
      + 'Phone: ' + (b.customerMobile || b.phone || '') + '\n'
      + 'Email: ' + (b.customerEmail || b.email || '') + '\n'
      + 'Travel Date: ' + (b.travelDate || '') + '\n'
      + 'Route: ' + (b.routeName || b.route || '') + '\n'
      + 'Pickup Point: ' + (b.pickupPointName || b.pickupPoint || '') + ' at ' + (b.pickupTime || '') + '\n'
      + 'Package: ' + (b.packageTitle || b.packageName || b.package || '') + ' (' + pax + ' Pax)\n\n'
      + 'Online Booking Fare: ₹' + onlineFare + '\n'
      + 'Advance Payable: ₹' + advanceAmount + ' (' + (b.paymentStatus || 'Pending Verification') + ')\n'
      + 'Remaining Balance to Collect on Bus: ₹' + balanceOnBus + '\n'
      + 'Guide & Sea Link to Collect on Bus: ₹' + totalToGuide + ' (Guide: ₹' + guideFee + ' + Toll: ₹' + tollFee + ')\n\n'
      + 'Special Requests: ' + (b.specialRequest || 'None') + '\n'
      + 'Timestamp: ' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd HH:mm:ss');

    MailApp.sendEmail({
      to: BUSINESS_CONFIG.EMAIL,
      subject: subject,
      body: plainText,
      name: 'MDB Online Booking Engine'
    });

    return { status: 'Sent' };
  } catch (err) {
    return { status: 'Failed', error: err.toString() };
  }
}

/**
 * Converts a Sheets date/timestamp or ISO date into an Asia/Kolkata YYYY-MM-DD key.
 */
function getIstDateKey_(value) {
  if (value instanceof Date && !isNaN(value.getTime())) return Utilities.formatDate(value, 'Asia/Kolkata', 'yyyy-MM-dd');
  var text = String(value || '').trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return text;
  var parsed = new Date(text);
  return !isNaN(parsed.getTime()) ? Utilities.formatDate(parsed, 'Asia/Kolkata', 'yyyy-MM-dd') : '';
}

/**
 * Build and upsert one aggregate row in the approved 8-column daily_reports sheet.
 * Revenue means verified payment ledger collections whose ledger created_at date matches report_date.
 * No customer names, phone numbers or email addresses are stored in the report or sent in the summary.
 */
function generateDailyReport_(reportDate) {
  var dateKey = String(reportDate || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) throw new Error('Report date must use YYYY-MM-DD.');
  var dateParts = dateKey.split('-').map(Number);
  var checkDate = new Date(Date.UTC(dateParts[0], dateParts[1] - 1, dateParts[2]));
  if (checkDate.getUTCFullYear() !== dateParts[0] || checkDate.getUTCMonth() !== dateParts[1] - 1 || checkDate.getUTCDate() !== dateParts[2]) throw new Error('Invalid report date.');

  var bookingRows = getRequiredSheet_(SHEET_NAMES.BOOKINGS).getDataRange().getValues();
  var paymentRows = getRequiredSheet_(SHEET_NAMES.BOOKING_PAYMENTS).getDataRange().getValues();
  var totalBookings = 0, confirmedBookings = 0, cancelledBookings = 0, pendingPayments = 0;
  var customers = {};
  for (var i = 1; i < bookingRows.length; i++) {
    var row = bookingRows[i];
    if (getIstDateKey_(row[0]) !== dateKey) continue;
    totalBookings++;
    var bookingStatus = String(row[17] || '').trim().toLowerCase();
    var paymentStatus = String(row[16] || '').trim().toLowerCase();
    if (bookingStatus === 'confirmed' || bookingStatus === 'completed') confirmedBookings++;
    if (bookingStatus === 'cancelled') cancelledBookings++;
    if (['payment pending', 'pending verification', 'pending'].indexOf(paymentStatus) !== -1) pendingPayments++;
    var phone = String(row[3] || '').replace(/\D/g, '');
    if (phone) customers[phone] = true;
  }

  var totalRevenue = 0;
  for (var p = 1; p < paymentRows.length; p++) {
    var payment = paymentRows[p];
    var paymentStatusValue = String(payment[6] || '').trim().toLowerCase();
    if (getIstDateKey_(payment[8]) === dateKey && ['verified', 'paid', 'success'].indexOf(paymentStatusValue) !== -1) {
      totalRevenue += Number(payment[3] || 0);
    }
  }

  var reportSheet = getRequiredSheet_(SHEET_NAMES.DAILY_REPORTS);
  var existingRows = reportSheet.getDataRange().getValues();
  var targetRow = -1, createdAt = new Date();
  for (var r = 1; r < existingRows.length; r++) {
    if (getIstDateKey_(existingRows[r][0]) === dateKey) {
      targetRow = r + 1;
      createdAt = existingRows[r][7] || createdAt;
      break;
    }
  }
  var reportValues = [dateKey, totalBookings, confirmedBookings, cancelledBookings, Object.keys(customers).length, totalRevenue, pendingPayments, createdAt];
  if (targetRow > 0) reportSheet.getRange(targetRow, 1, 1, 8).setValues([reportValues]);
  else reportSheet.appendRow(reportValues);

  return {
    report_date: dateKey,
    total_bookings: totalBookings,
    confirmed_bookings: confirmedBookings,
    cancelled_bookings: cancelledBookings,
    total_customers: Object.keys(customers).length,
    total_revenue: totalRevenue,
    pending_payments: pendingPayments,
    created_at: createdAt instanceof Date ? createdAt.toISOString() : createdAt
  };
}

/** Scheduled 10:00 PM IST summary. Trigger installation is a separate owner-approved setup step. */
function sendDailyOwnerReport() {
  var todayStr = Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd');
  try {
    var report = generateDailyReport_(todayStr);
    var subject = 'Daily Operations Summary - Mumbai Darshan Bus (' + todayStr + ')';
    var reportText = 'MUMBAI DARSHAN BUS ONLINE - DAILY SUMMARY\n'
      + 'Date: ' + todayStr + '\n\n'
      + 'Total bookings: ' + report.total_bookings + '\n'
      + 'Confirmed/completed bookings: ' + report.confirmed_bookings + '\n'
      + 'Cancelled bookings: ' + report.cancelled_bookings + '\n'
      + 'Unique customers: ' + report.total_customers + '\n'
      + 'Verified payments received: INR ' + report.total_revenue + '\n'
      + 'Pending payments: ' + report.pending_payments + '\n\n'
      + 'This is an aggregate report. Customer names, mobile numbers and email addresses are intentionally excluded.';
    if (!checkLiveEmailsActive()) {
      appendEmailLog_(todayStr, 'Owner Daily Report', BUSINESS_CONFIG.EMAIL, 'Skipped', 'Live email dispatch is disabled in Settings. Report was saved to daily_reports.');
      logActivity('DAILY_REPORT_SAVED_EMAIL_SKIPPED', todayStr, 'Daily aggregate report saved; email dispatch disabled.');
      return { status: 'success', report: report, emailStatus: 'Skipped' };
    }
    MailApp.sendEmail({ to: BUSINESS_CONFIG.EMAIL, subject: subject, body: reportText, name: 'MDB Daily Operations Reporter' });
    appendEmailLog_(todayStr, 'Owner Daily Report', BUSINESS_CONFIG.EMAIL, 'Sent', '');
    logActivity('DAILY_REPORT_DISPATCHED', todayStr, 'Aggregate report sent; bookings=' + report.total_bookings);
    return { status: 'success', report: report, emailStatus: 'Sent' };
  } catch (err) {
    appendEmailLog_(todayStr, 'Owner Daily Report', BUSINESS_CONFIG.EMAIL, 'Failed', String(err));
    logActivity('DAILY_REPORT_FAILED', todayStr, String(err));
    return { status: 'error', message: String(err) };
  }
}

/**
 * Retry Failed Emails for a Specific Booking
 */
function retryFailedEmails(bookingId) {
  var sheet = getRequiredSheet_(SHEET_NAMES.BOOKINGS);
  if (!sheet) return { status: 'error', message: 'Bookings sheet not found' };

  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (String(data[i][1]).trim().toLowerCase() === String(bookingId).trim().toLowerCase()) {
      var currentPaymentStatus = String(data[i][16] || '');
      if (currentPaymentStatus !== 'Advance Paid' && currentPaymentStatus !== 'Fully Paid') {
        return { status: 'error', bookingId: bookingId, message: 'Confirmation emails are blocked until payment is verified.' };
      }
      if (!checkLiveEmailsActive()) {
        return { status: 'error', bookingId: bookingId, message: 'Live email sending is disabled in Settings. Enable it before retrying confirmation emails.' };
      }

      var bookingObj = {
        bookingId: data[i][1],
        customerName: data[i][2],
        customerMobile: data[i][3],
        customerEmail: data[i][4],
        travelDate: data[i][5],
        routeName: data[i][6],
        pickupPointName: data[i][7],
        packageTitle: data[i][9],
        passengerCount: data[i][10],
        onlineBookingFare: data[i][14],
        paymentStatus: data[i][16]
      };

      var previousCustomerStatus = String(data[i][18] || '');
      var previousOwnerStatus = String(data[i][19] || '');
      var custRes = previousCustomerStatus === 'Sent' || previousCustomerStatus.indexOf('Skipped') === 0 ? { status: previousCustomerStatus } : sendCustomerBookingEmail(bookingObj, bookingObj.bookingId);
      var ownerRes = previousOwnerStatus === 'Sent' ? { status: previousOwnerStatus } : sendOwnerBookingNotification(bookingObj, bookingObj.bookingId);
      var retryMessage = 'Booking ' + bookingObj.bookingId + ' confirmation email retry.';
      if (previousCustomerStatus !== 'Sent' && previousCustomerStatus.indexOf('Skipped') !== 0) upsertBookingNotification_(bookingObj.bookingId, bookingObj.customerEmail || 'customer-email-missing', 'BOOKING_CONFIRMED_CUSTOMER_EMAIL', retryMessage, custRes.status || 'Failed', custRes.status === 'Sent' ? new Date() : '');
      if (previousOwnerStatus !== 'Sent') upsertBookingNotification_(bookingObj.bookingId, BUSINESS_CONFIG.EMAIL, 'BOOKING_CONFIRMED_OWNER_EMAIL', retryMessage, ownerRes.status || 'Failed', ownerRes.status === 'Sent' ? new Date() : '');

      sheet.getRange(i + 1, 19).setValue(custRes.status);
      sheet.getRange(i + 1, 20).setValue(ownerRes.status);
      sheet.getRange(i + 1, 21).setValue((custRes.error || '') + ' ' + (ownerRes.error || ''));

      return {
        status: 'success',
        bookingId: bookingId,
        customerEmailStatus: custRes.status,
        ownerEmailStatus: ownerRes.status,
        message: 'Email retry complete.'
      };
    }
  }

  return { status: 'not_found', message: 'Booking ID not found' };
}

/**
 * Controlled Test Function for Owner
 * Run this function manually in Google Apps Script Editor to verify MailApp permissions safely.
 */
function testSendBookingEmail() {
  var sampleBooking = {
    customerName: 'Test Traveler (Rahul Sharma)',
    customerEmail: BUSINESS_CONFIG.EMAIL,
    customerMobile: '9619975457',
    travelDate: Utilities.formatDate(new Date(Date.now() + 86400000), 'Asia/Kolkata', 'yyyy-MM-dd'),
    routeName: 'Western Line',
    pickupPointName: 'Borivali East - National Park Gate',
    pickupTime: '6:30 AM',
    packageTitle: 'AC Bus + Lunch',
    passengerCount: 3,
    onlineBookingFare: 1500, // 3 × ₹500
    advancePayable: 200,     // ₹200 advance per booking
    balancePayable: 1300,    // Remaining bus package balance
    paymentStatus: 'Pending Verification',
    specialRequest: 'Test booking verification'
  };

  Logger.log('Running controlled email dispatch test to ' + BUSINESS_CONFIG.EMAIL + '...');
  var res = sendCustomerBookingEmail(sampleBooking, 'TEST-MDB-9999');
  Logger.log('Customer Email Result: ' + JSON.stringify(res));

  var ownerRes = sendOwnerBookingNotification(sampleBooking, 'TEST-MDB-9999');
  Logger.log('Owner Notification Result: ' + JSON.stringify(ownerRes));
}

/**
 * Installs daily 10:00 PM IST trigger for Daily Operations Report
 * Run this function once manually in Google Apps Script Editor when owner approves.
 */
function setupDailyReportTrigger() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'sendDailyOwnerReport') {
      ScriptApp.deleteTrigger(triggers[i]);
    }
  }

  ScriptApp.newTrigger('sendDailyOwnerReport')
    .timeBased()
    .everyDays(1)
    .atHour(22)
    .inTimezone('Asia/Kolkata')
    .create();

  Logger.log('Installed daily trigger for sendDailyOwnerReport at 10:00 PM IST.');
}

/**
 * Checks if live email dispatch is explicitly enabled in Settings sheet
 */
function checkLiveEmailsActive() {
  try {
    var sheet = getRequiredSheet_(SHEET_NAMES.SETTINGS);
    if (!sheet) return DEFAULT_LIVE_EMAILS_ACTIVE;
    var data = sheet.getDataRange().getValues();
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][0]).trim() === 'ENABLE_LIVE_EMAILS') {
        var val = String(data[i][1]).trim().toLowerCase();
        return val === 'true' || val === 'yes' || val === '1';
      }
    }
  } catch (e) {}
  return DEFAULT_LIVE_EMAILS_ACTIVE;
}



/**
 * Update booking status
 */
function handleBookingStatusUpdate(d) {
  return { status: 'error', message: 'Admin booking status updates are disabled until a secure authenticated admin channel is implemented. No data was changed.' };
}

/**
 * Update rental status
 */
function handleRentalStatusUpdate(d) {
  return { status: 'error', message: 'Admin rental status/quotation updates are disabled until a secure authenticated admin channel is implemented. Rental enquiry records remain inquiry-only. No data was changed.' };
}

/**
 * Public lookup: exact Booking ID + registered mobile are both required.
 * Returns a minimal projection only; never returns email, full phone, requests or payment references.
 */
function handlePublicBookingLookup_(d) {
  var bookingId = String(d.bookingId || '').trim();
  var mobile = normalizeMobile_(d.mobile || d.phone || '');
  if (!/^[A-Za-z0-9_-]{5,80}$/.test(bookingId) || mobile.length !== 10) {
    return { status: 'error', message: 'Enter a valid Booking ID and the 10-digit registered mobile number.' };
  }
  if (!consumePublicAttempt_('lookup', bookingId + ':' + mobile, 5, 600)) {
    return { status: 'error', message: 'Too many lookup attempts. Please try again after 10 minutes.' };
  }
  var sheet = getRequiredSheet_(SHEET_NAMES.BOOKINGS);
  var rows = sheet.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    var rowId = String(rows[i][1] || '').trim().toLowerCase();
    var rowMobile = normalizeMobile_(rows[i][3]);
    if (rowId === bookingId.toLowerCase() && rowMobile === mobile) {
      return { status: 'success', booking: {
        bookingId: String(rows[i][1] || ''),
        customerName: maskCustomerName_(rows[i][2]),
        travelDate: safeCellText_(rows[i][5]),
        route: safeCellText_(rows[i][6]),
        pickupPoint: safeCellText_(rows[i][7]),
        packageName: safeCellText_(rows[i][9]),
        passengers: Number(rows[i][10] || 0),
        amount: Number(rows[i][14] || 0),
        paymentStatus: safeCellText_(rows[i][16]),
        bookingStatus: safeCellText_(rows[i][17])
      } };
    }
  }
  return { status: 'not_found', message: 'Booking details could not be verified. Check the Booking ID and registered mobile.' };
}

function normalizeMobile_(value) { return String(value || '').replace(/\D/g, '').slice(-10); }
function maskCustomerName_(value) {
  var name = String(value || '').trim();
  if (!name) return '';
  var parts = name.split(/\s+/);
  return parts.length > 1 ? parts[0] + ' ' + parts.slice(1).map(function(p) { return p.charAt(0) + '***'; }).join(' ') : name.charAt(0) + '***';
}
function safeCellText_(value) { return value instanceof Date ? Utilities.formatDate(value, 'Asia/Kolkata', 'yyyy-MM-dd') : String(value == null ? '' : value).slice(0, 200); }
function consumePublicAttempt_(purpose, rawKey, limit, ttlSeconds) {
  // Every public webhook action enters through doPost(), which acquires the global
  // ScriptLock before dispatch and holds it through this read/check/write. This makes
  // the CacheService counter update serialized across concurrent web requests.
  // Cache TTL bounds storage; the key contains only a one-way hash of the identifiers.
  var digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(rawKey));
  var key = 'PUB_' + purpose + '_' + Utilities.base64EncodeWebSafe(digest).replace(/=+$/g, '').slice(0, 40);
  var cache = CacheService.getScriptCache();
  var count = Number(cache.get(key) || 0);
  if (count >= limit) return false;
  cache.put(key, String(count + 1), ttlSeconds);
  return true;
}

/** Public cancellation request. Refund is only recorded for verified money received; no automatic refund is initiated. */
function handlePublicCancellationRequest_(d) {
  var bookingId = String(d.bookingId || '').trim();
  var mobile = normalizeMobile_(d.mobile || d.phone || '');
  var reason = safeSheetText_(d.reason || '', 500);
  if (!/^[A-Za-z0-9_-]{5,80}$/.test(bookingId) || mobile.length !== 10 || reason.length < 3) {
    return { status: 'error', message: 'Booking ID, registered 10-digit mobile and cancellation reason are required.' };
  }
  if (!consumePublicAttempt_('cancel', bookingId + ':' + mobile, 3, 3600)) return { status: 'error', message: 'Too many cancellation requests. Please contact the business directly.' };
  var bookingSheet = getRequiredSheet_(SHEET_NAMES.BOOKINGS);
  var bookings = bookingSheet.getDataRange().getValues();
  var bookingRow = null;
  var bookingMatches = 0;
  var mobileMatches = 0;
  for (var i = 1; i < bookings.length; i++) {
    if (String(bookings[i][1] || '').trim().toLowerCase() === bookingId.toLowerCase()) {
      bookingMatches++;
      if (normalizeMobile_(bookings[i][3]) === mobile) { bookingRow = bookings[i]; mobileMatches++; }
    }
  }
  if (bookingMatches === 0 || mobileMatches === 0) return { status: 'not_found', message: 'Booking details could not be verified.' };
  if (bookingMatches !== 1) return { status: 'reconciliation_required', message: 'Duplicate Booking ID detected. Cancellation request was not recorded; Admin reconciliation is required.' };
  if (String(bookingRow[17] || '').toLowerCase() === 'cancelled') return { status: 'duplicate', message: 'This booking is already cancelled.' };
  var cancelSheet = getRequiredSheet_(SHEET_NAMES.BOOKING_CANCELLATIONS);
  var cancelRows = cancelSheet.getDataRange().getValues();
  for (var c = 1; c < cancelRows.length; c++) {
    if (String(cancelRows[c][1] || '').trim().toLowerCase() === bookingId.toLowerCase() && ['Pending Review','Approved'].indexOf(String(cancelRows[c][6] || '')) !== -1) {
      return { status: 'duplicate', message: 'A cancellation request is already under review.' };
    }
  }
  var payments = getRequiredSheet_(SHEET_NAMES.BOOKING_PAYMENTS).getDataRange().getValues();
  var linkedPayments = [];
  for (var p = 1; p < payments.length; p++) if (String(payments[p][1] || '').trim().toLowerCase() === bookingId.toLowerCase()) linkedPayments.push(payments[p]);
  if (linkedPayments.length > 1) return { status: 'reconciliation_required', message: 'Multiple payment ledger rows exist for this booking. Cancellation request was not recorded; Admin reconciliation is required.' };
  var verifiedPaid = 0;
  if (linkedPayments.length === 1 && String(linkedPayments[0][6] || '').trim().toLowerCase() === 'verified') {
    var linkedAmount = Number(linkedPayments[0][3]);
    var linkedFare = Number(bookingRow[14]);
    var linkedMode = String(linkedPayments[0][4] || '').toLowerCase();
    var expectedLinkedAmount = linkedMode.indexOf('full') !== -1 ? linkedFare : Math.min(200, linkedFare);
    if (!String(linkedPayments[0][0] || '').trim() || !String(linkedPayments[0][5] || '').trim() || !linkedPayments[0][8] || !isFinite(linkedAmount) || linkedAmount <= 0 || !isFinite(linkedFare) || linkedFare <= 0 || linkedAmount > linkedFare + 0.009 || Math.abs(linkedAmount - expectedLinkedAmount) > 0.009) return { status: 'reconciliation_required', message: 'Verified payment evidence is incomplete or inconsistent with the booking fare/payment mode. Cancellation request was not recorded; Admin reconciliation is required.' };
    verifiedPaid = linkedAmount;
  }
  cancelSheet.appendRow(['CAN-' + Utilities.getUuid(), bookingRow[1], bookingRow[2], bookingRow[3], reason, verifiedPaid, 'Pending Review', new Date()]);
  upsertBookingNotification_(bookingId, BUSINESS_CONFIG.EMAIL, 'CANCELLATION_REQUEST_RECEIVED', 'A customer cancellation request is awaiting Admin review for booking ' + bookingId + '.', 'Pending Admin Review', '');
  logActivity('CANCELLATION_REQUEST_RECEIVED', bookingId, 'Customer cancellation request recorded; refund amount is verified paid amount only; manual review required.');
  return { status: 'success', message: 'Cancellation request received. The team will review it. No refund has been processed.', refundReviewAmount: verifiedPaid };
}

function createAdminCancellation_(adminEmail, d) {
  var bookingId = String(d.bookingId || '').trim();
  var reason = safeSheetText_(d.reason || '', 500);
  if (!bookingId || reason.length < 3) return { status: 'error', message: 'Booking ID and cancellation reason are required.' };
  var bookingSheet = getRequiredSheet_(SHEET_NAMES.BOOKINGS);
  var rows = bookingSheet.getDataRange().getValues();
  var booking = null;
  var bookingMatches = 0;
  for (var i = 1; i < rows.length; i++) if (String(rows[i][1] || '').trim().toLowerCase() === bookingId.toLowerCase()) { bookingMatches++; if (!booking) booking = rows[i]; }
  if (bookingMatches === 0) return { status: 'not_found', message: 'Booking not found.' };
  if (bookingMatches !== 1) return { status: 'reconciliation_required', message: 'Duplicate Booking ID detected. Cancellation record was not created; Admin reconciliation is required.' };
  var cancelSheet = getRequiredSheet_(SHEET_NAMES.BOOKING_CANCELLATIONS);
  var old = cancelSheet.getDataRange().getValues();
  for (var j = 1; j < old.length; j++) if (String(old[j][1] || '').trim().toLowerCase() === bookingId.toLowerCase() && String(old[j][6] || '') !== 'Rejected') return { status: 'duplicate', message: 'Cancellation record already exists for this booking.' };
  var payRows = getRequiredSheet_(SHEET_NAMES.BOOKING_PAYMENTS).getDataRange().getValues();
  var linkedPayments = [];
  for (var k = 1; k < payRows.length; k++) if (String(payRows[k][1] || '').trim().toLowerCase() === bookingId.toLowerCase()) linkedPayments.push(payRows[k]);
  if (linkedPayments.length > 1) return { status: 'reconciliation_required', message: 'Multiple payment ledger rows exist for this booking. Cancellation record was not created; Admin reconciliation is required.' };
  var verifiedPaid = 0;
  if (linkedPayments.length === 1 && String(linkedPayments[0][6] || '').trim().toLowerCase() === 'verified') {
    var linkedAmount = Number(linkedPayments[0][3]);
    var linkedFare = Number(booking[14]);
    var linkedMode = String(linkedPayments[0][4] || '').toLowerCase();
    var expectedLinkedAmount = linkedMode.indexOf('full') !== -1 ? linkedFare : Math.min(200, linkedFare);
    if (!String(linkedPayments[0][0] || '').trim() || !String(linkedPayments[0][5] || '').trim() || !linkedPayments[0][8] || !isFinite(linkedAmount) || linkedAmount <= 0 || !isFinite(linkedFare) || linkedFare <= 0 || linkedAmount > linkedFare + 0.009 || Math.abs(linkedAmount - expectedLinkedAmount) > 0.009) return { status: 'reconciliation_required', message: 'Verified payment evidence is incomplete or inconsistent with the booking fare/payment mode. Cancellation record was not created; Admin reconciliation is required.' };
    verifiedPaid = linkedAmount;
  }
  cancelSheet.appendRow(['CAN-' + Utilities.getUuid(), booking[1], booking[2], booking[3], reason, verifiedPaid, 'Pending Review', new Date()]);
  upsertBookingNotification_(bookingId, BUSINESS_CONFIG.EMAIL, 'CANCELLATION_REQUEST_RECEIVED', 'Admin recorded a cancellation review for booking ' + bookingId + '.', 'Pending Admin Review', '');
  logAdminActivity_(adminEmail, 'ADMIN_CANCELLATION_CREATED', bookingId + '; verified paid amount=' + verifiedPaid);
  return { status: 'success', refundReviewAmount: verifiedPaid, refundStatus: 'Pending Review', message: 'Cancellation review record created. No automatic refund was sent.' };
}

function updateAdminRefundStatus_(adminEmail, d) {
  var cancellationId = String(d.cancellationId || '').trim();
  var status = String(d.refundStatus || '').trim();
  var allowed = ['Pending Review', 'Approved', 'Refunded', 'Rejected'];
  if (!cancellationId || allowed.indexOf(status) === -1) return { status: 'error', message: 'Invalid cancellation ID or refund status.' };
  var sheet = getRequiredSheet_(SHEET_NAMES.BOOKING_CANCELLATIONS);
  var rows = sheet.getDataRange().getValues();
  var targetRow = -1;
  var cancellationMatches = 0;
  for (var i = 1; i < rows.length; i++) if (String(rows[i][0] || '').trim() === cancellationId) { cancellationMatches++; if (targetRow < 0) targetRow = i + 1; }
  if (cancellationMatches === 0) return { status: 'not_found', message: 'Cancellation record not found.' };
  if (cancellationMatches !== 1) return { status: 'reconciliation_required', message: 'Duplicate cancellation ID detected. No refund status was changed; Admin reconciliation is required.' };
  var cancellationRow = rows[targetRow - 1];
  var bookingId = String(cancellationRow[1] || '');
  var currentStatus = String(cancellationRow[6] || 'Pending Review').trim();
  var verifiedPaidCap = Number(cancellationRow[5] || 0);

  // Idempotent same-state requests are safe and do not rewrite the audit row.
  if (status === currentStatus) {
    return { status: 'success', cancellationId: cancellationId, refundStatus: currentStatus, message: 'Cancellation/refund status is already ' + currentStatus + '.' };
  }

  // Prevent reversing terminal outcomes or skipping the review/approval step.
  if (currentStatus === 'Refunded' || currentStatus === 'Rejected') {
    return { status: 'error', message: 'This cancellation record is in a terminal state and cannot be changed.' };
  }
  if (currentStatus === 'Pending Review' && ['Approved', 'Rejected'].indexOf(status) === -1) {
    return { status: 'error', message: 'Cancellation must be approved or rejected before any refund can be marked completed.' };
  }
  if (currentStatus === 'Approved' && ['Refunded', 'Rejected'].indexOf(status) === -1) {
    return { status: 'error', message: 'An approved cancellation can only be marked Refunded after manual refund, or Rejected.' };
  }
  if (status === 'Refunded') {
    if (d.manualRefundConfirmed !== true) return { status: 'error', message: 'Confirm the actual manual refund was completed outside this system before marking it Refunded.' };
    if (!isFinite(verifiedPaidCap) || verifiedPaidCap <= 0) return { status: 'error', message: 'No verified payment is recorded for this booking; a zero-value refund cannot be marked Refunded.' };
  }
  var bookingSheet = getRequiredSheet_(SHEET_NAMES.BOOKINGS);
  var bookingRows = bookingSheet.getDataRange().getValues();
  var bookingMatches = 0;
  var matchedBookingRow = -1;
  for (var b = 1; b < bookingRows.length; b++) if (String(bookingRows[b][1] || '').trim().toLowerCase() === bookingId.toLowerCase()) { bookingMatches++; if (matchedBookingRow < 0) matchedBookingRow = b + 1; }
  if (bookingMatches === 0) return { status: 'not_found', message: 'Linked booking record was not found. Refund status was not changed.' };
  if (bookingMatches !== 1) return { status: 'reconciliation_required', message: 'Duplicate Booking ID detected. Refund status was not changed; Admin reconciliation is required.' };
  sheet.getRange(targetRow, 7).setValue(status);
  if (status === 'Approved' || status === 'Refunded') bookingSheet.getRange(matchedBookingRow, 18).setValue('Cancelled');
  upsertBookingNotification_(bookingId, BUSINESS_CONFIG.EMAIL, 'CANCELLATION_REFUND_STATUS_UPDATED', 'Cancellation/refund review for booking ' + bookingId + ' changed to ' + status + '.', 'Recorded - Admin Follow-up', '');
  logAdminActivity_(adminEmail, 'ADMIN_REFUND_STATUS_UPDATED', cancellationId + ' => ' + status + '; manual refund only');
  return { status: 'success', cancellationId: cancellationId, refundStatus: status, message: status === 'Refunded' ? 'Refund marked completed based on owner confirmation; no gateway refund was initiated.' : 'Cancellation/refund status updated.' };
}

/**
 * EmailLog writer. Exact six-column schema; logging failure never changes the send result.
 */
function appendEmailLog_(bookingId, recipientType, recipient, status, error) {
  try {
    getRequiredSheet_(SHEET_NAMES.EMAIL_LOG).appendRow([new Date(), String(bookingId || ''), String(recipientType || ''), String(recipient || ''), String(status || ''), String(error || '')]);
  } catch (logError) { Logger.log('EmailLog write failed: ' + logError); }
}
function upsertBookingNotification_(bookingId, recipient, notificationType, message, status, sentAt) {
  try {
    var sheet = getRequiredSheet_(SHEET_NAMES.BOOKING_NOTIFICATIONS);
    var rows = sheet.getDataRange().getValues();
    var rowNum = -1;
    for (var i = 1; i < rows.length; i++) if (String(rows[i][1]) === String(bookingId) && String(rows[i][2]) === String(recipient) && String(rows[i][3]) === String(notificationType)) { rowNum = i + 1; break; }
    var record = ['NTF-' + Utilities.getUuid(), bookingId, recipient, notificationType, message, status, new Date(), sentAt || ''];
    if (rowNum > 0) {
      var oldId = rows[rowNum - 1][0]; record[0] = oldId;
      sheet.getRange(rowNum, 1, 1, 8).setValues([record]);
    } else sheet.appendRow(record);
  } catch (err) { Logger.log('Notification log failed: ' + err); }
}

/** Return a schema-checked existing tab. Runtime requests never create tabs. */
function getRequiredSheet_(sheetName) {
  var ss = getSpreadsheet_();
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) throw new Error('Required schema tab is missing: ' + sheetName + '. Run the approved setupDatabase() bootstrap.');
  var expected = DATABASE_SCHEMA[sheetName];
  if (!expected) throw new Error('Tab is not in the approved 17-tab schema: ' + sheetName);
  var actual = sheet.getLastColumn() ? sheet.getRange(1, 1, 1, sheet.getLastColumn()).getDisplayValues()[0].map(function(v) { return String(v).trim(); }) : [];
  if (actual.length !== expected.length || expected.some(function(h, i) { return actual[i] !== h; })) {
    throw new Error('Schema mismatch in ' + sheetName + '. Expected exact approved headers/order; no write was performed.');
  }
  return sheet;
}

function validateDatabaseSchema_() {
  var ss = getSpreadsheet_();
  var actualNames = ss.getSheets().map(function(sh) { return sh.getName(); }).sort();
  var expectedNames = Object.keys(DATABASE_SCHEMA).sort();
  var extras = actualNames.filter(function(n) { return expectedNames.indexOf(n) === -1; });
  var missing = expectedNames.filter(function(n) { return actualNames.indexOf(n) === -1; });
  var errors = [];
  if (extras.length) errors.push('Unapproved extra tabs: ' + extras.join(', '));
  if (missing.length) errors.push('Missing tabs: ' + missing.join(', '));
  expectedNames.forEach(function(name) {
    var sh = ss.getSheetByName(name);
    if (!sh) return;
    var expected = DATABASE_SCHEMA[name];
    var actual = sh.getLastColumn() ? sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0].map(function(v){return String(v).trim();}) : [];
    if (actual.length !== expected.length || expected.some(function(h,i){return actual[i] !== h;})) errors.push('Header mismatch: ' + name);
  });
  if (errors.length) throw new Error('Schema validation failed: ' + errors.join(' | '));
  return { ok: true, spreadsheetId: ss.getId(), tabCount: expectedNames.length, headerCount: expectedNames.reduce(function(n,k){return n + DATABASE_SCHEMA[k].length;},0) };
}

/** Activity logger uses the exact seven-column activity_log schema. */
function logActivity(action, ref, details) {
  try {
    var sheet = getRequiredSheet_(SHEET_NAMES.ACTIVITY_LOG);
    sheet.appendRow(['LOG-' + Utilities.getUuid(), '', String(action || ''), String(details || ''), 'system', String(ref || ''), new Date()]);
  } catch (e) { /* logging is best-effort; do not hide the primary operation result */ }
}

/**
 * Return JSON response
 */
function createJsonResponse(data, statusCode) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Standalone, idempotent Google Spreadsheet bootstrap.
 * Owner must NOT create a blank Google Sheet manually. Run only at final setup.
 * If SPREADSHEET_ID exists, reopen that spreadsheet; otherwise create one once,
 * persist its ID, then create/validate only the approved 17 tabs.
 */
function migrateLegacyPackageOptionsPricing_(sheet, props) {
  // Run once. Exact legacy Western/Central defaults move to the current fare;
  // custom prices remain untouched. All currently active offers are switched OFF,
  // while their discount values are retained for deliberate future activation.
  var migrationKey = 'PACKAGE_PRICE_POLICY_UPDATE_83';
  if (props && props.getProperty(migrationKey) === 'true') return 0;
  var legacy = {
    western: { non_ac_no_lunch: 200, ac_no_lunch: 300, non_ac_lunch: 400, ac_lunch: 500 },
    central: { non_ac_no_lunch: 200, ac_no_lunch: 300, non_ac_lunch: 400, ac_lunch: 500 }
  };
  var current = { non_ac_no_lunch: 250, ac_no_lunch: 350, non_ac_lunch: 450, ac_lunch: 550 };
  if (!sheet || sheet.getLastRow() <= 1) {
    if (props) props.setProperty(migrationKey, 'true');
    return 0;
  }
  var rows = sheet.getDataRange().getValues();
  var changed = 0;
  for (var i = 1; i < rows.length; i++) {
    var key = String(rows[i][0] || '').trim().toLowerCase();
    var route = normalizeRouteGroup_(rows[i][1]);
    var price = Number(rows[i][3]);
    var nextPrice = legacy[route] && Object.prototype.hasOwnProperty.call(legacy[route], key) && price === legacy[route][key] ? current[key] : price;
    var offerFlag = String(rows[i][4] || '').trim().toLowerCase();
    var offerEnabled = rows[i][4] === true || offerFlag === 'true' || offerFlag === 'yes' || offerFlag === '1';
    if (nextPrice !== price || offerEnabled) {
      // Keep Offer Discount INR intact; only the ON/OFF switch is reset.
      sheet.getRange(i + 1, 4, 1, 3).setValues([[nextPrice, false, rows[i][5] || 0]]);
      changed++;
    }
  }
  if (props) props.setProperty(migrationKey, 'true');
  return changed;
}

function setupDatabase() {
  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    var props = PropertiesService.getScriptProperties();
    var spreadsheetId = props.getProperty('SPREADSHEET_ID');
    var ss;
    if (spreadsheetId) {
      if (PROTECTED_SPREADSHEET_IDS.indexOf(spreadsheetId) !== -1) throw new Error('Configured SPREADSHEET_ID is production/retired and protected. Setup stopped without accessing it.');
      ss = SpreadsheetApp.openById(spreadsheetId);
    } else {
      ss = SpreadsheetApp.create('Mumbai Darshan Bus Online - Database');
      spreadsheetId = ss.getId();
      props.setProperty('SPREADSHEET_ID', spreadsheetId);
    }

    var names = Object.keys(DATABASE_SCHEMA);
    // Reuse the default first tab only when it is still an empty Sheet1.
    var first = ss.getSheets()[0];
    if (first && first.getName() === 'Sheet1' && first.getLastRow() === 0 && !ss.getSheetByName(names[0])) {
      first.setName(names[0]);
    }

    names.forEach(function(name) {
      var sh = ss.getSheetByName(name);
      var headers = DATABASE_SCHEMA[name];
      if (!sh) {
        sh = ss.insertSheet(name);
        sh.getRange(1,1,1,headers.length).setValues([headers]);
        sh.setFrozenRows(1);
        sh.getRange(1,1,1,headers.length).setBackground('#0b0d13').setFontColor('#f59e0b').setFontWeight('bold');
      } else if (sh.getLastRow() === 0 || sh.getLastColumn() === 0) {
        sh.clear();
        sh.getRange(1,1,1,headers.length).setValues([headers]);
        sh.setFrozenRows(1);
      }
    });

    // Seed approved route/package prices only when PackageOptions is empty. This is
    // within the existing approved tab/columns; route offers remain independently OFF.
    var packageSheet = ss.getSheetByName(SHEET_NAMES.PACKAGE_OPTIONS);
    if (packageSheet.getLastRow() <= 1) {
      var packageRows = [];
      var routePrices = { western: [250,350,450,550], central: [250,350,450,550], harbour: [250,350,450,550], kalyan_dombivli: [250,350,450,550] };
      var packageKeys = ['non_ac_no_lunch','ac_no_lunch','non_ac_lunch','ac_lunch'];
      var labels = ['Non-AC Bus Ticket','AC Bus Ticket','Non-AC Bus + Lunch','AC Bus + Lunch'];
      Object.keys(routePrices).forEach(function(route) { packageKeys.forEach(function(key, index) { packageRows.push([key, route, labels[index], routePrices[route][index], false, 0, 'Approved']); }); });
      packageSheet.getRange(2,1,packageRows.length,7).setValues(packageRows);
    }

    // Validate every tab/header before writing even default Settings rows.
    validateDatabaseSchema_();

    // Upgrade only exact old Western/Central defaults. Custom Admin rates remain intact.
    migrateLegacyPackageOptionsPricing_(packageSheet, props);

    // Seed only the approved Settings columns (key, value, description, updated_at).
    var settings = ss.getSheetByName(SHEET_NAMES.SETTINGS);
    if (settings.getLastRow() <= 1) {
      var now = new Date();
      settings.getRange(2,1,5,4).setValues([
        ['BUSINESS_EMAIL', BUSINESS_CONFIG.EMAIL, 'Owner notification email', now],
        ['BUSINESS_PHONE', BUSINESS_CONFIG.PHONE, 'Business contact number', now],
        ['ENABLE_LIVE_EMAILS', 'false', 'Emails remain disabled until owner authorization', now],
        ['ADVANCE_PER_BOOKING_INR', '200', 'Advance amount per booking, not per person', now],
        ['DAILY_REPORT_RECIPIENT', BUSINESS_CONFIG.EMAIL, 'Daily operations report recipient', now]
      ]);
    }
    var settingsValues = settings.getDataRange().getValues();
    var hasRentalPricing = settingsValues.slice(1).some(function(row) { return String(row[0] || '').trim() === 'PUBLIC_RENTAL_PRICING_JSON'; });
    if (!hasRentalPricing) settings.appendRow(['PUBLIC_RENTAL_PRICING_JSON', JSON.stringify(defaultRentalPricing_()), 'Public customer-facing Local Darshan and Outstation rate catalogue', new Date()]);

    var result = validateDatabaseSchema_();
    Logger.log(JSON.stringify(result));
    return result;
  } finally {
    lock.releaseLock();
  }
}
