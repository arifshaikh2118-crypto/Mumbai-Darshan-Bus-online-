# Update 78 — Customer Enquiry Handoff Correction

**Project:** Mumbai Darshan Bus Online  
**Date:** 21 November 2026  
**Baseline:** Update 77 — Local Deep Audit Cross-Check  
**Scope:** Local source correction and offline validation only. Payment, Google Sheets setup, Apps Script deployment, GitHub, Preview, live email and production deployment remain deferred.

## 1. Work completed

### A. Group Booking no longer reports a false server submission
- Removed the call to `StorageService.createGroupEnquiry()` from the customer form.
- Removed the misleading “Group Booking Request Submitted” success state and invented group reference number / 30-minute callback promise.
- The form now validates contact name, 10-digit mobile, real local-calendar travel date, and integer passenger count (10–500).
- It prepares a WhatsApp message containing the entered group requirements and displays a clear handoff link.
- The customer is explicitly told that the enquiry has not been submitted or saved to the server until they continue to WhatsApp and press Send.
- If no WhatsApp number is configured, the form fails closed with an actionable message.
- The default date and minimum date now use the shared local-date helper rather than UTC `toISOString()`.

### B. Contact Us no longer reports a false dispatched message
- Removed the local-only “Message Dispatched!” success claim.
- Contact form now validates name, 10-digit mobile and message.
- It prepares a WhatsApp message containing name, phone, optional email, subject and message.
- The page clearly says the message has not been sent or saved to the server until the customer continues to WhatsApp and presses Send.
- WhatsApp number is normalized to digits before creating links; missing configuration fails closed.
- Removed the unsupported “quick reply within 5 minutes” promise and corrected the form instructions/CTA.

### C. Regression test added
- Added `validation/test_customer_enquiry_whatsapp_handoff.cjs`.
- It checks both enquiry forms for WhatsApp handoff, truthful pre-send copy, required validation, date validation and removal of false local-submission behavior.
- New regression test: **14 assertions PASS**.

## 2. Validation performed

| Check | Result |
|---|---:|
| Main offline validation runner | **44/44 PASS** |
| New Group Booking + Contact handoff contract | **14 assertions PASS** |
| TypeScript/TSX syntax transpilation | **32 files, 0 syntax errors** |
| JavaScript `.js` / `.cjs` / `.mjs` syntax | **50 files PASS** |
| JSON configuration parse | **6/6 PASS** |
| Apps Script syntax | **PASS** |
| English-copy guard | **35 files PASS** |
| Rebuilt ZIP integrity | **PASS** |

## 3. What remains and why

1. **Actual group enquiry persistence remains unimplemented.** The approved 17-tab / 139-header schema has no dedicated group-enquiry tab or matching Express API. This correction uses an explicit WhatsApp handoff rather than inventing a new schema or claiming server storage.
2. **Contact and group WhatsApp delivery still depends on the customer pressing Send.** Opening WhatsApp or preparing a message is not proof of delivery.
3. **Public configuration still uses browser storage / initial defaults.** A safe Sheets-backed public configuration model is deferred to the later Google Sheets phase because the approved schema lacks pickup and package fields consumed by the website.
4. **Express backend hosting is still unresolved.** Firebase Hosting currently serves static files and has no verified `/api/**` route to an Express host.
5. **Build and browser tests remain pending.** `node_modules` and `package-lock.json` are absent; `bun.lock` is empty. A real dependency install, semantic type-check, Vite production build, browser E2E and mobile-device checks need a network-enabled runner.
6. **Live Sheets / Apps Script staging remains unverified.** No spreadsheet creation, deployment, secret configuration or live data test was performed.

## 4. Explicitly not performed
- PhonePe / payment integration.
- Google Sheets creation/setup or public configuration migration.
- Apps Script deployment, live email or triggers.
- GitHub commit/push/Actions, Preview refresh, Firebase/Cloud Run deployment, DNS changes or production deployment.
- No approved sheet/tab/header, pricing, booking advance, rental rates or business rules were changed.

**Overall status: INCOMPLETE / NOT production-ready. Do not deploy.**
