# Mumbai Darshan Bus Online — Update 45
## Rental Billing Rules & Local-First Workflow
**Date:** 20 November 2026  
**Baseline:** Update 44 — Public Configuration Readiness & Schema Gap Audit  
**Status:** Local source changes and documentation updated. Google Sheets, Apps Script deployment, payment and live deployment remain deferred by owner instruction.

### Owner's updated sequencing instruction
- Continue remaining local project source work first.
- Do not require the owner to manually create a Google Sheet.
- At the later Google Sheets phase, provide one complete Apps Script setup code that automatically creates the spreadsheet and approved tabs.
- Defer Google Sheets setup, Apps Script deployment, payment integration, live email and all production deployment until later.
- GitHub remains deferred until local source files and local work are complete.

The missing original workbook is therefore not a blocker for the current local-only phase. The existing approved schema snapshot remains the project reference; do not silently change its tabs or columns.

### Local source issue found and corrected
The rental panel had conflicting outstation wording stating that driver and parking were included. This contradicted the approved business rule that outstation driver allowance / DA-permit is extra and parking, toll, border tax and entry charges are extra at actuals.

Changes in `src/components/CarRentalPanel.tsx`:
1. Corrected the outstation policy banner to state driver allowance / DA-permit is extra as shown in the estimate.
2. Corrected the outstation minimum-billing note and quotation breakdown note to state parking, toll, border tax and entry charges are extra at actuals.
3. Preserved the Mumbai local rule: vehicle, driver and parking are included in the local package price.
4. Added an optional local tour-guide checkbox. If selected, the estimate adds a flat **₹2,000 per booking/vehicle**, never per passenger.
5. Stores the guide request in the existing `specialRequirements` field and includes the request in the WhatsApp follow-up message.
6. Disabled changing the guide option after an enquiry is held for retry, to avoid the selected request changing while the same pending enquiry reference is retried.
7. Did not add or change any Google Sheets columns, database schema, supplier cost, or private rate.

### Business rules regression coverage
Added `validation/test_business_rules_alignment.cjs` to check:
- Four approved route/package price bands.
- ₹200 advance per booking in initial settings.
- ₹50 per-person guide charge and ₹10 per-person Sea Link toll for shared bus tour.
- Breakfast remains fixed/operator-selected for applicable lunch packages; customer selects only the three approved lunch options.
- Local private guide is optional and ₹2,000 flat per booking/vehicle.
- Local driver/parking inclusion and outstation extra-charge wording.
- Rental enquiry panel remains below the homepage booking form.

### Documentation updates
- `README.md`: clarifies that spreadsheet creation, Apps Script deployment and payment are deferred; one setup code will create the spreadsheet and tabs automatically.
- `GOOGLE_APPS_SCRIPT_SETUP.md`: clarifies local-first sequencing and no manual spreadsheet creation.
- `google-apps-script/DEPLOYMENT_GUIDE.md`: clarifies that deployment/staging is deferred and the owner will not create tabs/headings manually.
- `schema/SCHEMA_WORKBOOK_README.md`: clarifies the original workbook is not required to continue local source work.

### Validation
- Offline regression runner: **16/16 PASS**.
- TypeScript/TSX syntax transpilation: **29/29 PASS**, zero syntax diagnostics (syntax-only; not a semantic type-check).
- Key JSON manifests: **4/4 PASS**.
- Apps Script `Code.gs` syntax remains covered by the offline runner.
- ZIP integrity will be checked after packaging.

### Deferred — not done in Update 45
- No Google Sheet created or modified.
- No Apps Script deployment or live execution.
- No payment gateway / PhonePe integration.
- No live email, triggers, GitHub commit/push/Actions, Preview refresh or production deployment.
- Public customer configuration still uses the current localStorage/default path; the secure Sheets-backed public configuration endpoint and hydration belong to the later integration phase.
- Full `npm run lint`, Vite production build and browser E2E remain unverified because dependencies are absent and npm registry DNS previously failed (`EAI_AGAIN`).

### Project status
**Not production-ready.** Update 45 is a local source and documentation increment only. Continue the remaining local code audit and tests before GitHub.
