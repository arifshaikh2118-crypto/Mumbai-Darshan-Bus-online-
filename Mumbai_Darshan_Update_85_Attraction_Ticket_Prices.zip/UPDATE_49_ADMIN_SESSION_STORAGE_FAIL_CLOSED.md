# Mumbai Darshan Bus Online — Update 49
## Admin Login: Session Storage Failure Must Fail Closed
**Date:** 20 November 2026  
**Baseline:** Update 48 — Cancellation Reason Formula-Injection Hardening  
**Scope:** Local Admin login resilience and regression coverage only.

### Audit finding
The Admin login handler attempted to save the signed session token in `sessionStorage`, but silently swallowed storage errors and still set `isAdminAuthenticated` to `true`. In browsers where session storage is blocked or unavailable, the UI could appear logged in even though protected API requests had no persisted token and would fail.

### Fix applied
- Admin login now treats session-storage write failure as an authentication failure.
- Any partially stored Admin session keys are cleared on a best-effort basis.
- A clear error is shown asking the user to enable browser site storage and retry.
- The Admin UI authenticated state is set only after both session values are stored successfully.
- No authentication design, token lifetime, server endpoints, UI layout, business rule, Google Sheet schema or integration was changed.

### Regression coverage
- Added `validation/test_admin_session_storage_fail_closed.cjs`.
- Test asserts the token is stored, partial credentials are cleared on failure, an error is shown, and authenticated UI state is not set on the failure path.

### Validation results
- Offline validation runner: **19/19 PASS** (including Apps Script syntax and regression checks).
- TypeScript/JavaScript/TSX/JSX syntax transpilation: **29/29 PASS**, zero syntax diagnostics. Syntax-only; not a semantic type-check.
- ZIP archive integrity: **PASS**.
- Full `npm run lint`, Vite production build and browser E2E: **pending**. Project dependencies are not installed; earlier npm registry access failed with DNS `EAI_AGAIN`.

### Not performed
No Google Sheet was created or modified. No Apps Script was executed or deployed. No payment/PhonePe integration, live email, GitHub commit/push/Actions, Preview refresh or production deployment was performed. These remain deferred under the owner's instructions.

### Status
Update 49 closes a fail-open UI-state edge case in Admin login when browser session storage cannot persist the token. This is a local source fix only and does not make the project production-ready.
