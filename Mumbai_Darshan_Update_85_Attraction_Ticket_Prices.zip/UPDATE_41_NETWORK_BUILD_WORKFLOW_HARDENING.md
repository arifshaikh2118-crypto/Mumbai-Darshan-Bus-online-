# Update 41 — Network Build Workflow Hardening

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 40 — Runtime Webhook Validation & Dependency Network Diagnosis  
**Release status:** INCOMPLETE — CI workflow strengthened and statically validated; it has not been executed on GitHub.

## 1. What was completed

| # | Work item | Result |
|---|---|---|
| 1 | Audited the existing manual GitHub Actions build workflow | Found a cache configuration that assumed a lockfile exists, while this repository currently has no package-lock |
| 2 | Removed npm cache setup from the workflow | Completed; avoids setup-node cache initialization failing before lockfile generation |
| 3 | Added offline regression tests as the first CI step | Completed |
| 4 | Added npm install step to generate the real package-lock on the network-enabled runner | Completed in workflow definition; not executed |
| 5 | Added non-empty lockfile and lockfile-version verification | Completed in workflow definition; not executed |
| 6 | Added clean `npm ci` reproducibility check | Completed in workflow definition; not executed |
| 7 | Kept full TypeScript check and Vite production build steps | Completed in workflow definition; not executed |
| 8 | Added separate artifact upload for generated package-lock | Completed in workflow definition; not executed |
| 9 | Added static CJS test for workflow safety and required steps | Completed |
| 10 | Updated `npm run test:offline` to run the new Update 41 checks | Completed |
| 11 | Updated README and network-runner instructions | Completed |
| 12 | Re-ran offline regression tests | PASS, 11/11 |
| 13 | Parsed workflow YAML and project JSON manifest | YAML parser PASS; project JSON files PASS |
| 14 | Updated Master Progress Tracker and built Update 41 ZIP | Completed; ZIP integrity verified |

## 2. Dependency/network diagnosis

A local npm install/lockfile generation attempt failed with:

```text
npm error code EAI_AGAIN
npm error syscall getaddrinfo
npm error request to https://registry.npmjs.org/@google%2fgenai failed
```

The npm cache contains no usable dependency package entries. `node_modules/` is absent. `package-lock.json` is absent. `bun.lock` remains 0 bytes and is not a valid dependency lockfile.

The project has 10 runtime dependencies and 9 development dependencies. No dependency lockfile was fabricated.

## 3. Local lint/build attempts

| Command | Result | Reason |
|---|---|---|
| `npm run test:offline` | PASS, 11/11 | All bundled Apps Script tests, runtime webhook tests, workflow safety test and Code.gs syntax passed |
| `npm run lint` | BLOCKED | TypeScript reports missing `vite/client` type definitions because project dependencies are not installed |
| `npm run build` | BLOCKED | Vite executable cannot be invoked in this runtime (`vite: Permission denied`); `node_modules/` is absent |
| npm lockfile generation | BLOCKED | npm registry DNS resolution failed with `EAI_AGAIN` |
| Workflow YAML parse | PASS | YAML syntax parsed successfully |
| JSON manifests | PASS | `package.json`, `firebase.json`, `google-apps-script/appsscript.json`, and schema manifest parsed successfully |

The local build failure is not evidence of a source-code compilation error. A real dependency install is required before TypeScript/build validation can be assessed.

## 4. Updated network-enabled workflow

The manual-only workflow now runs in this order:

1. Checkout source.
2. Set up Node.js 22.
3. Run `npm run test:offline`.
4. Run `npm install --legacy-peer-deps --no-audit --no-fund` to resolve dependencies and generate `package-lock.json`.
5. Verify the lockfile is non-empty and lockfileVersion is supported.
6. Run `npm ci --legacy-peer-deps --no-audit --no-fund` to validate reproducible installation.
7. Run `npm run lint`.
8. Run `npm run build`.
9. Upload `dist/` for inspection.
10. Upload generated `package-lock.json` for review.

The workflow remains `workflow_dispatch` only. It does not deploy Firebase, publish Preview, touch Google Sheets, deploy Apps Script, send emails, change DNS, activate PhonePe or access production data.

**Important:** This workflow has not been committed to GitHub or executed. No actual GitHub Actions result, dependency install, lockfile, lint pass or production build pass is claimed.

## 5. Remaining work

### P0 — Run the network-enabled workflow
- [ ] Owner/developer must commit and push the project source to the intended GitHub repository.
- [ ] Manually run **Mumbai Darshan Network Build Validation** from GitHub Actions.
- [ ] Inspect install, lockfile verification, `npm ci`, lint and build results.
- [ ] Download and review the generated lockfile and build artifact.
- [ ] If the run fails, preserve the exact first error and fix it in a later update.

### P0 — Browser and hosting verification
- [ ] Define and run browser E2E using an isolated staging API and spreadsheet.
- [ ] Confirm actual Express hosting target and Cloud Run service ID/region if Firebase Hosting + Cloud Run is selected.
- [ ] Verify `/api/**` reaches Express before SPA fallback.
- [ ] Verify booking, rental enquiry, lookup, cancellation, Admin sessions, status updates, email retry, refunds, reports and seven operational CRUD tabs.
- [ ] Verify mobile booking and rental enquiry layout.

### P1 — Owner-approved isolated staging
- [ ] Create/initialize only an isolated staging spreadsheet after approval.
- [ ] Verify exact 17 tabs / 139 headers.
- [ ] Configure private secrets and Script Properties.
- [ ] Test booking, duplicate retries, rental enquiry-only, cancellation, Admin actions, notifications, EmailLog, reports, concurrency and throttling.
- [ ] Controlled email test only with explicit approval.

### P2 — Separately approved release work
- [ ] GitHub commit and Preview refresh.
- [ ] PhonePe after merchant credentials and server-side verification.
- [ ] Production Apps Script, email activation, DNS and website deployment only with explicit approval.

## 6. Safety and release status

No external service was contacted. No GitHub commit or workflow run occurred. No Google Sheet was created/modified. No Apps Script deployment, email, PhonePe activation, DNS change, Preview refresh or production deployment occurred.

**Conclusion:** Update 41 removes a likely workflow startup issue caused by npm cache configuration without a lockfile, and adds a proper sequence for lockfile generation, reproducible clean install, lint and build on a network-enabled runner. The source-level offline suite passes 11/11. The project remains INCOMPLETE and is not production-ready until the GitHub workflow actually passes and browser/staging gates are completed.
