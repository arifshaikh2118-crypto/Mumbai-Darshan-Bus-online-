# Update 80 — Public Configuration Synchronization

**Date:** 21 November 2026  
**Baseline:** `Mumbai_Darshan_Update_79_Booking_Rental_Audit_Fixed.zip`  
**Scope:** Local source implementation and offline validation only. No live Google Sheet, Apps Script deployment, hosting, or production service was contacted or changed.

## 1. What changed

### Server-owned read-only public endpoint
- Added `GET /api/public-config` to Express.
- Express calls the configured Apps Script URL server-to-server using the explicit `PUBLIC_GET_CONFIG` action; the browser never receives the Apps Script URL or any API secret.
- Added bounded per-IP rate limiting and a 30-second in-memory response cache.
- The endpoint fails closed if the server URL is missing/invalid, the upstream response is not successful, or the required configuration is incomplete.

### Apps Script public data allowlist
- Added `PUBLIC_GET_CONFIG` to the webhook action router.
- The response reads only approved `PackageOptions` and `PickupPoints` tabs.
- It exposes only the 16 route/package price rows, per-package/per-route offer flag and discount, plus pickup route/name/order/active flags.
- It does not expose Settings, AdminUsers, bookings, rental enquiries, payment ledger, cancellations, or other private tabs.
- Requires all 16 package/route combinations, unique keys, positive integer prices, valid discounts, and blank/Approved price review status.
- Normalizes route names such as “Western Line” to approved route IDs.

### Customer website hydration
- `StorageService.refreshPublicConfiguration()` validates the complete 16-row price matrix before writing any values.
- It refreshes the customer package prices and package-specific offers from `PackageOptions`.
- It refreshes the active/inactive flag for matching existing pickup points using route + pickup name + sort order. Existing pickup times, landmarks, reporting times, and map URLs remain from the existing local content because those fields are not present in the approved sheet schema.
- The App waits for the initial refresh attempt before mounting price-dependent pages, preventing the first render from briefly showing stale local prices while the refresh is still pending.
- If refresh fails, the website retains the existing local defaults and displays a visible warning that live Sheet prices could not be verified.
- Booking Form and Pricing page now apply the Sheet's package-specific offer discount rather than relying on the old route-wide browser offer for rows supplied by the public configuration.

## 2. Important scope boundary — not fully migrated

This update implements a safe synchronization path for the fields that exist in the approved schema. It does **not** complete every public configuration migration:

- Pickup point additions, renamed pickup names, times, landmarks, reporting times and Google Maps URLs cannot be hydrated from the current four-column `PickupPoints` schema. Only active flags for matching existing points are synchronized.
- Route descriptions/activation are still local defaults; there is no approved Routes tab.
- Local rental packages and outstation customer rates remain browser-storage/default-backed. The approved operational tabs do not yet provide a public, complete rental-rate payload with the required customer display structure.
- General business settings / WhatsApp number are not returned from the private Settings tab.
- The public endpoint is only source-implemented. It has not been tested against a live deployed Apps Script or live workbook.
- The server still needs an approved backend host and `/api/**` routing. Firebase static hosting configuration has not been changed.

Do not describe the entire public configuration as live-synchronized until these missing data fields have an approved source and live verification has passed.

## 3. Validation

- Offline runner: **47/47 PASS** (includes new public configuration static and runtime checks).
- Public config endpoint/hydration contract: **23 assertions PASS**.
- Apps Script public config runtime: **9 assertions PASS** (16 price rows, safe allowlisted response fields, active pickup mapping, duplicate combination rejection).
- TypeScript/TSX syntax transpilation: **35/35 files, 0 syntax errors**.
- JavaScript syntax checks: **PASS**.
- JSON parsing: **6/6 files PASS**.
- Apps Script `Code.gs` syntax: **PASS**.
- English-copy guard: **35 files PASS**.
- Full semantic `tsc --noEmit`: **BLOCKED** because `vite/client` type definitions are unavailable; `node_modules` is absent.
- Vite production build: **NOT RUN** because dependencies are not installed.
- Browser E2E / mobile device: **NOT RUN**.
- Live Apps Script / Sheets test: **NOT RUN**; owner-deferred.

## 4. No changes to owner-approved boundaries

- No sheet tabs, columns, or schemas were added, deleted, renamed, or reordered.
- No prices were changed. The approved initial matrix remains Western/Central ₹200/₹300/₹400/₹500 and Harbour/Kalyan–Dombivli ₹250/₹350/₹450/₹550.
- ₹200 advance per booking, guide ₹50/person, Sea Link toll ₹10/person, lunch rules and rental billing rules remain unchanged.
- No PhonePe, payment collection, email activation, Google Sheet creation, Apps Script deployment, GitHub, Preview refresh, backend/hosting deployment, DNS, or production deployment was performed.

## 5. Next work

1. Design and implement an approved public rental-rate configuration payload without exposing supplier cost/margin data.
2. Decide whether the pickup-point schema may be expanded later; do not change it without owner approval. Until then, only existing pickup activation flags can synchronize.
3. Resolve backend hosting and `/api/**` routing after owner approval, then test the public config endpoint against a staging workbook.
4. Install dependencies from a reviewed lockfile on a network-enabled runner; run full TypeScript check and Vite build.
5. Run browser E2E and mobile real-device tests.

**Overall status: PARTIAL LOCAL IMPLEMENTATION COMPLETE. Project remains INCOMPLETE / NOT production-ready. Do not deploy.**
