# Update 71 — Admin Cancellation Response Handling and English UI Copy

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 70 — Admin Financial Report Label Accuracy  
**Focus:** Ensure cancellation/refund UI correctly handles nested Apps Script business errors and uses English copy.

## Audit finding

The protected Express route for refund-status updates returns the Apps Script response inside `data.result`. The cancellation panel previously checked only the outer HTTP response and `data.success`. The Express route can return an HTTP-success response while the Apps Script business result reports `error`, `not_found`, or `duplicate`. In that case, the UI could display the inner error message as if the status update had succeeded and refresh the panel.

The cancellation panel also contained one remaining Hindi validation message, inconsistent with the requested English-only project copy.

## Changes made

1. Updated `AdminCancellationsPanel.tsx` to inspect `data.result.status` in addition to the outer HTTP response and `data.success`.
2. Treat nested Apps Script statuses `error`, `not_found`, and `duplicate` as failed operations and surface the actual Apps Script message.
3. Replaced the remaining Hindi manual-refund validation message with clear English copy.
4. Added `validation/test_admin_cancellation_ui_response_contract.cjs` with 6 assertions for nested error handling, server route alignment, English validation copy, and absence of Devanagari text in the cancellation panel.
5. Added the cancellation/refund, cancellation UI, financial reporting, and payment reconciliation contract tests to `validation/run-offline-checks.cjs`, so these regression checks run with the main offline validation command.

## Verification

- Main offline runner: **10 test suites PASS** (6 Apps Script suites and 4 Admin regression suites).
- Cancellation/refund state-machine checks: **15 assertions PASS**.
- Cancellation UI response and English-copy checks: **6 assertions PASS**.
- Financial-reporting contract checks: **7 assertions PASS**.
- Payment-reconciliation contract checks: **22 assertions PASS**.
- Apps Script `Code.gs` syntax: **PASS**.
- TypeScript/TSX syntax transpilation: **31 files, 0 syntax errors**.
- ZIP integrity: **PASS**.
- JSON configuration validation: **not run separately in this update**.
- Full npm lint, semantic type-check, production build, and browser E2E: **not run**; project dependencies are not installed.
- Live Google Sheets / Apps Script tests: **not run**.

## Scope boundaries

- No booking status state machine, refund policy, verified payment calculation, or cancellation sheet data was changed.
- No sheet/tab/header/schema changes.
- No payment gateway activation or automatic refund capability was added.
- No rental workflow, pricing, or public booking flow was changed.
- No live Google Sheets access, Apps Script execution/deployment, GitHub commit/push, Preview refresh, live email, external mutation, or Firebase/production deployment was performed.
- Newly changed cancellation UI copy and all Update 71 documentation are in English. Other existing project content was not mass-translated in this focused update.

**Overall status: INCOMPLETE / NOT production-ready.** The nested business-error handling is hardened and offline regression-tested. Full build, browser E2E, and live integration verification remain outstanding.
