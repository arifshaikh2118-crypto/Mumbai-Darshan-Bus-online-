# Update 64 — Booking retry persistence fail-closed hardening

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 63 — Booking Retry Recovery After Refresh  
**Scope:** Local frontend/storage source and regression test only.

## Deep check and confirmed issue

Update 63 added a browser-local pending Booking ID pointer and a recovery screen after refresh. A further storage edge case remained: the generic `setItem()` helper catches browser storage errors instead of throwing. `createBooking()` could therefore return a booking object even if the browser failed to persist the full booking record. The retry pointer helper also reported success after writing the pointer without reading it back or first verifying that the full local booking record existed.

That could leave a pointer that cannot recover the actual booking after refresh.

## Changes made

1. **Verify the full booking record**
   - `createBooking()` now reads the newly created booking back from the existing local booking store after saving it.
   - If the complete record cannot be read back, it throws an actionable error and does not proceed to network sync.
   - This prevents a false assumption that browser-local booking persistence succeeded.

2. **Verify retry pointer**
   - `savePendingBookingRetryId()` now requires a non-empty ID.
   - It verifies the corresponding unsynced booking record exists before writing the pointer.
   - It reads the pointer back and compares the exact ID (case-insensitive).
   - A missing record or failed pointer write returns `false`.

3. **Fail closed before sending the booking**
   - The booking form now stops before calling the Sheets sync endpoint if the retry pointer could not be safely persisted.
   - The customer sees a clear message that no request was sent and no payment was taken.
   - When a pointer is successfully stored, a failed network sync retains the same Booking ID for retry after refresh.
   - The existing recovery view continues to show the original booking summary and retries the same ID, not a newly generated booking.

4. **Regression coverage**
   - Expanded `validation/test_booking_retry_recovery.cjs` to 13 source-contract assertions.
   - Covers full booking read-back, ID pointer read-back, stale/synced pointer handling, same-ID retry, no new booking creation, and fail-closed behavior before network submission.

## Verification

- Offline validation runner: **30/30 PASS**.
- TypeScript/TSX syntax transpilation: **35/35 PASS**, zero syntax diagnostics (syntax-only; not a semantic type-check).
- Apps Script `Code.gs` syntax: **PASS** (unchanged source).
- JSON manifests/configuration: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full `npm run lint`, semantic type-check and `npm run build`: **not run**, because project dependencies are not installed in this local project folder.
- Browser refresh/retry E2E: **pending**.
- Live Google Sheets / Apps Script integration: **not tested**; setup and deployment remain deferred.

## Limitations and scope boundaries

- Retry recovery remains browser-local. Clearing browser site data, using another device/browser, or disabling browser storage can prevent automatic recovery.
- If local storage cannot persist the full booking and pointer, the booking flow now fails closed before sending the request.
- Cross-device recovery requires the later approved server-backed Sheets lookup flow.
- No Google Sheet creation, Apps Script execution/deployment, payment gateway/PhonePe, GitHub commit/push, Preview refresh, live email, or production deployment.
- No change to approved 17-tab / 139-header schema, fare, ₹200 advance rule, route/package pricing, attraction selection-on-bus rule, rental policy, or Admin access policy.

**Overall status: INCOMPLETE / NOT production-ready.** Local persistence failure handling is hardened and source-tested; browser E2E, full build and live integration remain outstanding.
