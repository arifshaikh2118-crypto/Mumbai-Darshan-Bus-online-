# Mumbai Darshan Bus Online — Master Progress Tracker
## Update 85 — Attraction Ticket Prices & On-Bus Guide Collection

**Date:** 21 November 2026  
**Baseline:** Update 84 — Public Content Accuracy & Attraction Collection Corrections

## Completed in Update 85
- [x] Owner-confirmed Bollywood Museum ticket rate restored/retained at **₹165 per person**. This supersedes the temporary removal decision in Update 84.
- [x] Homepage now shows the six legacy Attraction Tickets & Charges entries in order: Gateway of India Boat Ride ₹210, Prince of Wales Museum ₹200, Orama 11D ₹220, Bollywood Museum ₹165, Sea Link Toll ₹10 and Guide Charge ₹50 per person.
- [x] Dedicated Attraction Tickets & Charges page shows all active priced optional attraction entries plus compulsory Guide / Sea Link charges.
- [x] Homepage, dedicated charges page, route-pricing page and FAQ read the current owner-controlled values from the existing Extra Charges store.
- [x] Admin Change Rate control remains the single manual rate-change path. No automatic tariff changes or inferred prices.
- [x] Optional attraction ticket charges are collected by the Tour Guide inside the bus only if the customer chooses to visit.
- [x] Guide Charge and Sea Link Toll remain compulsory and collected by the Tour Guide inside the bus.
- [x] All six charges remain excluded from online bus package fare and ₹200 advance.
- [x] Removed stale hardcoded price repeats from customer-facing pages; landmark cards point to the central current-rate list.
- [x] Removed FAQ guidance that customers can select attraction tickets in a non-existent Step 5 or pay at venue counters.
- [x] Added 29 regression assertions for ticket rates, dynamic public display, Admin rate updates, collection rules and online fare exclusion.
- [x] Preserved approved 17-tab / 139-header schema, route package prices, offer controls, pickup timings, rental rules and payment deferral.

## Owner-confirmed current rates
| Item | Rate/person | Rule |
|---|---:|---|
| Gateway of India Boat Ride | ₹210 | Optional; guide collects on bus if chosen |
| Prince of Wales Museum | ₹200 | Optional; guide collects on bus if chosen |
| Orama 11D Magic Show | ₹220 | Optional; guide collects on bus if chosen |
| Bollywood Museum | **₹165** | Optional; guide collects on bus if chosen |
| Bandra–Worli Sea Link Toll | ₹10 | Compulsory; guide collects on bus |
| Guide Charge | ₹50 | Compulsory; guide collects on bus |

## Validation
| Check | Result |
|---|---:|
| Offline validation | **51/51 PASS** |
| Update 85 attraction-ticket regression | **29 assertions PASS** |
| Public content / Bollywood ₹165 regression | **11 assertions PASS** |
| TypeScript / TSX / JS syntax transpilation | **33 files / 0 errors** |
| Apps Script syntax | **PASS** |
| English-copy guard | **36 files PASS** |
| JSON parse | **6/6 PASS** |
| Semantic TypeScript check | Blocked — `vite/client` missing (`TS2688`) |
| Vite production build | Blocked — Vite not installed |
| Browser / mobile E2E | Not run |
| Live website / Sheets / Apps Script | Not touched |

## Remaining work
- [ ] Confirm current public cache and rendered homepage after a later owner-approved deployment.
- [ ] Browser E2E and real-device mobile checks.
- [ ] Install dependencies in a network-enabled environment and complete semantic TypeScript check and Vite build.
- [ ] Complete remaining local source work before GitHub/network build phase.
- [ ] Later, only with approval: Sheets setup/migration, Apps Script deployment, payment integration, Preview refresh, hosting/DNS and production deployment.

## Owner constraints preserved
- No live deployment or external mutation without explicit approval.
- No Google Sheet manual creation; later setup code must create the approved workbook automatically.
- No schema/tab/header changes without approval.
- Keep Supabase until migration is fully tested and removal is explicitly approved.
- PhonePe/payment gateway remains deferred.
- Rental enquiries remain inquiry-only; no rental owner/customer email notifications.
- Each update includes a ZIP, Project Index, detailed report, changed-file list and validation results.

**Overall status: Local Update 85 complete; project remains INCOMPLETE / NOT production-ready. Do not deploy.**
