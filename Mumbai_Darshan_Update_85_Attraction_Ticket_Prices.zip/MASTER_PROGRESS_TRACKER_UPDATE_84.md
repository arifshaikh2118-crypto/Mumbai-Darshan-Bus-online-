**Superseded by Update 85:** The owner reconfirmed Bollywood Museum ticket price ₹165/person. Update 85 restores it and makes all six ticket/charge rates visible from the Admin-controlled price source. Do not treat Update 84's tariff-removal item as current.

# Mumbai Darshan Bus Online — Master Progress Tracker
## Update 84 — Public Content Accuracy & Attraction Collection Corrections

**Date:** 21 November 2026  
**Baseline:** Update 83 — Uniform Bus Fare, Pickup-Time and Booking-Copy Corrections

## Completed in Update 84
- [x] Corrected the Places Covered summary to match the source catalogue: 11 BUS_HALT / 33 NO_HALT.
- [x] Removed the unverified fixed ₹165 Bollywood Museum price from public attraction and pricing copy.
- [x] Marked the Bollywood Museum seed tariff as unconfirmed and added a safe local-cache migration that changes only the exact legacy seed record; custom Admin edits are preserved.
- [x] Changed Admin tour-guide attraction reconciliation to accept actual per-person rates per tour and calculate totals from those values.
- [x] Kept historical offline collection records unchanged.
- [x] Aligned cancellation-policy refund processing copy with manual UPI refunds and the 5–7 working day estimate; removed unsupported card/net-banking and automatic SMS/email claims.
- [x] Added 11 assertions for the Update 84 public content and migration safeguards.
- [x] Preserved uniform package pricing, Bhayandar 6:15 AM pickup, OFF-by-default route offers, approved rental rules and 17-tab / 139-header schema.

## Validation
| Check | Result |
|---|---:|
| Offline validation | **50/50 PASS** |
| Update 84 regression test | **11 assertions PASS** |
| TypeScript / TSX syntax transpilation | **32 files / 0 errors** |
| Apps Script syntax | **PASS** |
| English-copy guard | **36 files PASS** |
| JSON parse | **6/6 PASS** |
| ZIP integrity | **PASS** |
| Semantic TypeScript check | Blocked — `vite/client` missing (`TS2688`) |
| Vite production build | Blocked — Vite not installed |
| Browser / mobile E2E | Not run |
| Live website / Sheets / Apps Script | Not touched |

## Remaining work
- [ ] Verify venue ticket rates before publishing them as current.
- [ ] Confirm live cancellation/privacy page cache after a later owner-approved deployment.
- [ ] Review public rental rate card before publication; defaults remain subject to owner review.
- [ ] Install dependencies in a network-enabled environment and complete semantic TypeScript check and Vite build.
- [ ] Browser E2E and real-device mobile checks.
- [ ] Complete remaining local source work before GitHub/network build phase.
- [ ] Later, only with approval: Sheets setup/migration, Apps Script deployment, payment integration, Preview refresh, hosting/DNS and production deployment.

## Owner constraints preserved
- No live deployment or external mutation without explicit approval.
- No Google Sheet manual creation; later setup code must create the approved workbook automatically.
- No schema/tab/header changes without approval.
- Keep Supabase until migration is fully tested and removal is explicitly approved.
- PhonePe/payment gateway remains deferred.
- Rental enquiries remain inquiry-only; no rental owner/customer email notifications.
- Each update includes a ZIP, Project Index, detailed report, changed-file list and validation results.

**Overall status: Local Update 84 corrections complete; project remains INCOMPLETE / NOT production-ready. Do not deploy.**
