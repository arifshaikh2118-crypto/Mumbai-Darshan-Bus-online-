# Mumbai Darshan Bus Online — Master Progress Tracker
## Update 79 — Booking Form & Car Rental Workflow Audit / Fix

**Date:** 21 November 2026  
**Source baseline:** Update 78  
**Current source package:** Update 79

## 1. Update 79 completed

- [x] Audited customer Booking Form pricing, route selection, advance/full payment calculations, compulsory guide/toll charges and meal selections.
- [x] Verified four-route initial pricing against the approved business price matrix.
- [x] Verified Apps Script independently calculates the online fare from the approved `PackageOptions` sheet and applies enabled offers.
- [x] Verified ₹200 advance is per booking; guide ₹50/person and Sea Link toll ₹10/person are separate from online package fare.
- [x] Verified booking persistence requires a local read-back before sending, stable retry ID recovery after refresh, exact backend ID echo, and duplicate handling.
- [x] Verified booking write + pending payment-ledger write behavior and rollback/reconciliation handling.
- [x] Found and fixed a critical rental sync defect: website omitted mandatory `rentalType` from the `NEW_RENTAL_ENQUIRY` payload, causing Apps Script validation to reject rental enquiries.
- [x] Added rental client-side validation matching Apps Script limits for name, mobile, passenger count, days, night DA, date, pickup and destination.
- [x] Increased collision resistance for public Booking IDs and Rental Enquiry IDs with Web Crypto UUID tokens plus fallback.
- [x] Verified rental local/outstation estimate calculations and confirmed the approved rental sheet remains exactly 19 columns.
- [x] Verified Admin reads rental enquiries through protected `ADMIN_GET_DATA`, maps approved fields, and uses authenticated status updates / WhatsApp follow-up.
- [x] Added `validation/test_rental_submission_contract.cjs` (13 assertions); expanded rental Apps Script runtime test to 28 assertions.
- [x] Updated this tracker, Project Index and detailed Update 79 report.

## 2. Validation

| Check | Result |
|---|---:|
| Offline test runner | **45/45 PASS** |
| Rental submission contract | **13 assertions PASS** |
| Rental Apps Script runtime | **28 assertions PASS** |
| TS/TSX syntax transpilation | **36 files / 0 syntax errors** |
| Apps Script syntax | **PASS** |
| English-copy guard | **35 files PASS** |
| ZIP integrity | **PASS** |
| Full semantic TypeScript check | Blocked: `vite/client` missing; `node_modules` absent |
| Vite build | Not run: Vite dependencies absent |
| Browser E2E / mobile device | Not run |
| Live Sheets / Apps Script | Not run; owner-deferred |

## 3. Current workstream status

| Workstream | Local source | Local tests | Live verification |
|---|---|---|---|
| Booking pricing and ₹200 advance calculation | Audited | PASS | Pending |
| Booking Sheets write + payment ledger | Implemented in source | PASS | Pending |
| Booking retry / duplicate protection | Implemented in source | PASS | Pending |
| Rental enquiry write | Fixed missing `rentalType` payload | PASS | Pending |
| Rental retry / duplicate protection | Implemented in source; IDs strengthened | PASS | Pending |
| Rental quotation calculation | Audited; existing formulas retained | PASS | Pending |
| Rental Admin visibility/status | Implemented in source | PASS | Pending |
| Public price/config synchronization | **Incomplete** — browser storage/default-backed | Known blocker | Pending |
| PhonePe / payment gateway | Deferred | N/A | Pending |
| Google Sheets setup / Apps Script deployment | Deferred | N/A | Pending |

## 4. Remaining work and why

### P0 — Public configuration accuracy
- [ ] Implement owner-approved Sheets-backed public configuration endpoint/hydration for routes, packages, offers and pickup details.
- [ ] Align public displayed prices with the authoritative `PackageOptions` sheet; the existing schema does not currently carry all pickup details consumed by the form.
- [ ] Hydrate public local rental/outstation customer rates from an approved source and test them against server-side display.
- Reason: current Booking Form and Car Rental Panel still use browser storage / initial defaults. A live Admin price change may not automatically reach a customer's browser. This is not solved by Update 79.

### P1 — Build and browser validation
- [ ] Install dependencies using a generated/approved lockfile on a network-enabled runner.
- [ ] Run full `tsc --noEmit` and Vite production build.
- [ ] Run browser E2E for all booking steps, local/outstation rental, retry after refresh, duplicate acknowledgement, Admin rental view and status update.
- [ ] Test mobile real-device form layout and route calculation.
- Reason: `node_modules` is absent and current environment cannot resolve `vite/client`.

### P2 — Owner-deferred live phase
- [ ] When approved, provide one Apps Script setup code that automatically creates the spreadsheet and approved tabs/schema; owner will not manually create a workbook.
- [ ] Configure secrets and deploy Apps Script only after approval.
- [ ] Verify real booking + payment ledger and rental enquiry writes in staging.
- [ ] Confirm backend hosting and `/api/**` routing; Firebase static hosting alone does not prove Express API availability.
- [ ] Run live email tests only after explicit approval.

### P3 — Later delivery
- [ ] GitHub work only after local source and remaining local audit are complete.
- [ ] Preview refresh, backend/hosting deployment, DNS and production deployment only after explicit approval.
- [ ] PhonePe integration only after merchant credentials and secure provider verification are ready.

## 5. Owner instructions preserved

- Do not remove Supabase until migration is fully tested and explicitly approved.
- Do not deploy Apps Script, create live Sheets, refresh Preview, use GitHub, change DNS or deploy production without explicit approval.
- Do not add/delete/rename approved sheet tabs or columns without permission.
- Rental enquiry remains inquiry-only; no rental customer/owner email and no rental payment.
- Keep PhonePe/payment integration deferred.
- Continue to provide an updated ZIP, Project Index, detailed report and this tracker after each completed local task.

## 6. Overall status

**Update 79 source fixes and audit are complete locally. The project remains INCOMPLETE / NOT production-ready. Do not deploy.**
