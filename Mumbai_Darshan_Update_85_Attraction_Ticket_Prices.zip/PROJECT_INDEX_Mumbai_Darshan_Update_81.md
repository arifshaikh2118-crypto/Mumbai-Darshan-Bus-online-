# Mumbai Darshan Bus Online — Project Index
## Latest update: Update 81 (21 November 2026)

### Update 81 — Centralized Local Darshan & Outstation Rental Pricing
- Preserved the approved **17-tab / 139-header** schema; no new sheet tab or column.
- Selected existing `Settings` key/value row `PUBLIC_RENTAL_PRICING_JSON` as the protected storage location for customer rental rates.
- Apps Script setup seeds six Local Darshan packages and sixteen Outstation rate classes only when the setting is absent.
- Public configuration returns only the validated rental pricing object; general Settings data stays private.
- Added authenticated Admin save API and **Private Fleet & Quotations → Customer Rental Pricing** editor.
- Added strict validation for all records and Night DA = daily DA.
- Customer Car Rental panel now requires both Active and Published flags.
- Offline validation: **48/48 PASS**; full Update 43 validation suite **48/48 PASS**; Apps Script syntax PASS; TS/TSX syntax 32 files / 0 errors; server TypeScript syntax PASS.
- Existing source rates are carried forward but not owner-confirmed; review before live publication.
- Full semantic TypeScript check, Vite build, browser/mobile testing and live Sheets/Apps Script verification remain pending.
- No live Sheet creation, Apps Script deployment, PhonePe, GitHub, Preview refresh, hosting/DNS/production deployment.

**Overall: INCOMPLETE / NOT production-ready. Do not deploy.** See `UPDATE_81_RENTAL_PRICING_CENTRALIZED.md` and `MASTER_PROGRESS_TRACKER_UPDATE_81.md`.

---

# Previous update — Update 80
Public tour prices, route offers and pickup activation flags synchronized through the server-owned public configuration. Local and outstation rental rate sync was incomplete at that point; Update 81 now addresses that source-code gap.

See `UPDATE_80_PUBLIC_CONFIGURATION_SYNC.md`.

---

# Previous update — Update 79
Booking Form and Car Rental workflow audit; mandatory `rentalType` payload defect fixed; retry and validation hardening completed.

See `UPDATE_79_BOOKING_RENTAL_AUDIT_AND_FIX.md`.
