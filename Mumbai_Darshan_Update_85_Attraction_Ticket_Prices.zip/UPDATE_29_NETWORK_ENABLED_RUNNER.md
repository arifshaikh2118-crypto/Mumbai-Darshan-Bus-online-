# Update 29 — Network-enabled build runner handoff

This update addresses the repeated local build-environment blocker by adding a manual GitHub Actions workflow and exact execution instructions. It does not alter UI, application logic, business pricing, or Google Sheets schema.

Files added:
- `.github/workflows/network-build-validation.yml`
- `validation/NETWORK_ENABLED_RUNNER_NOTE.md`

The workflow is manual-only (`workflow_dispatch`) and runs on a GitHub-hosted Ubuntu runner with Node.js 22. It installs dependencies, runs the full TypeScript check, builds the Vite production bundle, and uploads `dist/` for inspection. It does not deploy anything.

Important: this workflow has not yet been committed to GitHub or executed. It therefore provides the network-enabled path but is not evidence that the build has passed. Browser CRUD tests and staging Google Sheets verification remain separate pending gates.
