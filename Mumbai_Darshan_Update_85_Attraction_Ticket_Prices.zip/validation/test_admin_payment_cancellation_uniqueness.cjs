const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const gas = fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8');

const paymentStart = gas.indexOf('function handleVerifiedPayment(d)');
const paymentEnd = gas.indexOf('/** Send confirmation emails', paymentStart);
assert.ok(paymentStart >= 0 && paymentEnd > paymentStart, 'verified payment callback must exist');
const payment = gas.slice(paymentStart, paymentEnd);
assert.match(payment, /var bookingMatches = 0[\s\S]*?bookingMatches !== 1[\s\S]*?Duplicate Booking ID detected/);
assert.match(payment, /var paymentMatches = 0[\s\S]*?paymentMatches !== 1[\s\S]*?Multiple payment ledger rows exist/);

const publicStart = gas.indexOf('function handlePublicCancellationRequest_(d)');
const adminStart = gas.indexOf('function createAdminCancellation_(adminEmail, d)');
const refundStart = gas.indexOf('function updateAdminRefundStatus_(adminEmail, d)');
const refundEnd = gas.indexOf('/**\n * EmailLog writer', refundStart);
assert.ok(publicStart >= 0 && adminStart > publicStart && refundStart > adminStart && refundEnd > refundStart);
const publicCancel = gas.slice(publicStart, adminStart);
const adminCancel = gas.slice(adminStart, refundStart);
const refund = gas.slice(refundStart, refundEnd);
assert.match(publicCancel, /bookingMatches !== 1[\s\S]*?Duplicate Booking ID detected/);
assert.match(publicCancel, /linkedPayments\.length > 1[\s\S]*?Multiple payment ledger rows exist/);
assert.match(publicCancel, /linkedPayments\[0\]\[0\][\s\S]*?linkedPayments\[0\]\[5\][\s\S]*?linkedPayments\[0\]\[8\]/);
assert.match(publicCancel, /expectedLinkedAmount[\s\S]*?Math\.abs\(linkedAmount - expectedLinkedAmount\)/);
assert.match(adminCancel, /bookingMatches !== 1[\s\S]*?Duplicate Booking ID detected/);
assert.match(adminCancel, /linkedPayments\.length > 1[\s\S]*?Multiple payment ledger rows exist/);
assert.match(adminCancel, /linkedPayments\[0\]\[0\][\s\S]*?linkedPayments\[0\]\[5\][\s\S]*?linkedPayments\[0\]\[8\]/);
assert.match(adminCancel, /expectedLinkedAmount[\s\S]*?Math\.abs\(linkedAmount - expectedLinkedAmount\)/);
assert.match(refund, /cancellationMatches !== 1[\s\S]*?Duplicate cancellation ID detected/);
assert.match(refund, /bookingMatches !== 1[\s\S]*?Duplicate Booking ID detected/);
assert.match(refund, /Refund status was not changed/);
assert.match(refund, /bookingSheet\.getRange\(matchedBookingRow, 18\)\.setValue\('Cancelled'\)/);

console.log('PASS: payment callback, cancellation creation and refund transitions reject ambiguous duplicate records and invalid verified evidence — 14 assertions.');
