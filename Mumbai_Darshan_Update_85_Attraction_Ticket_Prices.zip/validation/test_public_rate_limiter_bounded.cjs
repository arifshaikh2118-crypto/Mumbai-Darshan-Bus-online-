const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');

const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'server/publicRateLimiter.ts'), 'utf8');
const serverSource = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');
assert.match(serverSource, /createBoundedRateLimiter\(5000, 256\)/, 'public endpoints must use a bounded limiter');
assert.match(serverSource, /publicActionLimiter\.allow\(`\$\{action\}:\$\{ip\}`, limit, windowMs\)/, 'public action and IP must remain separate throttle keys');

const output = ts.transpileModule(source, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 }
}).outputText;
const sandbox = { exports: {}, Map };
vm.runInNewContext(output, sandbox);
const { createBoundedRateLimiter } = sandbox.exports;

const limiter = createBoundedRateLimiter(3, 2);
assert.equal(limiter.allow('lookup:ip-a', 2, 1000, 100), true);
assert.equal(limiter.allow('lookup:ip-a', 2, 1000, 101), true);
assert.equal(limiter.allow('lookup:ip-a', 2, 1000, 102), false, 'limit still blocks excess requests');
assert.equal(limiter.allow('cancel:ip-a', 1, 1000, 103), true, 'different action has independent bucket');
assert.equal(limiter.size(), 2, 'map tracks only active keys');

const bounded = createBoundedRateLimiter(2, 100);
assert.equal(bounded.allow('ip-1', 1, 100, 0), true);
assert.equal(bounded.allow('ip-2', 1, 100, 0), true);
assert.equal(bounded.allow('ip-3', 1, 100, 1), false, 'new keys fail closed at active capacity');
assert.equal(bounded.size(), 2, 'active map cannot exceed configured capacity');
assert.equal(bounded.allow('ip-3', 1, 100, 101), true, 'expired entries are pruned before new key admission');
assert.equal(bounded.size(), 1, 'expired keys are removed');

const periodic = createBoundedRateLimiter(10, 3);
periodic.allow('expired', 1, 1, 0);
periodic.allow('keep', 3, 50, 2);
periodic.allow('keep', 3, 50, 3); // triggers periodic prune
assert.equal(periodic.size(), 1, 'periodic cleanup removes expired keys');

console.log('Bounded public rate limiter: 14 assertions passed.');
