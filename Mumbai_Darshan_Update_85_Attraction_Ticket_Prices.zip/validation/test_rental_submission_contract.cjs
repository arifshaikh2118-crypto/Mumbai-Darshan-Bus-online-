const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const storage = fs.readFileSync(path.join(root, 'src/services/storage.ts'), 'utf8');
const panel = fs.readFileSync(path.join(root, 'src/components/CarRentalPanel.tsx'), 'utf8');
const gas = fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');
const idSource = storage.slice(storage.indexOf('function generatePublicReferenceToken'), storage.indexOf('const KEYS =', storage.indexOf('function generatePublicReferenceToken')));

const syncStart = storage.indexOf('static async syncRentalToGoogleSheets');
const syncEnd = storage.indexOf('// CSV Export for Bookings', syncStart);
assert.ok(syncStart >= 0 && syncEnd > syncStart, 'rental sync method must exist');
const sync = storage.slice(syncStart, syncEnd);
assert.match(sync, /action:\s*'NEW_RENTAL_ENQUIRY'[\s\S]*?id:\s*rental\.id[\s\S]*?rentalType:\s*rental\.rentalType/,
  'public rental payload must include the required Local/Outstation discriminator');
assert.match(gas, /var rentalType = String\(d\.rentalType \|\| ''\)\.trim\(\)\.toLowerCase\(\)/,
  'Apps Script must validate the rental discriminator received from the website');
assert.match(idSource, /crypto\.randomUUID\(\)/, 'public references must use high-entropy Web Crypto IDs when available');
assert.match(storage, /return `MDB-\$\{yyyy\}\$\{mm\}\$\{dd\}-\$\{generatePublicReferenceToken\(\)\}`/, 'booking IDs must use the collision-resistant token');
assert.match(storage, /id: `CRE-\$\{new Date\(\)\.toISOString\(\)\.slice\(0, 10\)\.replace\(\/-\/g, ''\)\}-\$\{generatePublicReferenceToken\(\)\}`/, 'rental enquiry IDs must use the collision-resistant token');
assert.match(server, /'NEW_BOOKING', 'NEW_RENTAL_ENQUIRY', 'CAR_RENTAL', 'PING_TEST'/,
  'Express public sync allowlist must continue to permit rental enquiries');
assert.match(panel, /Number\.isInteger\(passengerCount\)[\s\S]*?passengerCount > 50/,
  'rental form must validate integer passenger count against server limit');
assert.match(panel, /Number\.isInteger\(daysCount\)[\s\S]*?daysCount > 30/,
  'outstation form must validate integer day count against server limit');
assert.match(panel, /Number\.isInteger\(nightCount\)[\s\S]*?nightCount > 30/,
  'night DA count must be a bounded integer');
assert.match(panel, /customerName\.trim\(\)\.length > 100/,
  'customer name must match Apps Script 100-character limit');
assert.match(panel, /pickupLocation\.trim\(\)\.length > 200/,
  'pickup must match Apps Script 200-character limit');
assert.match(panel, /destination\.trim\(\)\.length > 200/,
  'destination must match Apps Script 200-character limit');
assert.match(panel, /Retry Same Enquiry \(\$\{pendingEnquiry\.id\}\)/,
  'retry must continue to use the original enquiry ID');
console.log('PASS: rental submission contract — required rentalType field, server allowlist, matching client validation limits and stable retry ID (13 assertions).');
