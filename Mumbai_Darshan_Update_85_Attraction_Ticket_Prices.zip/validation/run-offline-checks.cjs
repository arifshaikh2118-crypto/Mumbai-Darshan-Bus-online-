const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const tests = [
  'test_admin_operational_ui.cjs',
  'test_admin_operational_write_policy.cjs',
  'test_admin_security.cjs',
  'test_customer_rate_model.cjs',
  'test_rental_enquiry_policy.cjs',
  'test_schema_alignment.cjs'
];
let failed = false;
for (const file of tests) {
  const p = path.join(root, 'google-apps-script', 'tests', file);
  const r = spawnSync(process.execPath, [p], { cwd: root, encoding: 'utf8' });
  process.stdout.write(`\n=== ${file} ===\n${r.stdout || ''}${r.stderr || ''}`);
  if (r.status !== 0) failed = true;
}
const validationTests = [
  'test_admin_cancellation_refund_state_machine.cjs',
  'test_admin_cancellation_ui_response_contract.cjs',
  'test_admin_financial_reporting_contract.cjs',
  'test_admin_payment_reconciliation.cjs',
  'test_admin_payment_cancellation_uniqueness.cjs',
  'test_public_config_runtime.cjs',
  'test_public_config_sync.cjs',
  'test_rental_pricing_config.cjs',
  'test_public_content_consistency.cjs'
];
for (const file of validationTests) {
  const p = path.join(root, 'validation', file);
  const r = spawnSync(process.execPath, [p], { cwd: root, encoding: 'utf8' });
  process.stdout.write(`\n=== validation/${file} ===\n${r.stdout || ''}${r.stderr || ''}`);
  if (r.status !== 0) failed = true;
}
const code = path.join(root, 'google-apps-script', 'Code.gs');
const tempCode = path.join(__dirname, 'Code.syntax-check.js');
fs.copyFileSync(code, tempCode);
const syntax = spawnSync(process.execPath, ['--check', tempCode], { encoding: 'utf8' });
fs.rmSync(tempCode, { force: true });
console.log(`\nApps Script syntax: ${syntax.status === 0 ? 'PASS' : 'FAIL'}`);
if (syntax.status !== 0) { process.stdout.write(syntax.stderr); failed = true; }
const tsPath = '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js';
if (fs.existsSync(tsPath)) {
  const ts = require(tsPath);
  const files = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (/\.(ts|tsx)$/.test(entry.name) && !entry.name.endsWith('.d.ts')) files.push(full);
    }
  }
  walk(path.join(root, 'src'));
  let diagnostics = 0;
  for (const file of files) {
    const source = fs.readFileSync(file, 'utf8');
    const result = ts.transpileModule(source, { compilerOptions: { jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext }, fileName: file, reportDiagnostics: true });
    diagnostics += (result.diagnostics || []).filter(d => d.category === ts.DiagnosticCategory.Error).length;
  }
  console.log(`TypeScript/TSX syntax transpilation: ${diagnostics === 0 ? 'PASS' : 'FAIL'} (${files.length} files, ${diagnostics} errors)`);
  if (diagnostics) failed = true;
} else {
  console.log('TypeScript/TSX syntax transpilation: SKIPPED (global compiler not found)');
}
process.exit(failed ? 1 : 0);
