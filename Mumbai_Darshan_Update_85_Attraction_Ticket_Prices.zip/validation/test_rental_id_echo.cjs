const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const storage = fs.readFileSync(path.join(root, 'src/services/storage.ts'), 'utf8');
const gas = fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8');
const panel = fs.readFileSync(path.join(root, 'src/components/CarRentalPanel.tsx'), 'utf8');

const syncStart = storage.indexOf('static async syncRentalToGoogleSheets');
const syncEnd = storage.indexOf('// CSV Export for Bookings', syncStart);
assert.ok(syncStart >= 0 && syncEnd > syncStart, 'rental sync method must exist');
const sync = storage.slice(syncStart, syncEnd);
assert.match(sync, /action:\s*'NEW_RENTAL_ENQUIRY'[\s\S]*?id:\s*rental\.id/, 'rental sync must send the stable enquiry ID');
assert.match(sync, /persistedEnquiryId = String\(result\?\.backendResponse\?\.enquiryId \|\| ''\)\.trim\(\)/, 'rental sync must read the backend-echoed enquiry ID');
assert.match(sync, /persistedEnquiryId\.toUpperCase\(\) === rental\.id\.trim\(\)\.toUpperCase\(\)/, 'rental sync must compare the exact submitted ID');
assert.match(sync, /\|\| !enquiryIdMatches/, 'missing or mismatched enquiry ID must fail closed');
assert.match(sync, /backendStatus === 'duplicate'[\s\S]*?same Rental Enquiry ID/, 'duplicate success message must explicitly refer to same ID');
assert.match(gas, /function handleRentalEnquiry\(d\)[\s\S]*?status:\s*'duplicate',\s*enquiryId:\s*enqId/, 'Apps Script duplicate response must echo enquiry ID');
assert.match(gas, /status:\s*'success',\s*enquiryId:\s*enqId/, 'Apps Script success response must echo enquiry ID');
assert.match(panel, /if \(!syncResult\.success\)[\s\S]*?setPendingEnquiry\(enquiry\)/, 'failed identity confirmation must keep the same enquiry draft for retry');
console.log('PASS: rental enquiry identity acknowledgement — 8 assertions.');
