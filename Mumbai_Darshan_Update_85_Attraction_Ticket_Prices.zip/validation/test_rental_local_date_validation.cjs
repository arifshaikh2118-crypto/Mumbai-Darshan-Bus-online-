const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');

const root = path.resolve(__dirname, '..');
const rental = fs.readFileSync(path.join(root, 'src/components/CarRentalPanel.tsx'), 'utf8');
const dateService = fs.readFileSync(path.join(root, 'src/services/date.ts'), 'utf8');

assert.match(rental, /isTodayOrFutureLocalDate\(travelDate\)/, 'rental submission must reject invalid or past dates');
assert.match(rental, /Please select today or a future travel date/, 'rental date validation must show clear feedback');
assert.match(rental, /return toLocalDateInputValue\(d\)/, 'rental default date must use local calendar formatting');
assert.match(rental, /type="date"\s+required\s+min=\{toLocalDateInputValue\(new Date\(\)\)\}/, 'rental date input must be required with local minimum');
assert.doesNotMatch(rental, /toISOString\(\)\.slice\(0,\s*10\)/, 'rental date must not derive from UTC ISO date');

process.env.TZ = 'Asia/Kolkata';
const transpiled = ts.transpileModule(dateService, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 }
});
const sandbox = { exports: {} };
vm.runInNewContext(transpiled.outputText, sandbox);
const { isTodayOrFutureLocalDate, toLocalDateInputValue } = sandbox.exports;
const indiaMidnight = new Date('2026-11-21T00:05:00+05:30');
assert.equal(toLocalDateInputValue(indiaMidnight), '2026-11-21', 'local formatter must retain India date after midnight');
assert.equal(isTodayOrFutureLocalDate('2026-11-20', indiaMidnight), false, 'yesterday must be rejected');
assert.equal(isTodayOrFutureLocalDate('2026-11-21', indiaMidnight), true, 'today must be accepted');
assert.equal(isTodayOrFutureLocalDate('2026-11-23', indiaMidnight), true, 'future dates must be accepted');
assert.equal(isTodayOrFutureLocalDate('2026-02-30', indiaMidnight), false, 'impossible dates must be rejected');

console.log('Rental local-date validation: 10 assertions passed.');
