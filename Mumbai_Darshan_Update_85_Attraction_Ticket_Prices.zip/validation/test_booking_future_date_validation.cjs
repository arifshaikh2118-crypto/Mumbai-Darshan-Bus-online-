const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const bookingForm = fs.readFileSync(path.join(root, 'src/components/BookingForm.tsx'), 'utf8');
const dateService = fs.readFileSync(path.join(root, 'src/services/date.ts'), 'utf8');

assert.match(bookingForm, /isTodayOrFutureLocalDate\(travelDate\)/, 'step-one validation must reject invalid or past dates');
assert.match(bookingForm, /Please select today or a future travel date/, 'date validation must show a clear message');
assert.match(bookingForm, /type="date"\s+required\s+min=\{toLocalDateInputValue\(new Date\(\)\)\}/, 'date input must be required and expose a local minimum');
assert.match(dateService, /if \(!\/\^\\d\{4\}-\\d\{2\}-\\d\{2\}\$\/\.test\(value\)\) return false/, 'date helper must validate strict YYYY-MM-DD format');
assert.match(dateService, /candidate\.getFullYear\(\) !== year/, 'date helper must reject impossible calendar dates');
assert.match(dateService, /return value >= toLocalDateInputValue\(now\)/, 'date helper must compare against local today');

process.env.TZ = 'Asia/Kolkata';
const ts = require('typescript');
const vm = require('node:vm');
const transpiled = ts.transpileModule(dateService, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 }
});
const sandbox = { exports: {} };
vm.runInNewContext(transpiled.outputText, sandbox);
const isTodayOrFuture = sandbox.exports.isTodayOrFutureLocalDate;
const localToday = new Date('2026-11-21T00:05:00+05:30');
assert.equal(isTodayOrFuture('2026-11-20', localToday), false, 'yesterday is rejected');
assert.equal(isTodayOrFuture('2026-11-21', localToday), true, 'today is accepted');
assert.equal(isTodayOrFuture('2026-11-22', localToday), true, 'future date is accepted');
assert.equal(isTodayOrFuture('2026-02-30', localToday), false, 'impossible date is rejected');
assert.equal(isTodayOrFuture('21-11-2026', localToday), false, 'non-ISO date is rejected');

console.log('Booking future-date validation: 11 assertions passed.');
