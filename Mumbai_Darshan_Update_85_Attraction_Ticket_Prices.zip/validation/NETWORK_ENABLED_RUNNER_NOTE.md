# Network-enabled runner note — Update 41

Date: 20 November 2026

## Why this is needed

The local runtime has no usable npm registry DNS route (`EAI_AGAIN` for `registry.npmjs.org`) and the npm cache contains no dependency packages. Therefore a local full install, lint/type-check and Vite build cannot be completed here.

## Workflow improvements in Update 41

The manual-only GitHub Actions workflow is:

`.github/workflows/network-build-validation.yml`

The workflow now:
1. Checks out the source on a GitHub-hosted Ubuntu runner with Node.js 22.
2. Runs `npm run test:offline` before installing dependencies.
3. Runs `npm install --legacy-peer-deps --no-audit --no-fund` to resolve dependencies and generate a real `package-lock.json`.
4. Verifies the generated lockfile exists and has a supported lockfile version.
5. Runs `npm ci --legacy-peer-deps --no-audit --no-fund` to prove a clean reproducible install.
6. Runs `npm run lint`.
7. Runs `npm run build`.
8. Uploads `dist/` and the generated lockfile as separate review artifacts.

The previous `setup-node` npm cache option was removed because this repository currently has no lockfile for the action to hash at workflow initialization. No lockfile is fabricated in this environment.

## Run instructions

1. Commit/push the project source including `.github/workflows/network-build-validation.yml` to the repository's `main` branch.
2. Open the repository on GitHub and select **Actions**.
3. Select **Mumbai Darshan Network Build Validation**.
4. Press **Run workflow**, select `main`, and confirm.
5. Inspect the regression, dependency install, lockfile verification, clean install, lint and build steps.
6. If all pass, download both artifacts and record the workflow URL and commit SHA in the Master Progress Tracker.
7. If a step fails, preserve the exact error and address it in a new source update.

## Safety boundary

The workflow is manual-only and validation-only. It does not deploy Firebase, publish Preview, change Google Sheets, run Apps Script setup, send email, change DNS, activate PhonePe or touch production data. It has not been committed to GitHub or executed from this chat. No real CI result is claimed.

Browser CRUD tests remain a separate gate and require a defined E2E suite plus an isolated staging API/spreadsheet target. Never point browser tests at production data or commit secrets.
