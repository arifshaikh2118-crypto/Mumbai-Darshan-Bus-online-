const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const gas = fs.readFileSync('google-apps-script/Code.gs', 'utf8');

const helperMatch = gas.match(/function safeSheetText_\(value, maxLength\) \{[\s\S]*?\n\}/);
assert.ok(helperMatch, 'Shared literal-cell text sanitizer must exist');
const context = {};
vm.runInNewContext(`${helperMatch[0]}; this.safeSheetText_ = safeSheetText_;`, context);
const safe = context.safeSheetText_;

for (const value of ['=1+1', '+SUM(A1:A2)', '-1+2', '@SUM(A1:A2)', '  =HYPERLINK("https://example.com")']) {
  assert.ok(safe(value, 200).startsWith("'"), `Formula-like value was not escaped: ${value}`);
}
assert.strictEqual(safe('Arif Shaikh', 100), 'Arif Shaikh');
assert.strictEqual(safe('  Mumbai Darshan  ', 100), 'Mumbai Darshan');
assert.strictEqual(safe('Long text', 4), 'Long');
assert.strictEqual(safe(null, 20), '');

const booking = gas.slice(gas.indexOf('function handleNewBooking'), gas.indexOf('function handleVerifiedPayment'));
const rental = gas.slice(gas.indexOf('function handleRentalEnquiry'), gas.indexOf('function runEmailConnectionTest'));
const publicCancellation = gas.slice(gas.indexOf('function handlePublicCancellationRequest_'), gas.indexOf('function createAdminCancellation_'));
const adminCancellation = gas.slice(gas.indexOf('function createAdminCancellation_'), gas.indexOf('function updateAdminRefundStatus_'));
for (const field of ['customerName', 'customerEmail', 'travelDate', 'routeName', 'pickupPointName', 'packageTitle', 'specialRequest']) {
  if (field === 'specialRequest') {
    assert.match(booking, /var bookingSpecialRequest = String\(b\.specialRequest \|\| ''\)\.trim\(\)\.slice\(0, 500\)[\s\S]*?safeSheetText_\(bookingSpecialRequest, 1000\)/, 'Customer special request must be sanitized before storage');
    assert.doesNotMatch(booking, /optionalAttractionRequest|Optional attractions requested/, 'Client attraction choices must not be appended to the booking record');
  } else {
    const sourceField = field === 'customerName' ? 'customerName' : field === 'customerEmail' ? 'customerEmail' : `b.${field}`;
    assert.ok(booking.includes(`safeSheetText_(${sourceField}`), `Booking field not sanitized: ${field}`);
  }
}
for (const field of ['vehicleType', 'tripType', 'specialRequirements', 'preferredCarModel', 'tempoTravellerSeatingCapacity', 'otherSeatingCapacity', 'acPreference', 'rentalDuration', 'pickupTime']) {
  assert.ok(rental.includes(`safeSheetText_(d.${field}`), `Rental field not sanitized: ${field}`);
}
assert.match(rental, /safeSheetText_\(customerName,\s*100\)/, 'Validated rental customer name must be formula-safe');
assert.match(rental, /safeSheetText_\(pickupLocation,\s*200\)/, 'Validated rental pickup must be formula-safe');
assert.match(rental, /safeSheetText_\(destination,\s*200\)/, 'Validated rental destination must be formula-safe');
assert.match(rental, /replace\(\/\\D\/g, ''\)/, 'Rental mobile must be normalized to digits before storage');
assert.match(booking, /Booking ID format is invalid/);
assert.match(rental, /Enquiry ID format is invalid/);
assert.match(publicCancellation, /var reason = safeSheetText_\(d\.reason \|\| ''/, 'Public cancellation reason must be stored as literal text');
assert.match(adminCancellation, /var reason = safeSheetText_\(d\.reason \|\| ''/, 'Admin cancellation reason must be stored as literal text');
console.log('PASS: formula-like customer text is escaped as literal text; booking, rental and cancellation reasons are length-bounded and sanitized; public IDs are format-validated.');
