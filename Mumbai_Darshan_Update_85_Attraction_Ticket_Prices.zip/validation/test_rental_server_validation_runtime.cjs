const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8');
const start = source.indexOf('function handleRentalEnquiry(d) {');
const end = source.indexOf('\n\n/**', start);
assert.ok(start >= 0 && end > start, 'rental handler must be present');
const handlerSource = source.slice(start, end);

let openedSheets = 0;
let appendedRows = [];
let sheetRows = [['id']];
const sheet = {
  getDataRange() { return { getValues() { return sheetRows; } }; },
  appendRow(row) { appendedRows.push(row); sheetRows.push(row); }
};
const sandbox = {
  SHEET_NAMES: { RENTAL_ENQUIRY: 'rental_enquiry' },
  Utilities: { formatDate() { return '2026-11-20'; } },
  getRequiredSheet_() { openedSheets++; return sheet; },
  safeSheetText_(value, max) { return String(value == null ? '' : value).replace(/^[=+@]/, "'$&").slice(0, max); },
  Date,
  Math,
  isFinite
};
vm.createContext(sandbox);
vm.runInContext(handlerSource, sandbox);
const valid = {
  id: 'CRE-20261120-123', customerName: 'Test Customer', customerMobile: '9876543210',
  travelDate: '2026-11-21', rentalType: 'local_darshan', passengerCount: 4,
  daysCount: 1, pickupLocation: 'Borivali East', destination: 'Mumbai Sightseeing (120 KM Local)',
  vehicleType: 'AC Sedan'
};
function rejected(patch, label) {
  const before = openedSheets;
  const result = sandbox.handleRentalEnquiry({ ...valid, ...patch, id: 'TEST-' + (before + 1) });
  assert.equal(result.status, 'error', label + ' should be rejected');
  assert.equal(openedSheets, before, label + ' must be rejected before opening/writing the sheet');
}
rejected({ customerName: 'AB' }, 'short customer name');
rejected({ customerName: 'x'.repeat(101) }, 'overlong customer name');
rejected({ customerMobile: '12345' }, 'short mobile');
rejected({ customerMobile: '+919876543210' }, 'country-code mobile instead of exact 10 digits');
rejected({ travelDate: '20-11-2026' }, 'non-ISO travel date');
rejected({ travelDate: '2026-02-30' }, 'impossible travel date');
rejected({ travelDate: '2026-11-19' }, 'past travel date');
rejected({ pickupLocation: ' ' }, 'blank pickup location');
rejected({ rentalType: '' }, 'missing rental type');
rejected({ rentalType: 'unknown' }, 'unknown rental type');
rejected({ rentalType: 'outstation', destination: '' }, 'blank outstation destination');
rejected({ passengerCount: 0 }, 'zero passengers');
rejected({ passengerCount: 51 }, 'more than 50 passengers');
rejected({ passengerCount: 2.5 }, 'fractional passenger count');
rejected({ daysCount: 31 }, 'more than 30 rental days');
rejected({ daysCount: 1.5 }, 'fractional rental duration');

const good = sandbox.handleRentalEnquiry(valid);
assert.equal(good.status, 'success', 'valid rental enquiry should save');
assert.equal(good.enquiryId, valid.id, 'success must echo the exact enquiry ID');
assert.equal(appendedRows.length, 1, 'valid enquiry should append exactly one row');
assert.equal(appendedRows[0].length, 19, 'rental row must preserve the approved 19-column mapping');
assert.equal(appendedRows[0][2], "'9876543210", 'stored phone must contain exactly the validated 10 digits');
assert.equal(appendedRows[0][8], 4, 'passenger count must be stored as validated integer');
assert.equal(appendedRows[0][9], 1, 'rental days must be stored as validated integer');

const duplicate = sandbox.handleRentalEnquiry(valid);
assert.equal(duplicate.status, 'duplicate', 'same ID must be idempotent');
assert.equal(appendedRows.length, 1, 'duplicate ID must not append a second row');

const outstation = sandbox.handleRentalEnquiry({
  ...valid, id: 'CRE-OUTSTATION-123', rentalType: 'outstation', tripType: 'Outstation',
  destination: 'Pune', daysCount: 2
});
assert.equal(outstation.status, 'success', 'valid outstation enquiry should save');
assert.equal(appendedRows.length, 2, 'outstation enquiry should append exactly one additional row');
assert.equal(appendedRows[1].length, 19, 'outstation enquiry must preserve the approved 19-column mapping');
assert.equal(appendedRows[1][6], 'Pune', 'outstation destination must be saved');

console.log('PASS: Apps Script rental server validation — 28 runtime assertions.');
