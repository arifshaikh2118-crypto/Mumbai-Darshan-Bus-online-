const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

const initial = read('src/data/initialData.ts');
const chargesPage = read('src/components/AttractionChargesPage.tsx');
const pricingPage = read('src/components/PricingPackagesPage.tsx');
const faq = read('src/components/FAQPage.tsx');
const tourGrid = read('src/components/TourPointsGrid.tsx');
const storage = read('src/services/storage.ts');
const admin = read('src/components/admin/AdminLayout.tsx');
const booking = read('src/components/BookingForm.tsx');
const app = read('src/App.tsx');

const expected = [
  ["id: 'gateway_boat_ride'", 'amount: 210'],
  ["id: 'museum_entry'", 'amount: 200'],
  ["id: 'bollywood_museum'", 'amount: 165'],
  ["id: 'orama_11d'", 'amount: 220'],
  ["id: 'sealink_toll'", 'amount: 10'],
  ["id: 'guide_charge'", 'amount: 50']
];
for (const [id, amount] of expected) {
  const start = initial.indexOf(id);
  assert.notEqual(start, -1, `${id} remains in the approved local price catalogue`);
  assert.ok(initial.slice(start, start + 700).includes(amount), `${id} preserves its approved price ${amount}`);
}

assert.match(chargesPage, /compulsoryCharges = extraCharges\.filter/, 'compulsory charges come from stored Admin-controlled data');
assert.match(chargesPage, /optionalTicketCharges = extraCharges\.filter/, 'optional ticket rows come from stored Admin-controlled data');
assert.match(chargesPage, /optionalTicketCharges\.map\(charge =>/, 'every active priced optional attraction is rendered');
assert.match(chargesPage, /₹\{charge\.amount\} \/ person/, 'public attraction section displays the current stored amount');
assert.match(chargesPage, /collected by the Tour Guide inside the bus only if you choose to visit/i, 'optional ticket charges are collected on the bus only when selected');
assert.match(chargesPage, /Compulsory On-Bus Charges/, 'guide and Sea Link compulsory charges remain visible');
assert.match(app, /publicTicketOrder = \['gateway_boat_ride', 'museum_entry', 'orama_11d', 'bollywood_museum', 'sealink_toll', 'guide_charge'\]/, 'homepage mirrors the six-ticket legacy attraction list in its original display order');
assert.match(app, /publicTicketCharges\.map\(charge =>/, 'homepage ticket list is rendered from the owner-controlled charge records');
assert.match(chargesPage, /not included in the online bus fare or ₹200 advance/i, 'guide/toll charges remain outside online fare and advance');
assert.match(pricingPage, /extraCharges\.filter\(charge => charge\.active && charge\.type === 'optional' && charge\.amount > 0\)\.map/, 'pricing page mirrors current Admin-managed optional ticket rates');
assert.doesNotMatch(faq, /Step 5 of your online booking|purchase on spot at venue ticket counters/, 'FAQ no longer tells customers to select or pay at venue during online booking');
assert.match(faq, /Tour Guide collects the ticket amount inside the bus/, 'FAQ explains bus-side guide collection');
assert.match(tourGrid, /See Attraction Tickets & Charges for the current rate/, 'landmark cards direct customers to the central rate list instead of stale duplicated prices');
assert.match(storage, /static updateExtraCharge\(id: string, changes: Partial<ExtraCharge>\)/, 'Admin rate changes persist through the existing storage service');
assert.match(admin, /StorageService\.updateExtraCharge\(charge\.id,/, 'Admin retains the manual Change Rate control');
assert.match(booking, /guideUnit \+ seaLinkUnit/, 'booking summary calculates guide/toll total from current rates');
assert.match(app, /guideFee \+ seaLinkFee/, 'homepage guide/toll notice uses current stored rates');

console.log('PASS Update 85 attraction ticket prices, guide collection and owner-controlled rates — 29 assertions.');
