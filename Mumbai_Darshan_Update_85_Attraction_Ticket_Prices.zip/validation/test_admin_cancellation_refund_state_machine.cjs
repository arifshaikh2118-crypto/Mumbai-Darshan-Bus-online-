const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const gas = fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');
const adminLayout = fs.readFileSync(path.join(root, 'src/components/admin/AdminLayout.tsx'), 'utf8');
const cancellationUI = fs.readFileSync(path.join(root, 'src/components/admin/AdminCancellationsPanel.tsx'), 'utf8');

const actionStart = gas.indexOf("if (action === 'ADMIN_UPDATE_BOOKING_STATUS')");
const actionEnd = gas.indexOf("if (action === 'ADMIN_CREATE_CANCELLATION')", actionStart);
assert.ok(actionStart >= 0 && actionEnd > actionStart);
const bookingAction = gas.slice(actionStart, actionEnd);
assert.match(bookingAction, /var allowedBooking = \['Confirmed', 'Pending Verification', 'Completed'\]/);
assert.match(bookingAction, /bookingStatus === 'Cancelled'[\s\S]*?Direct cancellation is disabled/);
assert.match(server, /bookingStatus === 'Cancelled'[\s\S]*?Cancellation & Refund Review workflow/);
assert.match(adminLayout, /\{b\.bookingStatus === 'Cancelled' && <option value="Cancelled">Cancelled<\/option>\}/,
  'historical cancelled bookings remain displayable but not directly selectable');

const refundStart = gas.indexOf('function updateAdminRefundStatus_(adminEmail, d)');
const refundEnd = gas.indexOf('function appendEmailLog_', refundStart);
assert.ok(refundStart >= 0 && refundEnd > refundStart);
const refund = gas.slice(refundStart, refundEnd);
assert.match(refund, /if \(status === currentStatus\)[\s\S]*?already ' \+ currentStatus/);
assert.match(refund, /currentStatus === 'Refunded' \|\| currentStatus === 'Rejected'/);
assert.match(refund, /currentStatus === 'Pending Review'[\s\S]*?indexOf\(status\) === -1/);
assert.match(refund, /currentStatus === 'Approved'[\s\S]*?indexOf\(status\) === -1/);
assert.match(refund, /d\.manualRefundConfirmed !== true/);
assert.match(refund, /verifiedPaidCap <= 0/);
assert.match(cancellationUI, /record\.refund_status === 'Pending Review'/);
assert.match(cancellationUI, /record\.refund_status === 'Approved'/);
assert.match(cancellationUI, /record\.refund_status === 'Refunded'/);
assert.match(cancellationUI, /record\.refund_status === 'Rejected'/);

console.log('PASS: Admin cancellation/refund workflow guardrails — 15 assertions.');
