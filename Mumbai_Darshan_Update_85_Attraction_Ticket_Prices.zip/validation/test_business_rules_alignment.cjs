const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const initial = fs.readFileSync(path.join(root, 'src', 'data', 'initialData.ts'), 'utf8');
const booking = fs.readFileSync(path.join(root, 'src', 'components', 'BookingForm.tsx'), 'utf8');
const rental = fs.readFileSync(path.join(root, 'src', 'components', 'CarRentalPanel.tsx'), 'utf8');
const app = fs.readFileSync(path.join(root, 'src', 'App.tsx'), 'utf8');
const storage = fs.readFileSync(path.join(root, 'src', 'services', 'storage.ts'), 'utf8');
const gas = fs.readFileSync(path.join(root, 'google-apps-script', 'Code.gs'), 'utf8');
const faq = fs.readFileSync(path.join(root, 'src', 'components', 'FAQPage.tsx'), 'utf8');
const legal = fs.readFileSync(path.join(root, 'src', 'components', 'LegalPoliciesPage.tsx'), 'utf8');
const pricingPage = fs.readFileSync(path.join(root, 'src', 'components', 'PricingPackagesPage.tsx'), 'utf8');

assert.match(initial, /advanceDepositFixedAmount:\s*200/);
const offerDefaults = initial.match(/export const INITIAL_OFFERS:[\s\S]*?\n\];/)?.[0] || '';
assert.equal((offerDefaults.match(/enabled:\s*false/g) || []).length, 4, 'all four route offers must start OFF');
const expectedPrices = [
  [/packageId:\s*'non_ac_no_lunch'[\s\S]*?basePrices:\s*\{[\s\S]*?western:\s*250,\s*central:\s*250,\s*harbour:\s*250,\s*kalyan_dombivli:\s*250/, 'Non-AC without lunch'],
  [/packageId:\s*'ac_no_lunch'[\s\S]*?basePrices:\s*\{[\s\S]*?western:\s*350,\s*central:\s*350,\s*harbour:\s*350,\s*kalyan_dombivli:\s*350/, 'AC without lunch'],
  [/packageId:\s*'non_ac_lunch'[\s\S]*?basePrices:\s*\{[\s\S]*?western:\s*450,\s*central:\s*450,\s*harbour:\s*450,\s*kalyan_dombivli:\s*450/, 'Non-AC with lunch'],
  [/packageId:\s*'ac_lunch'[\s\S]*?basePrices:\s*\{[\s\S]*?western:\s*550,\s*central:\s*550,\s*harbour:\s*550,\s*kalyan_dombivli:\s*550/, 'AC with lunch']
];
for (const [pattern, label] of expectedPrices) assert.match(initial, pattern, `Approved route pricing mismatch: ${label}`);
assert.match(initial, /id:\s*'guide_charge'[\s\S]*?amount:\s*50[\s\S]*?priceType:\s*'per_person'/);
assert.match(initial, /id:\s*'sealink_toll'[\s\S]*?amount:\s*10[\s\S]*?priceType:\s*'per_person'/);
for (const meal of ['Veg Biryani', 'Butter Paneer', 'Veg Thali']) assert.ok(booking.includes(meal), `Lunch choice missing: ${meal}`);
assert.match(booking, /Breakfast and lunch are included in applicable packages/);
assert.match(booking, /Breakfast will be served as Samosa or Kanda Poha, as decided by the operator/);
assert.match(initial, /name:\s*'Bhayandar East',[\s\S]*?time:\s*'6:15 AM'/, 'Bhayandar East pickup must be 6:15 AM');
assert.match(faq, /Bhayandar East starts at 6:15 AM/, 'FAQ pickup timing must agree with the pickup catalogue');
assert.doesNotMatch(faq, /Bhayandar East starts at 6:30 AM/, 'FAQ must not publish the incorrect Bhayandar time');
assert.match(storage, /legacyPrices:[\s\S]*?non_ac_no_lunch:[\s\S]*?western:\s*200,\s*central:\s*200/, 'old Western/Central local cache rates must be migrated');
assert.match(storage, /storedOffers\.map\(offer => \(\{ \.\.\.offer, enabled: false \}\)\)/, 'old local offers must be switched OFF once while preserving discount values');
assert.match(gas, /routePrices = \{ western: \[250,350,450,550\], central: \[250,350,450,550\], harbour: \[250,350,450,550\], kalyan_dombivli: \[250,350,450,550\] \}/, 'Apps Script bootstrap must seed the same rate card for every route');
assert.match(gas, /packagePrice = getApprovedPackagePrice_/, 'server-side booking pricing must remain authoritative');
assert.match(pricingPage, /const offerIsActive = sheetOffer \? sheetOffer\.enabled : Boolean\(currentOffer\?\.enabled\)/, 'pricing page must show the offer label only when the actual route/package offer is enabled');
assert.match(faq, /booking remains pending until the advance payment is verified/, 'FAQ must not imply an unverified advance confirms a booking');
assert.match(legal, /Individual seat numbers are not issued/, 'terms must accurately state that shared tours do not issue seat numbers');

assert.match(rental, /includeLocalTourGuide/);
assert.match(rental, /includeLocalTourGuide \? 2000 : 0/);
assert.match(rental, /Tour Guide requested: ₹2,000 flat per booking\/vehicle/);
assert.match(rental, /Flat ₹2,000 per booking \/ vehicle\. Not charged per passenger\./);
assert.match(rental, /Vehicle, driver and parking included/);
assert.match(rental, /Tour Guide optional at ₹2,000 flat per booking\/vehicle/);
assert.match(rental, /Driver allowance \/ DA-Permit extra as shown in the estimate/);
assert.match(rental, /Parking, Toll, Border Tax and Entry charges extra at actuals/);
assert.strictEqual((rental.match(/Driver and parking included/g) || []).length, 1, 'Only the local quote summary may say driver and parking are included');
assert.match(rental, /Vehicle, driver and parking included/);
assert.match(rental, /Tour Guide optional at ₹2,000 flat per booking\/vehicle/);
const bookingPos = app.indexOf('<BookingForm initialRoute={preselectedRoute} />');
const rentalPos = app.indexOf('<CarRentalPanel />', bookingPos);
assert.ok(bookingPos >= 0 && rentalPos > bookingPos, 'Homepage rental enquiry panel must remain immediately below booking form section');
assert.match(initial, /name:\s*'Bhayandar East',[\s\S]*?time:\s*'6:15 AM'/, 'Bhayandar East pickup must remain 6:15 AM');
assert.match(booking, /pickupTime:\s*selectedPickup\?\.time \|\| ''/, 'Booking must use the selected catalogue pickup time and never invent a fallback time');
assert.doesNotMatch(booking, /pickupTime:\s*selectedPickup\?\.time \|\| '6:30 AM'/, 'Booking must not use a generic 6:30 AM fallback');
console.log('PASS approved business rules: uniform route pricing, Bhayandar 6:15 AM, offer-off defaults, legacy cache migration, booking verification wording, no seat numbers, guide/toll, lunch choices and rental billing.');
