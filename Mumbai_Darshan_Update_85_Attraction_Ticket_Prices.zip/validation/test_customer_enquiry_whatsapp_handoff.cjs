const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const group = fs.readFileSync(path.join(root, 'src/components/GroupBookingPage.tsx'), 'utf8');
const contact = fs.readFileSync(path.join(root, 'src/components/ContactUsPage.tsx'), 'utf8');

assert.match(group, /isTodayOrFutureLocalDate\(tentativeDate\)/);
assert.match(group, /approximatePassengers < 10 \|\| approximatePassengers > 500/);
assert.match(group, /https:\/\/wa\.me\/\$\{whatsappNumber\}\?text=/);
assert.match(group, /Continue to WhatsApp and Send/);
assert.match(group, /Your enquiry has not been submitted or saved to our server/);
assert.doesNotMatch(group, /StorageService\.createGroupEnquiry/);
assert.doesNotMatch(group, /Group Booking Request Submitted!/);
assert.match(group, /toLocalDateInputValue\(d\)/);

assert.match(contact, /cleanPhone\.length !== 10/);
assert.match(contact, /https:\/\/wa\.me\/\$\{whatsappNumber\}\?text=/);
assert.match(contact, /Continue to WhatsApp and Send/);
assert.match(contact, /Your message has not been sent or saved to our server/);
assert.doesNotMatch(contact, /Message Dispatched!/);
assert.match(contact, /role="alert"/);

console.log('Group booking + contact WhatsApp handoff: 14 assertions PASS');
