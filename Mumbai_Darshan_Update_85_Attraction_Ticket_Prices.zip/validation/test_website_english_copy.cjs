const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
function collectSourceFiles(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const absolute = path.join(directory, entry.name);
    if (entry.isDirectory()) return collectSourceFiles(absolute);
    return /\.(tsx?|jsx?)$/i.test(entry.name) ? [absolute] : [];
  });
}
const files = [...new Set([
  ...collectSourceFiles(path.join(root, 'src')),
  path.join(root, 'index.html'),
  path.join(root, 'PREVIEW.html'),
  path.join(root, 'server.ts'),
  path.join(root, 'google-apps-script', 'Code.gs'),
])].filter((file) => fs.existsSync(file));
const forbidden = [
  'abhi available nahi', 'verify nahi ho saki', 'submit nahi hui',
  'enter karein', 'lookup nahi hoga', 'record ho gayi hai',
  'team review karegi', 'refund automatic nahi hoga',
  'reason likhein', 'abhi Google Sheets mein confirm nahi hui',
  'Security ke liye apna',
  'kripya', 'dhanyavaad', 'aapka booking', 'aapki booking',
  'sampark karein', 'yahan click karein', 'form bharein',
  'aapka naam', 'mobile number dalein', 'details bhejein',
];
let failures = 0;
for (const absolute of files) {
  const relative = path.relative(root, absolute);
  const content = fs.readFileSync(absolute, 'utf8');
  for (const phrase of forbidden) {
    if (content.toLowerCase().includes(phrase.toLowerCase())) {
      console.error(`FAIL ${relative}: legacy non-English UI phrase found: ${phrase}`);
      failures++;
    }
  }
  if (/[\u0900-\u097F]/u.test(content)) {
    console.error(`FAIL ${relative}: Devanagari text found in website UI source`);
    failures++;
  }
  console.log(`PASS ${relative}: no detected non-English UI copy`);
}
if (failures) process.exit(1);
console.log(`English-copy guard: ${files.length} frontend, preview, server and Apps Script source files PASS`);
