const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const storage = fs.readFileSync(path.join(root, 'src/services/storage.ts'), 'utf8');
const bookingForm = fs.readFileSync(path.join(root, 'src/components/BookingForm.tsx'), 'utf8');
const gas = fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8');

assert.match(storage, /action:\s*'NEW_BOOKING'[\s\S]*?bookingId:\s*booking\.id/, 'frontend must send the stable Booking ID to Apps Script');
assert.match(storage, /const persistedBookingId = String\(proxyResult\?\.backendResponse\?\.bookingId \|\| ''\)\.trim\(\)/, 'frontend must read the Booking ID echoed by Apps Script');
assert.match(storage, /persistedBookingId\.toUpperCase\(\) === booking\.id\.trim\(\)\.toUpperCase\(\)/, 'frontend must require an exact Booking ID match before success');
assert.match(gas, /var row = \[[\s\S]*?\/\/ 1\. Timestamp\s*\n\s*bId,\s*\/\/ 2\. Booking ID/, 'Apps Script must place Booking ID in the approved Bookings column 2');
assert.doesNotMatch(storage, /optionalAttractions:\s*booking\.selectedOptionalAttractions/, 'frontend must not send customer-selected attraction details');
assert.match(bookingForm, /selectedOptionalAttractions:\s*\[\][\s\S]*?totalOptionalAmount:\s*0/, 'new online bookings must contain no pre-selected attractions or attraction charges');
assert.doesNotMatch(bookingForm, /Optional Attractions Selection|selectedOptionalExtras|optionalChargesList\.map/, 'customer booking form must not provide attraction selection controls');
assert.match(bookingForm, /choose which attractions to visit after boarding[\s\S]*?No attraction has been pre-selected/, 'booking receipt must explain that attraction choices happen on the bus');
assert.match(gas, /var bookingSpecialRequest = String\(b\.specialRequest \|\| ''\)\.trim\(\)\.slice\(0, 500\)[\s\S]*?safeSheetText_\(bookingSpecialRequest, 1000\)/, 'Apps Script must save only the customer special request');
assert.doesNotMatch(gas, /optionalAttractionRequest|Optional attractions requested/, 'Apps Script must not persist client-supplied attraction selections');
assert.match(gas, /sheet\.appendRow\(row\);[\s\S]*?return \{\s*status:\s*'success',\s*bookingId:\s*bId/, 'Apps Script must append the booking row and return its persisted ID');
assert.match(gas, /function handleNewBooking\(b\)[\s\S]*?lock\.waitLock\(30000\)[\s\S]*?handleNewBookingLocked_\(b\)/, 'booking duplicate check and writes must be serialized');
assert.match(gas, /paySheet\.appendRow\(\[[\s\S]*?catch \(paymentLedgerError\)[\s\S]*?sheet\.deleteRow\(bookingRowNumber\)/, 'partial payment-ledger failure must attempt booking-row rollback');
assert.match(bookingForm, /if \(!syncResult\.success\)[\s\S]*?setSubmissionError[\s\S]*?setCurrentStep\(7\)/, 'receipt must remain blocked until Google Sheets confirms save');

console.log('Booking ID and booking-detail Google Sheets persistence: 10 assertions passed.');

assert.match(fs.readFileSync(path.join(root, 'src/components/BookingForm.tsx'), 'utf8'), /customerEmail: customerEmail\.trim\(\), \/\/ Optional: never invent an email address/);
assert.match(fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8'), /persons > 50/);
assert.match(fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8'), /A valid 10-digit customer mobile number is required/);
