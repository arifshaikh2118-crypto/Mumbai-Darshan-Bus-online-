# Next steps after Update 27

1. Use a network-enabled Node 22 runner and run:
   - `npm install --legacy-peer-deps --no-audit --no-fund`
   - `npm run lint`
   - `npm run build`
2. Fix semantic or build failures, then rerun all six suites with `node validation/run-offline-checks.cjs`.
3. Configure a dedicated staging Apps Script deployment and spreadsheet only after owner-approved setup; keep secrets in environment/script properties, never source files.
4. Browser-test all seven operational tabs with unique disposable test rows and verify Google Sheets persistence and Activity Log.
5. After staging acceptance, update the existing Preview URL and document its verification. Production deployment remains a separate explicit approval step.
