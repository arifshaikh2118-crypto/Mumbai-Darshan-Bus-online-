const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const admin = fs.readFileSync(path.join(root, 'src/components/admin/AdminLayout.tsx'), 'utf8');
const reports = fs.readFileSync(path.join(root, 'src/components/admin/AdminReportsTab.tsx'), 'utf8');

// Sheet-backed Admin collections must be derived exclusively from verified ledger rows.
const mapperStart = admin.indexOf('const mapSheetBooking =');
const mapperEnd = admin.indexOf('const normalizeRentalStatus =', mapperStart);
const mapper = admin.slice(mapperStart, mapperEnd);
assert.match(mapper, /const verifiedPayments = paymentRows\.filter\([\s\S]*?payment_status\s*\|\|\s*''\)\.toLowerCase\(\) === 'verified'/);
assert.match(mapper, /const paid = verifiedPayments\.reduce\([\s\S]*?Number\.isFinite\(value\) && value > 0 \? value : 0/);
assert.match(mapper, /amountPaid: paid, balancePayable: Math\.max\(0, amount - paid\)/);
assert.match(mapper, /amountPaid: paid, balancePayable:/,
  'amountPaid must use the verified ledger-derived paid value');

// Reports aggregate the mapped amountPaid value and must label it as all online payments,
// not only advance payments; activeBookings excludes cancelled rows but includes pending rows.
assert.match(reports, /const totalAdvanceCollected = activeBookings\.reduce\(\(acc, b\) => acc \+ \(b\.amountPaid \|\| 0\), 0\)/);
assert.match(reports, /<span>Online Payments Collected<\/span>/);
assert.match(reports, /Across \{activeBookings\.length\} non-cancelled bookings/);
assert.doesNotMatch(reports, /Online Advance Collected|From \{activeBookings\.length\} confirmed bookings/);
assert.match(reports, /const activeBookings = bookings\.filter\(b => \{[\s\S]*?b\.bookingStatus === 'Cancelled'/);

console.log('PASS: Admin financial reporting uses verified-ledger amounts and accurate collection labels — 7 assertions.');
