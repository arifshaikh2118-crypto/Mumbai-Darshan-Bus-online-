const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const bookingForm = fs.readFileSync(path.join(root, 'src/components/BookingForm.tsx'), 'utf8');
const dateService = fs.readFileSync(path.join(root, 'src/services/date.ts'), 'utf8');

assert.match(bookingForm, /toLocalDateInputValue\(d\)/, 'default travel date must use local calendar formatting');
assert.match(bookingForm, /min=\{toLocalDateInputValue\(new Date\(\)\)\}/, 'date picker minimum must use local calendar formatting');
assert.doesNotMatch(bookingForm, /toISOString\(\)\.slice\(0,\s*10\)/, 'booking date input must not derive dates from UTC ISO strings');
assert.match(dateService, /getFullYear\(\)/, 'formatter must use local year');
assert.match(dateService, /getMonth\(\)\s*\+\s*1/, 'formatter must use local month');
assert.match(dateService, /getDate\(\)/, 'formatter must use local day');

// Regression example: midnight in India is the previous UTC calendar day.
process.env.TZ = 'Asia/Kolkata';
const indiaMidnight = new Date('2026-11-21T00:00:00+05:30');
const localDate = `${indiaMidnight.getFullYear()}-${String(indiaMidnight.getMonth() + 1).padStart(2, '0')}-${String(indiaMidnight.getDate()).padStart(2, '0')}`;
assert.equal(localDate, '2026-11-21');
assert.equal(indiaMidnight.toISOString().slice(0, 10), '2026-11-20');

console.log('Booking local-date regression: 7 assertions passed.');
