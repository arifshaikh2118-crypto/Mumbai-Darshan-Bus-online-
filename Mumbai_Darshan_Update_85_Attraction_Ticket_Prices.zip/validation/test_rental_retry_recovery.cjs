const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const storage = fs.readFileSync(path.join(root, 'src/services/storage.ts'), 'utf8');
const panel = fs.readFileSync(path.join(root, 'src/components/CarRentalPanel.tsx'), 'utf8');

assert.match(storage, /PENDING_RENTAL_RETRY:\s*'mdb_pending_rental_retry_v1'/,
  'rental retry pointer must use a dedicated versioned key');
assert.match(storage, /static createCarRentalEnquiry\([\s\S]*?setItem\(KEYS\.CAR_RENTALS, rentals\)[\s\S]*?const persistedEnquiry = this\.getCarRentals\(\)\.find[\s\S]*?if \(!persistedEnquiry\)[\s\S]*?throw new Error/,
  'rental enquiry creation must verify the full local draft can be read back');
assert.match(storage, /static savePendingRentalRetryId\(id: string\): boolean[\s\S]*?this\.getCarRentals\(\)\.find[\s\S]*?localStorage\.setItem\(KEYS\.PENDING_RENTAL_RETRY, cleanId\)[\s\S]*?localStorage\.getItem\(KEYS\.PENDING_RENTAL_RETRY\)/,
  'retry pointer must verify the exact enquiry exists and read back the ID');
assert.match(storage, /static getPendingRentalForRetry\(\): CarRentalEnquiry \| null[\s\S]*?localStorage\.getItem\(KEYS\.PENDING_RENTAL_RETRY\)[\s\S]*?this\.getCarRentals\(\)\.find/,
  'restore helper must retrieve the exact enquiry from local records');
assert.match(storage, /static clearPendingRentalRetryId\(id\?: string\): void[\s\S]*?current\.toUpperCase\(\) !== id\.trim\(\)\.toUpperCase\(\)/,
  'clear helper must not delete a different pending rental ID');
assert.match(panel, /React\.useEffect\(\(\) => \{[\s\S]*?StorageService\.getPendingRentalForRetry\(\)[\s\S]*?setIsRestoredPendingEnquiry\(true\)/,
  'rental panel must restore the pending enquiry after refresh');
assert.match(panel, /const enquiry = pendingEnquiry \|\| StorageService\.createCarRentalEnquiry/,
  'retry must reuse the restored enquiry rather than create a new reference');
assert.match(panel, /StorageService\.savePendingRentalRetryId\(enquiry\.id\)[\s\S]*?if \(!retryPointerSaved\)[\s\S]*?return;[\s\S]*?StorageService\.syncRentalToGoogleSheets/,
  'rental sync must not run unless the recovery pointer was saved');
assert.match(panel, /StorageService\.clearPendingRentalRetryId\(enquiry\.id\)[\s\S]*?setPendingEnquiry\(null\)/,
  'pointer must clear only after exact backend acknowledgement');
assert.match(panel, /Retry Same Enquiry \(\$\{pendingEnquiry\.id\}\)/,
  'recovery panel must show and retry the same rental enquiry ID');
assert.match(panel, /Rental enquiries are inquiry-only, not confirmed bookings/,
  'recovery panel must preserve inquiry-only business policy');
assert.match(panel, /No request was sent to Google Sheets/,
  'failed local retry persistence must fail closed before network submission');

console.log('PASS: rental enquiry retry recovery after refresh — 12 assertions.');
