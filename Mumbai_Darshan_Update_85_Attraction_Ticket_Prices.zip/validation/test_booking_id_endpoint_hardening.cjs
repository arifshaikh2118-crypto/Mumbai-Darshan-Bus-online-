const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');

const root = path.resolve(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');
const helperSource = fs.readFileSync(path.join(root, 'server/bookingRequestValidation.ts'), 'utf8');
const compiled = ts.transpileModule(helperSource, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 }
});
const sandbox = { exports: {} };
vm.runInNewContext(compiled.outputText, sandbox);
const { validateBookingIdRequest, localBookingDateCode } = sandbox.exports;

const now = new Date(2026, 10, 20, 0, 5);
const valid = {
  customerName: 'Arif Shaikh',
  customerMobile: '9876543210',
  travelDate: '2026-11-20',
  routeId: 'western',
  packageId: 'ac-bus'
};
assert.equal(validateBookingIdRequest(valid, now).valid, true, 'valid booking-ID request is accepted');
assert.equal(validateBookingIdRequest({ ...valid, travelDate: '2026-11-19' }, now).valid, false, 'past date is rejected');
assert.equal(validateBookingIdRequest({ ...valid, travelDate: '2026-02-30' }, now).valid, false, 'impossible date is rejected');
assert.equal(validateBookingIdRequest({ ...valid, travelDate: '20-11-2026' }, now).valid, false, 'non-ISO date is rejected');
assert.equal(validateBookingIdRequest({ ...valid, customerName: 'x'.repeat(101) }, now).valid, false, 'overlong name is rejected');
assert.equal(validateBookingIdRequest({ ...valid, customerMobile: '12345' }, now).valid, false, 'invalid mobile is rejected');
assert.equal(validateBookingIdRequest({ ...valid, routeId: 'r'.repeat(81) }, now).valid, false, 'overlong route ID is rejected');
assert.equal(validateBookingIdRequest({ ...valid, packageId: '' }, now).valid, false, 'missing package is rejected');
assert.equal(validateBookingIdRequest(null, now).valid, false, 'missing body is rejected');
assert.equal(localBookingDateCode(now), '20261120', 'ID date code uses local calendar date');

assert.match(server, /allowPublicAction\(ip, 'booking-id', 8, 10 \* 60 \* 1000\)/, 'legacy booking-ID endpoint is throttled per IP');
assert.match(server, /validateBookingIdRequest\(req\.body\)/, 'endpoint uses strict server-side request validation');
assert.match(server, /crypto\.randomInt\(1000, 10000\)/, 'booking ID suffix uses cryptographic randomness');
assert.match(server, /localBookingDateCode\(\)/, 'booking ID date prefix uses local date');
assert.match(server, /it does not\s*\n\/\/ persist a booking/, 'endpoint documentation must not imply that ID generation persists a booking');
console.log('Booking ID endpoint hardening: 14 assertions passed.');
