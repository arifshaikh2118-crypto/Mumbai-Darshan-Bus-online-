const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const gas = fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8');
const admin = fs.readFileSync(path.join(root, 'src/components/admin/AdminLayout.tsx'), 'utf8');
const panel = fs.readFileSync(path.join(root, 'src/components/admin/AdminPaymentReconciliationPanel.tsx'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');

assert.match(gas, /var paymentReconciliation = buildBookingPaymentReconciliation_\(bookings, payments\)/);
assert.match(gas, /paymentReconciliation: paymentReconciliation/);
const helperStart = gas.indexOf('function buildBookingPaymentReconciliation_(');
const helperEnd = gas.indexOf('function constantTimeEquals_', helperStart);
assert.ok(helperStart >= 0 && helperEnd > helperStart);
const helper = gas.slice(helperStart, helperEnd);
for (const code of ['MISSING_LEDGER','ORPHAN_LEDGER_ROW','MULTIPLE_LEDGER_ROWS','BOOKING_MARKED_PAID_WITHOUT_VERIFIED_LEDGER','VERIFIED_LEDGER_BOOKING_NOT_PAID','VERIFIED_AMOUNT_EXCEEDS_BOOKING','VERIFIED_AMOUNT_MODE_MISMATCH','VERIFIED_EVIDENCE_INCOMPLETE','DUPLICATE_TRANSACTION_REFERENCE','DUPLICATE_PAYMENT_ID']) {
  assert.ok(helper.includes(code), `missing reconciliation finding ${code}`);
}
assert.match(helper, /findings\.length < 250/);
assert.match(helper, /findingCount > 250/);
assert.match(helper, /summary\.issueCount = findingCount/);
assert.match(gas.slice(Math.max(0, helperStart - 300), helperStart), /Read-only reconciliation/);
assert.match(admin, /const paid = verifiedPayments\.reduce/);
assert.doesNotMatch(admin, /ledgerPaid \|\| \(paymentLabel\.includes\('fully paid'\)/,
  'Admin must not infer paid cash from booking status when verified ledger evidence is missing');
assert.match(admin, /AdminPaymentReconciliationPanel report=\{adminSheetData\.paymentReconciliation\}/);
assert.match(panel, /No amounts or sheet rows are changed/);
assert.match(panel, /Requires manual review — no automatic correction was applied/);
assert.match(server, /app\.get\('\/api\/admin\/data', requireAdmin[\s\S]*?callAppsScriptAdmin\('ADMIN_GET_DATA', req\.adminSession\.email\)[\s\S]*?data: data\.data/);
assert.match(server, /callAppsScriptAdmin[\s\S]*?data\?\.status !== 'success'/);
console.log('PASS: Admin payment reconciliation payload, anomaly rules, ledger-only revenue and read-only UI — 22 assertions.');
