const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

const initial = read('src/data/initialData.ts');
const tourGrid = read('src/components/TourPointsGrid.tsx');
const attractionPage = read('src/components/AttractionChargesPage.tsx');
const pricingPage = read('src/components/PricingPackagesPage.tsx');
const adminReports = read('src/components/admin/AdminReportsTab.tsx');
const legal = read('src/components/LegalPoliciesPage.tsx');
const storage = read('src/services/storage.ts');

const tourPoints = initial.split('export const INITIAL_TOUR_POINTS: TourPoint[] = [')[1].split('\n];')[0];
const haltCount = (tourPoints.match(/haltStatus: 'BUS_HALT'/g) || []).length;
const driveCount = (tourPoints.match(/haltStatus: 'NO_HALT'/g) || []).length;
assert.equal(haltCount, 11, 'tour point data has 11 BUS_HALT stops');
assert.equal(driveCount, 33, 'tour point data has 33 NO_HALT drive-by points');
assert.match(tourGrid, /11 dedicated halt stops[\s\S]*?33 scenic drive-by viewing points/, 'public directory totals must match the underlying catalogue');

assert.match(initial, /id: 'bollywood_museum'[\s\S]*?amount: 165,[\s\S]*?exactPriceConfirmed: true/, 'Bollywood Museum owner-listed ticket rate must remain ₹165');
assert.match(initial, /name: 'Bollywood Museum',[\s\S]*?entryFee: 165,[\s\S]*?See Attraction Tickets & Charges for the current rate/, 'tour-point entry fee must remain recorded while directing customers to the central rate list');
assert.match(storage, /static getTourPoints\(\): TourPoint\[\] \{[\s\S]*?return getItem<TourPoint\[]>\(KEYS\.TOUR_POINTS, INITIAL_TOUR_POINTS\);/, 'saved Admin attraction rates must not be automatically overwritten');
assert.match(attractionPage, /optionalTicketCharges\.map[\s\S]*?charge\.amount/, 'public attraction page must render optional ticket prices from Admin-controlled Extra Charges');
assert.match(attractionPage, /collected by the Tour Guide inside the bus/, 'optional attraction ticket fees must be collected by the Tour Guide on the bus');
assert.match(pricingPage, /extraCharges\.filter\(charge => charge\.active && charge\.type === 'optional' && charge\.amount > 0\)/, 'pricing page must use current Admin-controlled optional ticket rates');
assert.match(adminReports, /Actual rate \/ person[\s\S]*?recBollywoodRate/, 'Admin attraction log must allow actual per-tour Bollywood rate');
assert.match(adminReports, /bollywoodCollected: recBollywoodPax \* recBollywoodRate/, 'Admin logs must store actual collected amount instead of a hardcoded tariff');
assert.match(adminReports, /totalCollected: recBoatPax \* recBoatRate \+ recMuseumPax \* recMuseumRate \+ recOramaPax \* recOramaRate \+ recBollywoodPax \* recBollywoodRate/, 'Admin total must use the actual rates entered for the tour');
assert.match(legal, /customer’s UPI account used for the booking payment[\s\S]*?5 to 7 working days[\s\S]*?does not currently process automated gateway refunds/, 'refund wording must reflect manual UPI processing, not unavailable card/netbanking gateway refunds');
assert.doesNotMatch(legal, /Debit\/Credit Card, or Net Banking|confirmation SMS\/email is dispatched/, 'policy must not promise unsupported payment channels or automated notifications');

console.log('PASS Update 85 attraction ticket prices and owner-controlled rate preservation — 11 assertions.');
