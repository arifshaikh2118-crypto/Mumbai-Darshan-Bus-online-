const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const storage = fs.readFileSync(path.join(root, 'src/services/storage.ts'), 'utf8');
const form = fs.readFileSync(path.join(root, 'src/components/BookingForm.tsx'), 'utf8');

assert.match(storage, /PENDING_BOOKING_RETRY:\s*'mdb_pending_booking_retry_v1'/,
  'pending booking retry pointer must use a dedicated versioned storage key');
assert.match(storage, /static savePendingBookingRetryId\(id: string\): boolean[\s\S]*?this\.getBookingById\(cleanId\)[\s\S]*?localStorage\.setItem\(KEYS\.PENDING_BOOKING_RETRY, cleanId\)[\s\S]*?localStorage\.getItem\(KEYS\.PENDING_BOOKING_RETRY\)/,
  'save helper must verify the booking exists and read back the persisted stable ID pointer');
assert.match(storage, /static createBooking\([\s\S]*?this\.saveBookings\(bookings\)[\s\S]*?const persistedBooking = this\.getBookingById\(newBooking\.id\)[\s\S]*?if \(!persistedBooking\)[\s\S]*?throw new Error/,
  'booking creation must fail closed if the complete local record cannot be read back after save');
assert.match(storage, /static getPendingBookingForRetry\(\): Booking \| null[\s\S]*?this\.getBookingById\(id\)[\s\S]*?booking\.syncedToGoogleSheets === true/,
  'restore helper must resolve the ID from local booking records and ignore already synced bookings');
assert.match(storage, /static clearPendingBookingRetryId\(id\?: string\): void[\s\S]*?current\.toUpperCase\(\) !== id\.trim\(\)\.toUpperCase\(\)/,
  'clear helper must not clear a newer/different pending ID');

assert.match(form, /React\.useEffect\(\(\) => \{[\s\S]*?StorageService\.getPendingBookingForRetry\(\)[\s\S]*?setCurrentStep\(6\)/,
  'booking form must restore unresolved booking after mount');
assert.match(form, /const savedBooking = pendingBooking \|\| StorageService\.createBooking\(bookingData\)/,
  'retry must reuse pending booking rather than create a new booking ID');
assert.match(form, /StorageService\.savePendingBookingRetryId\(savedBooking\.id\)[\s\S]*?if \(!retryPointerSaved\)[\s\S]*?return;[\s\S]*?StorageService\.syncBookingToGoogleSheets/,
  'booking sync must stop before network submission if refresh-safe retry pointer cannot be persisted');
assert.match(form, /StorageService\.clearPendingBookingRetryId\(savedBooking\.id\)/,
  'successful acknowledgement must clear only the same pending ID');
assert.match(form, /if \(!pendingBooking && !validateStep\(4\)\) return/,
  'restored retry must not require the now-empty original form fields');
assert.match(form, /Retry Same Booking \(\$\{pendingBooking\.id\}\)/,
  'restored state must offer retry of the same visible Booking ID');
assert.match(form, /do not submit a new booking/,
  'recovery message must warn against duplicate booking submission');
assert.match(form, /No request was sent to Google Sheets and no payment was taken/,
  'failed local recovery persistence must explicitly fail closed before network or payment');

console.log('PASS: booking retry recovery after refresh — 13 assertions.');
