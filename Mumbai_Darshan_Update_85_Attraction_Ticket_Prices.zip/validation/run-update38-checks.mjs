#!/usr/bin/env node
import { readdirSync, readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const testsDir = path.join(root, 'google-apps-script', 'tests');
const tests = readdirSync(testsDir).filter((name) => name.endsWith('.cjs')).sort();
let failed = 0;

for (const name of tests) {
  const file = path.join(testsDir, name);
  const result = spawnSync(process.execPath, [file], { cwd: root, encoding: 'utf8' });
  const passed = result.status === 0;
  console.log(`${passed ? 'PASS' : 'FAIL'} ${name}`);
  if (result.stdout?.trim()) console.log(result.stdout.trim());
  if (result.stderr?.trim()) console.error(result.stderr.trim());
  if (!passed) failed += 1;
}

const codeGs = path.join(root, 'google-apps-script', 'Code.gs');
const syntax = spawnSync(process.execPath, ['--check'], {
  cwd: root,
  input: readFileSync(codeGs, 'utf8'),
  encoding: 'utf8'
});
const syntaxPassed = syntax.status === 0;
console.log(`${syntaxPassed ? 'PASS' : 'FAIL'} Apps Script Code.gs syntax`);
if (syntax.stderr?.trim()) console.error(syntax.stderr.trim());
if (!syntaxPassed) failed += 1;

console.log(`\nOffline validation: ${tests.length + 1 - failed}/${tests.length + 1} checks passed.`);
process.exitCode = failed === 0 ? 0 : 1;
