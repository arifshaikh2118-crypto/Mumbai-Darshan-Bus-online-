const fs = require('fs');
const assert = require('assert');
const path = require('path');

const source = fs.readFileSync(path.join(__dirname, '..', 'server.ts'), 'utf8');
const routeStart = source.indexOf("app.post('/api/admin/login'");
assert.notStrictEqual(routeStart, -1, 'Admin login route must exist');
const routeEnd = source.indexOf("\n});", routeStart);
assert.notStrictEqual(routeEnd, -1, 'Admin login route must close');
const route = source.slice(routeStart, routeEnd);

const blockedCheck = route.indexOf('if (attempt.blockedUntil > now)');
const expiredReset = route.indexOf('if (attempt.resetAt <= now)');
const failedIncrement = route.indexOf('attempt.count += 1');
assert.ok(blockedCheck >= 0 && expiredReset > blockedCheck && failedIncrement > expiredReset,
  'Active lockout must be enforced first, expired window reset second, and failed attempt counted last');
assert.match(route, /attempt\.count = 0;\s*attempt\.resetAt = now \+ 15 \* 60 \* 1000;\s*attempt\.blockedUntil = 0;/,
  'Expired cooldown must clear the stale counter and block state and start a fresh window');
assert.doesNotMatch(route, /if\s*\(attempt\.resetAt\s*<\s*now\)\s*\{\s*attempt\.count\s*=\s*1;/,
  'Do not reset the window after incrementing the failed-attempt counter');

assert.match(source, /createAdminLoginAttemptStore\(5000, 256\)/, 'Admin login attempt records must be memory-bounded');
assert.match(source, /const UPSTREAM_TIMEOUT_MS = 30_000;/, 'Upstream timeout must be explicitly bounded');
assert.strictEqual((source.match(/AbortSignal\.timeout\(UPSTREAM_TIMEOUT_MS\)/g) || []).length, 3,
  'Admin, public booking and public sync Apps Script calls must all have bounded timeouts');

function applyPolicy(state, now, failed) {
  if (state.blockedUntil > now) return { blocked: true, state };
  if (state.resetAt <= now) {
    state.count = 0;
    state.resetAt = now + 15 * 60 * 1000;
    state.blockedUntil = 0;
  }
  if (failed) {
    state.count += 1;
    if (state.count >= 5) state.blockedUntil = now + 15 * 60 * 1000;
  }
  return { blocked: false, state };
}

let state = { count: 4, resetAt: 1000, blockedUntil: 0 };
let result = applyPolicy(state, 999, true);
assert.strictEqual(result.state.count, 5, 'Fifth failure inside the active window must count');
assert.strictEqual(result.state.blockedUntil, 999 + 15 * 60 * 1000, 'Fifth failure must start cooldown');
result = applyPolicy(result.state, 999 + 15 * 60 * 1000 + 1, true);
assert.strictEqual(result.blocked, false, 'Expired cooldown must allow a fresh attempt');
assert.strictEqual(result.state.count, 1, 'First post-cooldown failure must be count one, not an immediate re-lock');
assert.strictEqual(result.state.blockedUntil, 0, 'Expired cooldown must clear old block');
console.log('PASS Admin login throttle and upstream resilience: lockout expiry resets before counting; all three Apps Script fetch paths have a 30-second timeout.');
