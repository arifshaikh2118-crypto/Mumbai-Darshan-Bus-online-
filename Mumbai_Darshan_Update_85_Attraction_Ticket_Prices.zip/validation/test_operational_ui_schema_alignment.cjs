const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const schema = JSON.parse(fs.readFileSync(path.join(root, 'schema', 'SCHEMA_SPEC.json'), 'utf8'));
const ui = fs.readFileSync(path.join(root, 'src', 'components', 'admin', 'OperationalSheetsManager.tsx'), 'utf8');
const block = ui.match(/const SHEETS:\s*SheetConfig\[\]\s*=\s*\[([\s\S]*?)\n\];/);
assert.ok(block, 'Operational Sheets Manager config must be present');
const keyToTab = {
  pickupPoints: 'PickupPoints',
  packageOptions: 'PackageOptions',
  bookingDates: 'BookingDates',
  rentalVehicles: 'rental_vehicles',
  websiteContent: 'website_content',
  attractionPoints: 'AttractionPoints',
  attractionTickets: 'AttractionTickets'
};
const configs = [...block[1].matchAll(/\{\s*key:\s*'([^']+)'[\s\S]*?headers:\s*\[([^\]]*)\][\s\S]*?required:\s*\[([^\]]*)\][\s\S]*?deleteKey:\s*\[([^\]]*)\]\s*\}/g)];
assert.strictEqual(configs.length, 7, `Expected seven operational sheet configs, got ${configs.length}`);
const parse = raw => [...raw.matchAll(/'([^']+)'/g)].map(m => m[1]);
for (const cfg of configs) {
  const key = cfg[1], tab = keyToTab[key];
  assert.ok(tab, `Unknown UI operational sheet key ${key}`);
  const allowed = schema.tabs[tab];
  assert.ok(Array.isArray(allowed), `Schema tab missing for ${key}: ${tab}`);
  const headers = parse(cfg[2]), required = parse(cfg[3]), deleteKey = parse(cfg[4]);
  for (const header of headers) assert.ok(allowed.includes(header), `${key}: UI header not in approved schema: ${header}`);
  for (const field of required) assert.ok(headers.includes(field), `${key}: required field is not editable/displayed: ${field}`);
  for (const field of deleteKey) assert.ok(required.includes(field), `${key}: delete key is not part of the required stable key: ${field}`);
}
console.log('PASS operational sheet UI schema: all 7 editable sheets, UI headers, required keys and delete keys match the approved 17-tab schema.');
