const fs = require('fs');
const assert = require('assert');
const helper = fs.readFileSync('src/services/adminSession.ts', 'utf8');
const layout = fs.readFileSync('src/components/admin/AdminLayout.tsx', 'utf8');
const components = [
  'src/components/admin/OperationalSheetsManager.tsx',
  'src/components/admin/AdminNotificationPanel.tsx',
  'src/components/admin/AdminRentalsTab.tsx',
  'src/components/admin/AdminCancellationsPanel.tsx'
].map(file => fs.readFileSync(file, 'utf8'));
assert.match(helper, /readAdminSessionToken[\s\S]*?try[\s\S]*?sessionStorage\.getItem[\s\S]*?catch[\s\S]*?return null/,
  'Token reads must fail closed when sessionStorage throws');
assert.match(helper, /storeAdminSession[\s\S]*?setItem\('mdb_admin_token'[\s\S]*?getItem\('mdb_admin_token'\) === token/,
  'Session persistence must be verified by reading the stored token back');
assert.match(helper, /clearAdminSession[\s\S]*?removeItem\('mdb_admin_token'[\s\S]*?removeItem\('mdb_admin_auth'/,
  'Session cleanup must remove both session keys');
assert.doesNotMatch(layout, /sessionStorage\.(?:getItem|removeItem)\(/,
  'AdminLayout must use guarded session helpers rather than direct storage access');
for (const source of components) {
  assert.match(source, /readAdminSessionToken/,
    'Every Admin action panel must use guarded token reads');
  assert.doesNotMatch(source, /sessionStorage\.getItem\(/,
    'Admin action panels must not read sessionStorage directly');
}
console.log('PASS: Admin token reads, writes, verification and cleanup fail closed across the Admin UI.');
