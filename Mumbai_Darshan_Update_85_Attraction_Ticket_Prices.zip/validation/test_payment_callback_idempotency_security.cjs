const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const gas = fs.readFileSync(path.join(__dirname, '..', 'google-apps-script', 'Code.gs'), 'utf8');
const start = gas.indexOf('function handleVerifiedPayment(d)');
const end = gas.indexOf('/** Send confirmation emails only after', start);
assert.ok(start >= 0 && end > start, 'payment verification handler must exist');
const handler = gas.slice(start, end);

assert.match(handler, /constantTimeEquals_\(configuredSecret,\s*suppliedCallbackSecret\)/,
  'payment callback secret must use constant-time comparison');
assert.match(handler, /d\.providerVerified !== true/,
  'payment must require a strict boolean provider verification flag');
assert.match(handler, /transaction reference or payment ID is already linked to another booking/,
  'a provider transaction/payment ID cannot be reused for another booking');
assert.match(handler, /existingLedgerStatus === 'verified'/,
  'an already verified ledger row must be detected before writing');
assert.match(handler, /sameVerifiedEvent[\s\S]*?String\(existingLedgerRow\[0\][\s\S]*?String\(existingLedgerRow\[5\][\s\S]*?Math\.round\(Number\(existingLedgerRow\[3\]/,
  'idempotent retry must match payment ID, transaction reference and amount');
assert.match(handler, /if \(!sameVerifiedEvent\)[\s\S]*?status: 'reconciliation_required'[\s\S]*?Existing ledger evidence was preserved/,
  'a different payment event must fail closed and preserve verified ledger evidence');
assert.match(handler, /safeSheetText_\(paymentId,\s*150\)/,
  'provider payment ID must be bounded and formula-safe before writing');
assert.match(handler, /safeSheetText_\(transactionRef,\s*150\)/,
  'provider transaction reference must be bounded and formula-safe before writing');
assert.match(handler, /safeSheetText_\(d\.provider \|\| 'Online Payment Gateway',\s*80\)/,
  'provider label must be bounded and formula-safe before writing');
assert.match(handler, /paymentSheet\.getRange\(paymentRow,\s*7\)\.setValue\('Verified'\)/,
  'only the trusted callback handler may mark the ledger verified');

console.log('PASS: payment callback authentication and verified-ledger idempotency — 10 assertions.');
