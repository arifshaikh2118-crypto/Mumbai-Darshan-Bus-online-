const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const panel = fs.readFileSync(path.join(root, 'src/components/admin/AdminCancellationsPanel.tsx'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');

assert.match(panel, /data\.result\?\.status/,
  'frontend must inspect the nested Apps Script result status');
assert.match(panel, /\['error', 'not_found', 'duplicate'\]\.includes\(/,
  'nested Apps Script business errors must not be treated as successful updates');
assert.match(panel, /throw new Error\(data\.result\?\.message \|\| data\.error \|\| 'Update failed'\)/,
  'surface the actual Apps Script error message');
assert.match(server, /callAppsScriptAdmin\('ADMIN_UPDATE_REFUND_STATUS'/,
  'refund status route must continue forwarding to the Apps Script state machine');
assert.match(panel, /Complete the actual manual refund before marking this record as Refunded/,
  'manual refund validation message must be English');
assert.doesNotMatch(panel, /[\u0900-\u097F]/,
  'cancellation panel must not contain Devanagari UI copy');
console.log('PASS: Admin cancellation UI response handling and English copy — 6 assertions.');
