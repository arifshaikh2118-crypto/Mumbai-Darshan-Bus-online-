# Update 26 — Offline Validation and Browser Test Readiness

Date: 11 November 2026

## Verified locally in this checkpoint
- All six existing Apps Script / Admin / rental policy test suites execute and pass.
- Apps Script `Code.gs` passes Node syntax parsing.
- All 26 TypeScript/TSX source files transpile with zero syntax diagnostics using the globally available TypeScript compiler.
- The source archive is checked with `unzip -t` after packaging.

## Not verified (do not treat as passed)
- Full TypeScript semantic checking (`npm run lint`).
- Vite production build.
- Browser E2E against the current React bundle.
- Google Sheets persistence, because no staging spreadsheet or deployed Apps Script endpoint is configured.

## Why blocked
The project dependencies are not present in this environment. `npm install --legacy-peer-deps --no-audit --no-fund` timed out; offline installation cannot resolve missing packages. `express`, `react`, `vite`, `playwright` and `puppeteer` are unavailable locally. Chromium exists, but without the built React bundle and browser automation library it cannot execute the current application UI meaningfully.

## Browser E2E checklist for a network-enabled staging runner
For each of the seven approved operational tabs (`PickupPoints`, `PackageOptions`, `BookingDates`, `rental_vehicles`, `website_content`, `AttractionPoints`, `AttractionTickets`):
1. Sign in with an active `AdminUsers` account and verify protected data loads.
2. Create a unique test row; verify success toast and refreshed row.
3. Reload the browser and verify the row persists from Google Sheets.
4. Edit a non-key field; verify the row updates and its stable key remains unchanged.
5. Attempt invalid numeric data and missing required key; verify client/server rejection.
6. Delete the test row; confirm dialog appears and refreshed data no longer contains it.
7. Verify matching `activity_log` create/update/delete entries.
8. Sign out / expire session and verify reads and writes return unauthorized.

Use only a dedicated staging spreadsheet. Never run destructive CRUD tests against production data.

## Required commands on a network-enabled runner
```bash
npm install --legacy-peer-deps --no-audit --no-fund
npm run lint
npm run build
```
Then run browser E2E with a supported browser automation runner and staging credentials supplied through secure environment variables. Do not commit secrets or add them to `.env.example`.
