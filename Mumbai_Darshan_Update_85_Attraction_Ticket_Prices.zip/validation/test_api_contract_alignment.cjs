const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');
const gas = fs.readFileSync(path.join(root, 'google-apps-script', 'Code.gs'), 'utf8');

const routes = new Map();
for (const match of server.matchAll(/app\.(get|post|put|delete)\(['"]([^'"]+)['"]\s*,([\s\S]*?)(?=\napp\.|\n\/\/|\n\/\*|$)/g)) {
  routes.set(`${match[1].toUpperCase()} ${match[2]}`, match[3]);
}
assert.ok(routes.size >= 14, `Expected Express route inventory; found ${routes.size}`);

const frontendPaths = new Set();
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (/\.(ts|tsx|js|jsx)$/.test(entry.name)) {
      const source = fs.readFileSync(full, 'utf8');
      for (const m of source.matchAll(/fetch\(\s*['"`](\/api\/[A-Za-z0-9_/${}./-]+)/g)) frontendPaths.add(m[1]);
    }
  }
}
walk(path.join(root, 'src'));

const missing = [];
for (const apiPath of frontendPaths) {
  const found = [...routes.keys()].some(key => key.endsWith(` ${apiPath}`));
  if (!found) missing.push(apiPath);
}
assert.deepStrictEqual(missing, [], `Frontend calls missing Express routes: ${missing.join(', ')}`);

const adminRoutes = [...routes.entries()].filter(([key]) => key.includes(' /api/admin/') && !key.endsWith(' /api/admin/login'));
for (const [key, body] of adminRoutes) {
  assert.match(body, /requireAdmin/, `Protected Admin route lacks requireAdmin middleware: ${key}`);
}
assert.ok(routes.has('POST /api/admin/login'), 'Admin login route must exist');

const adminActions = new Set([...server.matchAll(/callAppsScriptAdmin\(\s*['"]([A-Z0-9_]+)['"]/g)].map(m => m[1]));
const gasActions = new Set([...gas.matchAll(/case\s+['"]([A-Z0-9_]+)['"]\s*:/g)].map(m => m[1]));
const missingActions = [...adminActions].filter(action => !gasActions.has(action));
assert.deepStrictEqual(missingActions, [], `Express Admin actions missing from Apps Script doPost switch: ${missingActions.join(', ')}`);

for (const required of ['NEW_BOOKING', 'NEW_RENTAL_ENQUIRY', 'CAR_RENTAL', 'PING_TEST']) {
  assert.ok(server.includes(`'${required}'`), `Public proxy allowlist missing ${required}`);
  assert.ok(gasActions.has(required), `Apps Script doPost missing ${required}`);
}

console.log(`PASS API contract: ${frontendPaths.size} frontend API paths have Express routes; ${adminRoutes.length} Admin routes use requireAdmin; ${adminActions.size} Admin Apps Script actions are dispatched.`);
