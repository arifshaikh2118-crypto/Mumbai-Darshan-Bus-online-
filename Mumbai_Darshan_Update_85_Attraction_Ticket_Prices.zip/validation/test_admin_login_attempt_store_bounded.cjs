const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');

const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'server/adminLoginAttemptStore.ts'), 'utf8');
const serverSource = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');
assert.match(serverSource, /createAdminLoginAttemptStore\(5000, 256\)/, 'Admin login state must use a bounded store');
assert.match(serverSource, /adminLoginAttempts\.getOrCreate\(ip, now\)/, 'Admin login must reject new IPs when bounded store is full');
assert.match(serverSource, /if \(!attempt\) return res\.status\(429\)/, 'capacity exhaustion must fail closed');
assert.doesNotMatch(serverSource, /adminLoginAttempts\.set\(/, 'route must not bypass bounded store admission');

const output = ts.transpileModule(source, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 }
}).outputText;
const sandbox = { exports: {}, Map };
vm.runInNewContext(output, sandbox);
const { createAdminLoginAttemptStore } = sandbox.exports;

const store = createAdminLoginAttemptStore(2, 100);
const first = store.getOrCreate('ip-a', 100);
assert.ok(first, 'first IP is admitted');
first.count = 4;
first.blockedUntil = 1000;
first.resetAt = 1000;
assert.equal(store.getOrCreate('ip-b', 100)?.count, 0, 'second IP is admitted');
assert.equal(store.getOrCreate('ip-c', 100), null, 'new IP is rejected at capacity');
assert.equal(store.size(), 2, 'store never exceeds configured capacity');
assert.equal(store.getOrCreate('ip-a', 200), first, 'existing IP can still read its active lockout state');
assert.equal(store.getOrCreate('ip-c', 1001)?.count, 0, 'expired entries are pruned before admitting new IP');
assert.equal(store.size(), 2, 'expired lockout entry is removed before admission');
store.delete('ip-b');
assert.equal(store.size(), 1, 'successful login can clear its IP entry');

const periodic = createAdminLoginAttemptStore(10, 2);
periodic.getOrCreate('expired', 0).resetAt = 4;
periodic.getOrCreate('keep', 5);
periodic.getOrCreate('keep', 6); // periodic prune runs on this call
assert.equal(periodic.size(), 1, 'periodic pruning removes expired attempt records');

console.log('Bounded Admin login attempt store: 10 assertions passed.');
