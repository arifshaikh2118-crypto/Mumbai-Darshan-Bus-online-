const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const server = fs.readFileSync(path.join(__dirname, '..', 'server.ts'), 'utf8');

assert.match(server, /express\.json\(\{\s*limit:\s*'256kb'\s*\}\)/, 'global JSON parser must reject bodies above 256 KB before route handlers');
assert.doesNotMatch(server, /express\.json\(\{\s*limit:\s*'10mb'/, 'the previous 10 MB parser allowance must not return');
assert.match(server, /error\?\.type === 'entity\.too\.large' \|\| error\?\.status === 413/, 'oversized parser errors must be recognized');
assert.match(server, /status\(413\)\.json\(\{ success: false, error: 'Request body exceeds the 256 KB server limit\.'/, 'oversized requests must receive a JSON 413 response');
assert.match(server, /error\?\.type === 'entity\.parse\.failed'/, 'malformed JSON parser errors must be recognized');
assert.match(server, /status\(400\)\.json\(\{ success: false, error: 'Request body must contain valid JSON\.'/, 'malformed JSON must receive a JSON 400 response');
assert.match(server, /app\.use\(\(error: any, req: any, res: any, next: any\) => \{[\s\S]*?entity\.parse\.failed[\s\S]*?\}\);\s*\/\/ Setup Vite/, 'parser error middleware must be registered after API routes and before static app setup');
console.log('JSON body size/error handling guard: 7 assertions passed.');
