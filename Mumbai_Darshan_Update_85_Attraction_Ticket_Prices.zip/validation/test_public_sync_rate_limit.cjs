const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const server = fs.readFileSync(path.join(__dirname, '..', 'server.ts'), 'utf8');

assert.match(server, /allowedPublicActions = new Set\(\['NEW_BOOKING', 'NEW_RENTAL_ENQUIRY', 'CAR_RENTAL', 'PING_TEST'\]\)/, 'only approved public actions remain allowed');
assert.match(server, /payloadBytes > 64 \* 1024/, 'public proxy payloads must be capped at 64 KB');
assert.match(server, /payload\.action === 'PING_TEST' \? 10 : 8/, 'public booking and rental writes have an 8-per-window limit; ping has 10');
assert.match(server, /allowPublicAction\(ip, `sync:\$\{payload\.action\}`, requestLimit, 10 \* 60 \* 1000\)/, 'sync writes must be throttled per IP and action');
assert.match(server, /status\(429\)\.json\(\{ success: false, error: 'Too many requests/, 'rate-limited requests must receive HTTP 429');
assert.match(server, /const configuredUrl = process\.env\.GOOGLE_APPS_SCRIPT_URL/, 'proxy remains pinned to the server-configured webhook');
assert.match(server, /const \{ payload \} = req\.body \|\| \{\}/, 'proxy does not require a browser-supplied webhook URL');
assert.doesNotMatch(server, /webhookUrl !== configuredUrl|typeof webhookUrl === 'string'/, 'browser cannot select or override the Apps Script destination');
assert.match(server, /!allowedPublicActions\.has\(payload\.action\)/, 'Admin-only actions remain blocked from the public proxy');
console.log('Public sync proxy rate-limit guard: 9 assertions passed.');
