const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'google-apps-script/Code.gs'), 'utf8');
const start = source.indexOf('function handlePublicGetConfig_() {');
const end = source.indexOf('\n\n/**', start);
assert.ok(start >= 0 && end > start, 'public config handler must exist');
const handler = source.slice(start, end);
const packageKeys = ['non_ac_no_lunch', 'ac_no_lunch', 'non_ac_lunch', 'ac_lunch'];
const routeKeys = ['western', 'central', 'harbour', 'kalyan_dombivli'];
const packageRows = [];
routeKeys.forEach((route, r) => packageKeys.forEach((key, i) => packageRows.push({
  'Package Key': key, 'Route Group': route, Label: key, 'Price INR': [200,300,400,500][i] + (r >= 2 ? 50 : 0),
  'Offer Enabled': false, 'Offer Discount INR': 0, 'Price Review Status': 'Approved',
  Secret: 'must never be copied'
})));
const pickupRows = [
  { Route: 'western', 'Pickup Point': 'Borivali East', 'Sort Order': 1, Active: true, Secret: 'no' },
  { Route: 'central', 'Pickup Point': 'Dadar', 'Sort Order': 2, Active: false, Secret: 'no' }
];
const sandbox = {
  SHEET_NAMES: { PACKAGE_OPTIONS: 'PackageOptions', PICKUP_POINTS: 'PickupPoints' },
  getRequiredSheet_(name) { return { name }; },
  readRentalPricingSetting_() { return { localPackages: Array.from({length:6},(_,i)=>({id:'loc_'+i})), outstationRates: Array.from({length:16},(_,i)=>({id:'out_'+i})) }; },
  rowsAsObjects_(sheet) { return sheet.name === 'PackageOptions' ? packageRows : pickupRows; },
  Date,
  normalizeRouteGroup_(value) { const v = String(value || '').toLowerCase(); if (v.includes('western')) return 'western'; if (v.includes('central')) return 'central'; if (v.includes('harbour') || v.includes('harbor')) return 'harbour'; if (v.includes('kalyan') || v.includes('dombiv')) return 'kalyan_dombivli'; return ''; }
};
vm.createContext(sandbox);
vm.runInContext(handler, sandbox);
const result = sandbox.handlePublicGetConfig_();
assert.equal(result.status, 'success');
assert.equal(result.config.packages.length, 16);
assert.equal(result.config.pickupPoints.length, 2);
assert.equal(result.config.rentalPricing.localPackages.length, 6);
assert.equal(result.config.rentalPricing.outstationRates.length, 16);
assert.equal(result.config.packages.find(x => x.packageKey === 'ac_lunch' && x.routeGroup === 'harbour').priceINR, 550);
assert.deepEqual(Object.keys(result.config.packages[0]).sort(), ['label','offerDiscountINR','offerEnabled','packageKey','priceINR','priceReviewStatus','routeGroup'].sort());
assert.deepEqual(Object.keys(result.config.pickupPoints[0]).sort(), ['active','name','route','sortOrder'].sort());
assert.equal(result.config.pickupPoints[1].active, false);
assert.throws(() => {
  packageRows[15] = { ...packageRows[0] };
  sandbox.handlePublicGetConfig_();
}, /Duplicate PackageOptions/);
packageRows[15] = { 'Package Key': 'ac_lunch', 'Route Group': 'kalyan_dombivli', Label: 'AC lunch', 'Price INR': 550, 'Offer Enabled': false, 'Offer Discount INR': 0, 'Price Review Status': 'Approved' };
pickupRows.push({ ...pickupRows[0] });
assert.equal(sandbox.handlePublicGetConfig_().status, 'error', 'duplicate pickup identity must fail closed');
console.log('PASS Apps Script public configuration runtime — 9 assertions.');
