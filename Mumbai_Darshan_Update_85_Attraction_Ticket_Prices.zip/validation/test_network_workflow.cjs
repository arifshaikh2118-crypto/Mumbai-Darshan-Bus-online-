const fs = require('fs');
const assert = require('assert');
const path = require('path');

const root = path.resolve(__dirname, '..');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/network-build-validation.yml'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

assert.match(workflow, /workflow_dispatch:/, 'CI workflow must remain manual-only');
assert.match(workflow, /npm run test:offline/, 'CI must run offline regression tests');
assert.match(workflow, /npm install --legacy-peer-deps --no-audit --no-fund/, 'CI must generate a lockfile using npm install');
assert.match(workflow, /test -s package-lock\.json/, 'CI must reject a missing/empty lockfile');
assert.match(workflow, /npm ci --legacy-peer-deps --no-audit --no-fund/, 'CI must verify reproducible clean installation');
assert.match(workflow, /npm run lint/, 'CI must run full TypeScript check');
assert.match(workflow, /npm run build/, 'CI must run Vite production build');
assert.match(workflow, /mumbai-darshan-package-lock-validation/, 'CI must upload generated lockfile for review');
assert.doesNotMatch(workflow, /firebase deploy|gcloud run deploy|firebase hosting:channel:deploy/i, 'CI must not deploy');
assert.strictEqual(pkg.scripts['test:offline'], 'node validation/run-update43-checks.mjs', 'package script must point to Update 41 runner');

console.log('PASS Network runner workflow: manual-only, offline tests, generated lockfile verification, clean npm ci, lint/build, lockfile artifact, no deployment.');
