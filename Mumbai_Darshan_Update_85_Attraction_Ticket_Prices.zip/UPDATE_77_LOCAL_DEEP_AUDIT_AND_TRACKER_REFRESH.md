# Update 77 — Local Deep Audit Cross-Check & Progress Tracker Refresh

**Project:** Mumbai Darshan Bus Online  
**Date:** 21 November 2026  
**Baseline:** Update 76 — Deep Project Audit, Server-Owned Sync & SEO Discovery  
**Scope:** Local source/package audit only. Payment, Google Sheets creation/setup, Apps Script deployment, GitHub, Preview, email activation and all live deployment remain deferred.

## 1. Work completed in this pass

### A. Re-opened and cross-checked the three Update 76 deliverables
- Inspected the complete Update 76 project ZIP (254 archive entries); ZIP integrity check passed.
- Cross-checked the project index and Update 76 deep-audit report against the actual source package, package scripts, Firebase configuration, Express server, Apps Script source, schema manifest and validation suite.
- Confirmed that the Update 76 report's release blockers are still present in the actual package; they are not merely stale tracker notes.
- Refreshed the project index and added this Update 77 report to the ZIP.

### B. Re-ran local validation from the supplied ZIP
| Check | Result |
|---|---:|
| `npm run test:offline` | **43/43 PASS** |
| JavaScript `.cjs` / `.mjs` syntax | **49 files PASS** |
| TypeScript / TSX syntax transpilation | **34 files, 0 errors** |
| JSON configuration parse | **6/6 PASS** |
| Apps Script syntax | **PASS** |
| ZIP integrity (input and rebuilt output) | **PASS** |
| English-copy source guard | **35 source/HTML files PASS** (included in offline suite) |

### C. Reconfirmed build limitations
- `package-lock.json` is absent.
- `bun.lock` exists but is **0 bytes** and is not a usable lockfile.
- `node_modules` is absent.
- `tsc --noEmit` was attempted and is blocked by missing `vite/client` type definitions (`TS2688`).
- The Vite production build cannot run because Vite is not installed (`vite: not found`).
- No semantic TypeScript project check, browser E2E, mobile real-device test or deployed API test is claimed as passed.

## 2. Confirmed work already completed in source

- Server-owned public booking/rental sync: browser-local webhook URL and auto-sync dependency removed; Express reads `GOOGLE_APPS_SCRIPT_URL` only from private server configuration and fails closed if missing/invalid.
- Public proxy controls remain: explicit action allowlist, payload limits, URL validation, timeout and per-IP/action throttling.
- SEO source assets are present: `public/robots.txt`, homepage-only `public/sitemap.xml`, canonical URL and social metadata.
- Booking and rental retry recovery, local-calendar date validation, customer-text formula-injection protection, Admin session-storage fail-closed behavior, bounded rate-limit/login stores, payment-ledger verification/reconciliation, cancellation/refund state-machine protections and duplicate-record guards remain present.
- Rental enquiry remains inquiry-only; no owner/customer rental email workflow was added.
- Approved schema manifest remains 17 tabs / 139 headers. No tab or header was changed.

## 3. Remaining work — not completed, with reason

### P0 — Must be resolved before any deployment
1. **Express backend hosting:** `firebase.json` still serves static `dist` and rewrites all paths to `/index.html`; there is no verified `/api/**` rewrite to an Express host. Firebase Hosting alone will not run `server.ts`. Backend host, service ID, region, runtime and secrets need owner/developer confirmation.
2. **Live staging:** no live Google Sheet, Apps Script deployment, active AdminUsers roster, server secrets, read/write path or staging test was accessed or verified.

### P1 — Local product/data-flow gaps requiring an explicit decision
3. **Public configuration is still browser-local:** routes, packages, offers, pickup points, tour/gallery content and rental rates continue to use `StorageService` / `localStorage` / `INITIAL_*`. The later Sheets-backed public configuration endpoint and hydration are intentionally deferred.
4. **Approved schema is incomplete for public hydration:** PickupPoints lacks pickup time, landmark, reporting time and map URL; PackageOptions lacks explicit `isAC`, `hasLunch` and description fields; there is no approved local/outstation rental-pricing or group-enquiry tab. The original workbook was not supplied/reconciled. No schema changes were invented.
5. **Group booking is local-only:** `GroupBookingPage.tsx` saves to browser storage but displays “Group Booking Request Submitted”; no Express endpoint or approved group-enquiry sheet exists. This needs an owner decision: approve a dedicated schema/API or change the experience to an explicit enquiry handoff. Left unchanged to avoid inventing a data flow or changing the approved UI/business behavior.

### P2 — Build and user-flow verification
6. Generate/review a real dependency lockfile on a network-enabled runner; then run clean `npm ci`, lint and production build.
7. Run browser E2E for booking/retry, rental inquiry/retry, lookup, cancellation, Admin login/session expiry, protected status changes, refunds, reports and all seven operational CRUD tabs.
8. Test mobile booking and verify the rental enquiry panel remains immediately below the booking form.
9. Verify the generated `dist` contains `robots.txt` and `sitemap.xml`; this cannot be confirmed until a successful Vite build.
10. Review runtime content (especially pickup, package, rental and group-booking text) in approved staging. The source English guard does not inspect future Sheet content.

## 4. Explicitly deferred — not attempted

- PhonePe/payment gateway integration and automated refunds.
- Google Sheet creation/setup and live data migration.
- Apps Script production deployment, triggers and live email activation.
- GitHub commit/push, Actions/network build, Preview refresh, Firebase/Cloud Run deployment, DNS/domain changes and production deployment.
- Public Sheets configuration endpoint/hydration until the later approved Sheets phase.
- No manual Google Sheet creation is required; when that phase is approved, the setup code must create the spreadsheet and approved tabs automatically.

## 5. Change and safety record

- Source code, customer UI, pricing, route rules, booking advance, rental rules, schema headers and live data were **not changed** in this pass.
- Only project tracking/audit documentation was refreshed and added.
- No external system, customer record, email, payment, deployment or DNS was touched.

**Overall status: INCOMPLETE / NOT production-ready.** The local offline regression suite passes, but the project must not be deployed until the P0 backend-hosting and staging gates, plus the remaining build and browser verification gates, are resolved.
