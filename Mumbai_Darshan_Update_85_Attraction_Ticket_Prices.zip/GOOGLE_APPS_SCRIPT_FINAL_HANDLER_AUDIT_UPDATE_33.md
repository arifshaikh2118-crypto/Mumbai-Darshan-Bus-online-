# Update 33 — Final Google Apps Script Handler Audit

**Scope:** Read-only final audit of the Update 32 source package. No handler, schema, website UI, payment, or deployment code was changed in this audit.

## Executive result

**Status: NOT READY for live production / real payment callbacks.** The approved schema checks and existing automated policy suites pass, and several important controls are present. However, the source review found two high-priority privacy/integrity issues and two medium-priority reliability/validation issues that should be fixed before enabling live traffic or payment callbacks.

## High-priority findings

### H1 — Admin data response is copied wholesale into the general activity log
- **Location:** `google-apps-script/Code.gs`, `doPost()` around lines 187–188; `ADMIN_GET_DATA` around lines 261–280.
- **Evidence:** after every action, `doPost()` calls `logActivity(..., JSON.stringify(result))`. `ADMIN_GET_DATA` returns full booking, rental, payment and cancellation datasets. This means the full Admin response—including customer names, mobile numbers, emails, special requests, and payment transaction references—can be duplicated into `activity_log.details`.
- **Impact:** unnecessary PII/financial-reference duplication in a general log; wider access and longer retention than required.
- **Required fix:** never serialize full action results into activity logs. Log only action name, success/failure, record identifier, and a safe count/summary. Add a regression test asserting that a simulated `ADMIN_GET_DATA` response's PII and transaction references never reach `activity_log`.

### H2 — Public booking intake trusts client-supplied price and payment amount
- **Location:** `handleNewBooking()` around lines 457–510.
- **Evidence:** `onlineFare` is taken from client-supplied `onlineBookingFare/grandTotal/amountInr/amount`; `advancePayable` is also accepted from the client. The handler stores these values in the booking and pending payment ledger without recalculating them against the approved `PackageOptions` and route/offer configuration.
- **Impact:** a caller can submit an arbitrary fare or advance amount. The later payment verifier checks the amount against the stored value, so a manipulated booking amount can become the expected amount for a later trusted callback.
- **Required fix:** calculate fare and advance server-side from approved route/package/offer records; reject unknown/inactive packages, invalid passenger counts and inconsistent food selections. Never use client-provided price fields as authority. Preserve the approved route-wise prices and ₹200 per-booking advance rule.

## Medium-priority findings

### M1 — Duplicate booking retry can repair the ledger using a hard-coded advance rule
- **Location:** duplicate branch in `handleNewBooking()` around lines 430–453.
- **Evidence:** when a booking row exists but its payment ledger row is missing, retry repair always creates `Math.min(200, duplicateFare)` with the label `Advance ₹200 per booking`, without recovering whether the original request was full-payment mode or another approved payment mode.
- **Impact:** a partial failure followed by retry can create a ledger row inconsistent with the original intended payment mode/amount.
- **Required fix:** persist/recover the intended payment mode/advance amount from a trusted server-side booking record or an idempotency record. If it cannot be established safely, stop and flag for Admin reconciliation rather than guessing.

### M2 — Public attempt limiter is not atomic under concurrency
- **Location:** `consumePublicAttempt_()` around lines 1161–1170.
- **Evidence:** it reads the cache counter and then writes the increment without a lock/atomic increment. Concurrent requests can both observe the same count and exceed the configured attempt limit.
- **Impact:** rate limiting is best-effort rather than a strict cap under concurrent requests.
- **Required fix:** use a lock around the read/check/write or a platform-supported atomic counter pattern; add concurrent-attempt tests. Keep the current privacy-preserving hashed cache key.

## Positive controls verified in source

- `getRequiredSheet_()` checks exact approved headers/order before writes; runtime handlers do not silently create missing tabs.
- Admin API checks the server-to-Apps-Script secret and active `AdminUsers` role roster.
- Admin settings and roster are excluded from general Admin data retrieval.
- Public booking lookup requires Booking ID plus registered mobile and returns a reduced projection.
- Public cancellation requires Booking ID plus mobile, rate limiting, and only counts verified ledger payments for refund review; no automatic refund is initiated.
- Payment verification checks a callback secret, `providerVerified === true`, booking existence, payment amount, and duplicate transaction/payment identifiers.
- Confirmation emails are deferred until verified payment; live email is controlled by the Settings flag.
- Rental enquiry remains inquiry-only and does not send customer/owner email.
- Daily report generation is date-keyed/upserted and scheduled email contains aggregate metrics rather than customer-level PII.
- Bootstrap is explicitly owner-run and is not executed by this audit.

## Test and static validation results

All eight existing CJS policy suites passed in this audit:

1. `test_admin_operational_ui.cjs` — PASS
2. `test_admin_operational_write_policy.cjs` — PASS
3. `test_admin_security.cjs` — PASS
4. `test_booking_privacy_notifications_cancellation.cjs` — PASS
5. `test_customer_rate_model.cjs` — PASS
6. `test_daily_reports.cjs` — PASS
7. `test_rental_enquiry_policy.cjs` — PASS
8. `test_schema_alignment.cjs` — PASS

These are existing static/policy tests. They do **not** currently cover H1, H2, M1, or M2, which is why those issues remain open despite the green test run.

## Not performed / not claimed

- No live Google Sheets write or staging spreadsheet test.
- No `setupDatabase()` execution; no spreadsheet creation.
- No trigger installation; no live MailApp delivery.
- No payment provider callback or PhonePe integration test.
- No Apps Script deployment, website deployment, GitHub commit, or Preview URL update.
- No real browser end-to-end test.

## Release gate / next required work

Resolve H1 and H2 first, then M1 and M2; add regression tests for each. Re-run all eight suites and syntax/build checks. Only after owner review should the project proceed to isolated staging spreadsheet tests. Keep PhonePe disabled and do not remove any legacy backend/project until migration acceptance is explicit.
