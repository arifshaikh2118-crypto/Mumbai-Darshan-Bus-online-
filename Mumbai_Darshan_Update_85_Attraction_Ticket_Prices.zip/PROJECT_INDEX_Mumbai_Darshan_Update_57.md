# Latest update — Update 57 (20 November 2026)

## Legacy booking-ID endpoint now validates inputs and throttles requests
- Found `/api/bookings/validate-and-create` was not referenced by current frontend source but remained publicly reachable. It had no per-IP throttle, weak field validation, a UTC date prefix, and `Math.random()` suffix generation. It generated an ID only and did not persist a booking.
- Added `server/bookingRequestValidation.ts`: strict body, customer-name length, 10-digit mobile, real `YYYY-MM-DD` calendar date, local-today-or-future date, and bounded route/package validation.
- Added a separate 8-request-per-IP-per-10-minute throttle using the existing bounded public limiter.
- Booking ID date prefix now uses the server's local calendar date; suffix uses `crypto.randomInt()`.
- Kept the legacy endpoint for compatibility, and explicitly documented that it does not persist bookings. Actual public booking writes remain on the approved `/api/sync-sheets` flow.
- Added `validation/test_booking_id_endpoint_hardening.cjs`.
- Offline validation: **27/27 PASS**. TypeScript/TSX/JS/JSX syntax transpilation: **34/34 PASS**. JSON manifests: **6/6 PASS**. ZIP integrity: **PASS**.
- Limitation: rate limiting is process-local/in-memory and not shared across instances. This legacy endpoint is not used by the current frontend based on source search.
- No UI, pricing, approved business rule, schema, Apps Script, Google Sheets, payment, GitHub, live email or deployment change. Full npm lint/build and browser E2E remain pending; project is not production-ready.

---

# Latest update — Update 57 (20 November 2026)

## Public Sheets sync proxy now has bounded per-IP throttling
- Found that `/api/sync-sheets` allowed unauthenticated approved booking/rental writes without an Express-side per-IP throttle. Existing lookup/cancellation throttles did not cover these write actions.
- Added per-IP/per-action limits: `NEW_BOOKING`, `NEW_RENTAL_ENQUIRY`, and `CAR_RENTAL` each allow 8 requests per 10 minutes; `PING_TEST` has its own 10-per-10-minute bucket. Requests over limit receive HTTP 429.
- Added a 64 KB serialized payload cap (HTTP 413 above the cap).
- Preserved the explicit public action allowlist, server-configured Apps Script URL pinning, and block on Admin actions through the public proxy.
- Added `validation/test_public_sync_rate_limit.cjs`.
- Offline validation: **25/25 PASS**. TypeScript/TSX/JS/JSX syntax transpilation: **33/33 PASS**. JSON manifests: **6/6 PASS**. ZIP integrity: **PASS**.
- Limitation: rate limiting remains process-local/in-memory, resets on restart and is not shared across multiple server instances. Payload cap is checked after Express JSON parsing.
- No UI, pricing, business rule, approved schema, Apps Script, Google Sheets, payment, GitHub or deployment change. Full npm lint/build and browser E2E remain pending; project is not production-ready.

---

## Previous update — Update 54: Admin login attempt storage is now bounded
- Found a second unbounded IP-key Map in Admin login throttling. Added `server/adminLoginAttemptStore.ts`, which prunes expired attempt/lockout records periodically and before admitting a new IP at capacity.
- Store is capped at 5,000 IP entries. When full of still-active records, new IPs fail closed with HTTP 429; existing IP lockout state and the five-failures/15-minute cooldown policy remain unchanged. Successful login still clears the IP entry.
- Added `validation/test_admin_login_attempt_store_bounded.cjs`; tests cover cap, fail-closed admission, active lockout preservation, expiry pruning, periodic cleanup and successful-login deletion.
- Offline validation: **24/24 PASS**. TypeScript/TSX syntax transpilation: **30/30 src files PASS**, plus server TypeScript syntax checked separately. JSON manifests: **6/6 PASS**.
- No UI, login policy, credentials, schema, API contract or external integration changed. Full npm lint/build and browser E2E remain pending; project is not production-ready.
- Google Sheets, Apps Script deployment, payment, live email, GitHub and production deployment remain deferred by owner instruction.
---

## Previous update — Update 53: Public API rate-limiter memory is now bounded
- Replaced the unbounded Express public lookup/cancellation IP-key Map with `server/publicRateLimiter.ts`.
- Expired entries are pruned every 256 calls and before new-key admission at capacity; active key storage is capped at 5,000 entries. New unique keys fail closed when the cap is full of active entries.
- Existing Express limits remain 10 lookup attempts per IP per 10 minutes and 4 cancellation attempts per IP per hour. Apps Script per-booking throttles are unchanged.
- Added `validation/test_public_rate_limiter_bounded.cjs`; actual TypeScript helper tests cover limits, action separation, capacity, expiry and periodic pruning.
- Offline validation: **23/23 PASS**. TypeScript/TSX/JS/JSX syntax transpilation: **33/33 PASS**. JSON manifests: **6/6 PASS**. ZIP integrity: **PASS**.
- Limitation: limiter is process-local/in-memory, resets on restart, and is not shared across multiple instances.
- No UI, pricing, business rule, approved schema or external integration changed. Full npm lint/build and browser E2E remain pending; project is not production-ready.
- Google Sheets, Apps Script deployment, payment, live email, GitHub and production deployment remain deferred by owner instruction.

---

## Previous update — Update 52: Rental enquiry date now uses local calendar validation
- Fixed the rental form default date and minimum date to use the visitor’s local calendar rather than UTC `toISOString()`, which could display the previous day around midnight in India.
- Rental enquiry submission now rejects missing, malformed, impossible, or past travel dates using the shared `isTodayOrFutureLocalDate()` helper. The date input is required.
- Added `validation/test_rental_local_date_validation.cjs`, executing the shared TypeScript helper and checking India-midnight, yesterday, today, future and impossible-date cases.
- Offline validation: **22/22 PASS**. TypeScript/TSX/JS/JSX syntax transpilation: **31/31 PASS**. JSON manifests: **6/6 PASS**. ZIP integrity: **PASS**.
- No UI redesign, pricing, business rule, schema, API, payment or external integration change.
- Full npm lint/build and browser E2E remain pending; project is not production-ready.
- Google Sheets, Apps Script deployment, payment, live email, GitHub and production deployment remain deferred by owner instruction.

---

## Previous update — Update 50: Admin session-storage access now fails closed across the UI
- Update 49 made login fail closed if session storage writes fail. Update 50 extended protection to every Admin session-storage read and cleanup path.
- Added `src/services/adminSession.ts` with guarded token read, verified token write, and best-effort cleanup helpers. Admin startup revalidation, protected data load, report/status actions, operational editor, rentals, cancellations, notifications and logout now use these helpers.
- Added `validation/test_admin_session_storage_access_fail_closed.cjs` and updated the Update 49 regression test to validate helper-based login.
- Offline validation: **20/20 PASS**. TypeScript/TSX syntax transpilation: **30/30 PASS**. ZIP integrity: **PASS**.
- No UI layout, pricing, business rule, schema, API, payment or external integration change.
- Full npm lint/build and browser E2E remain pending; project is not production-ready.
- Google Sheets, Apps Script deployment, payment, live email, GitHub and production deployment remain deferred by owner instruction.


# Mumbai Darshan Bus Online — Master Progress Tracker

**Current package:** Update 56 — JSON Request Body Size Hardening  
**Baseline:** Update 55 — Public Sync Proxy Rate Limit  
**Date:** 20 November 2026

## Owner sequencing instruction

- [x] GitHub work must wait until the complete project files and remaining local work are finished.
- [x] Updates 44–45 did not commit/push code, run GitHub Actions, refresh Preview or deploy.
- [x] Google Sheets creation/setup, Apps Script deployment, payment integration and all live deployment are deferred by owner instruction.
- [x] Owner will not manually create a Google Sheet; the later complete Apps Script setup code must create the spreadsheet and approved tabs automatically.
- [ ] GitHub/network-enabled build phase only after local source and project files are complete.

## Completed source work

- [x] Approved 17-tab / 139-header schema manifest and bootstrap source retained.
- [x] Booking server-side pricing/advance calculation and duplicate partial-write reconciliation gate retained.
- [x] Rental enquiry remains inquiry-only; no owner/customer rental email.
- [x] Admin session, secret-gated Apps Script actions and active AdminUsers roster retained.
- [x] Public lookup/cancellation privacy and throttling retained.
- [x] EmailLog, notifications, cancellation/refund review and Daily Reports source retained.
- [x] Update 36 protected Admin dispatch, public mutation lockdown, proxy allowlist and server-configured webhook URL fixes retained.
- [x] Update 37 Firebase guide corrected to explain Express API hosting requirement.
- [x] Update 38 added dependency-free offline validation runner.
- [x] Update 39 public Express proxy requires explicit allowed action; Apps Script rejects missing/blank action.
- [x] Update 40 runtime tests reject missing, blank and non-string actions; lock release and explicit PING_TEST verified.
- [x] Update 41 manual network build workflow definition added; execution deferred by owner instruction.
- [x] Update 42 fixed expired Admin login lockout-window reset order.
- [x] Update 42 added 30-second timeout to all 3 Apps Script fetch paths.
- [x] Update 43 verified all 13 frontend API paths have Express routes.
- [x] Update 43 verified 10 protected Admin routes use `requireAdmin`.
- [x] Update 43 verified all 10 Express Admin actions are dispatched in Apps Script.
- [x] Update 43 aligned all 7 Operational Sheets Manager UI configs with approved schema headers/keys.
- [x] Update 44 added a regression guard that detects missing public configuration fields before any public sync implementation is attempted.
- [x] Update 45 corrected outstation billing copy: driver allowance / DA-permit is extra; parking, toll, border tax and entry charges are extra at actuals.
- [x] Update 45 added an optional local tour-guide request at ₹2,000 flat per booking/vehicle, not per passenger; it is included in the estimate and recorded in the existing special-requirements field.
- [x] Update 43 added API contract and operational UI schema regression tests.
- [x] Update 49: Admin login fails closed if sessionStorage cannot persist the signed token; partial keys are cleared best-effort and an actionable error is shown.
- [x] Update 50: all Admin token reads, writes, and cleanup are routed through guarded session helpers; stored token is read back before login success.
- [x] Update 51: booking wizard rejects past, malformed and impossible travel dates using local-calendar validation.
- [x] Update 52: rental enquiry default/minimum date uses local calendar; submission rejects past, malformed and impossible travel dates.
- [x] Update 53: public lookup/cancellation rate-limit storage prunes expired keys and is capped at 5,000 active keys.
- [x] Update 54: Admin login attempt/lockout storage prunes expired IP records and is capped at 5,000 entries; new IPs fail closed at capacity.
- [x] Offline validation runner PASS, 24/24 (Update 54).
- [x] TypeScript/TSX syntax transpilation PASS, 30/30 source files plus server helper syntax checks (syntax-only).
- [x] JSON manifests PASS, 6/6.

## Deferred integration item — public configuration remains browser-local

**Deferred by owner instruction — not part of the current local-only phase:** Admin operational edits are intended to be saved to Google Sheets, while customer-facing routes/packages/offers/pickup points/tour points currently read through `StorageService` from browser `localStorage` and `INITIAL_*` defaults. `BookingForm.tsx` uses those getters. This public config API/hydration work will be done in the later Google Sheets / Apps Script phase; it is not a blocker for current local source work.

- [ ] Add a dedicated read-only public configuration endpoint.
- [ ] Explicitly allowlist public fields from operational tabs only.
- [ ] Never expose AdminUsers, Settings secrets, bookings, payment references, supplier costs or private Admin data.
- [ ] Add safe defaults, response validation and bounded cache.
- [ ] Hydrate public booking and content components from Sheets-backed public config.
- [ ] Ensure Admin changes become visible to public pages after a safe refresh.
- [x] Add regression guard for current public-config schema readiness; full endpoint/privacy/cache tests remain pending until the endpoint is designed.
- [ ] Test against isolated staging before production cutover.

Do not reuse protected `ADMIN_GET_DATA` as a public endpoint.

## Update 44 — public configuration readiness audit

The current approved schema does not fully describe the data model consumed by the customer-facing booking UI:

- `PickupPoints` has only `Route`, `Pickup Point`, `Sort Order`, `Active`; the frontend pickup model also consumes time, landmark, reporting time and map URL.
- `PackageOptions` has package key, route group, label, price and offer fields, but no explicit `isAC`, `hasLunch`, or package description fields used by the booking model.
- The operational tabs do not provide the existing route descriptions or all customer-facing extra-charge configuration.
- The frontend `BookingForm` still reads routes, packages, offers and pickup points from `StorageService` / browser localStorage and initial defaults.
- The 17-tab schema manifest is explicitly a reconstructed audit snapshot, not a live workbook read. A Library title search for the original `Google app script codegx.xlsx` did not locate it; it must be reconciled with the original workbook before final mapping.

**Safety decision:** no public endpoint and no frontend hydration were added in Update 44. Mapping incomplete fields to invented values, exposing `ADMIN_GET_DATA`, or exposing raw private tabs would be unsafe. No sheet, column, live data, UI, deployment, or GitHub workflow was changed.

A new offline readiness test locks in these findings so the later integration does not silently claim Sheets-backed public configuration is complete. The owner has clarified that no Google Sheet should be manually created and this integration is deferred.

## Latest verification status

| Check | Result |
|---|---|
| Apps Script CJS regression suites | PASS, 9/9 |
| Apps Script `Code.gs` syntax | PASS |
| Admin login throttle / upstream timeout regression | PASS |
| Frontend API path alignment | PASS, 13/13 |
| Protected Admin route middleware | PASS, 10/10 |
| Express-to-Apps Script Admin action dispatch | PASS, 10/10 |
| Operational UI schema alignment | PASS, 7/7 sheets |
| Offline validation runner | PASS, 18/18 (Update 47) |
| TypeScript/TSX syntax transpilation | PASS, 29/29 (rechecked Update 45) |
| Key JSON manifests | PASS, 4/4 (rechecked Update 45) |
| npm registry access | BLOCKED — DNS `EAI_AGAIN` |
| npm cache | No usable package cache entries |
| `package-lock.json` | MISSING |
| `bun.lock` | EMPTY, unusable |
| `node_modules` | ABSENT |
| Full `npm run lint` | PENDING — dependencies/types unavailable |
| `npm run build` | PENDING — dependencies unavailable |
| GitHub Actions workflow | NOT RUN — deferred by owner |
| Browser E2E | PENDING |
| Hosting architecture / API runtime | PENDING owner/developer confirmation |
| Google Sheets staging | PENDING owner approval |

## Latest local source update — Update 47 (20 November 2026)

- Added Apps Script `safeSheetText_()` to store public customer text as literal Google Sheets cell text rather than allowing formula-like values to be interpreted as formulas.
- Applied sanitization and maximum lengths to public booking and rental enquiry text fields.
- Added strict format validation for booking and rental enquiry IDs.
- Added `validation/test_sheets_formula_injection.cjs`; it exercises the actual sanitizer helper and checks field coverage and ID validation.
- Offline validation now passes **18/18**; TypeScript/TSX syntax transpilation **29/29**; JSON manifests **4/4**.
- No UI, approved pricing, booking rules, schema headers, external services or deployment settings changed.
- No Google Sheet / Apps Script / payment / GitHub / Preview / production action performed.

## Latest local source update — Update 48 (20 November 2026)

- Audit found public and Admin cancellation reasons still went directly into `Booking Cancellations` via `appendRow()` after Update 47.
- Both cancellation handlers now use `safeSheetText_()` with a 500-character limit.
- Regression test covers both public and Admin cancellation write paths.
- Offline validation at Update 48: **18/18 PASS**; TypeScript/TSX syntax transpilation: **31/31 PASS**; ZIP integrity: **PASS**.
- No workbook, deployment, payment, UI, pricing, business-rule, GitHub or external service was changed.

## Remaining local work before GitHub

- [ ] Continue source-level audit of customer booking, rental, Admin, privacy/security and responsive UI flows. (Updates 46–50 fixed local-date formatting, customer/cancellation text formula safety, and Admin session-storage fail-closed handling across all Admin access paths.)
- [ ] Add regression tests for approved business rules and close any confirmed source-level defects.
- [ ] Reconcile README, setup guides, update reports and project tracker with the owner-approved local-first sequence.
- [ ] Preserve approved UI, pricing, booking rules and schema except for explicitly authorized business-rule corrections.
- [ ] Complete all source/package files and local validation before GitHub activity.

Google Sheets / Apps Script public configuration API, sheet bootstrap run, deployment, payment integration and live email are explicitly deferred to a later phase; they are not current local blockers.

## Later — network build, browser E2E and staging

### P0 — Network-enabled build (only after local files are complete)
- [ ] Owner/developer commits/pushes project source to intended GitHub repository.
- [ ] Manually run **Mumbai Darshan Network Build Validation** workflow.
- [ ] Verify npm install generates a valid package-lock.
- [ ] Verify clean `npm ci` passes.
- [ ] Verify `npm run lint` passes.
- [ ] Verify `npm run build` passes.
- [ ] Review uploaded lockfile and dist artifacts; record workflow URL and commit SHA.

### P0 — Hosting architecture and browser E2E
- [ ] Confirm hosting target for Express server.
- [ ] If Firebase Hosting + Cloud Run is approved, confirm actual service ID and region, then configure `/api/**` rewrite before SPA fallback.
- [ ] Verify `/api/*` reaches Express and Admin routes reject unauthenticated calls.
- [ ] Run browser E2E for booking submit/retry, rental inquiry, lookup, cancellation, Admin login/session expiry, status updates, email retry, refunds, reports and seven operational CRUD tabs.
- [ ] Test mobile booking flow and rental enquiry panel immediately below booking form.

### P1 — Later Google Sheets / Apps Script staging (owner approval only; no manual sheet creation)
- [ ] Provide/run one complete Apps Script setup code using `setupDatabase()` to create the spreadsheet and approved tabs automatically.
- [ ] Confirm exact 17 tabs / 139 headers and approved seed data.
- [ ] Configure private server environment and Apps Script Script Property secrets.
- [ ] Test booking/payment-pending ledger writes, duplicate retries, rental inquiry-only writes, lookup/cancellation, Admin reads/mutations, EmailLog, notifications and daily reports.
- [ ] Test concurrency and throttling.
- [ ] Owner-approved controlled email test; only then decide on trigger installation.

### P2 — Later separately approved integration and delivery
- [ ] Add the dedicated public configuration read endpoint and safe frontend hydration; keep private Admin/customer/payment data excluded.
- [ ] Complete payment integration only after merchant credentials and approved server-side verification design are available.

### P3 — Later separately approved delivery
- [ ] Preview refresh after build/tests and approval.
- [ ] PhonePe integration after merchant credentials and server-side signature/status verification.
- [ ] Production Apps Script deployment, email activation, DNS/domain changes and website deployment only with explicit approval.

## Preserved business and safety rules

- No changes to approved sheet tabs/columns without permission.
- No supplier cost/rate/margin/private garage information in customer-facing code.
- No extra ₹5 rental-rate markup; approved customer rates remain unchanged.
- ₹200 advance is per booking, not per person.
- No automatic refund; PhonePe remains deferred.
- No rental enquiry emails; follow up via WhatsApp.
- No live Sheet, Apps Script, GitHub, Preview or production action without explicit approval.

**Overall: INCOMPLETE. Updates 46–49 add the local-date correction, Sheets text formula-safety coverage, cancellation reason hardening, and Admin session-storage fail-closed behavior. Latest offline validation passes 26/26; 30 frontend source files plus server TypeScript helpers pass syntax transpilation. Critical remaining local task: continue source audit and complete local project files. Public Sheets-backed configuration hydration, GitHub, network build, browser E2E and deployment remain deferred to the approved later phases.**


## Update 49 — Admin session-storage fail-closed fix

- Admin login previously swallowed `sessionStorage` write errors and still marked the UI authenticated. This could show an authenticated Admin shell without a usable stored token.
- Login now clears any partial keys best-effort, displays a clear browser-storage error, and returns before setting authenticated state.
- Added a regression test for the failure path.
- Offline validation: **19/19 PASS**; TS/JS/TSX/JSX syntax transpilation: **29/29 PASS**.
- No external actions or integrations performed. Full npm lint/build and browser E2E remain pending.


## Update 50 — Admin session-storage access hardening

- Follow-up audit found direct `sessionStorage.getItem()` / `removeItem()` calls remained in Admin startup, protected data loading, report/status actions, operational editor, rental/cancellation actions, notifications and logout.
- Added guarded helpers in `src/services/adminSession.ts`; all Admin UI token access now uses them. Token persistence is verified by reading the token back.
- Storage read exceptions return no token; cleanup is best-effort and does not throw.
- Offline validation: **20/20 PASS**; TypeScript/TSX syntax transpilation: **30/30 PASS**; ZIP integrity: **PASS**.
- No UI/business rules/schema/API/integration changes; no external actions performed.

**Overall: INCOMPLETE. Update 50 extends Admin session-storage fail-closed handling to every Admin path. Full npm lint/build and browser E2E remain pending; Google Sheets, Apps Script deployment, payment, GitHub and production deployment remain deferred.**


## Update 51 — Booking future-date validation

- Booking wizard Step 1 previously checked only for a non-empty travel date; the HTML date input's `min` attribute alone was not sufficient validation.
- Added a local-calendar date helper that strictly validates `YYYY-MM-DD`, rejects impossible dates, and blocks dates before local today.
- Booking wizard now calls the helper and marks the date field required. Existing local `min` behavior is preserved.
- Added a regression test that executes the actual TypeScript helper for past/today/future/impossible/malformed dates.
- Offline validation: **21/21 PASS**; TS/TSX/JS/JSX syntax transpilation: **31/31 PASS**; JSON manifests: **4/4 PASS**.
- This is frontend validation only; no server-side date validation is claimed.
- No external action, UI redesign, pricing, business rule, schema, payment or deployment change.

**Overall: INCOMPLETE. Update 51 strengthens local booking-date validation. Full npm lint/build and browser E2E remain pending; Google Sheets, Apps Script deployment, payment, GitHub and production deployment remain deferred.**


## Update 52 — Rental local-date validation

- Found that `CarRentalPanel.tsx` used `toISOString().slice(0, 10)` for both the default travel date and minimum date. This UTC conversion can show yesterday in India around local midnight.
- Replaced both with the shared local date formatter. Rental form now requires a date and validates it on submit using `isTodayOrFutureLocalDate()`.
- Added `validation/test_rental_local_date_validation.cjs`; actual TypeScript helper executed in Asia/Kolkata test timezone.
- Offline validation **22/22 PASS**; syntax transpilation **31/31 PASS**; JSON manifests **6/6 PASS**; ZIP integrity **PASS**.
- Full npm lint/build and browser E2E remain pending. No external actions or deployments.

**Overall status: INCOMPLETE / NOT production-ready.**


## Update 53 — Public API rate-limiter memory bound

- [x] Replace unbounded public Express rate-limit Map with bounded helper.
- [x] Prune expired keys periodically and at capacity.
- [x] Fail closed for new unique keys if the 5,000 active-key cap is reached.
- [x] Preserve existing lookup/cancellation per-IP limits and independent action buckets.
- [x] Add executable regression test for the real TypeScript helper.
- [x] Offline validation 23/23; syntax transpilation 33/33; JSON 6/6; ZIP integrity PASS.
- [ ] Full npm lint/build and browser E2E remain pending.

**Overall: INCOMPLETE / NOT production-ready.** Public limiter remains process-local; multi-instance distributed limiting is not implemented. Google Sheets, Apps Script deployment, payment, GitHub and production deployment remain deferred.


## Update 54 — Admin login attempt store bounded

- Replaced the unbounded `adminLoginAttempts` Map with `createAdminLoginAttemptStore(5000, 256)`.
- Expired records are pruned every 256 store calls and before admission at capacity. Entries remain while either the rolling 15-minute window or lockout period is active.
- New IPs fail closed with HTTP 429 when 5,000 entries are still active. Existing IP lockout state remains accessible, the five-failures/15-minute policy is unchanged, and successful login deletes that IP's entry.
- Added executable helper regression tests; offline validation **24/24 PASS**. Frontend syntax **30/30 PASS**; server TS files syntax checked separately.
- Full npm lint/build and browser E2E remain pending. The store remains process-local and resets on server restart. No external actions or deployments.

**Overall: INCOMPLETE / NOT production-ready.**


## Update 55 detailed record
- The public sync proxy now rate-limits approved booking/rental write actions per IP and action, and independently limits `PING_TEST`.
- Public proxy payloads are capped at 64 KB. Existing Apps Script URL pinning and action allowlist are retained.
- Tests: **25/25 offline**, **33/33 syntax**, **6/6 JSON**, ZIP integrity PASS.
- The limiter is still process-local; multi-instance shared enforcement and end-to-end browser testing remain outstanding.
- No external actions or deployments were performed.


## Update 56 — JSON request body size hardening

- Found a mismatch in the Express request pipeline: the global JSON parser accepted bodies up to 10 MB, while the public Sheets sync proxy only rejected serialized payloads above 64 KB after parsing. That meant oversized input could consume parser memory before route-level rejection.
- Reduced the global Express JSON parser limit to **256 KB**, preserving headroom for authenticated Admin operational requests while preventing the previous 10 MB allowance.
- Added an Express error middleware after API routes: oversized JSON receives a consistent JSON **413** response; malformed JSON receives a JSON **400** response.
- Added `validation/test_json_body_size_limit.cjs` with seven regression assertions.
- Offline validation runner: **26/26 PASS**.
- TypeScript/TSX/server helper syntax transpilation: **33/33 PASS**, zero syntax diagnostics. JSON manifests: **6/6 PASS**.
- Full npm lint/build not run because `node_modules` is not present. Browser E2E remains pending.
- The public sync proxy's stricter 64 KB cap, per-action throttles, explicit public allowlist, server-pinned Apps Script URL and protected Admin routes remain unchanged.
- No UI, pricing, business rule, approved schema, Google Sheets, Apps Script, payment, GitHub, Preview, email or deployment change. No external system was touched.

**Overall: INCOMPLETE / NOT production-ready.** The 256 KB parser limit is an in-process request-size safeguard; it does not replace upstream proxy/load-balancer limits or distributed rate limiting. Full npm lint/build and browser E2E remain outstanding. Google Sheets setup, Apps Script deployment, payment, GitHub and live deployment remain deferred by owner instruction.
