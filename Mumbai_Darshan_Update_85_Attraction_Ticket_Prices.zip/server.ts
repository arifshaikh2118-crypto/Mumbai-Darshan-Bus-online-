import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { createBoundedRateLimiter } from './server/publicRateLimiter.ts';
import { createAdminLoginAttemptStore } from './server/adminLoginAttemptStore.ts';
import { localBookingDateCode, validateBookingIdRequest } from './server/bookingRequestValidation.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const UPSTREAM_TIMEOUT_MS = 30_000;

// Bound JSON parsing before route-level validation to prevent oversized bodies
// from being fully materialized in memory. The public Sheets proxy is stricter (64 KB).
app.use(express.json({ limit: '256kb' }));

// Admin authentication: no built-in/default passcodes. Configure secrets only in the server environment.
const ADMIN_PASSCODE = process.env.ADMIN_PASSCODE || '';
const ADMIN_SESSION_SECRET = process.env.ADMIN_SESSION_SECRET || '';
const ADMIN_SESSION_TTL_SECONDS = 30 * 60;
const adminLoginAttempts = createAdminLoginAttemptStore(5000, 256);

function base64url(value: Buffer | string): string {
  return Buffer.from(value).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}
function signAdminToken(email: string): string {
  const payload = base64url(JSON.stringify({ sub: email.toLowerCase(), role: 'admin', exp: Math.floor(Date.now() / 1000) + ADMIN_SESSION_TTL_SECONDS }));
  const signature = crypto.createHmac('sha256', ADMIN_SESSION_SECRET).update(payload).digest();
  return `${payload}.${base64url(signature)}`;
}
function verifyAdminToken(token: string): { email: string } | null {
  if (!ADMIN_SESSION_SECRET || !token || token.length > 2048) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const expected = crypto.createHmac('sha256', ADMIN_SESSION_SECRET).update(parts[0]).digest();
  let supplied: Buffer;
  try { supplied = Buffer.from(parts[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64'); } catch { return null; }
  if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(parts[0].replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
    if (!payload.sub || payload.role !== 'admin' || !Number.isFinite(payload.exp) || payload.exp <= Math.floor(Date.now() / 1000)) return null;
    return { email: String(payload.sub) };
  } catch { return null; }
}
function requireAdmin(req: any, res: any, next: any) {
  const header = String(req.headers.authorization || '');
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const session = verifyAdminToken(token);
  if (!session) return res.status(401).json({ authenticated: false, error: 'Admin session invalid or expired' });
  req.adminSession = session;
  next();
}
async function callAppsScriptAdmin(action: string, email: string, extra: Record<string, unknown> = {}) {
  const webhookUrl = process.env.GOOGLE_APPS_SCRIPT_URL || '';
  const apiSecret = process.env.ADMIN_API_SECRET || '';
  if (!webhookUrl || !apiSecret) throw new Error('Secure Google Apps Script admin connection is not configured');
  const target = new URL(webhookUrl);
  if (target.protocol !== 'https:' || target.hostname !== 'script.google.com' || !/^\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(target.pathname)) throw new Error('Invalid Google Apps Script Web App URL');
  const response = await fetch(target.toString(), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, adminEmail: email, adminApiSecret: apiSecret, ...extra }), redirect: 'follow', signal: AbortSignal.timeout(UPSTREAM_TIMEOUT_MS) });
  const data: any = await response.json();
  if (!response.ok || data?.status !== 'success') throw new Error(data?.message || 'Google Apps Script admin request failed');
  return data;
}

app.post('/api/admin/login', async (req, res) => {
  const ip = String(req.ip || req.socket?.remoteAddress || 'unknown');
  const now = Date.now();
  const attempt = adminLoginAttempts.getOrCreate(ip, now);
  if (!attempt) return res.status(429).json({ success: false, error: 'Admin login temporarily unavailable. Please try again later.' });
  if (attempt.blockedUntil > now) return res.status(429).json({ success: false, error: 'Too many attempts. Try again later.' });
  // Reset an expired attempt window before counting the next failed login.
  // Otherwise a stale count of five can immediately re-lock the IP after cooldown.
  if (attempt.resetAt <= now) {
    attempt.count = 0;
    attempt.resetAt = now + 15 * 60 * 1000;
    attempt.blockedUntil = 0;
  }
  const email = String(req.body?.email || '').trim().toLowerCase();
  const passcode = String(req.body?.passcode || '');
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !ADMIN_PASSCODE || !ADMIN_SESSION_SECRET || !process.env.ADMIN_API_SECRET || !process.env.GOOGLE_APPS_SCRIPT_URL) {
    return res.status(503).json({ success: false, error: 'Secure admin authentication is not configured or credentials are incomplete.' });
  }
  const suppliedPass = Buffer.from(passcode);
  const expectedPass = Buffer.from(ADMIN_PASSCODE);
  const passOk = suppliedPass.length === expectedPass.length && crypto.timingSafeEqual(suppliedPass, expectedPass);
  if (!passOk) {
    attempt.count += 1;
    if (attempt.count >= 5) attempt.blockedUntil = now + 15 * 60 * 1000;
    return res.status(401).json({ success: false, error: 'Invalid admin credentials' });
  }
  try {
    const roster = await callAppsScriptAdmin('ADMIN_AUTH_CHECK', email);
    if (!roster.authorized) return res.status(403).json({ success: false, error: 'This email is not an active authorized AdminUsers account.' });
    adminLoginAttempts.delete(ip);
    return res.json({ success: true, token: signAdminToken(email), role: roster.role || 'admin', expiresIn: ADMIN_SESSION_TTL_SECONDS });
  } catch (error: any) {
    return res.status(503).json({ success: false, error: error.message || 'Admin authorization service unavailable' });
  }
});

// Public booking lookup and cancellation endpoints. Both require Booking ID + registered mobile;
// no personal data is accepted in query strings. Per-IP throttles are in-memory and reset on restart.
// Keep public endpoint throttling bounded: expired IP keys are pruned, and
// new keys fail closed if the bounded map is full of still-active entries.
const publicActionLimiter = createBoundedRateLimiter(5000, 256);
let publicConfigCache: { expiresAt: number; value: any } | null = null;
function allowPublicAction(ip: string, action: string, limit: number, windowMs: number): boolean {
  return publicActionLimiter.allow(`${action}:${ip}`, limit, windowMs);
}
async function callPublicAppsScript(payload: Record<string, unknown>) {
  const webhookUrl = process.env.GOOGLE_APPS_SCRIPT_URL || '';
  const target = new URL(webhookUrl);
  if (target.protocol !== 'https:' || target.hostname !== 'script.google.com' || !/^\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(target.pathname)) throw new Error('Secure booking service is not configured');
  const response = await fetch(target.toString(), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), redirect: 'follow', signal: AbortSignal.timeout(UPSTREAM_TIMEOUT_MS) });
  const data: any = await response.json();
  if (!response.ok || !data || !['success', 'not_found', 'duplicate', 'error'].includes(data.status)) throw new Error('Booking service unavailable');
  return data;
}
app.post('/api/bookings/lookup', async (req, res) => {
  const ip = String(req.ip || req.socket?.remoteAddress || 'unknown');
  if (!allowPublicAction(ip, 'lookup', 10, 10 * 60 * 1000)) return res.status(429).json({ status: 'error', message: 'Too many attempts. Please try again after 10 minutes.' });
  const bookingId = String(req.body?.bookingId || '').trim(); const mobile = String(req.body?.mobile || '').replace(/\D/g, '').slice(-10);
  if (!/^[A-Za-z0-9_-]{5,80}$/.test(bookingId) || mobile.length !== 10) return res.status(400).json({ status: 'error', message: 'Booking ID and 10-digit registered mobile are required.' });
  try { const data = await callPublicAppsScript({ action: 'PUBLIC_BOOKING_LOOKUP', bookingId, mobile }); return res.status(data.status === 'success' ? 200 : data.status === 'not_found' ? 404 : 400).json(data); }
  catch (error: any) { return res.status(502).json({ status: 'error', message: error.message || 'Booking lookup unavailable' }); }
});
app.post('/api/bookings/cancellation-request', async (req, res) => {
  const ip = String(req.ip || req.socket?.remoteAddress || 'unknown');
  if (!allowPublicAction(ip, 'cancel', 4, 60 * 60 * 1000)) return res.status(429).json({ status: 'error', message: 'Too many requests. Please contact customer care.' });
  const bookingId = String(req.body?.bookingId || '').trim(); const mobile = String(req.body?.mobile || '').replace(/\D/g, '').slice(-10); const reason = String(req.body?.reason || '').trim();
  if (!/^[A-Za-z0-9_-]{5,80}$/.test(bookingId) || mobile.length !== 10 || reason.length < 3 || reason.length > 500) return res.status(400).json({ status: 'error', message: 'Booking ID, registered mobile and reason are required.' });
  try { const data = await callPublicAppsScript({ action: 'PUBLIC_CANCELLATION_REQUEST', bookingId, mobile, reason }); return res.status(data.status === 'success' || data.status === 'duplicate' ? 200 : data.status === 'not_found' ? 404 : 400).json(data); }
  catch (error: any) { return res.status(502).json({ status: 'error', message: error.message || 'Cancellation service unavailable' }); }
});

app.get('/api/admin/verify', requireAdmin, (req: any, res) => {
  return res.json({ authenticated: true, email: req.adminSession.email });
});

app.get('/api/admin/data', requireAdmin, async (req: any, res) => {
  try {
    const data = await callAppsScriptAdmin('ADMIN_GET_DATA', req.adminSession.email);
    return res.json({ success: true, data: data.data });
  } catch (error: any) {
    return res.status(502).json({ success: false, error: error.message || 'Unable to retrieve admin data' });
  }
});

app.post('/api/admin/rental-pricing', requireAdmin, async (req: any, res) => {
  const pricing = req.body?.rentalPricing;
  if (!pricing || typeof pricing !== 'object' || Array.isArray(pricing) || !Array.isArray(pricing.localPackages) || !Array.isArray(pricing.outstationRates) || pricing.localPackages.length !== 6 || pricing.outstationRates.length !== 16) {
    return res.status(400).json({ success: false, error: 'Rental pricing must include all 6 Local Darshan packages and 16 Outstation vehicle rates.' });
  }
  try {
    const result = await callAppsScriptAdmin('ADMIN_SAVE_RENTAL_PRICING', req.adminSession.email, { rentalPricing: pricing });
    if (result?.status !== 'success') return res.status(400).json({ success: false, error: result?.message || 'Rental pricing was rejected.' });
    publicConfigCache = null;
    return res.json({ success: true, message: result.message || 'Rental pricing saved.' });
  } catch (error: any) { return res.status(502).json({ success: false, error: error.message || 'Rental pricing save failed.' }); }
});

app.post('/api/admin/reports/daily/generate', requireAdmin, async (req: any, res) => {
  const reportDate = String(req.body?.reportDate || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(reportDate)) return res.status(400).json({ success: false, error: 'Report date must use YYYY-MM-DD.' });
  try {
    const result = await callAppsScriptAdmin('ADMIN_GENERATE_DAILY_REPORT', req.adminSession.email, { reportDate });
    return res.json({ success: true, result });
  } catch (error: any) {
    return res.status(502).json({ success: false, error: error.message || 'Daily report generation failed' });
  }
});

app.post('/api/admin/bookings/status', requireAdmin, async (req: any, res) => {
  const bookingId = String(req.body?.bookingId || '').trim();
  const bookingStatus = String(req.body?.bookingStatus || '').trim();
  if (!bookingId || bookingId.length > 80 || bookingStatus === 'Cancelled' || !['Confirmed', 'Pending Verification', 'Completed'].includes(bookingStatus)) {
    return res.status(400).json({ success: false, error: bookingStatus === 'Cancelled'
      ? 'Use the Cancellation & Refund Review workflow; direct cancellation is disabled.'
      : 'Invalid booking ID or status.' });
  }
  try {
    const result = await callAppsScriptAdmin('ADMIN_UPDATE_BOOKING_STATUS', req.adminSession.email, { bookingId, bookingStatus });
    if (result?.status !== 'success') {
      return res.status(result?.status === 'not_found' ? 404 : 409).json({ success: false, error: result?.message || 'Booking status update was rejected.', result });
    }
    return res.json({ success: true, result });
  } catch (error: any) {
    return res.status(502).json({ success: false, error: error.message || 'Unable to update booking status' });
  }
});

app.post('/api/admin/operational/upsert', requireAdmin, async (req: any, res) => {
  const sheetKey = String(req.body?.sheetKey || '');
  const record = req.body?.record;
  const allowed = ['pickupPoints', 'packageOptions', 'bookingDates', 'rentalVehicles', 'websiteContent', 'attractionPoints', 'attractionTickets'];
  if (!allowed.includes(sheetKey) || !record || typeof record !== 'object' || Array.isArray(record) || Object.keys(record).length > 20) {
    return res.status(400).json({ success: false, error: 'Invalid operational sheet or record.' });
  }
  try {
    const result = await callAppsScriptAdmin('ADMIN_UPSERT_OPERATIONAL_RECORD', req.adminSession.email, { sheetKey, record });
    return res.json({ success: true, result });
  } catch (error: any) { return res.status(502).json({ success: false, error: error.message || 'Operational record save failed' }); }
});

app.post('/api/admin/operational/delete', requireAdmin, async (req: any, res) => {
  const sheetKey = String(req.body?.sheetKey || '');
  const key = req.body?.key;
  const allowed = ['pickupPoints', 'packageOptions', 'bookingDates', 'rentalVehicles', 'websiteContent', 'attractionPoints', 'attractionTickets'];
  if (!allowed.includes(sheetKey) || !key || typeof key !== 'object' || Array.isArray(key)) return res.status(400).json({ success: false, error: 'Invalid operational sheet or record key.' });
  try {
    const result = await callAppsScriptAdmin('ADMIN_DELETE_OPERATIONAL_RECORD', req.adminSession.email, { sheetKey, key });
    return res.json({ success: true, result });
  } catch (error: any) { return res.status(502).json({ success: false, error: error.message || 'Operational record delete failed' }); }
});

app.post('/api/admin/rentals/status', requireAdmin, async (req: any, res) => {
  const enquiryId = String(req.body?.enquiryId || '').trim();
  const status = String(req.body?.status || '').trim();
  const allowed = ['New', 'Contacted', 'Quote Sent', 'Follow-up', 'Confirmed', 'Not Interested', 'Cancelled'];
  if (!enquiryId || enquiryId.length > 80 || !allowed.includes(status)) return res.status(400).json({ success: false, error: 'Invalid rental enquiry ID or status.' });
  try {
    const result = await callAppsScriptAdmin('ADMIN_UPDATE_RENTAL_STATUS', req.adminSession.email, { enquiryId, status });
    return res.json({ success: true, result });
  } catch (error: any) {
    return res.status(502).json({ success: false, error: error.message || 'Unable to update rental enquiry status' });
  }
});

app.post('/api/admin/bookings/retry-emails', requireAdmin, async (req: any, res) => {
  const bookingId = String(req.body?.bookingId || '').trim();
  if (!bookingId || bookingId.length > 80) return res.status(400).json({ success: false, error: 'Valid Booking ID is required.' });
  try { const result = await callAppsScriptAdmin('ADMIN_RETRY_BOOKING_EMAILS', req.adminSession.email, { bookingId }); return res.json({ success: result.status === 'success', result }); }
  catch (error: any) { return res.status(502).json({ success: false, error: error.message || 'Email retry failed' }); }
});

app.post('/api/admin/cancellations', requireAdmin, async (req: any, res) => {
  const bookingId = String(req.body?.bookingId || '').trim(); const reason = String(req.body?.reason || '').trim();
  if (!bookingId || bookingId.length > 80 || reason.length < 3 || reason.length > 500) return res.status(400).json({ success: false, error: 'Booking ID and cancellation reason are required.' });
  try { const result = await callAppsScriptAdmin('ADMIN_CREATE_CANCELLATION', req.adminSession.email, { bookingId, reason }); return res.json({ success: true, result }); }
  catch (error: any) { return res.status(502).json({ success: false, error: error.message || 'Unable to create cancellation record' }); }
});
app.post('/api/admin/cancellations/refund-status', requireAdmin, async (req: any, res) => {
  const cancellationId = String(req.body?.cancellationId || '').trim(); const refundStatus = String(req.body?.refundStatus || '').trim(); const manualRefundConfirmed = req.body?.manualRefundConfirmed === true;
  if (!cancellationId || cancellationId.length > 100 || !['Pending Review', 'Approved', 'Refunded', 'Rejected'].includes(refundStatus)) return res.status(400).json({ success: false, error: 'Invalid cancellation or refund status.' });
  if (refundStatus === 'Refunded' && !manualRefundConfirmed) return res.status(400).json({ success: false, error: 'Confirm the refund was completed manually before marking it Refunded.' });
  try { const result = await callAppsScriptAdmin('ADMIN_UPDATE_REFUND_STATUS', req.adminSession.email, { cancellationId, refundStatus, manualRefundConfirmed }); return res.json({ success: true, result }); }
  catch (error: any) { return res.status(502).json({ success: false, error: error.message || 'Unable to update refund status' }); }
});

// Public, read-only customer configuration. The browser never receives the
// Apps Script URL or private Settings/AdminUsers rows. Cache briefly and fail closed.
app.get('/api/public-config', async (req, res) => {
  const ip = String(req.ip || req.socket?.remoteAddress || 'unknown');
  if (!allowPublicAction(ip, 'public-config', 30, 10 * 60 * 1000)) {
    return res.status(429).json({ success: false, error: 'Too many configuration refreshes. Please retry shortly.' });
  }
  if (publicConfigCache && publicConfigCache.expiresAt > Date.now()) {
    res.setHeader('Cache-Control', 'public, max-age=30, stale-while-revalidate=30');
    return res.json(publicConfigCache.value);
  }
  try {
    const result = await callPublicAppsScript({ action: 'PUBLIC_GET_CONFIG' });
    if (result?.status !== 'success' || !result.config || result.config.version !== 1 ||
        !Array.isArray(result.config.packages) || result.config.packages.length !== 16 ||
        !Array.isArray(result.config.pickupPoints) || result.config.pickupPoints.length < 1 ||
        !result.config.rentalPricing || !Array.isArray(result.config.rentalPricing.localPackages) || result.config.rentalPricing.localPackages.length !== 6 ||
        !Array.isArray(result.config.rentalPricing.outstationRates) || result.config.rentalPricing.outstationRates.length !== 16) {
      return res.status(503).json({ success: false, error: 'Customer configuration is incomplete or unavailable.' });
    }
    const responseBody = { success: true, config: result.config };
    publicConfigCache = { expiresAt: Date.now() + 30_000, value: responseBody };
    res.setHeader('Cache-Control', 'public, max-age=30, stale-while-revalidate=30');
    return res.json(responseBody);
  } catch (error: any) {
    return res.status(502).json({ success: false, error: error?.message || 'Customer configuration service unavailable.' });
  }
});

// 2. Reliable Server-to-Server Google Sheets Proxy (Eliminates browser no-cors)
app.post('/api/sync-sheets', async (req, res) => {
  try {
    const { payload } = req.body || {};
    const allowedPublicActions = new Set(['NEW_BOOKING', 'NEW_RENTAL_ENQUIRY', 'CAR_RENTAL', 'PING_TEST']);
    // Require an explicit action: never infer a booking write from a missing or empty action.
    if (!payload || typeof payload !== 'object' || Array.isArray(payload) || typeof payload.action !== 'string' || !allowedPublicActions.has(payload.action)) {
      return res.status(403).json({ success: false, error: 'An explicit allowed public action is required. Use an authenticated Admin endpoint for Admin actions.' });
    }
    // Keep public writes bounded by client IP so the unauthenticated proxy cannot
    // be used to flood the Apps Script deployment. PING_TEST has its own bucket.
    let payloadBytes = 0;
    try { payloadBytes = Buffer.byteLength(JSON.stringify(payload), 'utf8'); }
    catch { return res.status(400).json({ success: false, error: 'Invalid public payload.' }); }
    if (payloadBytes > 64 * 1024) return res.status(413).json({ success: false, error: 'Public payload exceeds the 64 KB limit.' });

    const configuredUrl = process.env.GOOGLE_APPS_SCRIPT_URL || '';
    if (!configuredUrl) {
      return res.status(503).json({ success: false, error: 'The server-side Google Apps Script URL is not configured.' });
    }
    let target: URL;
    try { target = new URL(configuredUrl); }
    catch { return res.status(503).json({ success: false, error: 'Invalid server-side Google Apps Script URL.' }); }
    if (target.protocol !== 'https:' || target.hostname !== 'script.google.com' || !/^\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(target.pathname) || target.username || target.password) {
      return res.status(503).json({ success: false, error: 'Server-side Google Apps Script URL failed validation.' });
    }
    const ip = String(req.ip || req.socket?.remoteAddress || 'unknown');
    const requestLimit = payload.action === 'PING_TEST' ? 10 : 8;
    if (!allowPublicAction(ip, `sync:${payload.action}`, requestLimit, 10 * 60 * 1000)) {
      return res.status(429).json({ success: false, error: 'Too many requests. Please try again after 10 minutes.' });
    }
    const response = await fetch(target.toString(), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), redirect: 'follow', signal: AbortSignal.timeout(UPSTREAM_TIMEOUT_MS) });
    const text = await response.text();
    let data: any;
    try { data = JSON.parse(text); }
    catch { return res.status(502).json({ success: false, error: 'Google Apps Script returned a non-JSON response.' }); }
    if (!response.ok || !data || !['success', 'duplicate'].includes(data.status)) {
      return res.status(502).json({ success: false, error: data?.message || `Google Apps Script rejected the request (HTTP ${response.status})` });
    }
    return res.json({ success: true, backendResponse: data });
  } catch (error: any) {
    return res.status(502).json({ success: false, error: error?.message || 'Failed to communicate with Google Apps Script.' });
  }
});

// 3. Legacy booking-ID validation endpoint. This generates an ID only; it does not
// persist a booking. Actual booking submission continues through the approved sync flow.
app.post('/api/bookings/validate-and-create', (req, res) => {
  const ip = String(req.ip || req.socket?.remoteAddress || 'unknown');
  if (!allowPublicAction(ip, 'booking-id', 8, 10 * 60 * 1000)) {
    return res.status(429).json({ success: false, error: 'Too many booking validation attempts. Please try again after 10 minutes.' });
  }

  const validation = validateBookingIdRequest(req.body);
  if (!validation.valid) {
    return res.status(400).json({ success: false, error: validation.error });
  }

  const bookingId = `MDB-${localBookingDateCode()}-${crypto.randomInt(1000, 10000)}`;
  return res.json({
    success: true,
    bookingId,
    advanceRequired: 200,
    timestamp: new Date().toISOString()
  });
});

// Return predictable JSON errors for malformed or oversized JSON bodies.
// This handler must remain after API routes so parser errors reach it.
app.use((error: any, req: any, res: any, next: any) => {
  if (res.headersSent) return next(error);
  if (error?.type === 'entity.too.large' || error?.status === 413) {
    return res.status(413).json({ success: false, error: 'Request body exceeds the 256 KB server limit.' });
  }
  if (error?.type === 'entity.parse.failed') {
    return res.status(400).json({ success: false, error: 'Request body must contain valid JSON.' });
  }
  return next(error);
});

// Setup Vite middlewares in development or static serving in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Mumbai Darshan Bus Online Server running on port ${PORT}`);
  });
}

startServer();
