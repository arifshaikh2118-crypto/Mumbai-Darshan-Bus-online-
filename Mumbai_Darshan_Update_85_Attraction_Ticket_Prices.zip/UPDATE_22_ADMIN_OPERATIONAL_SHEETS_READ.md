# Update 22 — Secure Admin Operational Sheets Read Integration

## Completed
- Extended the authenticated `ADMIN_GET_DATA` Apps Script action to return all approved operational datasets: PickupPoints, PackageOptions, BookingDates, rental_vehicles, EmailLog, booking_notifications, activity_log, daily_reports, website_content, AttractionPoints and AttractionTickets.
- AdminUsers and Settings are deliberately excluded from the generic browser-facing Admin data response. This prevents exposing the authorization roster or potentially sensitive configuration values.
- Added a live Admin Console overview with record counts and expandable, read-only previews (first 10 rows) for each operational dataset.
- Added a refresh action that re-fetches data through the existing short-lived signed Admin session and trusted server proxy.
- No sheet/tab/column was added, renamed, reordered or removed. No supplier rate, supplier cost, margin or profit fields were introduced.
- These datasets are explicitly read-only in this release. Existing localStorage-based editors are not represented as successfully saved to Sheets; secure write endpoints for each tab require separate validation and are not enabled by this update.

## Security
- Data retrieval remains behind `requireAdmin` in the website server and `ADMIN_API_SECRET` plus active `AdminUsers` roster validation in Apps Script.
- `AdminUsers` and `Settings` are not returned.

## Not performed
- No Google Sheet created or modified; no Apps Script deployment; no live secrets configured; no GitHub commit; no Preview or production deployment.
