# Update 67 — Admin cancellation and refund workflow guardrails

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 66 — Core Booking and Payment Callback Security  
**Focus:** Admin booking status, cancellation review and manual refund workflow.

## Important issue found

The Admin booking-status action could set a booking directly to `Cancelled`. That bypassed the dedicated Cancellation & Refund Review record, which captures the cancellation reason and the verified-paid amount used as the refund review cap.

The refund-status handler also accepted arbitrary status changes. This allowed a cancellation to skip approval, move backwards after approval, or change away from a completed `Refunded` / `Rejected` outcome. It could also mark a zero-verified-payment cancellation as `Refunded`.

## Changes made

1. **Direct booking cancellation blocked**
   - Server and Apps Script Admin booking-status endpoints now reject direct `Cancelled` updates.
   - Admin booking status control no longer offers `Cancelled` as a new selectable status.
   - Historical bookings already marked `Cancelled` remain displayable.
   - Admin must use the dedicated Cancellation & Refund Review workflow to create an auditable cancellation record.

2. **Refund status state machine**
   - `Pending Review` can move to `Approved` or `Rejected`.
   - `Approved` can move to `Refunded` or `Rejected`.
   - `Refunded` and `Rejected` are terminal states.
   - Repeating the current status is idempotent and does not rewrite the audit row.
   - Invalid skips and backward transitions are rejected.

3. **Manual refund safeguards**
   - `Refunded` requires the strict boolean `manualRefundConfirmed === true`.
   - The cancellation record must have a positive verified-paid review cap; a zero-payment booking cannot be marked refunded.
   - The system still does not initiate a gateway refund. The Admin must complete the actual refund outside this system before confirming it.

4. **Admin UI alignment**
   - Cancellation review dropdown shows only the valid next states for the current status.
   - Existing `Refunded` / `Rejected` records are locked to their terminal state.
   - Existing cancelled bookings remain visible in the booking table without exposing a direct cancellation action.

5. **Regression tests**
   - Updated Apps Script runtime fixture to test direct-cancel rejection, positive and zero verified-paid cases, required approval, manual refund confirmation, terminal-state protection and same-state idempotency.
   - Added `validation/test_admin_cancellation_refund_state_machine.cjs` with 15 source-contract assertions.

## Verification

- Offline validation runner: **34/34 PASS**.
- Admin cancellation/refund guardrail assertions: **15 PASS**.
- Payment callback idempotency assertions from Update 66: **10 PASS**.
- TypeScript/TSX syntax transpilation: **35/35 PASS**, zero syntax diagnostics (syntax-only; not a semantic type-check).
- Apps Script `Code.gs` syntax: **PASS** (included in offline runner).
- JSON manifests/configuration: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full `npm run lint`, semantic type-check and `npm run build`: **not run**; project dependencies are not installed.
- Browser E2E and live Google Sheets / Apps Script tests: **not run**.

## Scope boundaries

- No sheet/tab/header/schema changes.
- No payment gateway integration or automatic refund capability was enabled.
- No pricing, rental enquiry, or other business rules changed.
- No Google Sheet creation, Apps Script execution/deployment, GitHub commit/push, Preview refresh, live email, external mutation, or production deployment.

**Overall status: INCOMPLETE / NOT production-ready.** Admin cancellation/refund transitions are more tightly controlled and offline-regression-tested. Live Sheets, browser E2E, full build and deployment verification remain outstanding.
