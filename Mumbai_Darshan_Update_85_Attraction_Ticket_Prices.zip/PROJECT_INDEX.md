# Mumbai Darshan Bus Online — Project Index
## Latest update: Update 85 (21 November 2026)

### Update 85 — Attraction Ticket Prices & On-Bus Guide Collection
- Restored and retained the owner-confirmed Bollywood Museum ticket price of **₹165/person**. This supersedes Update 84's temporary decision to remove the rate.
- Added the six-ticket/charge list to the homepage in the legacy Attraction Tickets section style: Boat Ride ₹210, Prince of Wales Museum ₹200, Orama 11D ₹220, Bollywood Museum ₹165, Sea Link Toll ₹10 and Guide Charge ₹50 per person.
- The homepage, dedicated Attraction Tickets & Charges page and route-pricing page read ticket prices from the existing Admin-controlled Extra Charges store. Admin Change Rate remains the owner-controlled price update mechanism.
- Optional attraction tickets are collected by the Tour Guide inside the bus only if the customer chooses to visit. Guide Charge and Sea Link Toll are compulsory and collected by the guide on the bus.
- All these charges remain separate from the online bus package fare and ₹200 advance. FAQ, booking summary and homepage collection copy now match this rule; obsolete Step 5 / venue-counter guidance removed.
- Offline validation 51/51 PASS; Update 85 regression 29 assertions PASS; Bollywood ₹165 regression 11 assertions PASS; TS/TSX/JS syntax 33 files / 0 errors; English-copy guard 36 files PASS; JSON parse 6/6 PASS.
- Semantic TypeScript check remains blocked by missing `vite/client`; Vite build remains blocked because Vite is not installed. Browser/mobile E2E not run.
- No live deployment, Sheets write, Apps Script deployment, payment, GitHub, Preview, hosting or DNS change.

**Overall: LOCAL UPDATE COMPLETE; INCOMPLETE / NOT production-ready. Do not deploy.**

See `UPDATE_85_ATTRACTION_TICKET_PRICES_AND_GUIDE_COLLECTION.md`, `MASTER_PROGRESS_TRACKER_UPDATE_85.md`, and `PROJECT_INDEX_Mumbai_Darshan_Update_85.md`.

---

## Previous update — Update 84
Public content accuracy, 44-point halt count, attraction collection audit and manual UPI refund wording. The Update 84 Bollywood Museum tariff-removal decision is superseded by Update 85 owner clarification; current public ticket rate is ₹165/person.

## Previous update — Update 83
Uniform bus fare, offer-off defaults, Bhayandar East 6:15 AM pickup, and booking-copy corrections. See `UPDATE_83_PRICE_PICKUP_AND_BOOKING_COPY_CORRECTIONS.md`.

## Previous update — Update 82
Public contact details and pickup catalogue guardrails. See `UPDATE_82_PUBLIC_CONTACT_AND_PICKUP_GUARDRAILS.md`.

## Previous update — Update 81
Centralized Local Darshan and Outstation rental pricing in protected Settings JSON without changing approved schema. See `UPDATE_81_RENTAL_PRICING_CENTRALIZED.md`.
