# Update 13 — Admin Booking Status Persistence Guard

Date: 11 November 2026

## Completed
- Admin booking status changes now call the configured Google Apps Script Web App through the existing `/api/sync-sheets` server proxy using `UPDATE_BOOKING_STATUS`.
- The browser's local booking record is changed only after Apps Script returns an explicit `status: success` response.
- Failed requests leave the local booking status unchanged and show an error to the Admin.
- Admin no longer has a manual Payment Status dropdown. Payment status is read-only in the booking detail view; only the trusted payment verification workflow may mark a booking paid.
- The existing Apps Script handler continues to reject manual paid states and refuses to confirm a booking unless its sheet row already has verified advance/full payment.
- No Google Sheets tab or column was added, removed, or renamed.

## Verification
- TypeScript/TSX syntax transpilation: 25 files, 0 syntax errors.
- `server.ts` TypeScript syntax transpilation: 0 syntax errors.
- Google Apps Script `Code.gs` parse: PASS.
- ZIP integrity: checked after packaging.

## Not verified / still pending
- Full Vite production build and dependency install: not run; dependencies are not installed in this environment.
- Live Google Sheets Admin status update: requires deployed Apps Script URL and a real test row.
- Admin list retrieval remains browser-local in this build. The existing 21-column Bookings schema does not contain every nested field required by the current Admin UI, and the Rental Enquiry master workbook's exact 19-column headings are not present in this package. No invented schema or lossy row mapping was introduced. A schema-backed read adapter is the next task after the authoritative workbook is available.
- GitHub upload/commit and Preview update: not performed. Preview remains on hold as requested.
- Production deployment: not performed.

## Repeatable method used
1. Extract the latest delivered Update 12 ZIP without resetting it.
2. Inspect the current Admin handlers, StorageService and Apps Script action contract.
3. Add a server-proxied Apps Script status update and update browser state only after server confirmation.
4. Remove the Admin-side manual paid-status control so payment verification remains authoritative.
5. Run TypeScript syntax transpilation, Apps Script parse, package ZIP and verify archive integrity.

## Change control
- New project backend is Google Apps Script + Google Sheets; no Supabase dependency is assumed.
- Preserve existing workbook tabs/headings and existing project history.
- No production deployment or payment activation without explicit approval.
