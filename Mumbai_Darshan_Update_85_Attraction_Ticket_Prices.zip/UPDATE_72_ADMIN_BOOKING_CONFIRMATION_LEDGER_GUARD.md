# Update 72 — Admin Booking Confirmation Requires Verified Ledger Evidence

**Date:** 20 November 2026  
**Status:** Offline implementation and validation complete; live verification pending.

## Summary

Audited the Admin booking-status workflow against the payment reconciliation rules. The previous Admin status guard trusted the `Payment Status` value in the Bookings row (`Advance Paid` / `Fully Paid`) without independently checking the linked payment ledger. A stale or manually altered label could therefore permit an Admin to mark a booking `Confirmed` or `Completed` even when the ledger did not contain valid verified payment evidence.

## Changes made

1. **Unique Booking ID required**
   - The Admin Apps Script action now counts matching Booking IDs.
   - Missing IDs are rejected.
   - Duplicate Booking IDs are rejected rather than updating the first matching row.

2. **Unique linked payment ledger row required for Confirmed / Completed**
   - The booking must have exactly one linked `booking_payments` row.
   - That row must have `payment_status = Verified`.
   - Missing, pending, or multiple ledger rows are rejected and directed to Admin reconciliation.

3. **Verified evidence must be complete and financially consistent**
   - Payment ID, transaction reference and verified timestamp must be present.
   - Verified amount and booking fare must be positive numeric values.
   - Verified amount cannot exceed the booking fare.
   - Amount must match the recorded advance/full-payment mode (₹200 advance cap or full booking fare).

4. **Express API now reflects Apps Script business failures**
   - `/api/admin/bookings/status` no longer returns `success: true` when Apps Script returns a business-level error.
   - Missing records return HTTP 404; other rejected updates return HTTP 409, with the underlying result and message preserved.

5. **Regression coverage**
   - Added `validation/test_admin_booking_confirmation_ledger_guard.cjs` with 10 source-contract assertions.
   - Expanded the Apps Script runtime fixture to cover a forged paid label without a verified ledger, missing transaction reference, duplicate payment ledger rows, successful completion with valid evidence, and duplicate Booking IDs.
   - Updated one legacy test expectation to match the existing English cancellation-panel message exactly; no UI copy was changed in that test-only adjustment.

## Validation results

- Main offline validation runner: **38/38 PASS**.
- New Admin confirmation / ledger source-contract test: **10 assertions PASS**.
- Apps Script `Code.gs` syntax: **PASS**.
- TypeScript/TSX syntax transpilation: **36 files, 0 syntax errors**.
- JSON configuration validation: **6/6 PASS**.
- ZIP integrity: **PASS**.

## Not performed

- Full `npm run lint` / semantic TypeScript type-check and `npm run build` were not run because `node_modules` is absent.
- Browser end-to-end testing was not run.
- No live Google Sheets workbook was read or modified; no Apps Script was executed or deployed.
- No production website deployment, GitHub push, Preview refresh, email, PhonePe/payment-gateway activation, or external mutation was performed.

## Scope and compatibility

- No sheet, tab, column, header, pricing, booking, payment, refund, or rental business rule was changed.
- The existing trusted payment callback remains the normal path that confirms a booking after successful provider verification.
- `Pending Verification` remains an allowed Admin status; the stricter ledger gate applies when setting `Confirmed` or `Completed`.
- All new validation messages and this update documentation are in English.

**Overall status: INCOMPLETE / NOT production-ready.** Live workbook review, browser testing and full build remain outstanding.
