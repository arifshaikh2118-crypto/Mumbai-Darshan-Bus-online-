# Update 37 — Work Completed, Not Completed & Remaining Work

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Previous baseline:** Update 36 — Deep Pre-External-Setup Cross-Check & Source Fixes  
**Release status:** INCOMPLETE — this is a continuation update, not a finished website.

## 1. What work was completed in Update 37

| # | Work item | Result |
|---|---|---|
| 1 | Review the Firebase Hosting guide against the actual project architecture | Completed |
| 2 | Correct the guide so it no longer suggests deploying the site as static-only | Completed |
| 3 | Explain that Firebase Hosting does not run the Express `server.ts` API | Completed |
| 4 | Document the conditional Firebase Hosting → Cloud Run rewrite approach | Completed as reference only; no service details invented |
| 5 | Add deployment gates for API routing, server secrets, runtime `PORT`, E2E, Preview and production approval | Completed |
| 6 | Update the current `PROJECT_INDEX.md` and Update 37 tracker | Completed |
| 7 | Package the updated source into a new ZIP and verify ZIP integrity | Completed |

## 2. What was not completed

| # | Work item | Status | Exact reason |
|---|---|---|---|
| 1 | Install project dependencies | Not completed | `npm install --legacy-peer-deps --no-audit --no-fund` timed out after 120 seconds in this environment. |
| 2 | Full TypeScript type-check / lint | Not completed | Dependencies and type packages are unavailable; `vite/client` could not be resolved. Syntax-only transpilation is not a full type-check. |
| 3 | Vite production build | Not completed | Build dependencies are not installed, so `npm run build` could not be run reliably. |
| 4 | Browser end-to-end tests | Not completed | No browser E2E runner is available in this environment and no built current bundle is available. |
| 5 | Confirm actual Express hosting target | Not completed | The source package does not establish the approved hosting target or actual Cloud Run service ID/region. |
| 6 | Connect Firebase Hosting `/api/**` to Express | Not completed | Requires owner/developer confirmation of hosting architecture and real backend service details. |
| 7 | Google Sheets staging setup and live tests | Not completed | Requires explicit owner approval and an isolated Google staging project; no external service was contacted. |
| 8 | Apps Script deployment/authorization and live concurrency tests | Not completed | Requires approved staging and authorization. |
| 9 | Live email test / trigger installation | Not completed | Explicit owner approval and controlled staging are still required; no email was sent. |
| 10 | GitHub commit / Preview refresh / production deployment | Not completed | These are later separately approved release steps; no publication or deployment was authorized. |
| 11 | PhonePe integration | Not completed | Merchant credentials and a separately approved server-side payment verification implementation are not available. |

## 3. What work remains — in priority order

### P0 — Must complete before Preview
- [ ] Run clean dependency installation on a network-enabled runner.
- [ ] Pass `npm run lint` and `npm run build`; fix all semantic/type/build errors.
- [ ] Confirm the actual Express hosting target.
- [ ] If Firebase Hosting + Cloud Run is approved, obtain the real service ID and region and configure `/api/**` rewrite before the SPA fallback.
- [ ] Verify API routes reach Express and Admin endpoints reject unauthenticated calls.
- [ ] Run browser E2E for booking submit/retry, rental enquiry, lookup, cancellation, Admin login/session expiry, protected status updates, email retry, refund review, daily reports and all seven operational CRUD tabs.
- [ ] Verify mobile booking flow and rental enquiry panel placement.

### P1 — Isolated Google Sheets / Apps Script staging (owner approval required)
- [ ] Run `setupDatabase()` once against an isolated staging project.
- [ ] Confirm 17 approved tabs / 139 headers and approved seed data.
- [ ] Configure private server environment variables and Apps Script Script Properties.
- [ ] Test booking writes, duplicate retries, inquiry-only rental writes, lookup/cancellation, Admin reads/mutations, EmailLog, notifications, daily reports, concurrency and throttling.
- [ ] Run controlled email test only after explicit approval; decide on trigger installation afterward.

### P2 — Later delivery (separate approval required)
- [ ] Commit source to GitHub.
- [ ] Refresh the existing Preview URL only after backend connectivity and E2E pass.
- [ ] Integrate PhonePe after merchant credentials and server-side signature/status verification are ready.
- [ ] Deploy Apps Script and production website; activate email and change DNS only with explicit approval.

## 4. Safety / external actions

No Google Sheet was created or modified. No Apps Script deployment or authorization occurred. No email was sent. PhonePe was not activated. No GitHub commit, Preview refresh, production deployment or DNS change occurred.

## 5. Verification evidence

- Apps Script CJS suites: PASS, 8/8 (from the Update 36 source package).
- Apps Script syntax and 29-file TypeScript/TSX syntax transpilation: PASS in Update 36.
- Schema regression: PASS, 17 tabs / 139 headers.
- ZIP integrity for this Update 37 package: PASS.
- Dependency installation: timed out after 120 seconds.
- Full lint/type-check and Vite build: not verified.
- Browser E2E and external staging: not run.

**Conclusion:** Update 37 completed one source-documentation/architecture correction and refreshed tracking. The website is not complete and is not production-ready. All incomplete items above remain open; none are marked complete by assumption.
