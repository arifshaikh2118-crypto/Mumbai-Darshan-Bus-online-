**Current-status note (Update 85):** Update 84's Bollywood Museum tariff-removal decision is superseded. Owner reconfirmed ₹165/person; Update 85 displays this rate in the homepage and Attraction Tickets & Charges pages. See `UPDATE_85_ATTRACTION_TICKET_PRICES_AND_GUIDE_COLLECTION.md`.

# Mumbai Darshan Bus Online — Project Index
## Latest update: Update 84 (21 November 2026)

### Update 84 — Public Content Accuracy & Attraction Collection Corrections
- Corrected Places Covered totals to 11 BUS_HALT and 33 NO_HALT based on the actual 44-point source catalogue.
- Removed the unverified fixed ₹165 Bollywood Museum tariff from public copy; venue confirmation is required.
- Added a narrow local-cache migration for only the exact old seeded ₹165 tour-point record; custom Admin edits remain intact.
- Admin tour-guide attraction collection logs now accept actual per-person rates per tour and calculate totals from entered values; historical logs remain unchanged.
- Aligned refund processing copy with manual UPI refunds and the 5–7 working day estimate; removed unsupported card/netbanking and automatic SMS/email claims.
- Preserved Update 83 uniform pricing, Bhayandar 6:15 AM, offers OFF by default and approved 17-tab / 139-header schema.
- Offline validation 50/50 PASS; Update 84 regression test 11 assertions PASS; TS/TSX syntax 32 files / 0 errors; Apps Script syntax PASS; English-copy guard 36 files PASS; JSON parse 6/6 PASS.
- Semantic TypeScript check remains blocked by missing `vite/client`; Vite build remains blocked because Vite is not installed. Browser/mobile E2E not run.
- No live deployment, Sheets write, Apps Script deployment, payment, GitHub, Preview, hosting or DNS change.

**Overall: LOCAL UPDATE COMPLETE; INCOMPLETE / NOT production-ready. Do not deploy.**

See `UPDATE_84_PUBLIC_CONTENT_ACCURACY_AND_ATTRACTION_AUDIT.md`, `MASTER_PROGRESS_TRACKER_UPDATE_84.md`, and `PROJECT_INDEX_Mumbai_Darshan_Update_84.md`.

---

## Previous update — Update 83
Uniform bus fare, offer-off defaults, Bhayandar East 6:15 AM pickup, and booking-copy corrections. See `UPDATE_83_PRICE_PICKUP_AND_BOOKING_COPY_CORRECTIONS.md`.

## Previous update — Update 82
Public contact details and pickup catalogue guardrails. See `UPDATE_82_PUBLIC_CONTACT_AND_PICKUP_GUARDRAILS.md`.

## Previous update — Update 81
Centralized Local Darshan and Outstation rental pricing in protected Settings JSON without changing approved schema. See `UPDATE_81_RENTAL_PRICING_CENTRALIZED.md`.
