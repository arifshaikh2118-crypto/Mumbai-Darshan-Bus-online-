# Update 31 — Booking Lookup Privacy, EmailLog, Notifications, Cancellation & Refund

**Date:** 11 November 2026  
**Baseline:** Update 30  
**Scope:** Complete the four P1 handler gaps identified in the Update 30 Apps Script audit.

## Implemented in source

### 1. Booking lookup privacy/security
- Disabled the old public GET lookup. Booking ID alone or mobile alone no longer returns a booking.
- Added POST lookup requiring both Booking ID and the exact registered 10-digit mobile.
- Added server per-IP throttling and Apps Script hashed booking/mobile attempt throttling.
- Response is a limited projection: masked customer name, travel date, route, pickup point, package, passenger count, fare, payment status and booking status.
- Does not return full mobile, email, special request, transaction reference or payment ledger data.
- Rebuilt customer lookup UI to use the server endpoint; it no longer reads localStorage for booking lookup.

### 2. EmailLog
- Added an exact six-column `EmailLog` append helper matching the approved schema.
- Customer booking emails, owner booking emails, email retries, owner connection-test emails and daily owner report attempts write Sent/Failed/Skipped status and error text.
- Live email remains disabled unless the owner enables `ENABLE_LIVE_EMAILS` in the approved Settings sheet.
- Confirmation emails are still only dispatched after trusted payment verification. Rental enquiries are excluded.

### 3. Booking notifications
- Added idempotent upsert into the exact eight-column `booking_notifications` schema.
- Verified booking confirmation creates customer and owner notification records. When live email is disabled they remain explicitly queued; no false Sent status is written.
- Email attempts update notification status and sent timestamp.
- Customer cancellation requests and Admin refund-status changes create internal follow-up notification records; these are recorded for Admin review, not falsely marked as delivered email/WhatsApp.
- Added authenticated Admin retry route/UI for failed or queued booking confirmation emails. Already Sent recipients are not resent by the retry helper.

### 4. Cancellation & refund
- Public cancellation request requires Booking ID + registered mobile + reason; server and Apps Script rate limits apply.
- Duplicate pending/approved requests are blocked.
- Cancellation record writes the existing approved eight columns only.
- `refund_amount` stores the verified-paid total as a review cap only; no client-supplied amount is trusted. It is not an automatically calculated final refund and does not apply any policy deduction.
- Admin can review Pending Review / Approved / Refunded / Rejected states through a session-protected API and Admin panel.
- Marking Refunded requires an explicit owner/Admin confirmation that the refund was actually completed manually.
- Approval/refund completion marks the booking Cancelled. No payment gateway refund is initiated.

## Verification completed
- All seven `google-apps-script/tests/*.cjs` suites pass.
- Schema harness tests booking lookup two-factor match, limited response, cancellation request, duplicate prevention, verified-paid refund amount, Admin refund confirmation gate, EmailLog writes, notification lifecycle rows and no extra sheets/columns.
- Apps Script `Code.gs` passes `node --check` after temporary `.js` copy.
- TypeScript/TSX syntax transpilation: 30 source files, zero syntax diagnostics (syntax-only check).
- Existing 17-tab / 139-header schema is unchanged.
- Existing 19-column rental enquiry and customer-only rental pricing remain unchanged.

## Not verified / not activated
- Full `tsc --noEmit` remains blocked because dependency type `vite/client` is unavailable in this environment.
- Vite production build and browser E2E are not run.
- No live Apps Script runtime or Google Sheets staging test was run.
- MailApp permission/real delivery is not tested; live email default remains OFF.
- No automatic refund is possible here; PhonePe/payment gateway remains deferred. Manual refund status is a record of owner confirmation only.
- Apps Script deployment, Google Sheet creation, GitHub commit, Preview update and production deployment were not performed.

## Exact next steps
1. Finish full dependency-backed TypeScript and Vite build.
2. Browser test public lookup and cancellation request, Admin notification retry and refund controls.
3. At owner-approved staging stage, test Apps Script/Sheets persistence and MailApp with a controlled test recipient.
4. Review cancellation policy wording/eligibility against the owner's final policy before enabling any customer-facing refund calculation. Current backend records verified paid amount only as a review cap and does not calculate a policy deduction or final refund amount.
5. Continue remaining Daily Reports and other pending handlers after this four-item milestone is accepted.
