# Mumbai Darshan Bus Online — Update 13

Admin booking status persistence and payment-state protection.

See `UPDATE_13_NOTES.md` and `PROJECT_INDEX.md` for changes, tests, limitations, and repeatable method.

Backend: Google Apps Script + Google Sheets. No Supabase dependency.
