# Update 79 — Booking Form & Car Rental Workflow Audit / Fix

**Date:** 21 November 2026  
**Baseline:** `Mumbai_Darshan_Update_78_Local_Work_Completed.zip`  
**Scope:** Local source audit and safe source fixes only. No live services were contacted or changed.

## 1. Critical finding and fix

### Rental enquiries were missing a mandatory field
- The customer rental form stored `rentalType` locally (`local_darshan` or `outstation`).
- `StorageService.syncRentalToGoogleSheets()` omitted `rentalType` from the public payload.
- `google-apps-script/Code.gs` requires that field and rejects every request unless it is exactly `local_darshan` or `outstation`.
- Result before this update: rental enquiry writes would be rejected by Apps Script even though the browser had the required value.
- Fix: added `rentalType: rental.rentalType` to the exact payload. The approved 19-column rental sheet mapping is unchanged.

## 2. Additional reliability fixes

- Increased public Booking ID and Rental Enquiry ID collision resistance. Both now use a 16-character token from `crypto.randomUUID()` where available, with a timestamped fallback. This replaces the previous 4-digit booking suffix and 3-digit rental suffix.
- Kept the original stable ID across retry attempts; no new ID is generated for a pending retry.
- Added customer-side rental validation matching Apps Script limits: name 3–100 chars, mobile 10 digits, passengers integer 1–50, outstation duration integer 1–30 days, night DA count integer 0–30, pickup/destination maximum 200 chars, and today-or-future local date.
- Added matching input bounds / step settings for relevant rental fields.
- Kept local tour guide at ₹2,000 flat per vehicle; local driver and parking remain included; outstation driver allowance/DA-Permit and parking/toll/border/entry remain extra at actuals as already defined.

## 3. Audit findings — no change required

### Booking amount and advance
- Customer UI calculates package fare as selected route/package unit price × passenger count, less any enabled route offer.
- The ₹200 advance is per booking, not per passenger; full-payment mode remains optional. Guide ₹50/person and Sea Link toll ₹10/person remain separate bus-side collections and are not added to the online package fare.
- Apps Script independently calculates the authoritative online fare from the approved `PackageOptions` sheet and computes the advance/full amount; it does not trust browser-supplied totals.
- It writes the booking to the approved 21-column `Bookings` sheet and a pending payment row to the approved `booking_payments` sheet. If the ledger write fails, it attempts rollback and returns an error/reconciliation state rather than acknowledging a partial save.
- No payment is treated as received: amount paid remains zero and booking remains `Payment Pending` / `Pending Verification` until trusted payment verification. PhonePe remains deferred.

### Four route price matrix
The initial source values still match the approved values:
- Western/Central: ₹200 Non-AC without lunch, ₹300 AC without lunch, ₹400 Non-AC + lunch, ₹500 AC + lunch.
- Harbour/Kalyan–Dombivli: ₹250 Non-AC without lunch, ₹350 AC without lunch, ₹450 Non-AC + lunch, ₹550 AC + lunch.
- Apps Script uses the approved `PackageOptions` sheet as write-time pricing authority and applies its enabled offer discount.

### Retry and duplicate protection
- Booking and rental drafts are locally persisted and read back before network submission.
- A pending retry pointer stores the exact original ID; refresh recovery reuses that ID.
- The browser requires the Apps Script response to echo the same Booking ID / Enquiry ID. Success or duplicate acknowledgement is accepted only for that same ID.
- Apps Script checks existing IDs under its script lock. Booking duplicate acknowledgement also checks that a linked payment ledger row exists; missing ledger evidence fails closed for reconciliation.
- Booking writes and payment-ledger writes are paired with rollback handling for partial failure.

### Rental quotation and Admin visibility
- Local rental estimate = selected local vehicle package + optional ₹2,000 flat guide fee.
- Outstation estimate uses garage → customer pickup → destination → garage road distance; billable distance is at least 300 KM per day; daily DA/permit and additional night DA are calculated separately. Toll/parking/border tax/entry remain actuals.
- The approved 19-column `rental_enquiry` schema intentionally has no quotation amount field. Quote breakdown is not persisted as a new column; the customer-facing form displays it and the existing special-requirements text records relevant DA/guide requests. No schema changes were made.
- Protected Admin data retrieval returns `rentalEnquiries`; Admin maps all approved enquiry fields and provides WhatsApp follow-up. Rental status updates use the authenticated Admin API and approved status column. No rental email or payment workflow is added.

## 4. Important remaining limitation

- **Public booking configuration is not yet hydrated from the approved Sheets-backed configuration.** The customer booking form still reads route/package/offer/pickup values from browser storage and initial defaults, while Apps Script writes against the authoritative `PackageOptions` sheet. If Admin changes Sheet prices without a corresponding public configuration refresh, the customer-displayed price can become stale even though the server records its own authoritative amount. This was already explicitly detected by `validation/test_public_config_readiness.cjs` and remains deferred to the later Sheets-backed public-configuration phase. Do not claim the live public price display is synchronized until that phase is completed and tested.
- Local rental package / outstation rates are also currently browser-storage/default-backed; live server-owned public rate hydration remains unverified.

## 5. Validation results

| Check | Result |
|---|---:|
| Main offline validation runner | **45/45 PASS** |
| New rental submission contract | **13 assertions PASS** |
| Apps Script rental runtime validation | **28 assertions PASS** (local + outstation, invalid input and duplicate ID) |
| TypeScript/TSX syntax transpilation | **36 files, 0 syntax errors** |
| Apps Script `Code.gs` syntax | **PASS** |
| English-copy guard | **35 files PASS** |
| ZIP integrity | **PASS** |
| Full semantic `tsc --noEmit` | **BLOCKED** — `vite/client` type definitions unavailable because `node_modules` is not installed |
| Vite production build | **NOT RUN** — Vite / dependencies are not installed |
| Browser E2E / real mobile device | **NOT RUN** — requires installed build/browser environment |
| Live Google Sheets / Apps Script | **NOT RUN** — owner deferred spreadsheet setup and Apps Script deployment |

## 6. Explicitly not performed

- No Google Sheet was created or modified; no Apps Script deployment or live write was made.
- No PhonePe/payment integration, payment collection, live email, or trigger setup.
- No schema tab/header/column change; approved 17 tabs / 139 headers and rental 19-column mapping are preserved.
- No GitHub commit/push/Actions, Preview refresh, backend/hosting deployment, DNS change or production deployment.
- No UI redesign or change to approved business prices/rental rates.

## 7. Next work

1. Complete remaining local source audit and documentation.
2. Later, after owner approval, implement the Sheets-backed public configuration endpoint/hydration so public displayed prices, pickup points and package options match server authority.
3. On a network-enabled runner, install dependencies from a real lockfile, run semantic type-check and production build.
4. Run browser E2E and real-device mobile checks.
5. Only after owner approval: setup Google Sheets automatically using the one-time Apps Script setup code, deploy Apps Script, configure secrets/backend hosting, and test live writes.

**Overall: INCOMPLETE / NOT production-ready. Do not deploy.**
