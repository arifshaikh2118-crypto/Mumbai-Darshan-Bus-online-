# Google Sheets & Apps Script — Current Setup Reference

**Mumbai Darshan Bus Online**  
Business email: `mumbaidarshanbooking@gmail.com`  
Business phone: `9619975457`

> **Status: deferred to a later phase by owner instruction.** Continue local source work first. Do not create a spreadsheet, deploy Apps Script, authorize MailApp, install triggers, or enable live email/payment now. The owner will not manually create a Google Sheet; the final single Apps Script setup code must create the spreadsheet and approved tabs automatically when this phase is approved.

## Approved database structure

The current source uses exactly **17 tabs / 139 headers**, defined by `schema/SCHEMA_SPEC.json` and `google-apps-script/Code.gs`. The bundled workbook is a reconstructed schema template based on the read-only schema audit snapshot; it is not the original `Google app script codegx.xlsx` file. See `schema/SCHEMA_WORKBOOK_README.md` for provenance.

The owner will not manually create a Google Sheet or type headings. At the approved setup stage, `setupDatabase()` creates the spreadsheet, stores `SPREADSHEET_ID`, creates only the approved tabs and headers, validates the schema, and seeds the 16 approved route/package rows only if `PackageOptions` is empty. Offers default OFF. Existing populated package rows are not overwritten.

## Current backend security model

- Public proxy accepts only `NEW_BOOKING`, `NEW_RENTAL_ENQUIRY` / `CAR_RENTAL`, and `PING_TEST`, and only the server-configured Apps Script URL.
- Public booking lookup and cancellation are dedicated POST endpoints; both require Booking ID and registered mobile.
- Admin reads and mutations go through authenticated Express routes and Apps Script `ADMIN_API_SECRET` plus an active `AdminUsers` roster entry.
- Direct public booking/rental status changes, email retry and email test actions are disabled.
- Rental enquiries are inquiry-only; no owner/customer email is sent.
- PhonePe/payment gateway is deferred. A browser must never call `PAYMENT_VERIFIED`.

## Private server configuration (only at staging)

Set these as private hosting/server environment variables, never in browser `VITE_*` variables or workbook cells:

- `GOOGLE_APPS_SCRIPT_URL`
- `ADMIN_PASSCODE`
- `ADMIN_SESSION_SECRET`
- `ADMIN_API_SECRET`

Set the same `ADMIN_API_SECRET` in Apps Script Project Settings → Script Properties. Add only authorized lowercase account emails to the `AdminUsers` roster with role `admin` or `owner` and `Active=TRUE`.

## Testing and release order

Follow `google-apps-script/DEPLOYMENT_GUIDE.md` for the controlled staging checklist. Do not run `setupDatabase()` or `setupDailyReportTrigger()` until owner approval. Keep `ENABLE_LIVE_EMAILS=false`. The website's **Test Business Email** control is intentionally informational only; controlled email authorization/test is owner-run from the Apps Script editor after approval. No email is sent through the public webhook.

Production remains blocked until full frontend type-check/build, browser E2E, isolated staging persistence/concurrency tests, private secret configuration, and explicit owner approval all pass.

## Customer Rental Pricing

Local Darshan and Outstation customer rates are stored as one validated JSON value under the existing `Settings` key `PUBLIC_RENTAL_PRICING_JSON`. This intentionally preserves the approved 17-tab / 139-header schema; no new tab or column is required. `setupDatabase()` seeds the six Local Darshan packages and sixteen Outstation rate classes from the existing audited website defaults only when the key is absent. Authorized Admins can edit the public customer rates in **Private Fleet & Quotations → Customer Rental Pricing**. The public configuration endpoint returns only this whitelisted rental-pricing object, never the full Settings sheet. Review every initial rate before final go-live.
