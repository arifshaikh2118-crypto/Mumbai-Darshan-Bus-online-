# Update 73 — Payment, Cancellation and Refund Record Integrity

**Date:** 20 November 2026  
**Status:** Offline implementation and validation complete; live verification pending.

## Summary

The follow-up audit found that several Apps Script workflows selected the first matching record when a Booking ID or Cancellation ID was duplicated. The trusted payment callback, public cancellation request, Admin cancellation creation, and refund-status transition could therefore operate on an ambiguous record. Cancellation review amounts also summed every verified payment row instead of requiring one unambiguous ledger row with complete evidence.

## Changes made

1. **Trusted payment callback**
   - Requires exactly one matching Booking ID before processing a verified payment callback.
   - Requires exactly one linked payment-ledger row before updating payment evidence.
   - Duplicate booking or payment rows return `reconciliation_required`; no payment or booking status is changed.

2. **Public cancellation request**
   - Counts all matching Booking IDs before matching the registered mobile number.
   - Duplicate Booking IDs fail closed instead of selecting the first matching booking.
   - Multiple linked payment rows fail closed and require Admin reconciliation.
   - A verified payment is used as the cancellation review cap only when payment ID, transaction reference, verified timestamp, positive amount, fare ceiling, and stored advance/full-payment mode all validate.
   - Pending or absent payment evidence continues to produce a zero review cap; the workflow does not invent a refund amount.

3. **Admin cancellation creation**
   - Requires exactly one matching Booking ID.
   - Rejects multiple linked payment-ledger rows.
   - Uses a verified payment amount as the review cap only when the ledger evidence and payment mode match the booking fare.

4. **Refund-status transition**
   - Requires exactly one matching Cancellation ID.
   - Before changing a refund state, requires exactly one linked Booking ID.
   - Duplicate or missing linked records are rejected before the cancellation status is written.
   - The existing manual-refund confirmation requirement and refund state machine remain unchanged.

5. **Regression coverage**
   - Added `validation/test_admin_payment_cancellation_uniqueness.cjs` with 14 source-contract assertions.
   - Added the new test to the main offline test discovery automatically (the existing runner scans `validation/test_*.cjs`).

## Validation results

- Full offline validation runner: **39/39 checks PASS**.
- New payment/cancellation uniqueness contract: **14 assertions PASS**.
- Existing Admin cancellation/refund state machine: **15 assertions PASS**.
- Existing payment reconciliation contract: **22 assertions PASS**.
- Apps Script `Code.gs` syntax: **PASS**.
- TypeScript/TSX syntax transpilation: **32 files, 0 syntax errors** (31 source files plus `server.ts`).
- JSON configuration: **6/6 PASS**.
- ZIP integrity: **PASS**.

## Not performed

- Full `npm run lint` / semantic type-check and `npm run build` were not run because `node_modules` is absent.
- Browser end-to-end testing was not run.
- No live Google Sheets workbook was read or modified; no Apps Script was executed or deployed.
- No production website deployment, GitHub push, Preview refresh, live email, PhonePe/payment-gateway activation, or external mutation was performed.

## Scope and compatibility

- No sheet, tab, column, header, pricing, booking, payment, refund, or rental business rule was changed.
- Payment gateway remains deferred. This change only hardens the existing trusted callback handler; it does not enable or invoke a provider.
- No Admin UI copy or customer-facing UI was changed in this update. All new validation messages, test names, and documentation are in English.

**Overall status: INCOMPLETE / NOT production-ready.** Live workbook review, browser testing and full build remain outstanding.
