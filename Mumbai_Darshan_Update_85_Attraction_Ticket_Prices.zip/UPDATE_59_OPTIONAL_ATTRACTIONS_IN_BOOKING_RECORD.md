# Update 59 — Optional attraction selections saved with the booking

**Date:** 20 November 2026  
**Scope:** Local customer booking source, Google Apps Script booking handler, and regression tests. No live spreadsheet or Apps Script deployment was performed.

## Issue found

The customer booking form already sent selected optional attraction names and passenger counts in the `NEW_BOOKING` payload. The Apps Script booking handler did not write that payload field into the approved 21-column `Bookings` row. As a result, a customer could select attractions, but the saved booking record did not retain those selections for the guide/team.

## Fix

- Persist optional attraction selections in the existing **Special Request** column (column 16); no new sheet column or tab was added.
- The saved note explicitly says the attraction selections are optional/offline and the guide collects the applicable fee only if the customer visits.
- Preserve the customer's own special request and append the attraction note after it.
- Bound the combined text to the existing 1,000-character field and pass it through `safeSheetText_` so formula-like input remains literal text.
- Do not add attraction charges to the online package fare or advance amount. The server-calculated online fare remains authoritative.
- A `None`/empty attraction selection adds no extra note.

## Regression tests

- Apps Script runtime test confirms selected attraction names and passenger counts are written to the existing Special Request cell.
- Test confirms the approved 21-column booking row remains unchanged and the online fare remains server-calculated (the test sends a forged browser total and still gets the approved fare).
- Test confirms the combined Special Request text stays within the existing 1,000-character column limit.
- Updated formula-injection test to verify the combined Special Request value is still sanitized.
- Frontend-to-Apps-Script contract test verifies the browser sends selected attraction names/counts and the Apps Script handler maps them into the existing column.

## Verification

- Offline validation runner: **28/28 PASS**.
- TypeScript/TSX syntax transpilation: **34/34 PASS**, zero syntax diagnostics (syntax-only; not a semantic type-check).
- Apps Script syntax: **PASS**.
- JSON manifests/configuration: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full npm lint/build: not run; dependencies are not installed locally.
- Browser E2E: pending.
- Live Google Sheets/Apps Script integration: not tested; spreadsheet bootstrap and deployment remain deferred as instructed.

## Scope boundaries

The approved 17-tab / 139-header schema, UI, route/package pricing, payment rules, and payment integration status were not changed. No Google Sheet, Apps Script deployment, payment gateway, GitHub, Preview, live email, or production deployment was touched.

**Overall status: INCOMPLETE / NOT production-ready.** The source now carries the selected attraction details into the booking record, but live persistence still needs to be verified during the later approved Sheets/Apps Script setup phase.
