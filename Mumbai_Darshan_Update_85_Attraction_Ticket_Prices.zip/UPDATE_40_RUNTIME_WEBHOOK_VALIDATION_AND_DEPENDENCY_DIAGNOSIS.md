# Update 40 — Runtime Webhook Validation & Dependency Network Diagnosis

**Project:** Mumbai Darshan Bus Online  
**Date:** 20 November 2026  
**Baseline:** Update 39 — Explicit Public Action Validation & Regression Hardening  
**Release status:** INCOMPLETE — runtime regression coverage improved; dependency installation, frontend build, browser E2E and external staging remain blocked.

## 1. What work was completed in Update 40

| # | Work item | Result |
|---|---|---|
| 1 | Added runtime-level Apps Script webhook test | Completed |
| 2 | Tested missing `action` payload | Rejected with HTTP 400 |
| 3 | Tested blank/whitespace `action` payload | Rejected with HTTP 400 |
| 4 | Tested non-string `action` payload | Rejected with HTTP 400 |
| 5 | Verified rejected requests release the Apps Script script lock | PASS |
| 6 | Verified an explicit allowed `PING_TEST` action still works | PASS |
| 7 | Added Update 40 offline test runner and changed `npm run test:offline` to use it | Completed |
| 8 | Updated README to describe the expanded regression suite | Completed |
| 9 | Re-ran offline validation | PASS, 10/10 checks |
| 10 | Re-parsed key JSON manifests | PASS, 4/4 |
| 11 | Updated Master Progress Tracker and packaged Update 40 ZIP | Completed; ZIP integrity verified |

## 2. Dependency installation diagnosis — not completed

A fresh lockfile-generation attempt was made:

```bash
npm install --package-lock-only --ignore-scripts --no-audit --no-fund --legacy-peer-deps --fetch-retries=0 --fetch-timeout=20000
```

**Observed result:**
- npm exited with code 1.
- `EAI_AGAIN` / `getaddrinfo` while resolving `registry.npmjs.org`.
- `package-lock.json` was not created.
- `node_modules` remains absent.
- Existing `bun.lock` remains 0 bytes and is not a usable dependency lockfile.

This is an environment DNS/network resolution failure, not proof of a source-code or dependency-version conflict. Do not fabricate a lockfile or claim dependencies are installed.

## 3. What was not completed — and why

| # | Work item | Status | Exact reason |
|---|---|---|---|
| 1 | Generate valid npm `package-lock.json` | Not completed | npm registry DNS lookup failed with `EAI_AGAIN` for `registry.npmjs.org`. |
| 2 | Install project dependencies | Not completed | Same registry DNS/network failure; `node_modules` remains absent. |
| 3 | Full TypeScript lint/type-check | Not completed | `tsc --noEmit` stops because `vite/client` type definitions are unavailable without dependencies. |
| 4 | Vite production build | Not completed | Vite and project dependencies are not installed. |
| 5 | Browser E2E | Not completed | No current production bundle or available browser E2E runner in this environment. |
| 6 | Confirm Express hosting target and `/api/**` routing | Not completed | Actual approved hosting target and Cloud Run service ID/region are not recorded in the project. |
| 7 | Google Sheets / Apps Script live staging | Not completed | Requires isolated staging and explicit owner approval. No external service was contacted. |
| 8 | GitHub, Preview, production, DNS, PhonePe and live email | Not completed | These are separately approved later-stage actions; none were authorized or performed. |

## 4. What work remains

### P0 — Dependency and build readiness
- [ ] Run dependency installation on a network-enabled runner with working DNS access to `registry.npmjs.org`.
- [ ] Generate and review a valid non-empty `package-lock.json`.
- [ ] Install reproducibly with `npm ci`.
- [ ] Pass `npm run lint`.
- [ ] Pass `npm run build`.
- [ ] Fix any semantic TypeScript/build errors.

### P0 — Hosting and browser verification
- [ ] Confirm the approved Express hosting platform.
- [ ] If Firebase Hosting + Cloud Run is selected, confirm real service ID and region and configure `/api/**` rewrite before SPA fallback.
- [ ] Verify `/api/*` reaches Express.
- [ ] Run browser E2E for booking, rental enquiry, lookup, cancellation, Admin authentication/session expiry, protected status updates, email retry, refunds, daily reports and all seven operational CRUD tabs.
- [ ] Verify mobile booking flow and rental enquiry panel placement.

### P1 — Isolated staging (owner approval required)
- [ ] Run `setupDatabase()` once against isolated staging.
- [ ] Verify 17 approved tabs / 139 headers and approved seed data.
- [ ] Configure private server secrets and Apps Script properties.
- [ ] Test booking writes, duplicate retries, inquiry-only rentals, lookup/cancellation, Admin APIs, EmailLog, notifications, daily reports, concurrency and throttling.
- [ ] Controlled email test only after explicit approval.

### P2 — Later separately approved delivery
- [ ] GitHub commit.
- [ ] Refresh existing Preview after backend and browser tests pass.
- [ ] PhonePe integration after merchant credentials and server-side verification are ready.
- [ ] Production Apps Script deployment, email activation, DNS/domain changes and website deployment only with explicit approval.

## 5. Verification evidence

- `npm run test:offline`: PASS, 10/10.
- Apps Script CJS regression suites: PASS, 9/9.
- Apps Script `Code.gs` syntax: PASS.
- Runtime webhook checks: missing, blank and non-string actions rejected; lock release verified; explicit PING_TEST accepted.
- Key JSON manifest parse checks: PASS, 4/4.
- npm lockfile generation: FAIL/BLOCKED due `EAI_AGAIN` DNS lookup to npm registry.
- `package-lock.json`: missing.
- `bun.lock`: 0 bytes, unusable.
- Dependency installation: not completed.
- Full `npm run lint`: BLOCKED by missing `vite/client` type definitions.
- `npm run build`: not run; dependencies unavailable.
- Browser E2E and external staging: not run.

## 6. Safety confirmations

No Google Sheet was created or modified. No Apps Script deployment or authorization occurred. No email was sent. PhonePe was not activated. No GitHub commit, Preview refresh, production deployment or DNS change occurred.

**Conclusion:** Update 40 adds runtime-level evidence that the Apps Script webhook fails closed for missing/blank/non-string actions while preserving valid explicit actions. It also confirms the dependency blocker is registry DNS resolution (`EAI_AGAIN`). The project remains incomplete and is not production-ready.
