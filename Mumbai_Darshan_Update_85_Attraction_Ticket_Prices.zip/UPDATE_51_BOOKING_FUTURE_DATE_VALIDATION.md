# Update 51 — Booking future-date validation

**Date:** 20 November 2026  
**Scope:** Local frontend source only. No external integrations or deployment.

## Finding

The booking date input already displayed a local-calendar minimum date, but the wizard's Step 1 validation only checked whether the date field was empty. A past date or an impossible date could therefore bypass the UI's intended minimum-date guard if the input state was changed outside the normal picker interaction.

## Changes

- Added `isTodayOrFutureLocalDate()` in `src/services/date.ts`.
- The helper accepts only strict `YYYY-MM-DD` values, rejects impossible calendar dates, and compares against the visitor's local calendar date (not UTC).
- Booking wizard Step 1 now calls the helper and blocks invalid or past dates with a clear message.
- Marked the date input as required while preserving its existing local `min` value.
- Added `validation/test_booking_future_date_validation.cjs`. It transpiles and executes the actual TypeScript helper and tests yesterday, today, tomorrow, impossible dates and malformed date strings.

## Verification

- Offline validation runner: **21/21 PASS**.
- TypeScript/TSX/JS/JSX syntax transpilation: **31/31 PASS** (syntax-only; not a semantic type-check).
- JSON manifests: **4/4 PASS**.
- Full npm lint/build: **not run**; project dependencies are not installed locally.
- Browser E2E: **pending**.

## Scope and limitations

This update hardens the customer-facing booking wizard's local validation. It does not claim server-side or Apps Script date validation. Google Sheets setup, Apps Script execution/deployment, payment, GitHub, Preview refresh, live email and production deployment remain deferred under the owner's sequencing instruction. No UI redesign, pricing, booking rules, approved schema, payment flow or external system was changed.

**Project status remains INCOMPLETE and NOT production-ready.**
