# Update 83 — Uniform Bus Fare, Pickup-Time and Booking-Copy Corrections

**Date:** 21 November 2026  
**Source baseline:** Update 82 — Public Contact Details & Pickup Catalogue Guardrails  
**Scope:** Local source audit and corrections only. No live deployment or external service mutation.

## 1. Owner-confirmed operating values

- Bhayandar East — Phatak, Sai Baba Temple: **6:15 AM** pickup; reporting at 6:00 AM.
- All four routes now use the same standard bus fares:
  - Non-AC without lunch: **₹250/person**
  - AC without lunch: **₹350/person**
  - Non-AC with breakfast and lunch: **₹450/person**
  - AC with breakfast and lunch: **₹550/person**
- The lunch-package difference remains +₹200/person, consistent with the existing package structure.
- New default package rows start with all route offers **OFF** and zero discount. Any previously active offer is switched OFF once; its discount value is retained so the owner can deliberately reuse or change it later.

## 2. Source corrections implemented

### Pricing and offers
- Updated all four route defaults in `src/data/initialData.ts` to the same rate card.
- Updated the Apps Script `setupDatabase()` seed rates in the existing `PackageOptions` tab; no tab or column was added.
- Added a one-time Apps Script migration for existing PackageOptions data. It changes only Western/Central rows whose stored fare exactly matches the previous default, preserves custom Admin prices, switches all currently active offers OFF once, and retains discount values for later manual activation. A script-property guard prevents repeat setup from turning off a future offer that the owner deliberately enables.
- Added a one-time browser local-storage migration for exact legacy Western/Central defaults. Custom local Admin prices are preserved; all active local offers are switched OFF once while their discount values remain available for later activation. The server-owned public `PackageOptions` configuration remains authoritative when it loads.
- Corrected the Pricing page's offer label so it follows the actual route/package offer flag. A disabled sheet offer cannot be presented as an active offer; a deliberately enabled offer still displays correctly.

### Pickup time and booking wording
- Confirmed the local pickup catalogue already has Bhayandar East at 6:15 AM and the FAQ already names 6:15 AM.
- Removed the generic 6:30 AM fallback from the booking payload. A real selected pickup always supplies its catalogue time; an absent pickup no longer invents a time.
- Updated the FAQ to say that a booking remains pending until the advance payment is verified, rather than claiming that payment automatically confirms reserved seats.
- Updated Terms & Conditions to state that shared tours do not issue individual seat numbers and seating is coordinated by the bus operator.

## 3. Regression coverage added/updated

- `validation/test_business_rules_alignment.cjs` now checks the uniform four-route rate card, all route offers OFF by default, legacy cache migration, Bhayandar 6:15 AM, no invented pickup-time fallback, payment-verification wording, no-seat-number wording, and the existing guide/toll/lunch/rental rules.
- `google-apps-script/tests/test_schema_alignment.cjs` now verifies all 16 seeded package/route rows, zero/off offer defaults, exact legacy price migration, preservation of custom Admin rates, and that a future Admin-enabled discount still applies.
- Approved Google Sheets schema remains **17 tabs / 139 headers**.

## 4. Validation results

| Check | Result |
|---|---:|
| `npm run test:offline` | **49/49 PASS** |
| TypeScript/TSX syntax transpilation | **32 files / 0 errors** |
| Apps Script syntax | **PASS** |
| English-copy guard | **36 source files PASS** |
| ZIP integrity | **PASS** — archive test completed with no errors |
| Semantic `npm run lint` | **BLOCKED** — `vite/client` type definitions unavailable (`TS2688`) |
| `npm run build` | **BLOCKED** — Vite is not installed (`vite: not found`) |
| Browser / real-device E2E | Not run |
| Live Sheets / Apps Script | Not run; no external mutation |

## 5. Important live-data limitation

This update changes local source only. It does **not** change the currently deployed website or any existing Google Sheet. The Apps Script migration runs only when the owner later runs the approved `setupDatabase()` workflow. Until the corrected source is deployed and any existing `PackageOptions` data is refreshed through the approved process, the live website may continue showing its currently published values. No deployment is authorized by this update.

## 6. Not changed

- No live website deployment, Firebase Hosting change, DNS change, Preview refresh, GitHub push, Google Sheet write, Apps Script deployment, payment gateway/PhonePe activation, or live email test.
- No approved sheet tab/header/schema changes.
- No change to ₹200 advance per booking, ₹50/person guide charge, ₹10/person Sea Link toll, lunch choices, pickup catalogue size, rental billing rules, Supabase retention, or rental enquiry-only workflow.
- Attraction ticket rates remain subject to separate venue verification; this update does not certify them as current.

**Overall status: Local corrections complete; production release remains incomplete and explicitly not deployed.**
