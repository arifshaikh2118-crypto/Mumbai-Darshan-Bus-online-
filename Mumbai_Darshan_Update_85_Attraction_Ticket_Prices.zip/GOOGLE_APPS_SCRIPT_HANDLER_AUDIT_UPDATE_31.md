# Apps Script Handler Audit — Update 31

## Four Update 30 findings and closure status

| Finding | Update 31 result |
|---|---|
| Public booking lookup exposes data by ID/mobile | Old GET path now rejects; POST requires exact Booking ID + registered mobile; response is limited/masked; server and Apps Script throttles added. Local test PASS. |
| EmailLog append path unclear | Added exact six-column append helper and wrappers for customer/owner sends, retries, connection test, daily report. Local test PASS. |
| booking_notifications had no write path | Added idempotent notification upsert for verified-payment booking emails and cancellation/refund follow-up events. Added authenticated retry. Local test PASS. |
| booking_cancellations had no creation/refund workflow | Added public verified cancellation request, verified-payment-only amount, duplicate protection, Admin review API/UI and manual refund confirmation. Local test PASS. |

## Security notes
- Booking lookup no longer uses GET query-string credentials.
- Only booking ID + registered mobile exact match can retrieve the limited projection.
- No full phone, email, special request or payment transaction reference is returned.
- Cancellation request is similarly verified against booking ID + mobile.
- Admin refund status changes require the signed Admin session through the server proxy and Apps Script secret/roster gate.
- Marking `Refunded` is blocked unless the caller explicitly confirms that the actual refund was completed manually.
- No payment gateway refund is sent by Apps Script.
- Notification `Pending Admin Review` and `Recorded - Admin Follow-up` are internal records, not a claim that email/WhatsApp was delivered.

## Schema integrity
- EmailLog: 6 columns unchanged.
- booking_notifications: 8 columns unchanged.
- booking_cancellations: 8 columns unchanged.
- No tabs or columns added.

## Test coverage
- Seven automated CJS suites pass.
- Schema harness checks exact lookup match, masked projection, wrong-mobile rejection, cancellation duplicate prevention, verified payment aggregation, Admin manual refund gate, EmailLog exact rows, notification writes and schema invariance.
- Apps Script syntax check passes.
- TypeScript/TSX syntax transpile passes for 30 files.

## Not covered by this local audit
- Live Apps Script execution, real Google Sheets persistence, MailApp authorization/delivery, browser E2E, production type-check/build, gateway refund or PhonePe callbacks.
