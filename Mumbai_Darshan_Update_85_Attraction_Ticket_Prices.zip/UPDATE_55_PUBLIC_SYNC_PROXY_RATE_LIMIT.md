# Update 55 — Public Sheets Sync Proxy Rate Limit

**Date:** 20 November 2026  
**Scope:** Local Express proxy hardening only. No external integrations or deployment.

## Finding

The public `/api/sync-sheets` proxy accepted the approved unauthenticated booking and rental write actions but had no Express-side per-IP request throttle. The lookup and cancellation endpoints were already throttled, but that protection did not cover new booking/rental writes through this proxy.

## Changes

- Added per-IP, per-action throttling to `/api/sync-sheets` after action and configured destination validation.
- `NEW_BOOKING`, `NEW_RENTAL_ENQUIRY`, and `CAR_RENTAL`: maximum **8 requests per IP per 10 minutes per action**.
- `PING_TEST`: separate bucket, maximum **10 requests per IP per 10 minutes**.
- Requests over the limit receive HTTP **429**; existing public rate-limiter capacity/expiry behavior is reused.
- Added a **64 KB serialized payload limit** for the public proxy, returning HTTP 413 when exceeded.
- Preserved the explicit public action allowlist and server-configured Apps Script URL pinning. Admin actions remain blocked from the public proxy.
- Added `validation/test_public_sync_rate_limit.cjs` to guard the action allowlist, payload cap, per-IP/action throttle, 429 behavior and destination pinning.

## Verification

- Offline validation runner: **25/25 PASS**.
- TypeScript/TSX/JS/JSX syntax transpilation: **33/33 PASS** (syntax-only; not a semantic type-check).
- JSON manifests: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full npm lint/build: **not run**; dependencies are not installed locally.
- Browser E2E: **pending**.

## Limitations and scope

- Rate limiting remains process-local/in-memory, resets on server restart, and is not shared across multiple server instances. A distributed limiter would require a separately approved shared store/infrastructure change.
- The 64 KB limit is applied to the serialized proxy payload after Express JSON parsing; it does not replace the global request-body parser limit.
- No Google Sheet, Apps Script deployment, payment gateway, GitHub repository, Preview, live email or production service was touched.
- No UI, pricing, booking rules, rental rules, approved schema or Admin API contract was changed.

**Project status remains INCOMPLETE and NOT production-ready.**
