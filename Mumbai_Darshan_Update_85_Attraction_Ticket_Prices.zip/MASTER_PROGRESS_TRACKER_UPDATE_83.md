# Mumbai Darshan Bus Online — Master Progress Tracker
## Update 83 — Uniform Bus Fare, Pickup-Time and Booking-Copy Corrections

**Date:** 21 November 2026  
**Source baseline:** Update 82

## Completed in Update 83
- [x] Confirmed Bhayandar East pickup is 6:15 AM; the local catalogue and FAQ agree.
- [x] Removed the generic 6:30 AM fallback from booking payloads so a missing pickup never invents a time.
- [x] Set all four route defaults to Non-AC ₹250 / AC ₹350 per person.
- [x] Retained the existing +₹200 lunch-package differential: Non-AC + breakfast/lunch ₹450; AC + breakfast/lunch ₹550.
- [x] Set all route offers OFF for the current policy; retained discount values for later manual activation and guarded the migration so future deliberate offers survive repeat setup.
- [x] Updated Apps Script bootstrap seed prices in the existing PackageOptions tab.
- [x] Added one-time Apps Script migration for exact legacy Western/Central defaults; custom Admin prices are preserved.
- [x] Added browser local-cache migration for exact legacy Western/Central defaults; custom local prices are preserved.
- [x] Fixed Pricing page offer status text to reflect the actual package/route offer state.
- [x] Corrected FAQ booking wording so payment verification is required before confirmation.
- [x] Corrected Terms wording: shared tours do not issue individual seat numbers.
- [x] Added/updated regression tests for price parity, pickup time, offer-off defaults, future offer activation and migration safety.
- [x] Preserved approved schema: **17 tabs / 139 headers**.

## Validation
| Check | Result |
|---|---:|
| Offline validation | **49/49 PASS** |
| TypeScript/TSX syntax transpilation | **32 files / 0 errors** |
| Apps Script syntax | **PASS** |
| English-copy guard | **36 files PASS** |
| ZIP integrity | **PASS** |
| Full semantic TypeScript check | Pending — `vite/client` type definitions unavailable (`TS2688`) |
| Vite production build | Pending — Vite not installed |
| Browser / mobile E2E | Pending |
| Live Sheets / Apps Script verification | Not run; owner-deferred |

## Important data and deployment boundary
- No live website, Google Sheet, Apps Script deployment, Firebase Hosting, DNS, Preview, GitHub, payment gateway, or email service was changed.
- The future `setupDatabase()` run will migrate only exact previous Western/Central default prices, preserve custom base rates, switch all active offers OFF once, retain discount values, and use a script-property guard so later manual offer activation survives repeat setup.
- Existing Google Sheets data is not changed until the owner explicitly authorizes and runs the approved setup/migration workflow.
- If the live site is still reading old `PackageOptions` rows, it can continue showing old values until the approved data refresh and deployment occur.

## Remaining work
- [ ] Confirm current `PackageOptions` rows during the later approved Sheets staging phase.
- [ ] Verify public pricing after an owner-approved staging deployment.
- [ ] Verify the live cached cancellation/privacy pages against the source policy component; this update did not change live pages.
- [ ] Review attraction ticket rates against current venue tariffs before claiming them as current.
- [ ] Review the public rental rate card before publication; source defaults remain subject to owner review.
- [ ] Install dependencies in a network-enabled environment and complete semantic TypeScript check / Vite build.
- [ ] Browser E2E and real-device mobile checks.
- [ ] Complete all local source work before GitHub/network build phase.
- [ ] Google Sheets creation/setup, Apps Script deployment, PhonePe/payment, live email, Preview refresh, hosting/DNS and production deployment remain deferred until explicit approval.

## Owner constraints preserved
- No manual Google Sheet creation; later provide one automatic setup script.
- No schema/tab/header changes without approval.
- Keep Supabase until migration is fully tested and removal is explicitly approved.
- Rental enquiries remain inquiry-only; no owner/customer rental email.
- No live deployment or external mutation without explicit approval.
- Each update includes a ZIP, Project Index, report, changed-file list and tracker.

**Overall status: Local corrections complete; project remains INCOMPLETE / NOT production-ready. Do not deploy.**
