# Mumbai Darshan Bus Online — Master Progress Tracker
## Update 30 — Consolidated completion, pending work and next actions

**Date:** 11 November 2026  
**Source baseline:** Update 29 — Network Enabled Runner  
**This update:** Documentation/status consolidation only. No application source, UI, pricing, schema, Apps Script runtime, Google Sheet, GitHub repository, Preview or production deployment was changed.

---

## 1. Current overall position

The project has a substantial amount of source-code work completed for the Google Sheets + Google Apps Script migration and Admin control centre. However, the project is **not yet end-to-end verified or ready for live operation**. The biggest outstanding gates are full dependency-backed build validation, real browser testing, and staging Google Sheets/Apps Script verification.

**Important status distinction:** “Implemented in source” means code and automated/static checks exist in the ZIP. It does not mean a deployed Apps Script, Google Sheet, browser workflow or live booking has been tested.

## 2. Completed in source / local automated verification

### A. Approved Google Sheets schema
- Schema workbook and `schema/SCHEMA_SPEC.json` included in the source package.
- 17 approved tabs and 139 approved header cells represented in the schema reference.
- Booking sheet mapping targets the approved 21 columns.
- Rental enquiry mapping is intended to preserve the approved 19-column inquiry schema.
- Payment, cancellation, notification, activity, email log, reports, operational and attraction sheets are represented in the schema.
- Generic operational editing is limited to the seven approved operational tabs; protected tabs are not exposed to generic CRUD.
- No new sheet or column is authorized by this tracker.

**Important reference limitation:** The original owner workbook `Google app script codegx.xlsx` was not recovered in the latest working package; the included schema workbook is a reconstructed/approved working reference. At final setup, the owner-approved original workbook/register must be cross-checked if it becomes available. Do not silently rename tabs or columns to resolve any discrepancy.

### B. Google Apps Script / backend source
- Schema validation and bootstrap code are included.
- `setupDatabase()` is designed to create a new spreadsheet automatically using `SpreadsheetApp.create()` when no spreadsheet ID is configured, store the ID in Script Properties, and reopen it on later runs.
- Runtime handlers validate required sheets/headers rather than silently creating missing tabs.
- Booking write mapping and duplicate protection are implemented in source.
- Booking acknowledgement is payment-pending; sheet-save acknowledgement alone does not confirm a booking.
- Trusted payment-verification gate exists in source; it is intended for server-to-server use and requires secrets/provider verification.
- Rental enquiry duplicate-safe submission and inquiry-only policy are represented in source.
- Admin authentication/session checks, protected Admin data retrieval and protected mutation endpoints are implemented in source.
- Operational sheet upsert/delete endpoints require an authenticated Admin session and validate approved sheet/column configuration.
- Activity logging is wired for relevant Admin actions in source.
- Public/unauthenticated Admin mutation paths are fail-closed.

### C. Admin Dashboard source
- Admin login and protected data retrieval source implemented.
- Bookings and Rental Enquiries data panels are connected to protected backend API paths in source.
- Booking and Rental Enquiry status update paths are protected by Admin session checks in source.
- Seven operational sheet editors have Add/Edit/Delete UI source:
  1. `PickupPoints`
  2. `PackageOptions`
  3. `BookingDates`
  4. `rental_vehicles`
  5. `website_content`
  6. `AttractionPoints`
  7. `AttractionTickets`
- Editors use existing approved headers, stable key protection, delete confirmation and refresh-after-write wiring.
- Other operational/reference tabs have read/preview source, while sensitive tabs such as `AdminUsers` and `Settings` are not exposed as generic browser data.

### D. Rental pricing and enquiry policy
- Rental Enquiry is inquiry-only, not a confirmed vehicle booking.
- The existing 19-column Rental Enquiry schema is to remain unchanged.
- Rental enquiry does not send customer/owner email notifications; WhatsApp is the follow-up channel.
- Customer-facing rental rates are the final rates already agreed by the owner.
- The existing ₹5 increase is already included in the customer rates; do not add another ₹5.
- No supplier rate, supplier cost, margin, profitability or supplier private details system should be added to the customer enquiry workflow or Admin UI.
- Do not add columns/tabs for supplier rates or profit without a new explicit request (current direction is not to add them).

### E. Payment and email safety source
- Booking creation remains pending payment/verification and must not be represented as a confirmed travel ticket.
- PhonePe/payment gateway is not activated; no live payment checkout or collection is available yet.
- Customer/owner confirmation emails are gated behind verified payment in source.
- Live email dispatch remains disabled/owner-controlled until final configuration and testing.

### F. Automated/static checks recorded in prior updates
- Schema alignment tests: PASS in the recorded local test runs.
- Admin security tests: PASS in the recorded local test runs.
- Rental enquiry policy tests: PASS in the recorded local test runs.
- Customer rental rate model tests: PASS in the recorded local test runs.
- Admin operational write policy tests: PASS in the recorded local test runs.
- Admin operational UI wiring tests: PASS in the recorded local test runs.
- Apps Script syntax checks: PASS in the recorded local test runs.
- TypeScript/TSX syntax transpilation: 26 files, zero syntax diagnostics in the recorded run.
- ZIP integrity checks: PASS for the delivered packages.

These results are local/static checks only; they do not replace full type-check, production build, browser E2E or live Sheets verification.

---

## 3. Not completed / pending — exact list

### P0 — Build and browser validation (deferred at owner's instruction for now)
- [ ] Commit the Update 29 network-enabled workflow to GitHub `main`.
- [ ] Run the GitHub Actions network-enabled workflow.
- [ ] Capture actual dependency-install result, run URL and commit SHA.
- [ ] Run `npm run lint` (`tsc --noEmit`) and fix genuine type errors.
- [ ] Run `npm run build` and fix genuine Vite/build errors.
- [ ] Inspect the production `dist` output and verify expected assets/routes.
- [ ] Run browser-based E2E tests; current static checks do not prove UI behavior.
- [ ] Test each of the seven operational tabs: create → reload → edit → reload → delete → reload.
- [ ] Verify unauthorized, expired and malformed Admin sessions are rejected in browser/API tests.
- [ ] Verify Activity Log rows are written for successful mutations and rejected actions as designed.

**Current blocker:** The local environment repeatedly timed out while installing npm dependencies and could not provide a dependable browser runtime. The network-enabled GitHub workflow exists in Update 29 but has not been committed or run. Per latest owner instruction, leave this runner task for later and continue with other project work; do not report it as passed.

### P1 — Apps Script and Google Sheets staging verification
- [ ] Confirm the final approved schema against the original owner workbook/register if it is supplied/recovered; reconcile only with explicit approval.
- [ ] Review all Apps Script handlers against every approved sheet and exact header.
- [ ] Create a dedicated staging spreadsheet only at the approved setup stage by running `setupDatabase()`; owner should not manually create a blank sheet/tabs/headings.
- [ ] Confirm setup creates exactly the approved 17 tabs/139 headers and is idempotent on rerun.
- [ ] Confirm the staging spreadsheet ID is stored in Script Properties and production/retired IDs remain protected.
- [ ] Deploy Apps Script as a staging Web App and record deployment/version details.
- [ ] Configure only the required staging secrets in Script Properties/server environment; never place secrets in browser code or sheets.
- [ ] Verify booking create, duplicate retry, payment-pending status and exact 21-column row mapping.
- [ ] Verify rental enquiry create, duplicate retry and exact 19-column row mapping; verify no emails are sent.
- [ ] Verify Admin login, expiry, lockout, authorized AdminUsers allowlist, data reads and protected writes.
- [ ] Verify all seven operational tabs persist Add/Edit/Delete after a fresh read.
- [ ] Verify payment ledger, cancellation, notification, email log, activity log and daily report behavior where handlers are enabled.
- [ ] Verify no runtime handler silently creates an unapproved tab or column.

### P2 — Backend hosting / API architecture
- [ ] Resolve the known hosting mismatch: `firebase.json` currently describes static Firebase Hosting; Express `/api/*` routes in `server.ts` do not run merely because static files are hosted.
- [ ] Select and configure an approved secure server runtime/proxy for `/api/*` (e.g. an explicitly selected Cloud Run/Functions architecture); do not invent a production target or deploy without approval.
- [ ] Ensure browser requests reach the secure server proxy and the proxy forwards only to the validated Apps Script `/exec` endpoint.
- [ ] Confirm secrets are server-side only and CORS/auth behavior is correct.
- [ ] Verify health checks, error handling, logs, rate limiting and safe retry/idempotency behavior.

### P3 — Booking, payments and email completion
- [ ] Complete end-to-end booking submission through the deployed secure proxy and staging Apps Script.
- [ ] Verify customer receipt is shown only after a confirmed Sheets save; pending-payment wording remains clear.
- [ ] PhonePe merchant onboarding/credentials and provider integration remain deferred until owner supplies credentials and explicitly authorizes activation.
- [ ] Implement provider callback/signature verification and independent payment-status query server-side before invoking `PAYMENT_VERIFIED`.
- [ ] Configure `PAYMENT_CALLBACK_SECRET` only in secure server/Apps Script settings at the final approved stage.
- [ ] Verify payment ledger-first update, duplicate transaction rejection, matching amount and booking confirmation after verified payment.
- [ ] Configure business email `mumbaidarshanbooking@gmail.com` only at final stage; preserve this address.
- [ ] Test owner/customer confirmation email delivery only after verified payment; verify queued status when live email is disabled.
- [ ] Verify EmailLog rows and safe retry behavior.
- [ ] Cancellation/refund workflow and notification dispatch need real staging validation; do not claim refunds are processed unless an actual provider workflow exists.

### P4 — Remaining Admin workflows and business operations
- [ ] Complete field-level validation and role/permission matrix for Admin/Owner roles.
- [ ] Verify Booking list filters/search/pagination and permitted status actions against live staging data.
- [ ] Verify Rental Enquiry follow-up/status flow and WhatsApp handoff; no email notifications for rental enquiry.
- [ ] Confirm final customer quote workflow uses only customer-facing rates; no supplier cost/margin/profit fields.
- [ ] Review reports/daily reports against source booking/payment data and verify totals.
- [ ] Verify EmailLog, booking_notifications, booking_cancellations and activity_log UI/operational handling.
- [ ] Verify attraction/pickup/package/booking-date settings reflect correctly in the customer booking form after save and refresh.
- [ ] Review website_content publishing/status behavior and ensure inactive content is not shown publicly.
- [ ] Audit Admin data export/privacy controls and ensure customer PII is not exposed to public pages.

### P5 — Preview, GitHub and final release
- [ ] After build + staging + browser gates pass, update the existing GitHub source repository with the approved source changes while preserving commit history/tags.
- [ ] Run the existing preview workflow using the successful cloud-runner method.
- [ ] Update the existing PageShare Preview URL only; do not create a second preview site.
- [ ] Inspect preview on mobile and desktop and verify booking/rental forms, navigation, pricing and Admin access behavior.
- [ ] Obtain owner approval before any production deployment.
- [ ] Final production checklist: environment secrets, Apps Script deployment, secure API host, domain/DNS, Firebase/hosting routing, email settings, payment provider and rollback plan.

---

## 4. Items explicitly deferred / not to do without approval

- Do not run `setupDatabase()` or create the staging spreadsheet until the final setup stage is explicitly approved.
- Do not modify the production spreadsheet or production data.
- Do not enable PhonePe or collect real payments before provider credentials and secure verification are configured.
- Do not enable live email sending before owner approval and staging delivery tests.
- Do not deploy the website or change the domain/hosting architecture without explicit approval.
- Do not update the existing Preview until the agreed validation threshold is reached.
- Do not add supplier rate/cost/margin/profit fields or systems; final customer rental rates already include the agreed ₹5 increase.
- Do not change the 17 approved tabs/139 headers or Rental Enquiry's 19 columns without explicit approval.
- Do not manually create Google Sheets tabs/headings; Apps Script must create the spreadsheet automatically at the final approved setup stage.

---

## 5. Known source/configuration risks to resolve

1. **Static hosting vs Express API:** static Firebase Hosting alone cannot execute `server.ts` Express routes. A real secure API host/rewrite is required before online data operations can work.
2. **No live deployment proof:** Apps Script setup/deployment, server secrets, Google Sheet staging writes and Gmail delivery have not been executed in this work sequence.
3. **No complete production build proof:** syntax transpilation is not equivalent to `tsc --noEmit` or Vite build.
4. **No browser E2E proof:** UI wiring tests are static/automated source checks; they do not prove persistence in a real browser.
5. **Schema source-of-truth:** reconstructed schema workbook is included; compare to the original owner workbook if it becomes available before final setup.
6. **Legacy notes:** older Update 12 text mentions supplier cost/margin quotation fields. That is superseded by the later owner decision in Updates 20–21: Rental Enquiry remains 19-column inquiry-only and no supplier cost/margin/profit system is to be retained or added. Follow the latest owner decision.

---

## 6. Recommended next work order (excluding network runner for now)

1. **Final backend handler audit:** map every Apps Script action to its exact tab/columns, authorization gate, idempotency behavior and audit log. Mark each handler implemented, blocked or absent.
2. **Hosting/API architecture decision note:** document the minimum secure runtime needed for `/api/*` and compare viable options without deploying or changing production.
3. **Booking + Rental workflow contract audit:** compare frontend payloads, Express proxy and Apps Script handlers; identify mismatched field names/statuses and fix only confirmed source defects.
4. **Notification + EmailLog + ActivityLog workflow audit:** verify exact event triggers, no rental enquiry emails, payment-first booking emails, and logging behavior.
5. **Cancellation + refund workflow audit:** document which parts are code-only, which require a payment provider, and prevent false refund/notification success.
6. After these source audits, return to the deferred network runner, complete full build/browser tests, then staging Google Sheets tests.

---

## 7. Apps Script handler audit findings (Update 30)

A static handler-to-schema audit was completed and saved as `GOOGLE_APPS_SCRIPT_HANDLER_AUDIT_UPDATE_30.md`. Key findings:

- Core source actions exist for booking create, rental enquiry create, trusted payment verification, Admin auth/data read, operational upsert/delete, and secure Admin booking/rental status updates. None has been verified against a deployed staging Apps Script/Google Sheet.
- Public `UPDATE_BOOKING_STATUS`, `UPDATE_RENTAL_STATUS`, `RETRY_EMAILS`, and `TEST_EMAIL` remain intentionally fail-closed; Admin status actions must use authenticated `/api/admin/...` server routes.
- Cancellation/refund and booking notification write/dispatch handlers were not found in the inspected Code.gs source; their sheets are currently read-only in Admin data retrieval.
- Email helper functions exist, but an exact `EmailLog` append path was not obvious in the inspected source and requires a focused follow-up audit.
- Daily report helper/trigger code exists, but exact 8-column persistence and trigger behavior remain unverified.
- Public GET booking lookup appears to return customer personal/travel/payment fields without an authentication check in `doGet`; privacy-safe response, rate limiting and access policy must be reviewed before public release.

These are static source findings, not live test results. See the separate handler audit report for the complete action/sheet matrix.

## 8. Release gate summary

| Gate | Status | Evidence / note |
|---|---|---|
| Approved schema represented in source | Implemented; final owner-workbook cross-check pending | 17 tabs / 139 headers in included schema reference |
| Apps Script schema/security source tests | PASS in recorded local runs | Not a deployed runtime test |
| Admin auth/data/CRUD source | Implemented in source | Real browser and staging persistence pending |
| Rental enquiry policy/customer rate rules | Implemented in source | 19-column and no supplier margin direction retained |
| Full TypeScript type-check | PENDING | npm dependencies unavailable in local environment |
| Vite production build | PENDING | Network runner workflow not yet executed |
| Browser E2E | PENDING | Requires build and browser/staging environment |
| Apps Script staging deployment | PENDING | Not executed |
| Staging Sheets CRUD | PENDING | No staging sheet created |
| Live payment / PhonePe | DEFERRED | Credentials/integration not active |
| Live email | DEFERRED | Owner-controlled; not activated |
| GitHub source commit | PENDING | Update 29 not committed |
| Existing Preview refresh | PENDING | Wait for validation gates |
| Production deployment | NOT AUTHORIZED / NOT DONE | Explicit owner approval required |

**Current next action:** Begin P1 source audit work (Apps Script handler-to-schema/action matrix), while keeping Update 29 network-enabled runner deferred as requested. No live setup/deployment actions until the required approval stage.
