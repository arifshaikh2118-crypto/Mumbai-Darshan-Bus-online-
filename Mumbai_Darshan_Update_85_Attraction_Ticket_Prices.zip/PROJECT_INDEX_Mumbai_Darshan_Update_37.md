# Mumbai Darshan Bus Online — Master Progress Tracker

**Current package:** Update 37 — Release-Gate Continuation & Hosting Architecture Correction  
**Baseline:** Update 36 — Deep Pre-External-Setup Cross-Check & Source Fixes  
**Date:** 20 November 2026

## Completed source work

- [x] Approved 17-tab / 139-header schema manifest and bootstrap source retained.
- [x] Booking server-side pricing/advance calculation and duplicate partial-write reconciliation gate retained.
- [x] Rental enquiry remains inquiry-only; no owner/customer rental email.
- [x] Admin session, secret-gated Apps Script actions and active AdminUsers roster retained.
- [x] Public lookup/cancellation privacy and throttling retained.
- [x] EmailLog, notifications, cancellation/refund review and Daily Reports source retained.
- [x] Update 36 protected Admin dispatch, public mutation lockdown, proxy allowlist and server-configured webhook URL fixes retained.
- [x] Update 37 corrected Firebase guide: static Hosting alone does not serve Express APIs; Cloud Run service ID/region must be confirmed, not guessed.

## Latest verification status

| Check | Result |
|---|---|
| Apps Script CJS suites | PASS, 8/8 |
| Apps Script Code.gs syntax | PASS in Update 36 |
| TypeScript/TSX syntax transpilation | PASS, 29 files / 0 diagnostics in Update 36 |
| Schema regression | PASS, 17 tabs / 139 headers |
| ZIP integrity | PASS in Update 36 |
| npm install | BLOCKED — timed out after 120 seconds |
| `npm run lint` / `tsc --noEmit` | BLOCKED — dependencies missing (`vite/client`) |
| `npm run build` | PENDING — dependencies unavailable |
| Browser E2E | PENDING |
| Hosting architecture / API runtime | PENDING owner/developer confirmation |
| Google Sheets staging | PENDING owner approval |
| Apps Script live concurrency | PENDING owner-approved staging |

## Remaining work before any external deployment

### P0 — Frontend dependency install/build
- [ ] Run clean `npm install --legacy-peer-deps --no-audit --no-fund` on a network-enabled runner.
- [ ] Pass `npm run lint` and `npm run build`.
- [ ] Resolve semantic TypeScript/build errors.
- [ ] Run browser E2E for booking submit/retry, rental inquiry, lookup, cancellation, Admin login/session expiry, Admin status updates, email retry, refunds, daily report and all seven operational CRUD tabs.
- [ ] Test mobile booking flow and confirm rental enquiry panel immediately follows booking form.

### P0 — Hosting architecture
- [ ] Confirm hosting target for Express server.
- [ ] If Firebase Hosting is retained, confirm actual Cloud Run service ID and region, then configure `/api/**` rewrite before SPA fallback.
- [ ] Verify the existing Preview architecture reaches the protected backend before refreshing the same Preview URL.
- [ ] Keep server secrets private and verify the platform-provided `PORT` is used.

### P1 — Google Sheets / Apps Script staging (owner approval only)
- [ ] Run `setupDatabase()` once against isolated staging.
- [ ] Confirm exact 17 tabs / 139 headers and approved seed rows.
- [ ] Configure private server environment and Apps Script Script Property secrets.
- [ ] Test booking/payment-pending ledger writes, duplicate retries, rental inquiry-only writes, lookup/cancellation, Admin reads/mutations, EmailLog, notifications and daily reports.
- [ ] Test concurrent requests and limiter behavior.
- [ ] Owner-approved controlled email test; only then decide on trigger installation.

### P2 — Later separately approved delivery
- [ ] GitHub source commit after build/tests and approval.
- [ ] Refresh existing Preview URL only after backend connectivity and browser E2E pass; do not create a new site.
- [ ] PhonePe integration after merchant credentials and server-side signature/status verification.
- [ ] Production Apps Script deployment, email activation, DNS/domain changes and website deployment only with explicit approval.

## Preserved rules

- No changes to approved sheet tabs/columns without permission.
- No supplier cost/rate/margin/private garage information in customer-facing code.
- No extra ₹5 rental-rate markup; approved customer rates remain unchanged.
- ₹200 advance is per booking, not per person.
- No automatic refund; PhonePe remains deferred.
- No rental enquiry emails; follow up via WhatsApp.
- No live Sheet, Apps Script, GitHub, Preview or production action without explicit approval.

**Overall: INCOMPLETE. Update 37 only corrected the hosting guide and repeated verification. Build, browser, hosting runtime and isolated live staging remain release blockers.**
