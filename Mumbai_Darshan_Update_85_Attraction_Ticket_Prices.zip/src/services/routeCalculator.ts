/**
 * Road-distance calculator for outstation quotations.
 * Geocoding: Photon (OpenStreetMap data); routing: OSRM public routing service.
 * No API key or additional npm dependency is required.
 */
export interface GeoPoint {
  label: string;
  lat: number;
  lon: number;
}

export interface GarageRouteResult {
  distanceKm: number;
  durationMinutes: number;
  points: GeoPoint[];
  mapUrl: string;
}

const DEFAULT_GARAGE_LOCATION = 'Jai Mata Di Travels, Shop No. 12, Om Poonam Enclave, Near Old Golden Nest, Mira Bhayandar Road, Mira Road East, Maharashtra 401107, India';

async function geocodePlace(query: string): Promise<GeoPoint> {
  const url = `https://photon.komoot.io/api/?q=${encodeURIComponent(query)}&limit=5&lang=en`;
  const response = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error('Location search is temporarily unavailable. Please try again.');
  const data = await response.json();
  const feature = data?.features?.[0];
  if (!feature?.geometry?.coordinates) {
    throw new Error('Could not find one of the required route locations. Please verify the pickup, destination and private garage address in Admin settings.');
  }
  const [lon, lat] = feature.geometry.coordinates;
  const props = feature.properties || {};
  const label = [props.name, props.street, props.city, props.state].filter(Boolean).join(', ') || query;
  return { label, lat: Number(lat), lon: Number(lon) };
}

export async function calculateBhayandarGarageRoute(
  pickupAddress: string,
  destinationAddress: string,
  garageAddress: string = DEFAULT_GARAGE_LOCATION
): Promise<GarageRouteResult> {
  if (!pickupAddress.trim() || !destinationAddress.trim()) {
    throw new Error('Enter both customer pickup location and destination.');
  }

  const [garage, pickup, destination] = await Promise.all([
    geocodePlace(garageAddress),
    geocodePlace(`${pickupAddress}, Mumbai Metropolitan Region, Maharashtra, India`),
    geocodePlace(`${destinationAddress}, India`)
  ]);

  // Route is ordered: Bhayandar garage -> customer pickup -> destination -> Bhayandar garage.
  const points = [garage, pickup, destination, garage];
  const coordinates = points.map(point => `${point.lon},${point.lat}`).join(';');
  const routeUrl = `https://router.project-osrm.org/route/v1/driving/${coordinates}?overview=false&steps=false`;
  const response = await fetch(routeUrl, { headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error('Road route service is temporarily unavailable. Please try again.');
  const routeData = await response.json();
  const route = routeData?.routes?.[0];
  if (routeData?.code !== 'Ok' || !route) {
    throw new Error('A complete road route could not be found for these locations. Please verify the pickup and destination.');
  }

  const distanceKm = Math.ceil(Number(route.distance) / 1000);
  const durationMinutes = Math.ceil(Number(route.duration) / 60);
  const mapUrl = `https://www.google.com/maps/dir/${points.map(point => `${point.lat},${point.lon}`).join('/')}`;
  return { distanceKm, durationMinutes, points, mapUrl };
}

export interface OutstationQuoteBreakdown {
  actualKm: number;
  billableKm: number;
  running: number;
  dailyDa: number;
  nightDa: number;
  total: number;
}

export function calculateOutstationQuote(
  actualKm: number, days: number, customerRatePerKm: number, dailyDa: number, nightCount: number
): OutstationQuoteBreakdown {
  const safeDays = Math.max(1, Math.floor(days || 1));
  const safeActualKm = Math.max(0, Math.ceil(actualKm || 0));
  const billableKm = Math.max(safeDays * 300, safeActualKm);
  const running = billableKm * customerRatePerKm;
  const dailyDaTotal = safeDays * dailyDa;
  const nightDaTotal = Math.max(0, Math.floor(nightCount || 0)) * dailyDa;
  return { actualKm: safeActualKm, billableKm, running, dailyDa: dailyDaTotal, nightDa: nightDaTotal, total: running + dailyDaTotal + nightDaTotal };
}
