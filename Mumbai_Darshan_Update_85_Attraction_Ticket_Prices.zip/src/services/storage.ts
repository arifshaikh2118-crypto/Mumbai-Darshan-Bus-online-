import {
  Booking,
  RouteConfig,
  PickupPoint,
  PackagePricing,
  RouteOffer,
  ExtraCharge,
  TourPoint,
  CarRentalEnquiry,
  GroupBookingEnquiry,
  CancellationRequest,
  AppSettings,
  PriceHistoryRecord,
  RouteId,
  PackageId,
  GalleryImage,
  LocalRentalPackage,
  OutstationVehicleRate,
  OfflineAttractionRecord
} from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_ROUTES,
  INITIAL_PACKAGES,
  INITIAL_OFFERS,
  INITIAL_EXTRA_CHARGES,
  INITIAL_PICKUP_POINTS,
  INITIAL_TOUR_POINTS,
  INITIAL_SAMPLE_BOOKINGS,
  INITIAL_GALLERY_IMAGES,
  INITIAL_LOCAL_RENTAL_PACKAGES,
  INITIAL_OUTSTATION_RATES,
  INITIAL_OFFLINE_ATTRACTIONS
} from '../data/initialData';

function generatePublicReferenceToken(): string {
  // Public references must have enough entropy to avoid same-day collisions.
  // Web Crypto is available on the production HTTPS site; retain a timestamped
  // fallback for older/local browser environments.
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID().replace(/-/g, '').slice(0, 16).toUpperCase();
    }
  } catch (error) {
    console.warn('Web Crypto reference generation unavailable; using fallback token.', error);
  }
  return `${Date.now().toString(36).toUpperCase()}-${Math.floor(10000000 + Math.random() * 90000000)}`;
}

const KEYS = {
  SETTINGS: 'mdb_settings_v1',
  ROUTES: 'mdb_routes_v1',
  PACKAGES: 'mdb_packages_v1',
  OFFERS: 'mdb_offers_v1',
  EXTRA_CHARGES: 'mdb_extra_charges_v1',
  PICKUP_POINTS: 'mdb_pickup_points_v1',
  TOUR_POINTS: 'mdb_tour_points_v1',
  BOOKINGS: 'mdb_bookings_v1',
  PENDING_BOOKING_RETRY: 'mdb_pending_booking_retry_v1',
  PENDING_RENTAL_RETRY: 'mdb_pending_rental_retry_v1',
  CAR_RENTALS: 'mdb_car_rentals_v1',
  GROUP_ENQUIRIES: 'mdb_group_enquiries_v1',
  CANCELLATIONS: 'mdb_cancellations_v1',
  PRICE_HISTORY: 'mdb_price_history_v1',
  GALLERY: 'mdb_gallery_v2',
  LOCAL_RENTAL: 'mdb_local_rental_v1',
  OUTSTATION_RATES: 'mdb_outstation_rates_v1',
  OFFLINE_ATTRACTIONS: 'mdb_offline_attractions_v1',
  PRICING_POLICY_MIGRATION: 'mdb_pricing_policy_update_83'
};

function getItem<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.error(`Error reading ${key} from storage:`, e);
    return fallback;
  }
}

function setItem<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error(`Error writing ${key} to storage:`, e);
  }
}

export class StorageService {
  // Refresh only the explicitly public configuration subset from the server proxy.
  // The server fetches approved PackageOptions/PickupPoints rows; no secret URL is sent
  // to the browser. Existing defaults remain available if the service is not configured.
  static async refreshPublicConfiguration(): Promise<{ success: boolean; message: string }> {
    try {
      const response = await fetch('/api/public-config', { method: 'GET', headers: { Accept: 'application/json' }, cache: 'no-store', signal: AbortSignal.timeout(10_000) });
      const result: any = await response.json();
      if (!response.ok || result?.success !== true || result?.config?.version !== 1 ||
          !Array.isArray(result.config.packages) || result.config.packages.length !== 16 ||
          !Array.isArray(result.config.pickupPoints) || result.config.pickupPoints.length < 1 ||
          !Array.isArray(result.config.rentalPricing?.localPackages) || result.config.rentalPricing.localPackages.length !== 6 ||
          !Array.isArray(result.config.rentalPricing?.outstationRates) || result.config.rentalPricing.outstationRates.length !== 16) {
        return { success: false, message: result?.error || 'Customer pricing configuration is not available.' };
      }

      const validRoutes: RouteId[] = ['western', 'central', 'harbour', 'kalyan_dombivli'];
      const validPackages: PackageId[] = ['non_ac_no_lunch', 'ac_no_lunch', 'non_ac_lunch', 'ac_lunch'];
      const priceMap = new Map<string, number>();
      const offerMap = new Map<string, { enabled: boolean; discountINR: number }>();
      for (const row of result.config.packages) {
        const route = String(row.routeGroup || '') as RouteId;
        const packageId = String(row.packageKey || '') as PackageId;
        const price = Number(row.priceINR);
        const key = `${packageId}|${route}`;
        const discount = Number(row.offerDiscountINR);
        if (!validRoutes.includes(route) || !validPackages.includes(packageId) ||
            !Number.isSafeInteger(price) || price <= 0 || !Number.isSafeInteger(discount) || discount < 0 || discount >= price ||
            typeof row.offerEnabled !== 'boolean' || priceMap.has(key)) {
          return { success: false, message: 'Customer pricing configuration contains invalid or duplicate rows.' };
        }
        priceMap.set(key, price);
        offerMap.set(key, { enabled: row.offerEnabled, discountINR: discount });
      }
      if (priceMap.size !== 16) return { success: false, message: 'All 16 route/package prices are required.' };

      const currentPackages = this.getPackages();
      if (currentPackages.length !== 4 || validPackages.some(id => !currentPackages.some(pkg => pkg.packageId === id))) {
        return { success: false, message: 'Local package display records do not match the approved four-package catalogue.' };
      }
      const updatedPackages = currentPackages.map(pkg => {
        const basePrices = { ...pkg.basePrices };
        const routeOffers: NonNullable<PackagePricing['routeOffers']> = {};
        validRoutes.forEach(route => {
          const key = `${pkg.packageId}|${route}`;
          basePrices[route] = priceMap.get(key)!;
          routeOffers[route] = offerMap.get(key)!;
        });
        return { ...pkg, basePrices, routeOffers };
      });

      const activeMap = new Map<string, boolean>();
      for (const row of result.config.pickupPoints) {
        const route = String(row.route || '') as RouteId;
        const name = String(row.name || '').trim();
        const order = Number(row.sortOrder);
        if (!validRoutes.includes(route) || !name || !Number.isSafeInteger(order) || order < 0 || typeof row.active !== 'boolean') {
          return { success: false, message: 'Pickup-point configuration contains invalid rows.' };
        }
        const key = `${route}|${name.toLowerCase()}|${order}`;
        if (activeMap.has(key)) return { success: false, message: 'Pickup-point configuration contains duplicate rows.' };
        activeMap.set(key, row.active);
      }
      const currentPickupPoints = this.getPickupPoints();
      const localPickupKeys = new Set(currentPickupPoints.map(point => `${point.routeId}|${point.name.trim().toLowerCase()}|${point.sortOrder}`));
      if (activeMap.size !== localPickupKeys.size || Array.from(activeMap.keys()).some(key => !localPickupKeys.has(key))) {
        return { success: false, message: 'Pickup-point rows do not exactly match the existing customer pickup catalogue; no partial update was applied.' };
      }
      const updatedPickupPoints = currentPickupPoints.map(point => {
        const key = `${point.routeId}|${point.name.trim().toLowerCase()}|${point.sortOrder}`;
        return activeMap.has(key) ? { ...point, active: activeMap.get(key)! } : point;
      });

      const rentalPricing = result.config.rentalPricing;
      const localIds = new Set(INITIAL_LOCAL_RENTAL_PACKAGES.map(row => row.id));
      const outstationIds = new Set(INITIAL_OUTSTATION_RATES.map(row => row.id));
      const validLocal = rentalPricing.localPackages.every((row: any) => row && localIds.has(String(row.id)) &&
        [row.durationHours, row.includedKm, row.customerPrice, row.extraKmRate, row.extraHourRate].every((n: any) => Number.isSafeInteger(Number(n)) && Number(n) >= 0) &&
        ['active','published','tollIncluded','parkingIncluded','driverBhattaIncluded','tourGuideIncluded'].every((k: string) => typeof row[k] === 'boolean'));
      const validOutstation = rentalPricing.outstationRates.every((row: any) => row && outstationIds.has(String(row.id)) &&
        [row.customerPerKm, row.customerDaPerDay, row.minKmPerDay, row.nightDaRate].every((n: any) => Number.isSafeInteger(Number(n)) && Number(n) >= 0) &&
        Number(row.nightDaRate) === Number(row.customerDaPerDay) && ['active','published','isAC'].every((k: string) => typeof row[k] === 'boolean'));
      if (!validLocal || !validOutstation || new Set(rentalPricing.localPackages.map((r: any) => r.id)).size !== 6 || new Set(rentalPricing.outstationRates.map((r: any) => r.id)).size !== 16) {
        return { success: false, message: 'Rental pricing configuration contains invalid, duplicate or unsupported vehicle records.' };
      }
      this.savePackages(updatedPackages);
      this.savePickupPoints(updatedPickupPoints);
      this.saveLocalRentalPackages(rentalPricing.localPackages as LocalRentalPackage[]);
      this.saveOutstationRates(rentalPricing.outstationRates as OutstationVehicleRate[]);
      return { success: true, message: 'Customer bus pricing, pickup availability and car rental rates refreshed.' };
    } catch (error: any) {
      console.warn('Public configuration refresh unavailable; retaining the current local configuration.', error);
      return { success: false, message: error?.message || 'Customer configuration refresh failed.' };
    }
  }

  // Settings
  static getSettings(): AppSettings {
    const stored = getItem<AppSettings>(KEYS.SETTINGS, INITIAL_SETTINGS);
    // Migrate only the old generic Bhayandar default. Preserve any garage address
    // explicitly configured by the owner. Supplier contact details are never stored
    // in public business phone/WhatsApp settings.
    if (!stored.rentalGarageAddress || stored.rentalGarageAddress.trim() === 'Bhayandar, Maharashtra, India') {
      const migrated = { ...stored, rentalGarageAddress: INITIAL_SETTINGS.rentalGarageAddress };
      setItem(KEYS.SETTINGS, migrated);
      return migrated;
    }
    return stored;
  }

  static updateSettings(settings: Partial<AppSettings>): AppSettings {
    const current = this.getSettings();
    const updated = { ...current, ...settings };
    setItem(KEYS.SETTINGS, updated);
    return updated;
  }

  // Routes
  static getRoutes(): RouteConfig[] {
    return getItem<RouteConfig[]>(KEYS.ROUTES, INITIAL_ROUTES);
  }

  static saveRoutes(routes: RouteConfig[]): void {
    setItem(KEYS.ROUTES, routes);
  }

  static updateRoute(id: RouteId, changes: Partial<RouteConfig>): void {
    const routes = this.getRoutes();
    const idx = routes.findIndex(r => r.id === id);
    if (idx !== -1) {
      routes[idx] = { ...routes[idx], ...changes };
      this.saveRoutes(routes);
    }
  }

  // Packages & Pricing
  private static ensureCurrentPricingPolicy(): void {
    if (getItem<boolean>(KEYS.PRICING_POLICY_MIGRATION, false)) return;

    const legacyPrices: Record<string, Partial<Record<RouteId, number>>> = {
      non_ac_no_lunch: { western: 200, central: 200 },
      ac_no_lunch: { western: 300, central: 300 },
      non_ac_lunch: { western: 400, central: 400 },
      ac_lunch: { western: 500, central: 500 }
    };
    const storedPackages = getItem<PackagePricing[]>(KEYS.PACKAGES, INITIAL_PACKAGES);
    const normalizedPackages = storedPackages.map(pkg => {
      const legacy = legacyPrices[pkg.packageId];
      const defaults = INITIAL_PACKAGES.find(item => item.packageId === pkg.packageId);
      const basePrices = { ...pkg.basePrices };
      if (legacy && defaults) {
        (['western', 'central'] as RouteId[]).forEach(route => {
          if (basePrices[route] === legacy[route]) basePrices[route] = defaults.basePrices[route];
        });
      }
      const routeOffers = pkg.routeOffers ? { ...pkg.routeOffers } : undefined;
      if (routeOffers) {
        (Object.keys(routeOffers) as RouteId[]).forEach(route => {
          const offer = routeOffers[route];
          if (offer) routeOffers[route] = { ...offer, enabled: false };
        });
      }
      return { ...pkg, basePrices, ...(routeOffers ? { routeOffers } : {}) };
    });

    const storedOffers = getItem<RouteOffer[]>(KEYS.OFFERS, INITIAL_OFFERS);
    setItem(KEYS.PACKAGES, normalizedPackages);
    // Disable every currently active local offer once; retain discount values so the
    // owner can deliberately turn a route/package offer ON again later.
    setItem(KEYS.OFFERS, storedOffers.map(offer => ({ ...offer, enabled: false })));
    setItem(KEYS.PRICING_POLICY_MIGRATION, true);
  }

  static getPackages(): PackagePricing[] {
    this.ensureCurrentPricingPolicy();
    return getItem<PackagePricing[]>(KEYS.PACKAGES, INITIAL_PACKAGES);
  }

  static savePackages(packages: PackagePricing[]): void {
    setItem(KEYS.PACKAGES, packages);
  }

  static updatePackagePrice(
    packageId: PackageId,
    routeId: RouteId,
    newPrice: number,
    adminName: string = 'Admin'
  ): void {
    const packages = this.getPackages();
    const pkg = packages.find(p => p.packageId === packageId);
    if (pkg) {
      const oldPrice = pkg.basePrices[routeId] ?? 0;
      pkg.basePrices[routeId] = newPrice;
      this.savePackages(packages);

      // Record in price history
      const history = this.getPriceHistory();
      const record: PriceHistoryRecord = {
        id: 'PH-' + Date.now(),
        timestamp: new Date().toISOString(),
        routeId,
        packageId,
        oldPrice,
        newPrice,
        updatedBy: adminName
      };
      history.unshift(record);
      setItem(KEYS.PRICE_HISTORY, history);
    }
  }

  static getPriceHistory(): PriceHistoryRecord[] {
    return getItem<PriceHistoryRecord[]>(KEYS.PRICE_HISTORY, []);
  }

  // Offers
  static getOffers(): RouteOffer[] {
    this.ensureCurrentPricingPolicy();
    return getItem<RouteOffer[]>(KEYS.OFFERS, INITIAL_OFFERS);
  }

  static saveOffers(offers: RouteOffer[]): void {
    setItem(KEYS.OFFERS, offers);
  }

  static updateRouteOffer(routeId: RouteId, offerChanges: Partial<RouteOffer>): void {
    const offers = this.getOffers();
    const idx = offers.findIndex(o => o.routeId === routeId);
    if (idx !== -1) {
      offers[idx] = { ...offers[idx], ...offerChanges };
    } else {
      offers.push({
        routeId,
        enabled: false,
        discountType: 'flat',
        discountValue: 0,
        label: `${routeId} Offer`,
        ...offerChanges
      });
    }
    this.saveOffers(offers);
  }

  // Extra Charges
  static getExtraCharges(): ExtraCharge[] {
    return getItem<ExtraCharge[]>(KEYS.EXTRA_CHARGES, INITIAL_EXTRA_CHARGES);
  }

  static saveExtraCharges(charges: ExtraCharge[]): void {
    setItem(KEYS.EXTRA_CHARGES, charges);
  }

  static updateExtraCharge(id: string, changes: Partial<ExtraCharge>): void {
    const charges = this.getExtraCharges();
    const idx = charges.findIndex(c => c.id === id);
    if (idx !== -1) {
      charges[idx] = { ...charges[idx], ...changes };
      this.saveExtraCharges(charges);
    }
  }

  // Pickup Points
  static getPickupPoints(): PickupPoint[] {
    return getItem<PickupPoint[]>(KEYS.PICKUP_POINTS, INITIAL_PICKUP_POINTS);
  }

  static savePickupPoints(points: PickupPoint[]): void {
    setItem(KEYS.PICKUP_POINTS, points);
  }

  static addPickupPoint(point: Omit<PickupPoint, 'id'>): PickupPoint {
    const points = this.getPickupPoints();
    const newPoint: PickupPoint = {
      ...point,
      id: `pt_${Date.now()}_${Math.floor(Math.random() * 1000)}`
    };
    points.push(newPoint);
    this.savePickupPoints(points);
    return newPoint;
  }

  static updatePickupPoint(id: string, changes: Partial<PickupPoint>): void {
    const points = this.getPickupPoints();
    const idx = points.findIndex(p => p.id === id);
    if (idx !== -1) {
      points[idx] = { ...points[idx], ...changes };
      this.savePickupPoints(points);
    }
  }

  static deletePickupPoint(id: string): void {
    const points = this.getPickupPoints().filter(p => p.id !== id);
    this.savePickupPoints(points);
  }

  // Tour Points (All 44)
  static getTourPoints(): TourPoint[] {
    // Preserve the owner's saved attraction ticket rates. Never overwrite or
    // automatically revise an existing Admin-edited ticket price.
    return getItem<TourPoint[]>(KEYS.TOUR_POINTS, INITIAL_TOUR_POINTS);
  }

  static saveTourPoints(points: TourPoint[]): void {
    setItem(KEYS.TOUR_POINTS, points);
  }

  static updateTourPoint(id: number, changes: Partial<TourPoint>): void {
    const points = this.getTourPoints();
    const idx = points.findIndex(p => p.id === id);
    if (idx !== -1) {
      points[idx] = { ...points[idx], ...changes };
      this.saveTourPoints(points);
    }
  }

  // Bookings
  static getBookings(): Booking[] {
    return getItem<Booking[]>(KEYS.BOOKINGS, INITIAL_SAMPLE_BOOKINGS);
  }

  static saveBookings(bookings: Booking[]): void {
    setItem(KEYS.BOOKINGS, bookings);
  }

  static getBookingById(id: string): Booking | undefined {
    return this.getBookings().find(b => b.id.trim().toUpperCase() === id.trim().toUpperCase());
  }

  // Persist only the stable Booking ID as a recovery pointer. The booking
  // record itself remains in the existing local booking store; no duplicate
  // customer PII is written to a second browser-storage key.
  static savePendingBookingRetryId(id: string): boolean {
    try {
      const cleanId = id.trim();
      if (!cleanId) return false;

      // The retry pointer is useful only if the full booking record was
      // successfully persisted in the existing local booking store.
      const booking = this.getBookingById(cleanId);
      if (!booking || booking.syncedToGoogleSheets === true) return false;

      localStorage.setItem(KEYS.PENDING_BOOKING_RETRY, cleanId);
      const persistedPointer = localStorage.getItem(KEYS.PENDING_BOOKING_RETRY)?.trim();
      if (persistedPointer?.toUpperCase() !== cleanId.toUpperCase()) {
        const current = localStorage.getItem(KEYS.PENDING_BOOKING_RETRY)?.trim();
        if (current?.toUpperCase() === cleanId.toUpperCase()) {
          localStorage.removeItem(KEYS.PENDING_BOOKING_RETRY);
        }
        return false;
      }
      return true;
    } catch (error) {
      console.warn('Could not persist pending booking retry reference:', error);
      return false;
    }
  }

  static getPendingBookingForRetry(): Booking | null {
    try {
      const id = localStorage.getItem(KEYS.PENDING_BOOKING_RETRY)?.trim();
      if (!id) return null;
      const booking = this.getBookingById(id);
      if (!booking || booking.syncedToGoogleSheets === true) {
        localStorage.removeItem(KEYS.PENDING_BOOKING_RETRY);
        return null;
      }
      return booking;
    } catch (error) {
      console.warn('Could not restore pending booking retry reference:', error);
      return null;
    }
  }

  static clearPendingBookingRetryId(id?: string): void {
    try {
      if (id) {
        const current = localStorage.getItem(KEYS.PENDING_BOOKING_RETRY)?.trim();
        if (current && current.toUpperCase() !== id.trim().toUpperCase()) return;
      }
      localStorage.removeItem(KEYS.PENDING_BOOKING_RETRY);
    } catch (error) {
      console.warn('Could not clear pending booking retry reference:', error);
    }
  }

  static getBookingsByMobile(mobile: string): Booking[] {
    const cleanMobile = mobile.replace(/\D/g, '').slice(-10);
    return this.getBookings().filter(b => b.customerMobile.replace(/\D/g, '').slice(-10) === cleanMobile);
  }

  static generateBookingId(): string {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    return `MDB-${yyyy}${mm}${dd}-${generatePublicReferenceToken()}`;
  }

  static createBooking(data: Omit<Booking, 'id' | 'createdAt' | 'historyLog'>): Booking {
    const bookings = this.getBookings();
    const newBooking: Booking = {
      ...data,
      id: this.generateBookingId(),
      createdAt: new Date().toISOString(),
      historyLog: [
        {
          timestamp: new Date().toISOString(),
          action: 'Booking Created',
          notes: `Customer created booking. Advance: ₹${data.amountPaid}, Balance: ₹${data.balancePayable}`
        }
      ]
    };

    bookings.unshift(newBooking);
    this.saveBookings(bookings);

    // setItem() intentionally catches browser storage errors for ordinary app
    // preferences. A booking is different: fail closed unless its complete local
    // record can be read back, otherwise refresh-safe retry cannot be guaranteed.
    const persistedBooking = this.getBookingById(newBooking.id);
    if (!persistedBooking) {
      throw new Error('This browser could not securely save your booking details. Please check available site storage and try again. No booking was sent to Google Sheets.');
    }

    // Persistence is deliberately separate from network sync. The caller must
    // await syncBookingToGoogleSheets and only then show a confirmed receipt.
    return persistedBooking;
  }

  // Admin booking-status changes are written to the authoritative Google Sheet first.
  // Local state is updated only after Apps Script confirms the row update.
  static async updateBookingStatusInGoogleSheets(
    id: string,
    bookingStatus: Booking['bookingStatus'],
    adminToken: string
  ): Promise<{ success: boolean; message: string }> {
    const booking = this.getBookingById(id);
    if (!booking) return { success: false, message: 'Booking not found in local records.' };
    if (!adminToken) return { success: false, message: 'Admin session is required.' };
    try {
      const response = await fetch('/api/admin/bookings/status', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminToken}` },
        body: JSON.stringify({ bookingId: id, bookingStatus })
      });
      const result = await response.json();
      if (!response.ok || result?.success !== true || result?.result?.status !== 'success') {
        return { success: false, message: result?.error || result?.result?.message || 'Google Sheets did not confirm the booking status update.' };
      }
      this.updateBooking(id, { bookingStatus }, `Status updated to ${bookingStatus} in Google Sheets`);
      return { success: true, message: result.result.message || 'Booking status updated in Google Sheets.' };
    } catch (error: any) { return { success: false, message: error?.message || 'Network error updating booking status.' }; }
  }

  static updateBooking(id: string, changes: Partial<Booking>, noteAction?: string): Booking | null {
    const bookings = this.getBookings();
    const idx = bookings.findIndex(b => b.id === id);
    if (idx === -1) return null;

    const old = bookings[idx];
    const history = old.historyLog ? [...old.historyLog] : [];
    if (noteAction) {
      history.unshift({
        timestamp: new Date().toISOString(),
        action: noteAction,
        notes: changes.adminNotes || 'Status or detail modified by Admin'
      });
    }

    const updated: Booking = {
      ...old,
      ...changes,
      lastUpdated: new Date().toISOString(),
      historyLog: history
    };

    bookings[idx] = updated;
    this.saveBookings(bookings);
    return updated;
  }

  // Gallery Images (Strictly verified authentic Mumbai sightseeing images)
  static getGalleryImages(): GalleryImage[] {
    const images = getItem<GalleryImage[]>(KEYS.GALLERY, INITIAL_GALLERY_IMAGES);
    const verified = images.filter(img => !img.imageUrl.includes('images.unsplash.com'));
    if (verified.length === 0) return INITIAL_GALLERY_IMAGES;
    return verified;
  }

  static saveGalleryImages(images: GalleryImage[]): void {
    setItem(KEYS.GALLERY, images);
  }

  static addGalleryImage(img: Omit<GalleryImage, 'id' | 'uploadedAt'>): GalleryImage {
    const images = this.getGalleryImages();
    const newImg: GalleryImage = {
      ...img,
      id: `gal_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      uploadedAt: new Date().toISOString()
    };
    images.push(newImg);
    this.saveGalleryImages(images);
    return newImg;
  }

  static updateGalleryImage(id: string, changes: Partial<GalleryImage>): void {
    const images = this.getGalleryImages();
    const idx = images.findIndex(img => img.id === id);
    if (idx !== -1) {
      images[idx] = { ...images[idx], ...changes };
      this.saveGalleryImages(images);
    }
  }

  static deleteGalleryImage(id: string): void {
    const images = this.getGalleryImages().filter(img => img.id !== id);
    this.saveGalleryImages(images);
  }

  // Local Rental Packages (12 hr / 120 km)
  static getLocalRentalPackages(): LocalRentalPackage[] {
    const stored = getItem<any[]>(KEYS.LOCAL_RENTAL, INITIAL_LOCAL_RENTAL_PACKAGES);
    // Preserve saved customer prices while migrating the old property name.
    const normalized = stored.map((item: any) => {
      const { proposedCustomerPrice, ...rest } = item || {};
      return { ...rest, customerPrice: rest.customerPrice ?? proposedCustomerPrice };
    });
    if (JSON.stringify(normalized) !== JSON.stringify(stored)) setItem(KEYS.LOCAL_RENTAL, normalized);
    return normalized as LocalRentalPackage[];
  }

  static saveLocalRentalPackages(packages: LocalRentalPackage[]): void {
    setItem(KEYS.LOCAL_RENTAL, packages);
  }

  static updateLocalRentalPackage(id: string, changes: Partial<LocalRentalPackage>): void {
    const packages = this.getLocalRentalPackages();
    const idx = packages.findIndex(p => p.id === id);
    if (idx !== -1) {
      packages[idx] = { ...packages[idx], ...changes };
      this.saveLocalRentalPackages(packages);
    }
  }

  // Outstation Vehicle Rates (300 km/day min)
  static getOutstationRates(): OutstationVehicleRate[] {
    const stored = getItem<any[]>(KEYS.OUTSTATION_RATES, INITIAL_OUTSTATION_RATES);
    // Preserve the final customer-facing prices exactly while migrating legacy
    // property names. No supplier/base-rate value is stored or calculated.
    const normalized = stored.map((item: any) => {
      const { proposedCustomerPerKm, proposedCustomerDaPerDay, ...rest } = item || {};
      const customerDaPerDay = rest.customerDaPerDay ?? proposedCustomerDaPerDay;
      return {
        ...rest,
        customerPerKm: rest.customerPerKm ?? proposedCustomerPerKm,
        customerDaPerDay,
        // Each additional Night DA after 11 PM equals the regular customer DA.
        nightDaRate: customerDaPerDay
      };
    });
    if (JSON.stringify(normalized) !== JSON.stringify(stored)) setItem(KEYS.OUTSTATION_RATES, normalized);
    return normalized as OutstationVehicleRate[];
  }

  static saveOutstationRates(rates: OutstationVehicleRate[]): void {
    setItem(KEYS.OUTSTATION_RATES, rates);
  }

  static updateOutstationRate(id: string, changes: Partial<OutstationVehicleRate>): void {
    const rates = this.getOutstationRates();
    const idx = rates.findIndex(r => r.id === id);
    if (idx !== -1) {
      rates[idx] = { ...rates[idx], ...changes };
      this.saveOutstationRates(rates);
    }
  }

  // Offline Attraction Collections (Tour Guide Collected on Bus)
  static getOfflineAttractions(): OfflineAttractionRecord[] {
    return getItem<OfflineAttractionRecord[]>(KEYS.OFFLINE_ATTRACTIONS, INITIAL_OFFLINE_ATTRACTIONS);
  }

  static saveOfflineAttractions(records: OfflineAttractionRecord[]): void {
    setItem(KEYS.OFFLINE_ATTRACTIONS, records);
  }

  static recordOfflineCollection(data: Omit<OfflineAttractionRecord, 'id' | 'collectedAt'>): OfflineAttractionRecord {
    const records = this.getOfflineAttractions();
    const newRecord: OfflineAttractionRecord = {
      ...data,
      id: `off_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      collectedAt: new Date().toISOString()
    };
    records.unshift(newRecord);
    this.saveOfflineAttractions(records);
    return newRecord;
  }

  static updateOfflineAttraction(id: string, changes: Partial<OfflineAttractionRecord>): void {
    const records = this.getOfflineAttractions();
    const idx = records.findIndex(r => r.id === id);
    if (idx !== -1) {
      records[idx] = { ...records[idx], ...changes };
      this.saveOfflineAttractions(records);
    }
  }

  // Car Rental Enquiries
  static getCarRentals(): CarRentalEnquiry[] {
    // Rental enquiries are loaded from the authenticated Google Sheets Admin API.
    // Scrub legacy browser records that may contain unsupported/private financial fields.
    const records = getItem<any[]>(KEYS.CAR_RENTALS, []);
    const safeRecords = records.map(record => {
      const {
        customerEmail, customerQuotation, supplierCost, grossMargin, daPermitAmount,
        extraExpenses, adminNotes, garageRouteSummary, estimatedKm, nightDaCount,
        ...approvedInquiryFields
      } = record || {};
      return approvedInquiryFields;
    });
    if (JSON.stringify(records) !== JSON.stringify(safeRecords)) setItem(KEYS.CAR_RENTALS, safeRecords);
    return safeRecords as CarRentalEnquiry[];
  }

  static createCarRentalEnquiry(data: Omit<CarRentalEnquiry, 'id' | 'createdAt' | 'status'>): CarRentalEnquiry {
    const rentals = this.getCarRentals();
    const newEnquiry: CarRentalEnquiry = {
      ...data,
      id: `CRE-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${generatePublicReferenceToken()}`,
      createdAt: new Date().toISOString(),
      status: 'New'
    };
    rentals.unshift(newEnquiry);
    setItem(KEYS.CAR_RENTALS, rentals);

    // Rental enquiries are inquiry-only, but the same refresh-safe retry
    // guarantee applies: do not attempt network sync if the local draft vanished.
    const persistedEnquiry = this.getCarRentals().find(item => item.id === newEnquiry.id);
    if (!persistedEnquiry) {
      throw new Error('This browser could not securely save your rental enquiry. Please check available site storage and try again. No enquiry was sent to Google Sheets.');
    }

    // The caller must await syncRentalToGoogleSheets before showing success.
    return persistedEnquiry;
  }

  static savePendingRentalRetryId(id: string): boolean {
    try {
      const cleanId = id.trim();
      if (!cleanId) return false;
      const enquiry = this.getCarRentals().find(item => item.id.trim().toUpperCase() === cleanId.toUpperCase());
      if (!enquiry) return false;
      localStorage.setItem(KEYS.PENDING_RENTAL_RETRY, cleanId);
      return localStorage.getItem(KEYS.PENDING_RENTAL_RETRY)?.trim().toUpperCase() === cleanId.toUpperCase();
    } catch (error) {
      console.warn('Could not persist pending rental retry reference:', error);
      return false;
    }
  }

  static getPendingRentalForRetry(): CarRentalEnquiry | null {
    try {
      const id = localStorage.getItem(KEYS.PENDING_RENTAL_RETRY)?.trim();
      if (!id) return null;
      const enquiry = this.getCarRentals().find(item => item.id.trim().toUpperCase() === id.toUpperCase());
      if (!enquiry) localStorage.removeItem(KEYS.PENDING_RENTAL_RETRY);
      return enquiry || null;
    } catch (error) {
      console.warn('Could not restore pending rental retry reference:', error);
      return null;
    }
  }

  static clearPendingRentalRetryId(id?: string): void {
    try {
      if (id) {
        const current = localStorage.getItem(KEYS.PENDING_RENTAL_RETRY)?.trim();
        if (current && current.toUpperCase() !== id.trim().toUpperCase()) return;
      }
      localStorage.removeItem(KEYS.PENDING_RENTAL_RETRY);
    } catch (error) {
      console.warn('Could not clear pending rental retry reference:', error);
    }
  }

  static updateCarRental(id: string, changes: Partial<CarRentalEnquiry>): void {
    const rentals = this.getCarRentals();
    const idx = rentals.findIndex(r => r.id === id);
    if (idx !== -1) {
      rentals[idx] = { ...rentals[idx], ...changes };
      setItem(KEYS.CAR_RENTALS, rentals);
    }
  }

  static async updateCarRentalInGoogleSheets(id: string, changes: Partial<CarRentalEnquiry>, adminToken: string): Promise<{ success: boolean; message: string }> {
    const current = this.getCarRentals().find(r => r.id === id);
    if (!current) return { success: false, message: 'Rental enquiry not found in local records.' };
    if (!adminToken) return { success: false, message: 'Admin session is required.' };
    const merged = { ...current, ...changes };
    try {
      const response = await fetch('/api/admin/rentals/status', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminToken}` },
        body: JSON.stringify({ enquiryId: id, status: merged.status })
      });
      const result = await response.json();
      if (!response.ok || result?.success !== true || result?.result?.status !== 'success') {
        return { success: false, message: result?.error || result?.result?.message || 'Google Sheets did not confirm the rental update.' };
      }
      this.updateCarRental(id, changes);
      return { success: true, message: result.result.message || 'Rental enquiry updated in Google Sheets.' };
    } catch (err: any) { return { success: false, message: err?.message || 'Rental update sync failed.' }; }
  }

  // Group Enquiries
  static getGroupEnquiries(): GroupBookingEnquiry[] {
    return getItem<GroupBookingEnquiry[]>(KEYS.GROUP_ENQUIRIES, [
      {
        id: 'GRP-20261109-201',
        createdAt: '2026-11-09T12:00:00Z',
        organizationName: 'Tata Consultancy Services - Cultural Club',
        contactPerson: 'Meera Iyer',
        mobile: '9819033445',
        email: 'meera.i@example.com',
        tentativeDate: '2026-11-20',
        approximatePassengers: 45,
        groupType: 'Corporate',
        preferredBusType: 'AC 49-Seater',
        lunchRequired: true,
        customRequests: 'Need morning breakfast and lunch packets for 45 employees. Customized pickup from Thane Hiranandani.',
        status: 'Quote Sent',
        adminNotes: 'Sent custom quote with veg thali lunch.'
      }
    ]);
  }

  static createGroupEnquiry(data: Omit<GroupBookingEnquiry, 'id' | 'createdAt' | 'status'>): GroupBookingEnquiry {
    const enquiries = this.getGroupEnquiries();
    const newEnquiry: GroupBookingEnquiry = {
      ...data,
      id: `GRP-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`,
      createdAt: new Date().toISOString(),
      status: 'New'
    };
    enquiries.unshift(newEnquiry);
    setItem(KEYS.GROUP_ENQUIRIES, enquiries);
    return newEnquiry;
  }

  static updateGroupEnquiry(id: string, changes: Partial<GroupBookingEnquiry>): void {
    const enquiries = this.getGroupEnquiries();
    const idx = enquiries.findIndex(g => g.id === id);
    if (idx !== -1) {
      enquiries[idx] = { ...enquiries[idx], ...changes };
      setItem(KEYS.GROUP_ENQUIRIES, enquiries);
    }
  }

  // Cancellation Requests
  static getCancellationRequests(): CancellationRequest[] {
    return getItem<CancellationRequest[]>(KEYS.CANCELLATIONS, []);
  }

  static requestCancellation(data: Omit<CancellationRequest, 'id' | 'requestDate' | 'status'>): CancellationRequest {
    const requests = this.getCancellationRequests();
    const newReq: CancellationRequest = {
      ...data,
      id: `CAN-${Date.now()}`,
      requestDate: new Date().toISOString(),
      status: 'Pending'
    };
    requests.unshift(newReq);
    setItem(KEYS.CANCELLATIONS, requests);
    return newReq;
  }

  static updateCancellationRequest(id: string, changes: Partial<CancellationRequest>): void {
    const requests = this.getCancellationRequests();
    const idx = requests.findIndex(r => r.id === id);
    if (idx !== -1) {
      requests[idx] = { ...requests[idx], ...changes };
      setItem(KEYS.CANCELLATIONS, requests);
    }
  }

  // Google Sheets Webhook Sync Helper
  static async syncBookingToGoogleSheets(booking: Booking): Promise<{ success: boolean; message: string }> {
    try {
      const payload = {
        action: 'NEW_BOOKING',
        bookingId: booking.id,
        travelDate: booking.travelDate,
        createdAt: booking.createdAt,
        customerName: booking.customerName,
        customerMobile: booking.customerMobile,
        customerEmail: booking.customerEmail,
        route: booking.routeName,
        pickupPoint: booking.pickupPointName,
        pickupTime: booking.pickupTime,
        packageId: booking.packageId,
        package: booking.packageTitle,
        passengers: booking.passengerCount,
        foodSelections: booking.foodSelections || { vegBiryani: 0, butterPaneer: 0, vegThali: 0 },
        vegBiryani: booking.foodSelections?.vegBiryani || 0,
        butterPaneer: booking.foodSelections?.butterPaneer || 0,
        vegThali: booking.foodSelections?.vegThali || 0,
        unitPackagePrice: booking.unitPackagePrice,
        packageAmount: booking.totalPackageAmount,
        onlineBookingFare: booking.grandTotal, // e.g. ₹1,500
        advancePayable: booking.amountPayableNow, // ₹200 advance per booking
        balancePayable: booking.balancePayable, // e.g. ₹1,300 payable on bus
        guideChargeUnit: booking.compulsoryCharges.guideChargeUnit,
        guideCharge: booking.compulsoryCharges.guideChargeTotal, // e.g. ₹150 payable to Guide
        seaLinkTollUnit: booking.compulsoryCharges.seaLinkTollUnit,
        seaLinkToll: booking.compulsoryCharges.seaLinkTollTotal, // e.g. ₹30 payable to Guide
        totalPayableToGuide: (booking.compulsoryCharges.guideChargeTotal + booking.compulsoryCharges.seaLinkTollTotal), // e.g. ₹180 payable to Guide inside bus
        grandTotal: booking.grandTotal, // Online Booking Fare
        amountInr: booking.grandTotal, // Authoritative column 15
        paymentMode: booking.paymentMode,
        amountPaid: booking.amountPaid,
        paymentStatus: booking.paymentStatus,
        bookingStatus: booking.bookingStatus,
        specialRequest: booking.specialRequest || ''
      };

      // Only report a sync after the server proxy confirms the Apps Script result.
      // A no-cors browser request cannot read the response and must never be
      // treated as proof that a row was saved in Google Sheets.
      const proxyRes = await fetch('/api/sync-sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payload })
      });
      const proxyResult = await proxyRes.json();
      const backendStatus = proxyResult?.backendResponse?.status;
      const persistedBookingId = String(proxyResult?.backendResponse?.bookingId || '').trim();
      const bookingIdMatches = persistedBookingId.toUpperCase() === booking.id.trim().toUpperCase();
      if (!proxyRes.ok || proxyResult?.success !== true || !['success', 'duplicate'].includes(backendStatus) || !bookingIdMatches) {
        const message = !bookingIdMatches
          ? 'Google Sheets did not confirm that the same Booking ID was saved. Do not make payment; retry or contact Mumbai Darshan.'
          : proxyResult?.error || proxyResult?.backendResponse?.message || 'Google Sheets did not confirm the booking sync.';
        this.updateBooking(booking.id, { syncedToGoogleSheets: false });
        return { success: false, message };
      }

      this.updateBooking(booking.id, { syncedToGoogleSheets: true });
      return { success: true, message: backendStatus === 'duplicate' ? 'The same Booking ID is already saved in Google Sheets.' : 'Booking ID and booking details successfully saved in Google Sheets.' };
    } catch (err: any) {
      console.warn('Google Sheets sync notice:', err);
      return { success: false, message: err?.message || 'Sync failed' };
    }
  }

  // Retry failed or queued booking emails via Google Apps Script Webhook
  static async retryBookingEmail(bookingId: string, adminToken: string): Promise<{ success: boolean; message: string }> {
    if (!adminToken) return { success: false, message: 'Admin session is required.' };
    try {
      const response = await fetch('/api/admin/bookings/retry-emails', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminToken}` },
        body: JSON.stringify({ bookingId })
      });
      const result = await response.json();
      const backend = result?.result;
      if (!response.ok || result?.success !== true || backend?.status !== 'success') {
        return { success: false, message: result?.error || backend?.message || 'Apps Script did not confirm the email retry.' };
      }
      this.updateBooking(bookingId, {
        customerEmailStatus: backend.customerEmailStatus || 'Retry completed; check Apps Script status',
        ownerEmailStatus: backend.ownerEmailStatus || 'Retry completed; check Apps Script status'
      });
      return { success: true, message: backend.message || 'Email retry completed by Apps Script.' };
    } catch (e: any) { return { success: false, message: e.message || 'Network error triggering retry' }; }
  }

  // Reliable sync for Rental Enquiries to Google Sheets
  static async syncRentalToGoogleSheets(rental: CarRentalEnquiry): Promise<{ success: boolean; message: string }> {
    try {
      const payload = {
        action: 'NEW_RENTAL_ENQUIRY',
        id: rental.id,
        // Apps Script validates this discriminator before accepting an enquiry.
        // Without it, every Local/Outstation rental write is rejected.
        rentalType: rental.rentalType,
        customerName: rental.customerName,
        customerMobile: rental.customerMobile,
        vehicleType: rental.vehicleType,
        preferredCarModel: rental.preferredCarModel || rental.vehicleType,
        tempoTravellerSeatingCapacity: rental.tempoTravellerSeatingCapacity || '',
        otherSeatingCapacity: rental.otherSeatingCapacity || '',
        acPreference: rental.acPreference || (rental.isAC ? 'AC' : 'Non-AC'),
        travelDate: rental.travelDate,
        pickupLocation: rental.pickupLocation,
        destination: rental.destination || '',
        tripType: rental.tripType || (rental.rentalType === 'outstation' ? 'Outstation' : 'Local'),
        passengerCount: rental.passengerCount,
        daysCount: rental.daysCount || 1,
        specialRequirements: rental.specialRequirements || '',
        rentalDuration: rental.rentalDuration || (rental.rentalType === 'outstation' ? `${rental.daysCount || 1} Days` : '12 Hours / 120 KM'),
        pickupTime: rental.preferredPickupTime || ''
      };

      const response = await fetch('/api/sync-sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payload })
      });
      const result = await response.json();
      const backendStatus = result?.backendResponse?.status;
      const persistedEnquiryId = String(result?.backendResponse?.enquiryId || '').trim();
      const enquiryIdMatches = persistedEnquiryId.toUpperCase() === rental.id.trim().toUpperCase();
      if (!response.ok || result?.success !== true || !['success', 'duplicate'].includes(backendStatus) || !enquiryIdMatches) {
        const message = !enquiryIdMatches
          ? 'Google Sheets did not confirm that the same Rental Enquiry ID was saved. Please retry with the same reference ID or contact Mumbai Darshan.'
          : result?.error || result?.backendResponse?.message || 'Google Sheets did not confirm the rental enquiry.';
        return { success: false, message };
      }
      return { success: true, message: backendStatus === 'duplicate' ? 'The same Rental Enquiry ID is already saved in Google Sheets.' : 'Rental enquiry successfully saved to Google Sheets.' };
    } catch (err: any) {
      return { success: false, message: err?.message || 'Sync failed' };
    }
  }

  // CSV Export for Bookings
  static exportBookingsToCSV(): void {
    const bookings = this.getBookings();
    const headers = [
      'Booking ID',
      'Created At',
      'Travel Date',
      'Customer Name',
      'Mobile',
      'Email',
      'Route',
      'Pickup Point',
      'Pickup Time',
      'Package',
      'Passengers',
      'Biryani',
      'Paneer',
      'Thali',
      'Package Total (₹)',
      'Guide Charge (₹)',
      'Sea Link Toll (₹)',
      'Optional Extras (₹)',
      'Grand Total (₹)',
      'Paid Now (₹)',
      'Balance Payable (₹)',
      'Payment Status',
      'Booking Status',
      'Special Requests'
    ];

    const rows = bookings.map(b => [
      `"${b.id}"`,
      `"${b.createdAt.slice(0, 10)}"`,
      `"${b.travelDate}"`,
      `"${b.customerName.replace(/"/g, '""')}"`,
      `"${b.customerMobile}"`,
      `"${b.customerEmail}"`,
      `"${b.routeName}"`,
      `"${b.pickupPointName}"`,
      `"${b.pickupTime}"`,
      `"${b.packageTitle}"`,
      b.passengerCount,
      b.foodSelections?.vegBiryani || 0,
      b.foodSelections?.butterPaneer || 0,
      b.foodSelections?.vegThali || 0,
      b.totalPackageAmount,
      b.compulsoryCharges.guideChargeTotal,
      b.compulsoryCharges.seaLinkTollTotal,
      b.totalOptionalAmount,
      b.grandTotal,
      b.amountPaid,
      b.balancePayable,
      `"${b.paymentStatus}"`,
      `"${b.bookingStatus}"`,
      `"${(b.specialRequest || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Mumbai_Darshan_Bookings_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Reset to factory defaults
  static resetToDefaults(): void {
    localStorage.removeItem(KEYS.SETTINGS);
    localStorage.removeItem(KEYS.ROUTES);
    localStorage.removeItem(KEYS.PACKAGES);
    localStorage.removeItem(KEYS.OFFERS);
    localStorage.removeItem(KEYS.EXTRA_CHARGES);
    localStorage.removeItem(KEYS.PICKUP_POINTS);
    localStorage.removeItem(KEYS.TOUR_POINTS);
    localStorage.removeItem(KEYS.BOOKINGS);
    localStorage.removeItem(KEYS.PENDING_BOOKING_RETRY);
    localStorage.removeItem(KEYS.CAR_RENTALS);
    localStorage.removeItem(KEYS.PENDING_RENTAL_RETRY);
    localStorage.removeItem(KEYS.GROUP_ENQUIRIES);
    localStorage.removeItem(KEYS.CANCELLATIONS);
    localStorage.removeItem(KEYS.PRICE_HISTORY);
  }
}
