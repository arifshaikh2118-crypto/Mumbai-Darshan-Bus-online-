/** Safe accessors for the Admin session token. Browser storage can be disabled or throw. */
export const readAdminSessionToken = (): string | null => {
  try {
    return window.sessionStorage.getItem('mdb_admin_token');
  } catch {
    return null;
  }
};

export const storeAdminSession = (token: string): boolean => {
  if (!token) return false;
  try {
    window.sessionStorage.setItem('mdb_admin_token', token);
    window.sessionStorage.setItem('mdb_admin_auth', 'true');
    return window.sessionStorage.getItem('mdb_admin_token') === token;
  } catch {
    clearAdminSession();
    return false;
  }
};

export const clearAdminSession = (): boolean => {
  try {
    window.sessionStorage.removeItem('mdb_admin_token');
    window.sessionStorage.removeItem('mdb_admin_auth');
    return true;
  } catch {
    return false;
  }
};
