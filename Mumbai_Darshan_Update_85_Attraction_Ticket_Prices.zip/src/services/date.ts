/** Format a Date for an HTML date input using the visitor's local calendar date.
 * Avoid toISOString(), which converts to UTC and can shift the date by one day.
 */
export const toLocalDateInputValue = (date: Date): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};


/** Accept only a real YYYY-MM-DD calendar date that is today or later locally. */
export const isTodayOrFutureLocalDate = (value: string, now: Date = new Date()): boolean => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  const candidate = new Date(year, month - 1, day);
  if (
    candidate.getFullYear() !== year ||
    candidate.getMonth() !== month - 1 ||
    candidate.getDate() !== day
  ) return false;
  return value >= toLocalDateInputValue(now);
};
