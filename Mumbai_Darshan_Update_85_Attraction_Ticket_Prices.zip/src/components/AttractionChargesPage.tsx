import React from 'react';
import { ShieldAlert, Ticket, ArrowRight } from 'lucide-react';
import { StorageService } from '../services/storage';

interface AttractionChargesPageProps {
  onBookNow: () => void;
}

export const AttractionChargesPage: React.FC<AttractionChargesPageProps> = ({ onBookNow }) => {
  const extraCharges = StorageService.getExtraCharges().filter(charge => charge.active);
  const compulsoryCharges = extraCharges.filter(charge => charge.type === 'compulsory');
  const optionalTicketCharges = extraCharges.filter(charge => charge.type === 'optional' && charge.amount > 0);
  const compulsoryTotal = compulsoryCharges.reduce((total, charge) => total + charge.amount, 0);

  return (
    <div className="space-y-8 max-w-5xl mx-auto w-full min-w-0">
      <div className="text-center space-y-3">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-400">Transparent Fee Policy</span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">Attraction Tickets & Charges</h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          See every listed ticket price before your tour. Attraction entry fees are separate from the bus package fare and are never added to your online booking amount.
        </p>
      </div>

      <section className="shiny-dark-card rounded-2xl p-5 sm:p-8 border border-rose-500/30 space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center"><ShieldAlert className="w-5 h-5" /></div>
          <div>
            <h2 className="text-lg font-bold text-white">Compulsory On-Bus Charges — ₹{compulsoryTotal} per person</h2>
            <p className="text-xs text-slate-400">These charges are collected separately by the Tour Guide inside the bus.</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {compulsoryCharges.map(charge => (
            <div key={charge.id} className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-2">
              <div className="flex items-start justify-between gap-3 border-b border-white/10 pb-2">
                <span className="font-bold text-white text-sm">{charge.name}</span>
                <strong className="text-base text-rose-400 font-mono whitespace-nowrap">₹{charge.amount} / person</strong>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{charge.description}</p>
              <p className="text-[11px] text-amber-300/90">Collected directly by the Tour Guide inside the bus. Not included in the online bus fare or ₹200 advance.</p>
            </div>
          ))}
        </div>
        <p className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 leading-relaxed">
          <strong>Payment note:</strong> Compulsory Guide and Sea Link charges are paid separately to the Tour Guide on the bus. They are not added to the bus package price or collected online.
        </p>
      </section>

      <section className="shiny-dark-card rounded-2xl p-5 sm:p-8 border border-white/10 space-y-5">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-amber-400">Optional — Pay Only If You Visit</span>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">Attraction Entry Tickets & Activities</h2>
          <p className="text-xs text-slate-400 mt-1">
            You decide after boarding which attractions you want to visit. If you choose an attraction, its listed ticket amount is collected by the Tour Guide inside the bus. If you skip it, you do not pay for it.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {optionalTicketCharges.map(charge => (
            <div key={charge.id} className="bg-[#12141c] p-4 sm:p-5 rounded-xl border border-white/10 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-2 min-w-0">
                  <Ticket className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                  <h3 className="font-bold text-white text-sm">{charge.name}</h3>
                </div>
                <strong className="text-base font-extrabold text-amber-400 font-mono whitespace-nowrap">₹{charge.amount} / person</strong>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{charge.description}</p>
              <div className="text-[11px] text-amber-300/90 bg-white/5 p-2.5 rounded-lg">
                Optional ticket. Collected by the Tour Guide inside the bus only if you choose to visit. Not included in the bus package fare or online advance.
              </div>
            </div>
          ))}
        </div>
        <div className="text-xs text-slate-400 bg-white/5 rounded-xl p-3">
          Jehangir Art Gallery: General hall entry is free; special exhibitions, if any, may have separate charges. Confirm with the Tour Guide before visiting.
        </div>
      </section>

      <div className="text-center pt-1">
        <button onClick={onBookNow} className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-extrabold text-xs cursor-pointer shadow-lg shadow-amber-500/20 hover:from-amber-300 hover:to-amber-400 active:scale-95 transition-all inline-flex items-center gap-2">
          <span>Proceed to Tour Booking</span><ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
