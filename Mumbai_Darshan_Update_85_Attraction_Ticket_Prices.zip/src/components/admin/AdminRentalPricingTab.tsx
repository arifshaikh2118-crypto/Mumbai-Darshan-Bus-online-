import React, { useEffect, useState } from 'react';
import { readAdminSessionToken } from '../../services/adminSession';
import { LocalRentalPackage, OutstationVehicleRate } from '../../types';

interface RentalPricingData {
  localPackages: LocalRentalPackage[];
  outstationRates: OutstationVehicleRate[];
}

export const AdminRentalPricingTab: React.FC<{
  pricing?: RentalPricingData | null;
  onSaved: () => void;
  showToast: (message: string) => void;
}> = ({ pricing, onSaved, showToast }) => {
  const [localPackages, setLocalPackages] = useState<LocalRentalPackage[]>([]);
  const [outstationRates, setOutstationRates] = useState<OutstationVehicleRate[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (pricing?.localPackages?.length === 6 && pricing?.outstationRates?.length === 16) {
      setLocalPackages(pricing.localPackages.map(row => ({ ...row })));
      setOutstationRates(pricing.outstationRates.map(row => ({ ...row })));
      setError('');
    }
  }, [pricing]);

  const updateLocal = (id: string, key: keyof LocalRentalPackage, value: number | boolean) =>
    setLocalPackages(rows => rows.map(row => row.id === id ? { ...row, [key]: value } : row));
  const updateOutstation = (id: string, key: keyof OutstationVehicleRate, value: number | boolean) =>
    setOutstationRates(rows => rows.map(row => row.id === id ? { ...row, [key]: value } : row));

  const save = async () => {
    if (localPackages.length !== 6 || outstationRates.length !== 16) { setError('Complete rate catalogue is not loaded. Refresh Admin data first.'); return; }
    const localValid = localPackages.every(row => [row.durationHours, row.includedKm, row.customerPrice, row.extraKmRate, row.extraHourRate].every(n => Number.isSafeInteger(n) && n >= 0) && row.customerPrice > 0 && row.durationHours > 0 && row.includedKm > 0);
    const outValid = outstationRates.every(row => [row.customerPerKm, row.customerDaPerDay, row.minKmPerDay, row.nightDaRate].every(n => Number.isSafeInteger(n) && n >= 0) && row.customerPerKm > 0 && row.minKmPerDay > 0 && row.nightDaRate === row.customerDaPerDay);
    if (!localValid || !outValid) { setError('Enter valid whole-number prices and limits. Night DA must equal the daily DA.'); return; }
    const token = readAdminSessionToken();
    if (!token) { setError('Admin session expired. Please sign in again.'); return; }
    setBusy(true); setError('');
    try {
      const response = await fetch('/api/admin/rental-pricing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ rentalPricing: { localPackages, outstationRates } })
      });
      const body = await response.json();
      if (!response.ok || !body.success) throw new Error(body.error || 'Rental rates could not be saved.');
      showToast('Rental customer rates saved securely to Google Sheets Settings.');
      onSaved();
    } catch (e: any) { setError(e?.message || 'Rental rates could not be saved.'); }
    finally { setBusy(false); }
  };

  const numberInput = (value: number, onChange: (value: number) => void) => (
    <input type="number" min="0" step="1" value={value} onChange={e => onChange(Number(e.target.value))}
      className="w-24 rounded-lg bg-slate-950 border border-white/10 px-2 py-1.5 text-xs text-white" />
  );
  const flagInput = (value: boolean, onChange: (value: boolean) => void) => (
    <input type="checkbox" checked={value} onChange={e => onChange(e.target.checked)} className="accent-emerald-400" />
  );

  if (!pricing || localPackages.length !== 6 || outstationRates.length !== 16) {
    return <section className="rounded-xl border border-amber-400/20 bg-amber-500/5 p-4 text-xs text-amber-200">Rental pricing catalogue is not loaded from the protected Settings record. Do not change customer rates until the Admin data refresh succeeds.</section>;
  }

  return <section className="rounded-xl border border-white/10 bg-[#12141c] p-4 space-y-5">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div><h3 className="text-sm font-bold text-white">Customer Rental Pricing</h3><p className="text-[11px] text-slate-400">Edit public customer rates. Saving writes the validated catalogue to the existing Settings sheet; the approved 17-tab / 139-header schema is unchanged.</p></div>
      <button disabled={busy} onClick={save} className="rounded-lg bg-emerald-500 px-4 py-2 text-xs font-bold text-slate-950 disabled:opacity-50">{busy ? 'Saving…' : 'Save All Rental Rates'}</button>
    </div>
    <div className="rounded-lg border border-sky-400/20 bg-sky-500/5 p-3 text-[11px] text-sky-100">Mumbai Local Darshan: 12 hours / 120 KM. Driver allowance and parking included. Tour guide is optional at ₹2,000 per booking/vehicle. Toll and entry charges remain extra at actuals.</div>
    <div className="space-y-2"><h4 className="text-xs font-bold text-white">Local Darshan Packages</h4><div className="overflow-x-auto"><table className="w-full min-w-[760px] text-[10px]"><thead className="text-slate-400"><tr>{['Vehicle','Base ₹','Hours','Included KM','Extra KM ₹','Extra Hour ₹','Active','Published'].map(h => <th key={h} className="p-2 text-left">{h}</th>)}</tr></thead><tbody>{localPackages.map(row => <tr key={row.id} className="border-t border-white/5 text-slate-200"><td className="p-2 font-semibold">{row.vehicleName}<span className="block text-slate-500">{row.seating}</span></td><td className="p-2">{numberInput(row.customerPrice,v=>updateLocal(row.id,'customerPrice',v))}</td><td className="p-2">{numberInput(row.durationHours,v=>updateLocal(row.id,'durationHours',v))}</td><td className="p-2">{numberInput(row.includedKm,v=>updateLocal(row.id,'includedKm',v))}</td><td className="p-2">{numberInput(row.extraKmRate,v=>updateLocal(row.id,'extraKmRate',v))}</td><td className="p-2">{numberInput(row.extraHourRate,v=>updateLocal(row.id,'extraHourRate',v))}</td><td className="p-2">{flagInput(row.active,v=>updateLocal(row.id,'active',v))}</td><td className="p-2">{flagInput(row.published,v=>updateLocal(row.id,'published',v))}</td></tr>)}</tbody></table></div></div>
    <div className="rounded-lg border border-amber-400/20 bg-amber-500/5 p-3 text-[11px] text-amber-100">Outstation: minimum 300 KM/day. Driver DA / permit is extra. Parking, toll, border tax and entry charges are extra at actuals. Additional Night DA after 11 PM equals the regular daily DA.</div>
    <div className="space-y-2"><h4 className="text-xs font-bold text-white">Outstation Rates</h4><div className="overflow-x-auto"><table className="w-full min-w-[760px] text-[10px]"><thead className="text-slate-400"><tr>{['Vehicle','Per KM ₹','Daily DA ₹','Min KM/Day','Night DA ₹','AC','Active','Published'].map(h => <th key={h} className="p-2 text-left">{h}</th>)}</tr></thead><tbody>{outstationRates.map(row => <tr key={row.id} className="border-t border-white/5 text-slate-200"><td className="p-2 font-semibold">{row.vehicleName}<span className="block text-slate-500">{row.seating}</span></td><td className="p-2">{numberInput(row.customerPerKm,v=>updateOutstation(row.id,'customerPerKm',v))}</td><td className="p-2">{numberInput(row.customerDaPerDay,v=>{updateOutstation(row.id,'customerDaPerDay',v);updateOutstation(row.id,'nightDaRate',v);})}</td><td className="p-2">{numberInput(row.minKmPerDay,v=>updateOutstation(row.id,'minKmPerDay',v))}</td><td className="p-2"><span className="text-slate-400">Same as Daily DA</span><span className="block font-bold">₹{row.customerDaPerDay}</span></td><td className="p-2">{flagInput(row.isAC,v=>updateOutstation(row.id,'isAC',v))}</td><td className="p-2">{flagInput(row.active,v=>updateOutstation(row.id,'active',v))}</td><td className="p-2">{flagInput(row.published,v=>updateOutstation(row.id,'published',v))}</td></tr>)}</tbody></table></div></div>
    {error && <p className="rounded-lg border border-rose-400/20 bg-rose-500/10 p-3 text-xs text-rose-200">{error}</p>}
    <div className="flex justify-end"><button disabled={busy} onClick={save} className="rounded-lg bg-emerald-500 px-4 py-2 text-xs font-bold text-slate-950 disabled:opacity-50">{busy ? 'Saving…' : 'Save All Rental Rates'}</button></div>
  </section>;
};
