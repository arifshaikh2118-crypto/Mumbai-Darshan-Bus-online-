import { readAdminSessionToken } from '../../services/adminSession';
import React, { useState } from 'react';
import { RefreshCw, Save, ShieldAlert } from 'lucide-react';

type CancellationRecord = {
  cancellation_id: string; booking_id: string; customer_name: string; mobile: string;
  cancellation_reason: string; refund_amount: number | string; refund_status: string; cancelled_at: string;
};

export const AdminCancellationsPanel: React.FC<{ records: CancellationRecord[]; onRefresh: () => void; showToast: (message: string) => void }> = ({ records, onRefresh, showToast }) => {
  const [values, setValues] = useState<Record<string, string>>({});
  const [manualConfirmed, setManualConfirmed] = useState<Record<string, boolean>>({});
  const [saving, setSaving] = useState<string | null>(null);
  const update = async (record: CancellationRecord) => {
    const next = values[record.cancellation_id] || record.refund_status || 'Pending Review';
    if (next === 'Refunded' && !manualConfirmed[record.cancellation_id]) {
      showToast('Complete the actual manual refund before marking this record as Refunded, then confirm the checkbox.'); return;
    }
    const token = readAdminSessionToken();
    if (!token) { showToast('Admin session expired. Please login again.'); return; }
    setSaving(record.cancellation_id);
    try {
      const response = await fetch('/api/admin/cancellations/refund-status', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ cancellationId: record.cancellation_id, refundStatus: next, manualRefundConfirmed: Boolean(manualConfirmed[record.cancellation_id]) }) });
      const data = await response.json();
      if (!response.ok || !data.success || ['error', 'not_found', 'duplicate'].includes(String(data.result?.status || '').toLowerCase())) {
        throw new Error(data.result?.message || data.error || 'Update failed');
      }
      showToast(data.result?.message || 'Cancellation status updated.'); onRefresh();
    } catch (error: any) { showToast(error.message || 'Cancellation update failed.'); }
    finally { setSaving(null); }
  };
  return <section className="mt-6 rounded-xl border border-rose-500/20 bg-rose-500/5 p-4 space-y-3">
    <div><h3 className="text-sm font-bold text-white">Cancellation & Refund Review</h3><p className="text-[11px] text-slate-400">Verified paid amount is shown as a review cap, not a final refund calculation. No gateway refund is initiated from this panel.</p></div>
    {records.length === 0 ? <p className="text-xs text-slate-500">No cancellation requests yet.</p> : records.map(record => <div key={record.cancellation_id} className="rounded-lg border border-white/10 bg-slate-950/60 p-3 space-y-2">
      <div className="flex flex-wrap justify-between gap-2"><div><p className="text-xs font-bold text-amber-300">{record.booking_id}</p><p className="text-[11px] text-slate-300">{record.customer_name} · {record.mobile}</p></div><p className="text-xs font-bold text-white">₹{Number(record.refund_amount || 0)} <span className="block text-[9px] font-normal text-slate-400">Verified paid / review cap</span></p></div>
      <p className="text-[11px] text-slate-400">Reason: {record.cancellation_reason}</p>
      <div className="flex flex-wrap items-center gap-2"><select value={values[record.cancellation_id] ?? record.refund_status ?? 'Pending Review'} onChange={e => setValues(old => ({ ...old, [record.cancellation_id]: e.target.value }))} className="rounded-lg bg-slate-900 border border-white/10 px-2 py-2 text-xs text-white">
        {(record.refund_status === 'Pending Review' || !record.refund_status) && <><option>Pending Review</option><option>Approved</option><option>Rejected</option></>}
        {record.refund_status === 'Approved' && <><option>Approved</option><option>Refunded</option><option>Rejected</option></>}
        {record.refund_status === 'Refunded' && <option>Refunded</option>}
        {record.refund_status === 'Rejected' && <option>Rejected</option>}
      </select>
        <button disabled={saving === record.cancellation_id} onClick={() => update(record)} className="inline-flex items-center gap-1 rounded-lg bg-amber-500 px-3 py-2 text-xs font-bold text-slate-950 disabled:opacity-50"><Save className="h-3 w-3" />{saving === record.cancellation_id ? 'Saving…' : 'Save'}</button>
        <button onClick={onRefresh} className="rounded-lg bg-white/10 p-2 text-slate-300" title="Refresh"><RefreshCw className="h-3 w-3" /></button>
      </div>
      {(values[record.cancellation_id] || record.refund_status) === 'Refunded' && <label className="flex items-start gap-2 text-[10px] text-rose-200"><input type="checkbox" checked={Boolean(manualConfirmed[record.cancellation_id])} onChange={e => setManualConfirmed(old => ({ ...old, [record.cancellation_id]: e.target.checked }))} /><span><ShieldAlert className="inline h-3 w-3 mr-1" />I confirm the refund has actually been completed manually outside this system.</span></label>}
    </div>)}
  </section>;
};
