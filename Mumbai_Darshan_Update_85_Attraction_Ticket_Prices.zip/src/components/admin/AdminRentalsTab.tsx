import { readAdminSessionToken } from '../../services/adminSession';
import React, { useMemo, useState } from 'react';
import { Car, Calendar, MapPin, Users, Phone, MessageCircle, RefreshCw, ShieldCheck, Clock3 } from 'lucide-react';
import { CarRentalEnquiry, RentalStatus } from '../../types';
import { StorageService } from '../../services/storage';

interface AdminRentalsTabProps {
  enquiries: CarRentalEnquiry[];
  onRefresh: () => void;
  showToast: (msg: string) => void;
}

const RENTAL_STATUSES: RentalStatus[] = [
  'New', 'Contacted', 'Quote Sent', 'Follow-up', 'Confirmed', 'Not Interested', 'Cancelled'
];

const statusLabel: Record<RentalStatus, string> = {
  New: 'New', Contacted: 'Contacted', 'Quote Sent': 'Quote Sent', 'Follow-up': 'Follow-up',
  Confirmed: 'Confirmed', 'Not Interested': 'Not Interested', Cancelled: 'Cancelled'
};

const formatValue = (value?: string | number) => value === undefined || value === null || value === '' ? '—' : String(value);

export const AdminRentalsTab: React.FC<AdminRentalsTabProps> = ({ enquiries, onRefresh, showToast }) => {
  const businessPhone = StorageService.getSettings().businessPhone;
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const filteredEnquiries = useMemo(() => enquiries.filter(item => statusFilter === 'ALL' || item.status === statusFilter), [enquiries, statusFilter]);

  const handleUpdateStatus = async (id: string, newStatus: RentalStatus) => {
    setUpdatingId(id);
    try {
      const token = readAdminSessionToken() || '';
      const response = await fetch('/api/admin/rentals/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ enquiryId: id, status: newStatus })
      });
      const result = await response.json();
      if (!response.ok || !result.success || result.result?.status !== 'success') throw new Error(result.error || result.result?.message || 'Update rejected');
      showToast(`Enquiry ${id}: ${newStatus} — Google Sheets updated`);
      onRefresh();
    } catch (error: any) {
      showToast(`Status update failed: ${error?.message || 'Network error'}`);
    } finally {
      setUpdatingId(null);
    }
  };

  const whatsappLink = (enquiry: CarRentalEnquiry) => {
    const phone = String(enquiry.customerMobile || '').replace(/\D/g, '');
    const normalizedPhone = phone.startsWith('91') ? phone : `91${phone}`;
    const message = `Hello ${enquiry.customerName},\n\nThank you for contacting Mumbai Darshan Bus Online about your vehicle rental enquiry (${enquiry.id}). We have received your requirements. Our team will check availability and get back to you with details.\n\nPlease let us know if any trip details need to be corrected.\n\nMumbai Darshan Bus Online\n+91 ${businessPhone}`;
    return `https://wa.me/${normalizedPhone}?text=${encodeURIComponent(message)}`;
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2"><Car className="w-5 h-5 text-amber-400" /> Rental Enquiries</h2>
          <p className="text-xs text-slate-400 mt-1">Customer enquiries only · Google Sheets is the source of truth · WhatsApp follow-up</p>
        </div>
        <button onClick={onRefresh} className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-white text-xs font-semibold">
          <RefreshCw className="w-3.5 h-3.5" /> Refresh enquiries
        </button>
      </div>

      <div className="rounded-xl border border-amber-500/25 bg-amber-500/10 p-3 flex gap-2.5">
        <ShieldCheck className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-100/90 leading-relaxed">
          <strong>Inquiry-only workflow.</strong> This screen uses only the approved 19 rental enquiry columns. Manage customer requirements, enquiry status, and WhatsApp follow-up here. No email is sent for rental enquiries.
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 rounded-xl bg-[#12141c] p-3 border border-white/10">
        <span className="text-xs text-slate-400 mr-1">Filter:</span>
        {['ALL', ...RENTAL_STATUSES].map(status => (
          <button key={status} onClick={() => setStatusFilter(status)} className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold ${statusFilter === status ? 'bg-amber-500 text-slate-950' : 'bg-white/5 text-slate-300 hover:bg-white/10'}`}>
            {status === 'ALL' ? `All (${enquiries.length})` : statusLabel[status as RentalStatus]}
          </button>
        ))}
      </div>

      {filteredEnquiries.length === 0 ? (
        <div className="p-10 text-center text-sm text-slate-400 bg-[#12141c] rounded-xl border border-white/10">No rental enquiries found for this status.</div>
      ) : (
        <div className="space-y-3">
          {filteredEnquiries.map(enquiry => (
            <article key={enquiry.id} className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-white/10 pb-3">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-amber-400 font-bold text-xs">{enquiry.id}</span>
                    <span className="text-white font-semibold text-sm">{enquiry.customerName}</span>
                  </div>
                  <span className="text-[11px] text-slate-500">Received: {formatValue(enquiry.createdAt)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <label htmlFor={`rental-status-${enquiry.id}`} className="text-[11px] text-slate-400">Status</label>
                  <select id={`rental-status-${enquiry.id}`} value={RENTAL_STATUSES.includes(enquiry.status) ? enquiry.status : 'New'} disabled={updatingId === enquiry.id}
                    onChange={event => handleUpdateStatus(enquiry.id, event.target.value as RentalStatus)}
                    className="bg-slate-900 border border-white/15 rounded-lg px-2.5 py-2 text-xs text-amber-300 font-semibold focus:outline-none focus:border-amber-400 disabled:opacity-50">
                    {RENTAL_STATUSES.map(status => <option key={status} value={status}>{status}</option>)}
                  </select>
                  {updatingId === enquiry.id && <Clock3 className="w-4 h-4 text-amber-300 animate-pulse" />}
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div><span className="block text-[10px] text-slate-500 mb-1">Mobile</span><a className="text-amber-300 font-mono inline-flex items-center gap-1" href={`tel:${enquiry.customerMobile}`}><Phone className="w-3 h-3" />{formatValue(enquiry.customerMobile)}</a></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">Vehicle Type</span><strong className="text-white">{formatValue(enquiry.vehicleType)}</strong></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">Preferred Model</span><strong className="text-white">{formatValue(enquiry.preferredCarModel)}</strong></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">Travel Date</span><strong className="text-white inline-flex items-center gap-1"><Calendar className="w-3 h-3" />{formatValue(enquiry.travelDate)}</strong></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">Passengers</span><strong className="text-white inline-flex items-center gap-1"><Users className="w-3 h-3" />{formatValue(enquiry.passengerCount)}</strong></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">Trip Type</span><strong className="text-white">{formatValue(enquiry.tripType || enquiry.rentalType)}</strong></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">Tempo Traveller Seats</span><strong className="text-white">{formatValue(enquiry.tempoTravellerSeatingCapacity)}</strong></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">Other Seat Capacity</span><strong className="text-white">{formatValue(enquiry.otherSeatingCapacity)}</strong></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">AC Preference</span><strong className="text-white">{formatValue(enquiry.acPreference)}</strong></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">Rental Duration</span><strong className="text-white">{formatValue(enquiry.rentalDuration || enquiry.daysCount)}</strong></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">Pickup Time</span><strong className="text-white">{formatValue(enquiry.preferredPickupTime)}</strong></div>
                <div><span className="block text-[10px] text-slate-500 mb-1">Days</span><strong className="text-white">{formatValue(enquiry.daysCount)}</strong></div>
              </div>

              <div className="rounded-lg bg-white/5 p-3 text-xs space-y-2">
                <div className="flex items-start gap-2 text-slate-200"><MapPin className="w-3.5 h-3.5 text-amber-300 shrink-0 mt-0.5" /><span><strong>Pickup:</strong> {formatValue(enquiry.pickupLocation)}</span></div>
                <div className="flex items-start gap-2 text-slate-200"><MapPin className="w-3.5 h-3.5 text-amber-300 shrink-0 mt-0.5" /><span><strong>Destination:</strong> {formatValue(enquiry.destination)}</span></div>
                <div><span className="text-slate-500">Special Request: </span><span className="text-white">{formatValue(enquiry.specialRequirements)}</span></div>
              </div>

              <div className="flex flex-wrap justify-end gap-2 pt-1">
                <a href={whatsappLink(enquiry)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold">
                  <MessageCircle className="w-3.5 h-3.5" /> WhatsApp follow-up
                </a>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
};
