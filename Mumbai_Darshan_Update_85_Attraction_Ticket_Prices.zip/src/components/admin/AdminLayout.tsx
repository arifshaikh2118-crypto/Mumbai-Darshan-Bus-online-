import { readAdminSessionToken, storeAdminSession, clearAdminSession } from '../../services/adminSession';
import React, { useState, useMemo, useEffect } from 'react';
import {
  LayoutDashboard,
  CalendarCheck,
  MapPin,
  Tag,
  Sparkles,
  DollarSign,
  Compass,
  Car,
  Users,
  FileSpreadsheet,
  History,
  Search,
  Plus,
  Edit,
  Trash2,
  Check,
  X,
  Download,
  Printer,
  Shield,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Send,
  Eye,
  Image as ImageIcon,
  BarChart3,
  KeyRound,
  Lock
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import {
  Booking,
  RouteConfig,
  PickupPoint,
  PackagePricing,
  RouteOffer,
  ExtraCharge,
  TourPoint,
  CarRentalEnquiry,
  GroupBookingEnquiry,
  RouteId,
  PackageId
} from '../../types';
import { AdminGalleryTab } from './AdminGalleryTab';
import { AdminRentalsTab } from './AdminRentalsTab';
import { AdminRentalPricingTab } from './AdminRentalPricingTab';
import { AdminReportsTab } from './AdminReportsTab';
import { OperationalSheetsManager } from './OperationalSheetsManager';
import { AdminCancellationsPanel } from './AdminCancellationsPanel';
import { AdminNotificationPanel } from './AdminNotificationPanel';
import { AdminPaymentReconciliationPanel } from './AdminPaymentReconciliationPanel';

type AdminTab =
  | 'dashboard'
  | 'bookings'
  | 'reports'
  | 'routes'
  | 'pickups'
  | 'pricing'
  | 'offers'
  | 'extra_charges'
  | 'tour_points'
  | 'gallery'
  | 'car_rentals'
  | 'group_enquiries'
  | 'google_sheets';

interface AdminLayoutProps {
  onExit: () => void;
}

const sheetDate = (value: any) => value ? String(value).slice(0, 10) : '';
const mapSheetBooking = (r: any, paymentRows: any[] = []): Booking => {
  const routeText = String(r['Pickup Route'] || '').toLowerCase();
  const routeId: RouteId = routeText.includes('central') ? 'central' : routeText.includes('harbour') ? 'harbour' : routeText.includes('kalyan') ? 'kalyan_dombivli' : 'western';
  const pkg = String(r['Package Key'] || '').toLowerCase();
  const isAC = pkg.includes('ac_') || String(r['Package Name'] || '').toLowerCase().startsWith('ac');
  const hasLunch = pkg.includes('lunch') || String(r['Package Name'] || '').toLowerCase().includes('lunch');
  const persons = Number(r.Persons || 0);
  const amount = Number(r['Amount INR'] || 0);
  const verifiedPayments = paymentRows.filter((payment: any) => String(payment.booking_id || '').toUpperCase() === String(r['Booking ID'] || '').toUpperCase() && String(payment.payment_status || '').toLowerCase() === 'verified');
  // The payment ledger is the sole source for collected-online amounts.
  // Never infer cash received from a booking status label when verified ledger evidence is absent.
  const paid = verifiedPayments.reduce((sum: number, payment: any) => {
    const value = Number(payment.amount || 0);
    return sum + (Number.isFinite(value) && value > 0 ? value : 0);
  }, 0);
  return {
    id: String(r['Booking ID'] || ''), createdAt: String(r.Timestamp || ''), travelDate: sheetDate(r['Travel Date']),
    routeId, routeName: String(r['Pickup Route'] || ''), pickupPointId: String(r['Pickup Point'] || ''), pickupPointName: String(r['Pickup Point'] || ''),
    pickupTime: '', reportingTime: '', packageId: (pkg || (isAC ? 'ac_no_lunch' : 'non_ac_no_lunch')) as PackageId,
    packageTitle: String(r['Package Name'] || ''), isAC, hasLunch, passengerCount: persons,
    foodSelections: { vegBiryani: Number(r['Veg Biryani Persons'] || 0), butterPaneer: Number(r['Butter Paneer Persons'] || 0), vegThali: Number(r['Veg Thali Persons'] || 0) },
    specialRequest: String(r['Special Request'] || ''), customerName: String(r.Name || ''), customerMobile: String(r.Phone || ''), customerEmail: String(r['Customer Email'] || ''),
    unitPackagePrice: persons ? amount / persons : amount, totalPackageAmount: amount, offerDiscountAmount: 0,
    compulsoryCharges: { guideChargeUnit: 0, guideChargeTotal: 0, seaLinkTollUnit: 0, seaLinkTollTotal: 0, totalCompulsoryAmount: 0 },
    selectedOptionalAttractions: [], totalOptionalAmount: 0, grandTotal: amount, paymentMode: 'advance', amountPayableNow: 200,
    amountPaid: paid, balancePayable: Math.max(0, amount - paid), paymentStatus: String(r['Payment Status'] || 'Pending Verification') as Booking['paymentStatus'],
    bookingStatus: String(r['Booking Status'] || 'Pending Verification') as Booking['bookingStatus'],
    customerEmailStatus: String(r['Customer Email Status'] || 'Pending') as any, ownerEmailStatus: String(r['Owner Email Status'] || 'Pending') as any, lastEmailError: String(r['Last Error'] || '')
  };
};
const normalizeRentalStatus = (value: unknown): CarRentalEnquiry['status'] => {
  const status = String(value || 'New');
  const legacy: Record<string, CarRentalEnquiry['status']> = {
    'New Enquiry': 'New', 'Quotation Pending': 'Follow-up', 'Quotation Sent': 'Quote Sent',
    'Awaiting Customer Approval': 'Follow-up', 'Supplier Availability Pending': 'Follow-up', 'Completed': 'Confirmed'
  };
  return legacy[status] || (['New', 'Contacted', 'Quote Sent', 'Follow-up', 'Confirmed', 'Not Interested', 'Cancelled'].includes(status) ? status as CarRentalEnquiry['status'] : 'New');
};
const mapSheetRental = (r: any): CarRentalEnquiry => ({
  id: String(r.id || ''), createdAt: String(r.created_at || ''), customerName: String(r.customer_name || ''), customerMobile: String(r.mobile || ''),
  travelDate: sheetDate(r.travel_date), rentalType: String(r.trip_type || '').toLowerCase().includes('outstation') ? 'outstation' : 'local_darshan',
  tripType: String(r.trip_type || ''), vehicleType: String(r.vehicle_type || ''), preferredCarModel: String(r.preferred_car_model || ''),
  tempoTravellerSeatingCapacity: r.tempo_traveller_seating_capacity ?? '', otherSeatingCapacity: r.other_seating_capacity ?? '',
  acPreference: String(r.ac_preference || ''), rentalDuration: String(r.rental_duration || ''), preferredPickupTime: String(r.pickup_time || ''),
  passengerCount: Number(r.persons || 0), pickupLocation: String(r.pickup_location || ''), destination: String(r.destination || ''),
  daysCount: Number(r.days || 0), specialRequirements: String(r.special_request || ''), status: normalizeRentalStatus(r.status)
});

export const AdminLayout: React.FC<AdminLayoutProps> = ({ onExit }) => {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminEmailInput, setAdminEmailInput] = useState('');
  const [passcodeInput, setPasscodeInput] = useState('');
  const [adminSheetData, setAdminSheetData] = useState<any | null>(null);
  const [adminDataLoading, setAdminDataLoading] = useState(false);
  const [dailyReportDate, setDailyReportDate] = useState(() => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10));
  const [dailyReportBusy, setDailyReportBusy] = useState(false);
  useEffect(() => {
    let cancelled = false;
    const token = readAdminSessionToken();
    if (!token) return;
    fetch('/api/admin/verify', { headers: { Authorization: `Bearer ${token}` } })
      .then(response => response.ok ? response.json() : Promise.reject(new Error('Session expired')))
      .then(data => { if (!cancelled && data.authenticated) setIsAdminAuthenticated(true); })
      .catch(() => { clearAdminSession(); });
    return () => { cancelled = true; };
  }, []);
  const [authError, setAuthError] = useState('');

  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [refreshKey, setRefreshKey] = useState<number>(0);

  const forceRefresh = () => setRefreshKey(prev => prev + 1);
  const handleGenerateDailyReport = async () => {
    const token = readAdminSessionToken();
    if (!token || !/^\d{4}-\d{2}-\d{2}$/.test(dailyReportDate)) { showToast('Valid Admin session and report date are required.'); return; }
    setDailyReportBusy(true);
    try {
      const response = await fetch('/api/admin/reports/daily/generate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ reportDate: dailyReportDate }) });
      const body = await response.json();
      if (!response.ok || !body.success || body.result?.status !== 'success') throw new Error(body.error || body.result?.message || 'Daily report generation failed');
      showToast(`Daily report saved for ${dailyReportDate}. Email was not sent.`);
      forceRefresh();
    } catch (error: any) { showToast(error?.message || 'Daily report generation failed.'); }
    finally { setDailyReportBusy(false); }
  };
  useEffect(() => {
    if (!isAdminAuthenticated) return;
    const token = readAdminSessionToken();
    if (!token) { setIsAdminAuthenticated(false); return; }
    let cancelled = false;
    setAdminDataLoading(true);
    setAdminSheetData(null);
    fetch('/api/admin/data', { headers: { Authorization: `Bearer ${token}` } })
      .then(async response => { const body = await response.json(); if (!response.ok || !body.success) throw new Error(body.error || 'Admin data retrieval failed'); return body.data; })
      .then(data => { if (!cancelled) setAdminSheetData(data); })
      .catch(() => { if (!cancelled) { setAdminSheetData(null); setIsAdminAuthenticated(false); clearAdminSession(); } })
      .finally(() => { if (!cancelled) setAdminDataLoading(false); });
    return () => { cancelled = true; };
  }, [isAdminAuthenticated, refreshKey]);

  // Dynamic live data
  const bookings = useMemo(() => adminSheetData ? (adminSheetData.bookings || []).map((row: any) => mapSheetBooking(row, adminSheetData.payments || [])) : (isAdminAuthenticated ? [] : StorageService.getBookings()), [refreshKey, adminSheetData, isAdminAuthenticated]);
  const routes = useMemo(() => StorageService.getRoutes(), [refreshKey]);
  const pickupPoints = useMemo(() => StorageService.getPickupPoints(), [refreshKey]);
  const packages = useMemo(() => StorageService.getPackages(), [refreshKey]);
  const offers = useMemo(() => StorageService.getOffers(), [refreshKey]);
  const extraCharges = useMemo(() => StorageService.getExtraCharges(), [refreshKey]);
  const tourPoints = useMemo(() => StorageService.getTourPoints(), [refreshKey]);
  const carRentals = useMemo(() => adminSheetData ? (adminSheetData.rentalEnquiries || []).map(mapSheetRental) : (isAdminAuthenticated ? [] : StorageService.getCarRentals()), [refreshKey, adminSheetData, isAdminAuthenticated]);
  const groupEnquiries = useMemo(() => StorageService.getGroupEnquiries(), [refreshKey]);
  const priceHistory = useMemo(() => StorageService.getPriceHistory(), [refreshKey]);
  const settings = useMemo(() => StorageService.getSettings(), [refreshKey]);

  // Notifications / Feedback toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // --- DASHBOARD METRICS CALCULATION ---
  const todayStr = new Date().toISOString().slice(0, 10);
  const todayBookings = bookings.filter(b => b.travelDate === todayStr);
  const upcomingBookings = bookings.filter(b => b.travelDate >= todayStr && b.bookingStatus !== 'Cancelled');
  const confirmedBookings = bookings.filter(b => b.bookingStatus === 'Confirmed' || b.bookingStatus === 'Completed');

  const totalPassengers = bookings
    .filter(b => b.bookingStatus !== 'Cancelled')
    .reduce((acc, b) => acc + b.passengerCount, 0);

  const verifiedCollectedRevenue = bookings
    .filter(b => b.bookingStatus !== 'Cancelled')
    .reduce((acc, b) => acc + (b.amountPaid || 0), 0);

  const totalOutstandingBalance = bookings
    .filter(b => b.bookingStatus !== 'Cancelled')
    .reduce((acc, b) => acc + (b.balancePayable || 0), 0);

  const acCount = bookings
    .filter(b => b.isAC && b.bookingStatus !== 'Cancelled')
    .reduce((acc, b) => acc + b.passengerCount, 0);

  const nonAcCount = bookings
    .filter(b => !b.isAC && b.bookingStatus !== 'Cancelled')
    .reduce((acc, b) => acc + b.passengerCount, 0);

  const lunchCount = bookings
    .filter(b => b.hasLunch && b.bookingStatus !== 'Cancelled')
    .reduce((acc, b) => acc + b.passengerCount, 0);

  // Meal totals
  const vegBiryaniTotal = bookings
    .filter(b => b.bookingStatus !== 'Cancelled')
    .reduce((acc, b) => acc + (b.foodSelections?.vegBiryani || 0), 0);

  const butterPaneerTotal = bookings
    .filter(b => b.bookingStatus !== 'Cancelled')
    .reduce((acc, b) => acc + (b.foodSelections?.butterPaneer || 0), 0);

  const vegThaliTotal = bookings
    .filter(b => b.bookingStatus !== 'Cancelled')
    .reduce((acc, b) => acc + (b.foodSelections?.vegThali || 0), 0);

  // --- BOOKING MANAGEMENT STATE ---
  const [bookingSearch, setBookingSearch] = useState('');
  const [bookingStatusFilter, setBookingStatusFilter] = useState<string>('ALL');
  const [bookingRouteFilter, setBookingRouteFilter] = useState<string>('ALL');
  const [selectedBookingForModal, setSelectedBookingForModal] = useState<Booking | null>(null);

  const filteredBookings = useMemo(() => {
    return bookings.filter(b => {
      const q = bookingSearch.toLowerCase().trim();
      const matchSearch =
        !q ||
        b.id.toLowerCase().includes(q) ||
        b.customerName.toLowerCase().includes(q) ||
        b.customerMobile.includes(q) ||
        b.pickupPointName.toLowerCase().includes(q);

      const matchStatus = bookingStatusFilter === 'ALL' || b.bookingStatus === bookingStatusFilter;
      const matchRoute = bookingRouteFilter === 'ALL' || b.routeId === bookingRouteFilter;

      return matchSearch && matchStatus && matchRoute;
    });
  }, [bookings, bookingSearch, bookingStatusFilter, bookingRouteFilter]);

  // Update booking status helper
  const handleUpdateBookingStatus = async (id: string, newStatus: Booking['bookingStatus']) => {
    try {
      const token = readAdminSessionToken() || '';
      const response = await fetch('/api/admin/bookings/status', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ bookingId: id, bookingStatus: newStatus }) });
      const result = await response.json();
      if (!response.ok || !result.success || result.result?.status !== 'success') throw new Error(result.error || result.result?.message || 'Update rejected');
      showToast(`Booking ${id} status updated in Google Sheets`);
      forceRefresh();
    } catch (error: any) { showToast(`Booking status update failed: ${error.message || 'Network error'}`); }
  };

  const handleRetryEmail = async (bookingId: string) => {
    showToast(`Triggering email retry for ${bookingId}...`);
    const token = readAdminSessionToken() || '';
    const res = await StorageService.retryBookingEmail(bookingId, token);
    showToast(res.message);
    forceRefresh();
    if (selectedBookingForModal?.id === bookingId) {
      setSelectedBookingForModal(bookings.find(item => item.id === bookingId) || null);
    }
  };

  // --- PICKUP POINT EDIT/ADD STATE ---
  const [editingPickup, setEditingPickup] = useState<PickupPoint | null>(null);
  const [isAddingPickup, setIsAddingPickup] = useState(false);
  const [newPickupRoute, setNewPickupRoute] = useState<RouteId>('western');
  const [newPickupName, setNewPickupName] = useState('');
  const [newPickupTime, setNewPickupTime] = useState('7:00 AM');
  const [newPickupLandmark, setNewPickupLandmark] = useState('');
  const [newPickupMaps, setNewPickupMaps] = useState('');

  // --- PACKAGE PRICE EDIT STATE ---
  const [editingPricePkg, setEditingPricePkg] = useState<PackageId | null>(null);
  const [tempPrices, setTempPrices] = useState<Record<RouteId, number>>({
    western: 0,
    central: 0,
    harbour: 0,
    kalyan_dombivli: 0
  });

  // --- TOUR POINT EDIT STATE ---
  const [editingTourPoint, setEditingTourPoint] = useState<TourPoint | null>(null);

  // --- GOOGLE SHEETS SETTINGS STATE ---
  const [rentalGarageAddressInput, setRentalGarageAddressInput] = useState(settings.rentalGarageAddress || 'Jai Mata Di Travels, Shop No. 12, Om Poonam Enclave, Near Old Golden Nest, Mira Bhayandar Road, Mira Road East, Maharashtra 401107, India');
  const [gsTestStatus, setGsTestStatus] = useState<string | null>(null);

  const handleSaveGarageSettings = () => {
    StorageService.updateSettings({
      rentalGarageAddress: rentalGarageAddressInput.trim() || 'Jai Mata Di Travels, Shop No. 12, Om Poonam Enclave, Near Old Golden Nest, Mira Bhayandar Road, Mira Road East, Maharashtra 401107, India'
    });
    forceRefresh();
    showToast('Garage settings saved.');
  };

  const handleTestWebhook = async () => {
    setGsTestStatus('Testing the server-configured Google Apps Script connection...');
    try {
      const response = await fetch('/api/sync-sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payload: { action: 'PING_TEST', timestamp: new Date().toISOString() } })
      });
      const result = await response.json();
      const backend = result?.backendResponse || {};
      setGsTestStatus(response.ok && backend.status === 'success' ? `Connected: ${backend.message}` : `Connection test failed: ${backend.message || result?.error || 'Unexpected Apps Script response'}`);
    } catch (e: any) {
      setGsTestStatus(`Connection test failed: ${e?.message || 'Network error'}`);
    }
  };

  const handleTestEmailConnection = async () => {
    setGsTestStatus('Email testing is intentionally disabled through the public website webhook. At final setup, the owner must run the controlled runEmailConnectionTest function from the Apps Script editor after reviewing the recipient and email settings.');
  };

  if (!isAdminAuthenticated) {
    return (
      <div className="min-h-screen bg-[#07080b] flex items-center justify-center p-4">
        <div className="bg-[#0e1017] border border-amber-500/30 rounded-2xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-5">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto">
              <Lock className="w-6 h-6" />
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight">Admin Console Authentication</h2>
            <p className="text-xs text-slate-400">
              Access is limited to active AdminUsers accounts. Sessions expire automatically after 30 minutes.
            </p>
          </div>

          <form
            onSubmit={async e => {
              e.preventDefault();
              setAuthError('');
              const cleanInput = passcodeInput.trim();
              if (!cleanInput) {
                setAuthError('Please enter the administrative passcode.');
                return;
              }

              try {
                const res = await fetch('/api/admin/login', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ email: adminEmailInput.trim(), passcode: cleanInput })
                });
                const data = await res.json();
                if (res.ok && data.success && data.token) {
                  // Fail closed if browser storage is blocked or cannot retain the token.
                  if (!storeAdminSession(data.token)) {
                    setAuthError('Browser session storage is unavailable. Enable site storage and try again.');
                    return;
                  }
                  setAdminSheetData(null);
                  setIsAdminAuthenticated(true);
                  setAuthError('');
                  return;
                }
                setAuthError(data?.error || 'Admin login rejected. Access remains locked.');
              } catch (netErr: any) {
                setAuthError(netErr?.message || 'Secure admin server unavailable. Access remains locked.');
              }
            }}
            className="space-y-4"
          >
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Authorized Admin Email</label>
              <input type="email" value={adminEmailInput} onChange={e => setAdminEmailInput(e.target.value)} placeholder="admin@example.com" autoComplete="username" className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 mb-3" required />
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Admin Security Passcode
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={passcodeInput}
                  onChange={e => setPasscodeInput(e.target.value)}
                  placeholder="Enter secure admin passcode"
                  className="w-full bg-slate-900 border border-white/15 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  autoFocus
                />
              </div>
              {authError && (
                <p className="text-[11px] text-rose-400 mt-1.5 font-medium">{authError}</p>
              )}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={onExit}
                className="flex-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-semibold text-xs cursor-pointer"
              >
                Return to Site
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md shadow-amber-500/20"
              >
                Unlock Console
              </button>
            </div>

            <p className="text-[10px] text-center text-slate-500">
              Authorized personnel only • Never share your passcode
            </p>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#07080b] text-slate-100 flex flex-col no-print">
      {/* Top Admin Header */}
      <div className="bg-[#0b0d13] border-b border-white/10 px-4 sm:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-bold">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-white tracking-tight flex items-center gap-2">
              <span>Mumbai Darshan Bus</span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                ADMIN CONSOLE
              </span>
            </h1>
            <p className="text-[11px] text-slate-400">
              Operations, Dynamic Pricing, 44 Tour Points & Google Sheets Sync Engine
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => StorageService.exportBookingsToCSV()}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-300 border border-white/10 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Bookings CSV</span>
          </button>

          <button
            onClick={() => { clearAdminSession(); setAdminSheetData(null); setIsAdminAuthenticated(false); onExit(); }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-semibold cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
            <span>Exit Admin</span>
          </button>
        </div>
      </div>

      {/* Toast Alert */}
      {toastMessage && (
        <div className="bg-emerald-500 text-slate-950 px-4 py-2 text-xs font-bold text-center flex items-center justify-center gap-2 shadow-md">
          <CheckCircle2 className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {adminDataLoading && <div className="px-4 py-2 text-center text-xs text-amber-300 bg-amber-500/10">Loading protected Google Sheets records…</div>}
      {/* Main Admin Body: Sidebar + Content */}
      <div className="flex-1 flex flex-col md:flex-row max-w-7xl w-full mx-auto p-4 sm:p-6 gap-6">
        {/* Navigation Sidebar */}
        <aside className="w-full md:w-64 shrink-0 space-y-1">
          <nav className="space-y-1 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'dashboard'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 shrink-0" />
              <span>A. Dashboard Overview</span>
            </button>

            <button
              onClick={() => setActiveTab('bookings')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'bookings'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <CalendarCheck className="w-4 h-4 shrink-0" />
                <span>B. Bookings</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/30 font-mono">
                {bookings.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('reports')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'reports'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <BarChart3 className="w-4 h-4 shrink-0" />
              <span>C. Reports & Collections</span>
            </button>

            <button
              onClick={() => setActiveTab('routes')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'routes'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <MapPin className="w-4 h-4 shrink-0" />
              <span>D. Route Setup (4 Lines)</span>
            </button>

            <button
              onClick={() => setActiveTab('pickups')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'pickups'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Compass className="w-4 h-4 shrink-0" />
                <span>E. Pickup Points</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/30 font-mono">
                {pickupPoints.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('pricing')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'pricing'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <DollarSign className="w-4 h-4 shrink-0" />
              <span>F. Packages & Pricing</span>
            </button>

            <button
              onClick={() => setActiveTab('offers')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'offers'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>G. Independent Offers</span>
            </button>

            <button
              onClick={() => setActiveTab('extra_charges')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'extra_charges'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Tag className="w-4 h-4 shrink-0" />
              <span>H. Compulsory & Extra Fees</span>
            </button>

            <button
              onClick={() => setActiveTab('tour_points')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'tour_points'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <MapPin className="w-4 h-4 shrink-0" />
                <span>I. All 44 Tour Points</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/30 font-mono">
                44
              </span>
            </button>

            <button
              onClick={() => setActiveTab('gallery')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'gallery'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <ImageIcon className="w-4 h-4 shrink-0" />
              <span>J. Dedicated Photo Gallery</span>
            </button>

            <button
              onClick={() => setActiveTab('car_rentals')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'car_rentals'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Car className="w-4 h-4 shrink-0" />
                <span>K. Private Fleet & Quotations</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/30 font-mono">
                {carRentals.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('group_enquiries')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'group_enquiries'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Users className="w-4 h-4 shrink-0" />
                <span>L. Group Enquiries</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/30 font-mono">
                {groupEnquiries.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('google_sheets')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all text-left cursor-pointer ${
                activeTab === 'google_sheets'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                  : 'text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10'
              }`}
            >
              <FileSpreadsheet className="w-4 h-4 shrink-0" />
              <span>Google Sheets & Backend</span>
            </button>
          </nav>

          <div className="pt-4 border-t border-white/10">
            <button
              onClick={() => {
                if (window.confirm('Reset all demo data back to default system values?')) {
                  StorageService.resetToDefaults();
                  forceRefresh();
                  showToast('Database reset to defaults.');
                }
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-[11px] text-slate-500 hover:text-rose-400 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Data to Default</span>
            </button>
          </div>
        </aside>

        {/* Content Area */}
        <main className="flex-1 bg-[#0e1017] border border-white/10 rounded-2xl p-4 sm:p-7 overflow-x-hidden">
          
          {/* TAB A: DASHBOARD */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">Executive Dashboard</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Real-time operational indicators, passenger volumes, verified revenues, and pending balances.
                </p>
              </div>

              {/* Top 4 KPI Metrics */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
                <div className="shiny-dark-card p-4 rounded-xl border border-white/10">
                  <span className="text-slate-400 text-xs block">Total Bookings</span>
                  <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">
                    {bookings.length}
                  </div>
                  <span className="text-[11px] text-amber-400 block mt-0.5">
                    {upcomingBookings.length} Upcoming Tours
                  </span>
                </div>

                <div className="shiny-dark-card p-4 rounded-xl border border-white/10">
                  <span className="text-slate-400 text-xs block">Total Passengers</span>
                  <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">
                    {totalPassengers}
                  </div>
                  <span className="text-[11px] text-emerald-400 block mt-0.5">
                    {todayBookings.reduce((acc, b) => acc + b.passengerCount, 0)} Traveling Today
                  </span>
                </div>

                <div className="shiny-dark-card p-4 rounded-xl border border-white/10">
                  <span className="text-slate-400 text-xs block">Verified Revenue</span>
                  <div className="text-2xl font-black text-emerald-400 font-mono tabular-nums mt-1">
                    ₹{verifiedCollectedRevenue}
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    Online advance & full payments
                  </span>
                </div>

                <div className="shiny-dark-card p-4 rounded-xl border border-white/10">
                  <span className="text-slate-400 text-xs block">Outstanding Balance</span>
                  <div className="text-2xl font-black text-amber-400 font-mono tabular-nums mt-1">
                    ₹{totalOutstandingBalance}
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    Payable on the bus by cash/UPI
                  </span>
                </div>
              </div>

              {adminSheetData?.paymentReconciliation && (
                <AdminPaymentReconciliationPanel report={adminSheetData.paymentReconciliation} onRefresh={forceRefresh} />
              )}

              {/* Fleet & Passenger Distribution */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* AC vs Non-AC */}
                <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-2 text-xs">
                  <h3 className="font-bold text-white uppercase tracking-wider text-[11px] text-slate-300">
                    Bus Category Split
                  </h3>
                  <div className="space-y-1.5 pt-1">
                    <div className="flex justify-between">
                      <span className="text-cyan-300">Luxury AC Buses:</span>
                      <strong className="font-mono text-white">{acCount} Pax</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">Standard Non-AC:</span>
                      <strong className="font-mono text-white">{nonAcCount} Pax</strong>
                    </div>
                  </div>
                </div>

                {/* Lunch & Food Requirements */}
                <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-2 text-xs">
                  <h3 className="font-bold text-white uppercase tracking-wider text-[11px] text-slate-300">
                    Catering & Meals ({lunchCount} Total)
                  </h3>
                  <div className="space-y-1 pt-1 text-slate-300">
                    <div className="flex justify-between">
                      <span>Veg Biryani + Raita:</span>
                      <strong className="font-mono text-amber-400">{vegBiryaniTotal}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Butter Paneer + Chapati:</span>
                      <strong className="font-mono text-amber-400">{butterPaneerTotal}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Veg Thali Meals:</span>
                      <strong className="font-mono text-amber-400">{vegThaliTotal}</strong>
                    </div>
                  </div>
                </div>

                {/* Route Bookings */}
                <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-2 text-xs">
                  <h3 className="font-bold text-white uppercase tracking-wider text-[11px] text-slate-300">
                    Line Bookings
                  </h3>
                  <div className="space-y-1 pt-1 text-slate-300">
                    {routes.map(r => {
                      const count = bookings.filter(b => b.routeId === r.id && b.bookingStatus !== 'Cancelled').length;
                      return (
                        <div key={r.id} className="flex justify-between">
                          <span>{r.name}:</span>
                          <strong className="font-mono text-white">{count}</strong>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Recent Bookings preview */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white">Recent Customer Bookings</h3>
                  <button
                    onClick={() => setActiveTab('bookings')}
                    className="text-xs text-amber-400 hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <span>View All ({bookings.length})</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="shiny-dark-card rounded-xl border border-white/10 overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900/80 text-slate-400 border-b border-white/10 text-[11px]">
                      <tr>
                        <th className="py-2.5 px-3">Booking ID</th>
                        <th className="py-2.5 px-3">Travel Date</th>
                        <th className="py-2.5 px-3">Customer</th>
                        <th className="py-2.5 px-3">Route & Pickup</th>
                        <th className="py-2.5 px-3">Package</th>
                        <th className="py-2.5 px-3">Paid / Total</th>
                        <th className="py-2.5 px-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {bookings.slice(0, 5).map(b => (
                        <tr key={b.id} className="hover:bg-white/5">
                          <td className="py-2.5 px-3 font-mono font-bold text-amber-400">
                            {b.id}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">{b.travelDate}</td>
                          <td className="py-2.5 px-3 font-medium text-white">
                            {b.customerName}
                            <span className="block text-[10px] text-slate-400">{b.customerMobile}</span>
                          </td>
                          <td className="py-2.5 px-3">
                            <span className="font-semibold text-white">{b.routeName}</span>
                            <span className="block text-[10px] text-slate-400">{b.pickupPointName} ({b.pickupTime})</span>
                          </td>
                          <td className="py-2.5 px-3">
                            {b.packageTitle} ({b.passengerCount}p)
                          </td>
                          <td className="py-2.5 px-3 font-mono tabular-nums whitespace-nowrap">
                            <span className="text-emerald-400 font-bold">₹{b.amountPaid}</span> / ₹{b.grandTotal}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              b.bookingStatus === 'Confirmed'
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : 'bg-amber-500/20 text-amber-300'
                            }`}>
                              {b.bookingStatus}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB B: BOOKINGS MANAGEMENT */}
          {activeTab === 'bookings' && (
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-bold text-white tracking-tight">Booking Management</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Search by Booking ID, customer phone, filter by line, and update booking status.
                  </p>
                </div>

                <button
                  onClick={() => StorageService.exportBookingsToCSV()}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-semibold cursor-pointer shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Bookings CSV</span>
                </button>
              </div>

              {/* Filters & Search */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-[#12141c] p-3 rounded-xl border border-white/10">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search by ID, name, mobile..."
                    value={bookingSearch}
                    onChange={e => setBookingSearch(e.target.value)}
                    className="w-full bg-slate-900 border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <select
                    value={bookingStatusFilter}
                    onChange={e => setBookingStatusFilter(e.target.value)}
                    className="w-full bg-slate-900 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="ALL">All Booking Statuses</option>
                    <option value="Confirmed">Confirmed</option>
                    <option value="Pending Verification">Pending Verification</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </div>

                <div>
                  <select
                    value={bookingRouteFilter}
                    onChange={e => setBookingRouteFilter(e.target.value)}
                    className="w-full bg-slate-900 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="ALL">All Routes</option>
                    {routes.map(r => (
                      <option key={r.id} value={r.id}>{r.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Bookings Table */}
              <div className="shiny-dark-card rounded-xl border border-white/10 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900/80 text-slate-400 border-b border-white/10 text-[11px]">
                      <tr>
                        <th className="py-3 px-3">Booking ID</th>
                        <th className="py-3 px-3">Date</th>
                        <th className="py-3 px-3">Customer</th>
                        <th className="py-3 px-3">Route & Pickup Stop</th>
                        <th className="py-3 px-3">Package / Meals</th>
                        <th className="py-3 px-3">Paid / Bal</th>
                        <th className="py-3 px-3">Status</th>
                        <th className="py-3 px-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {filteredBookings.map(b => (
                        <tr key={b.id} className="hover:bg-white/5 transition-colors">
                          <td className="py-3 px-3 font-mono font-bold text-amber-400 whitespace-nowrap">
                            {b.id}
                          </td>
                          <td className="py-3 px-3 whitespace-nowrap text-white font-medium">
                            {b.travelDate}
                          </td>
                          <td className="py-3 px-3">
                            <span className="font-semibold text-white block">{b.customerName}</span>
                            <span className="text-[10px] text-slate-400 font-mono">{b.customerMobile}</span>
                          </td>
                          <td className="py-3 px-3 max-w-[200px] truncate">
                            <span className="text-white font-medium block truncate">{b.pickupPointName}</span>
                            <span className="text-[10px] text-amber-400 font-mono">{b.pickupTime} ({b.routeName})</span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="text-slate-200 block">{b.packageTitle} ({b.passengerCount}p)</span>
                            {b.foodSelections && (
                              <span className="text-[10px] text-emerald-400 block">
                                Biryani: {b.foodSelections.vegBiryani}, Paneer: {b.foodSelections.butterPaneer}, Thali: {b.foodSelections.vegThali}
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-3 font-mono tabular-nums whitespace-nowrap">
                            <span className="text-emerald-400 font-bold">₹{b.amountPaid}</span>
                            {b.balancePayable > 0 && (
                              <span className="text-amber-400 block text-[10px]">Due: ₹{b.balancePayable}</span>
                            )}
                          </td>
                          <td className="py-3 px-3 whitespace-nowrap">
                            <select
                              value={b.bookingStatus}
                              onChange={e => handleUpdateBookingStatus(b.id, e.target.value)}
                              className="bg-slate-900 border border-white/10 rounded px-2 py-1 text-[11px] text-white focus:outline-none"
                            >
                              <option value="Confirmed">Confirmed</option>
                              <option value="Pending Verification">Pending</option>
                              <option value="Completed">Completed</option>
                              {b.bookingStatus === 'Cancelled' && <option value="Cancelled">Cancelled</option>}
                            </select>
                          </td>
                          <td className="py-3 px-3 text-right whitespace-nowrap">
                            <button
                              onClick={() => setSelectedBookingForModal(b)}
                              className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-white font-semibold text-xs cursor-pointer inline-flex items-center gap-1"
                            >
                              <Eye className="w-3 h-3" />
                              <span>Details</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB: REPORTS & OFFLINE COLLECTIONS */}
          {activeTab === 'reports' && (
            <AdminReportsTab
              bookings={bookings}
              routes={routes}
              rentals={carRentals}
              showToast={showToast}
            />
          )}

          {/* TAB D: ROUTES CONFIGURATION */}
          {activeTab === 'routes' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">Four Tour Routes Management</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Configure line names, descriptions, display order, and active switches.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {routes.map(r => (
                  <div key={r.id} className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-base text-white">{r.name}</span>
                      <label className="flex items-center gap-2 cursor-pointer text-xs">
                        <span className={r.active ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
                          {r.active ? 'Active' : 'Disabled'}
                        </span>
                        <input
                          type="checkbox"
                          checked={r.active}
                          onChange={e => {
                            StorageService.updateRoute(r.id, { active: e.target.checked });
                            forceRefresh();
                            showToast(`Updated ${r.name} status.`);
                          }}
                          className="h-4 w-4 rounded text-amber-500"
                        />
                      </label>
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Route Corridor Description</label>
                      <input
                        type="text"
                        value={r.description}
                        onChange={e => {
                          StorageService.updateRoute(r.id, { description: e.target.value });
                          forceRefresh();
                        }}
                        className="w-full bg-slate-900 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                      <span>Stops on this Line: <strong>{pickupPoints.filter(p => p.routeId === r.id).length}</strong></span>
                      <span>Display Order: {r.displayOrder}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB D: PICKUP POINTS MANAGEMENT */}
          {activeTab === 'pickups' && (
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-bold text-white tracking-tight">Pickup Points & Timings Management</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Add, edit timings, reorder, or update boarding landmarks. Updates reflect immediately on customer pages.
                  </p>
                </div>

                <button
                  onClick={() => setIsAddingPickup(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs cursor-pointer hover:bg-amber-400 shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add New Pickup Stop</span>
                </button>
              </div>

              {/* Add Modal/Form */}
              {isAddingPickup && (
                <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-3">
                  <h3 className="font-bold text-sm text-amber-300">Create New Boarding Stop</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-300 mb-1">Assigned Route</label>
                      <select
                        value={newPickupRoute}
                        onChange={e => setNewPickupRoute(e.target.value as RouteId)}
                        className="w-full bg-slate-900 border border-white/10 rounded-lg p-2 text-white"
                      >
                        {routes.map(r => (
                          <option key={r.id} value={r.id}>{r.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-1">Pickup Stop Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Borivali West"
                        value={newPickupName}
                        onChange={e => setNewPickupName(e.target.value)}
                        className="w-full bg-slate-900 border border-white/10 rounded-lg p-2 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-1">Departure Time</label>
                      <input
                        type="text"
                        placeholder="e.g. 7:15 AM"
                        value={newPickupTime}
                        onChange={e => setNewPickupTime(e.target.value)}
                        className="w-full bg-slate-900 border border-white/10 rounded-lg p-2 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-1">Boarding Landmark</label>
                      <input
                        type="text"
                        placeholder="e.g. Gokul Hotel"
                        value={newPickupLandmark}
                        onChange={e => setNewPickupLandmark(e.target.value)}
                        className="w-full bg-slate-900 border border-white/10 rounded-lg p-2 text-white"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => setIsAddingPickup(false)}
                      className="px-3 py-1.5 rounded-lg bg-white/10 text-xs text-slate-300"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        if (!newPickupName.trim()) return;
                        StorageService.addPickupPoint({
                          routeId: newPickupRoute,
                          name: newPickupName.trim(),
                          time: newPickupTime.trim(),
                          landmark: newPickupLandmark.trim(),
                          reportingTime: '15 min prior',
                          sortOrder: pickupPoints.length + 1,
                          active: true,
                          googleMapsUrl: newPickupMaps.trim() || undefined
                        });
                        setIsAddingPickup(false);
                        setNewPickupName('');
                        forceRefresh();
                        showToast('New pickup point added successfully!');
                      }}
                      className="px-4 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs"
                    >
                      Save Point
                    </button>
                  </div>
                </div>
              )}

              {/* Table of pickup points */}
              <div className="shiny-dark-card rounded-xl border border-white/10 overflow-hidden">
                <div className="overflow-x-auto max-h-[500px]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900/90 text-slate-400 sticky top-0 border-b border-white/10 text-[11px]">
                      <tr>
                        <th className="py-2.5 px-3">Route</th>
                        <th className="py-2.5 px-3">Point Name</th>
                        <th className="py-2.5 px-3">Pickup Time</th>
                        <th className="py-2.5 px-3">Landmark</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {pickupPoints.map(pt => (
                        <tr key={pt.id} className="hover:bg-white/5">
                          <td className="py-2.5 px-3 text-amber-400 font-semibold whitespace-nowrap">
                            {routes.find(r => r.id === pt.routeId)?.name || pt.routeId}
                          </td>
                          <td className="py-2.5 px-3 font-bold text-white whitespace-nowrap">
                            {pt.name}
                          </td>
                          <td className="py-2.5 px-3 font-mono tabular-nums text-white whitespace-nowrap">
                            {pt.time}
                          </td>
                          <td className="py-2.5 px-3 text-slate-300">
                            {pt.landmark}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className={pt.active ? 'text-emerald-400' : 'text-slate-500'}>
                              {pt.active ? 'Active' : 'Disabled'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right whitespace-nowrap space-x-2">
                            <button
                              onClick={() => {
                                const newTime = window.prompt(`Edit pickup time for ${pt.name}:`, pt.time);
                                if (newTime) {
                                  StorageService.updatePickupPoint(pt.id, { time: newTime });
                                  forceRefresh();
                                  showToast(`Updated ${pt.name} time to ${newTime}`);
                                }
                              }}
                              className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-slate-300 text-[11px]"
                            >
                              Edit Time
                            </button>
                            <button
                              onClick={() => {
                                StorageService.updatePickupPoint(pt.id, { active: !pt.active });
                                forceRefresh();
                              }}
                              className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-slate-400 text-[11px]"
                            >
                              {pt.active ? 'Disable' : 'Enable'}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB E: PACKAGE AND PRICING MANAGEMENT */}
          {activeTab === 'pricing' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">Bus Packages & Route-Wise Pricing</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Update rates independently per line. Existing bookings retain their original stored prices; changes take effect for new bookings immediately.
                </p>
              </div>

              <div className="space-y-4">
                {packages.map(pkg => (
                  <div key={pkg.packageId} className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
                      <div>
                        <h3 className="font-bold text-base text-white">{pkg.title}</h3>
                        <p className="text-xs text-slate-400">{pkg.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs px-2 py-0.5 rounded font-bold ${pkg.isAC ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-700 text-slate-300'}`}>
                          {pkg.isAC ? 'AC Bus' : 'Non-AC'}
                        </span>
                        {pkg.hasLunch && (
                          <span className="text-xs px-2 py-0.5 rounded font-bold bg-emerald-500/20 text-emerald-300">
                            + Lunch
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {(['western', 'central', 'harbour', 'kalyan_dombivli'] as RouteId[]).map(rId => {
                        const rName = routes.find(r => r.id === rId)?.name || rId;
                        const currentRate = pkg.basePrices[rId] ?? 0;

                        return (
                          <div key={rId} className="p-3 rounded-lg bg-slate-900 border border-white/5 space-y-1.5">
                            <span className="text-[11px] font-semibold text-slate-400 block">{rName}</span>
                            <div className="flex items-center justify-between">
                              <span className="text-base font-extrabold text-amber-400 font-mono">
                                ₹{currentRate}
                              </span>
                              <button
                                onClick={() => {
                                  const val = window.prompt(`Enter new price for ${pkg.title} on ${rName} (Current: ₹${currentRate}):`, String(currentRate));
                                  if (val && !isNaN(Number(val))) {
                                    StorageService.updatePackagePrice(pkg.packageId, rId, Number(val), 'Admin Panel');
                                    forceRefresh();
                                    showToast(`Price updated to ₹${val} for ${rName}`);
                                  }
                                }}
                                className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/20 text-[10px] text-white"
                              >
                                Edit
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>

              {/* Price Change Audit Log */}
              {priceHistory.length > 0 && (
                <div className="space-y-3 pt-4 border-t border-white/10">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <History className="w-4 h-4 text-amber-400" />
                    <span>Price Change History Audit</span>
                  </h3>
                  <div className="space-y-1.5 text-xs">
                    {priceHistory.slice(0, 5).map(record => (
                      <div key={record.id} className="p-2.5 rounded-lg bg-white/5 flex items-center justify-between text-slate-300">
                        <div>
                          <strong className="text-white">{record.packageId}</strong> on {record.routeId}:
                          changed from <span className="line-through text-slate-500">₹{record.oldPrice}</span> to <strong className="text-amber-400">₹{record.newPrice}</strong>
                        </div>
                        <span className="text-[10px] text-slate-500">
                          {new Date(record.timestamp).toLocaleString()} by {record.updatedBy}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB F: INDEPENDENT ROUTE OFFERS */}
          {activeTab === 'offers' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">Four Independent Route Offers</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Each line has its own independent offer control. An offer on one route never affects another route.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(['western', 'central', 'harbour', 'kalyan_dombivli'] as RouteId[]).map(rId => {
                  const rName = routes.find(r => r.id === rId)?.name || rId;
                  const offer = offers.find(o => o.routeId === rId) || {
                    routeId: rId,
                    enabled: false,
                    discountType: 'flat',
                    discountValue: 0,
                    label: `${rName} Special`
                  };

                  return (
                    <div key={rId} className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-3">
                      <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                        <span className="font-bold text-white text-base">{rName} Offer</span>
                        <label className="flex items-center gap-2 cursor-pointer text-xs">
                          <span className={offer.enabled ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
                            {offer.enabled ? 'ON' : 'OFF'}
                          </span>
                          <input
                            type="checkbox"
                            checked={offer.enabled}
                            onChange={e => {
                              StorageService.updateRouteOffer(rId, { enabled: e.target.checked });
                              forceRefresh();
                              showToast(`${rName} offer switched ${e.target.checked ? 'ON' : 'OFF'}`);
                            }}
                            className="h-4 w-4 rounded text-amber-500"
                          />
                        </label>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div>
                          <label className="block text-slate-400 mb-1">Discount Type</label>
                          <select
                            value={offer.discountType}
                            onChange={e => {
                              StorageService.updateRouteOffer(rId, { discountType: e.target.value as any });
                              forceRefresh();
                            }}
                            className="w-full bg-slate-900 border border-white/10 rounded-lg p-2 text-white"
                          >
                            <option value="flat">Flat ₹ Discount</option>
                            <option value="percentage">Percentage (%)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-slate-400 mb-1">Discount Value</label>
                          <input
                            type="number"
                            min={0}
                            value={offer.discountValue}
                            onChange={e => {
                              StorageService.updateRouteOffer(rId, { discountValue: Number(e.target.value) });
                              forceRefresh();
                            }}
                            className="w-full bg-slate-900 border border-white/10 rounded-lg p-2 text-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-slate-400 text-xs mb-1">Customer Display Label</label>
                        <input
                          type="text"
                          value={offer.label}
                          onChange={e => {
                            StorageService.updateRouteOffer(rId, { label: e.target.value });
                            forceRefresh();
                          }}
                          className="w-full bg-slate-900 border border-white/10 rounded-lg p-2 text-xs text-white"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB G: EXTRA CHARGES MANAGEMENT */}
          {activeTab === 'extra_charges' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">Compulsory & Optional Extra Charges</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Manage compulsory Guide / Sea Link charges and all optional attraction ticket rates shown on the customer website.
                </p>
              </div>

              <div className="space-y-3">
                {extraCharges.map(charge => (
                  <div key={charge.id} className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-2.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-2">
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                          charge.type === 'compulsory' ? 'bg-rose-500/20 text-rose-300' : 'bg-amber-500/20 text-amber-300'
                        }`}>
                          {charge.type === 'compulsory' ? 'Compulsory' : 'Optional Excursion'}
                        </span>
                        <h3 className="font-bold text-white text-sm">{charge.name}</h3>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          <span className="text-xs text-slate-400">Rate:</span>
                          <span className="text-base font-extrabold text-amber-400 font-mono">
                            {charge.amount > 0 ? `₹${charge.amount}` : 'TBD'}
                          </span>
                        </div>
                        <button
                          onClick={() => {
                            const newAmt = window.prompt(`Enter new rate for ${charge.name}:`, String(charge.amount));
                            if (newAmt && !isNaN(Number(newAmt))) {
                              StorageService.updateExtraCharge(charge.id, {
                                amount: Number(newAmt),
                                exactPriceConfirmed: Number(newAmt) > 0
                              });
                              forceRefresh();
                              showToast(`Updated ${charge.name} rate to ₹${newAmt}`);
                            }
                          }}
                          className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-xs text-white"
                        >
                          Change Rate
                        </button>
                      </div>
                    </div>

                    <p className="text-xs text-slate-400">{charge.description}</p>
                    {charge.collectorNotice && (
                      <p className="text-[11px] text-amber-300/80 italic">{charge.collectorNotice}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB H: ALL 44 TOUR POINTS */}
          {activeTab === 'tour_points' && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">All 44 Mumbai Tour Landmarks</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Update BUS HALT status, passenger get-down permission, entry fees, and verified Google Maps URLs.
                </p>
              </div>

              <div className="shiny-dark-card rounded-xl border border-white/10 overflow-hidden">
                <div className="overflow-x-auto max-h-[550px]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900/90 text-slate-400 sticky top-0 border-b border-white/10 text-[11px]">
                      <tr>
                        <th className="py-2.5 px-3 w-10">#</th>
                        <th className="py-2.5 px-3">Landmark Name</th>
                        <th className="py-2.5 px-3">Halt Status</th>
                        <th className="py-2.5 px-3">Get Down</th>
                        <th className="py-2.5 px-3">Fee Status</th>
                        <th className="py-2.5 px-3">Google Maps URL</th>
                        <th className="py-2.5 px-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {tourPoints.map(pt => (
                        <tr key={pt.id} className="hover:bg-white/5">
                          <td className="py-2.5 px-3 font-mono text-slate-400">#{pt.id}</td>
                          <td className="py-2.5 px-3 font-bold text-white">{pt.name}</td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              pt.haltStatus === 'BUS_HALT' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-700 text-slate-300'
                            }`}>
                              {pt.haltStatus}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            {pt.canGetDown ? <span className="text-emerald-400 font-semibold">Yes</span> : <span className="text-slate-500">No</span>}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            {pt.feeStatus} {pt.entryFee ? `(₹${pt.entryFee})` : ''}
                          </td>
                          <td className="py-2.5 px-3 max-w-[150px] truncate">
                            {pt.googleMapsUrl ? (
                              <a href={pt.googleMapsUrl} target="_blank" rel="noopener noreferrer" className="text-amber-400 hover:underline">
                                Map Link
                              </a>
                            ) : (
                              <span className="text-slate-500 italic">None</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-right whitespace-nowrap">
                            <button
                              onClick={() => {
                                const newHalt = pt.haltStatus === 'BUS_HALT' ? 'NO_HALT' : 'BUS_HALT';
                                StorageService.updateTourPoint(pt.id, {
                                  haltStatus: newHalt,
                                  canGetDown: newHalt === 'BUS_HALT'
                                });
                                forceRefresh();
                                showToast(`Toggled ${pt.name} to ${newHalt}`);
                              }}
                              className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-[10px] text-white"
                            >
                              Toggle Halt
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB: PHOTO GALLERY MANAGEMENT */}
          {activeTab === 'gallery' && (
            <AdminGalleryTab onRefresh={forceRefresh} showToast={showToast} />
          )}

          {/* TAB: CAR & BUS RENTALS FLEET */}
          {activeTab === 'car_rentals' && (
            <div className="space-y-5">
              <AdminRentalPricingTab pricing={adminSheetData?.rentalPricing || null} onSaved={forceRefresh} showToast={showToast} />
              <AdminRentalsTab
                enquiries={carRentals}
                onRefresh={forceRefresh}
                showToast={showToast}
              />
            </div>
          )}

          {/* TAB: GROUP ENQUIRIES */}
          {activeTab === 'group_enquiries' && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">Large Group Booking Enquiries</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Corporate, school, and tour operator charters (10 to 50+ passengers).
                </p>
              </div>

              <div className="space-y-3">
                {groupEnquiries.map(grp => (
                  <div key={grp.id} className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-2.5 text-xs">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-amber-400 font-bold">{grp.id}</span>
                        <span className="text-slate-400">·</span>
                        <span className="font-bold text-white">{grp.organizationName || grp.contactPerson}</span>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold text-[10px]">
                        {grp.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-slate-300">
                      <div>Contact: <strong className="text-white">{grp.contactPerson}</strong></div>
                      <div>Mobile: <strong className="text-white">{grp.mobile}</strong></div>
                      <div>Date: <strong className="text-white">{grp.tentativeDate}</strong></div>
                      <div>Group Size: <strong className="text-white">{grp.approximatePassengers} Pax</strong></div>
                    </div>

                    <p className="text-slate-300">
                      Bus: {grp.preferredBusType} | Lunch Required: {grp.lunchRequired ? 'Yes' : 'No'}
                    </p>
                    {grp.customRequests && (
                      <p className="text-amber-300 italic">Requirements: {grp.customRequests}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: GOOGLE SHEETS & APPS SCRIPT BACKEND */}
          {activeTab === 'google_sheets' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
                  <span>Google Sheets Database & Google Apps Script Engine</span>
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Customer booking and rental requests use the Google Apps Script URL configured securely on the hosting server.
                </p>
              </div>

              <div className="bg-[#12141c] p-5 rounded-xl border border-white/10 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-white mb-1.5">Outstation Company Garage Address</label>
                  <input type="text" value={rentalGarageAddressInput} onChange={e => setRentalGarageAddressInput(e.target.value)} placeholder="Exact Bhayandar garage address" className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white" />
                  <span className="text-[11px] text-amber-200/80 mt-1 block">This exact address is used as the starting and ending point for automatic garage-to-garage route KM. Save it before calculating quotations.</span>
                </div>
                <div className="rounded-lg border border-sky-400/20 bg-sky-500/5 p-3">
                  <p className="text-xs font-semibold text-sky-200">Secure server-side connection</p>
                  <p className="text-[11px] text-slate-300 mt-1">The Google Apps Script Web App URL and Admin secrets must be configured in the hosting provider's private environment. They are not stored in browser settings or exposed to customers. See <strong>google-apps-script/DEPLOYMENT_GUIDE.md</strong>.</p>
                </div>

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    onClick={handleSaveGarageSettings}
                    className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer"
                  >
                    Save Garage Settings
                  </button>

                  <button
                    onClick={handleTestWebhook}
                    className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Test Server Connection</span>
                  </button>

                  <button
                    onClick={handleTestEmailConnection}
                    className="px-4 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-200 font-semibold text-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Test Business Email</span>
                  </button>

                  <button
                    onClick={() => StorageService.exportBookingsToCSV()}
                    className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-semibold text-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download CSV for Manual Sheet Import</span>
                  </button>
                </div>

                {gsTestStatus && (
                  <div className={`p-3 rounded-lg border text-xs ${gsTestStatus.toLowerCase().includes('failed') ? 'bg-rose-500/10 border-rose-500/30 text-rose-300' : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'}`}>
                    {gsTestStatus}
                  </div>
                )}
              </div>

              {/* Protected operational-sheet overview: live data from the authenticated Apps Script API */}
              <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-white">Live Google Sheets Operational Data</h3>
                    <p className="text-[11px] text-slate-400">Read-only view of approved schema tabs. AdminUsers and Settings values are intentionally not exposed here.</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <input aria-label="Daily report date" type="date" value={dailyReportDate} onChange={e => setDailyReportDate(e.target.value)} className="rounded-lg border border-white/10 bg-slate-900 px-2 py-1.5 text-[11px] text-white" />
                    <button onClick={handleGenerateDailyReport} disabled={dailyReportBusy || !dailyReportDate} className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 text-[11px] font-bold">{dailyReportBusy ? 'Generating…' : 'Generate Daily Report'}</button>
                    <button onClick={forceRefresh} className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white text-[11px] font-semibold">Refresh Data</button>
                  </div>
                </div>
                {!adminSheetData ? (
                  <p className="text-xs text-amber-300">Protected Sheets data is not loaded. Confirm the Admin session and backend connection.</p>
                ) : (
                  <>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                      {([
                        ['Pickup Points', 'pickupPoints'], ['Package Options', 'packageOptions'], ['Booking Dates', 'bookingDates'],
                        ['Rental Vehicles', 'rentalVehicles'], ['Email Log', 'emailLog'], ['Notifications', 'notifications'],
                        ['Activity Log', 'activityLog'], ['Daily Reports', 'dailyReports'], ['Website Content', 'websiteContent'],
                        ['Attraction Points', 'attractionPoints'], ['Attraction Tickets', 'attractionTickets']
                      ] as [string, string][]).map(([label, key]) => (
                        <div key={key} className="rounded-lg bg-slate-900 border border-white/5 p-3">
                          <div className="text-[10px] text-slate-400">{label}</div>
                          <div className="text-lg font-extrabold text-emerald-300">{Array.isArray((adminSheetData as any)[key]) ? (adminSheetData as any)[key].length : '—'}</div>
                          <div className="text-[9px] text-slate-500">records</div>
                        </div>
                      ))}
                    </div>
                    <div className="space-y-2">
                      {([
                        ['Pickup Points', 'pickupPoints'], ['Package Options & Route Offers', 'packageOptions'], ['Booking Date Controls', 'bookingDates'],
                        ['Rental Vehicles', 'rentalVehicles'], ['Email Log', 'emailLog'], ['Booking Notifications', 'notifications'],
                        ['Activity Log', 'activityLog'], ['Daily Reports', 'dailyReports'], ['Website Content', 'websiteContent'],
                        ['Attraction Points', 'attractionPoints'], ['Attraction Tickets', 'attractionTickets']
                      ] as [string, string][]).map(([label, key]) => {
                        const rows = Array.isArray((adminSheetData as any)[key]) ? (adminSheetData as any)[key] : [];
                        return (
                          <details key={key} className="rounded-lg border border-white/10 bg-slate-900/60">
                            <summary className="cursor-pointer px-3 py-2 text-xs font-semibold text-slate-200">{label} <span className="text-slate-500">({rows.length})</span></summary>
                            <div className="px-3 pb-3 overflow-x-auto">
                              {rows.length === 0 ? <p className="text-[11px] text-slate-500">No records in this sheet yet.</p> : (
                                <table className="w-full text-[10px] text-left"><tbody>
                                  {rows.slice(0, 10).map((row: any, index: number) => (
                                    <tr key={index} className="border-t border-white/5"><td className="py-1.5 pr-2 text-slate-500">{index + 1}</td><td className="py-1.5 text-slate-300"><pre className="whitespace-pre-wrap break-all font-sans">{JSON.stringify(row)}</pre></td></tr>
                                  ))}
                                </tbody></table>
                              )}
                              {rows.length > 10 && <p className="text-[10px] text-slate-500 pt-2">Showing first 10 of {rows.length} records.</p>}
                            </div>
                          </details>
                        );
                      })}
                    </div>
                  </>
                )}
              </div>

              {adminSheetData && <OperationalSheetsManager data={adminSheetData} onRefresh={forceRefresh} showToast={showToast} />}
              {adminSheetData && <AdminCancellationsPanel records={adminSheetData.cancellations || []} onRefresh={forceRefresh} showToast={showToast} />}
              {adminSheetData && <AdminNotificationPanel records={adminSheetData.notifications || []} onRefresh={forceRefresh} showToast={showToast} />}

              {/* Pre-packaged Apps Script Code Viewer */}
              <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300">Included Google Apps Script Source (`google-apps-script/Code.gs`)</span>
                  <span className="text-[10px] text-emerald-400">Ready to copy/paste</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  This project comes with a fully implemented Google Apps Script engine in the repository with automatic multi-sheet bootstrapping, auto-formatting, and booking lookup API.
                </p>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Booking Details Modal */}
      {selectedBookingForModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12141c] border border-white/20 rounded-2xl p-6 max-w-lg w-full space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <span className="text-xs uppercase font-bold text-amber-400">Booking Dossier</span>
                <h3 className="text-lg font-black text-white font-mono">{selectedBookingForModal.id}</h3>
              </div>
              <button
                onClick={() => setSelectedBookingForModal(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              <p>Customer: <strong className="text-white">{selectedBookingForModal.customerName}</strong></p>
              <p>Mobile: <strong className="text-white">{selectedBookingForModal.customerMobile}</strong></p>
              <p>Email: <span className="text-white">{selectedBookingForModal.customerEmail}</span></p>
              <p>Travel Date: <strong className="text-amber-400">{selectedBookingForModal.travelDate}</strong></p>
              <p>Route: <strong className="text-white">{selectedBookingForModal.routeName}</strong></p>
              <p>Pickup Spot: <strong className="text-white">{selectedBookingForModal.pickupPointName}</strong> at <strong>{selectedBookingForModal.pickupTime}</strong></p>
              <p>Package: <span className="text-white">{selectedBookingForModal.packageTitle} ({selectedBookingForModal.passengerCount} Persons)</span></p>

              {selectedBookingForModal.foodSelections && (
                <div className="p-2 rounded bg-white/5 space-y-0.5">
                  <span className="font-semibold text-emerald-400 block">Food Requirements:</span>
                  <div>Veg Biryani: {selectedBookingForModal.foodSelections.vegBiryani}</div>
                  <div>Butter Paneer: {selectedBookingForModal.foodSelections.butterPaneer}</div>
                  <div>Veg Thali: {selectedBookingForModal.foodSelections.vegThali}</div>
                </div>
              )}

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 space-y-1.5 text-xs">
                <div className="flex justify-between font-bold text-white">
                  <span>Online Bus Booking Fare:</span>
                  <span className="font-mono text-amber-400">₹{selectedBookingForModal.totalPackageAmount}</span>
                </div>
                <div className="flex justify-between items-center text-slate-300">
                  <span>Payment Status:</span>
                  <span className={`font-semibold ${selectedBookingForModal.paymentStatus === 'Advance Paid' || selectedBookingForModal.paymentStatus === 'Fully Paid' ? 'text-emerald-400' : 'text-amber-300'}`}>
                    {selectedBookingForModal.paymentStatus}
                  </span>
                </div>
                <div className="flex justify-between text-amber-300 font-semibold">
                  <span>Remaining Bus Balance (Payable on Bus):</span>
                  <span className="font-mono">₹{selectedBookingForModal.balancePayable}</span>
                </div>
              </div>

              {/* Guide Collections Box */}
              <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1 text-xs">
                <span className="font-bold text-amber-400 block text-[11px] uppercase tracking-wider">
                  Payable Directly to Guide Inside Bus:
                </span>
                <div className="flex justify-between text-slate-300 text-[11px]">
                  <span>Guide Charge ({selectedBookingForModal.compulsoryCharges?.guideChargeUnit || 50}/pax):</span>
                  <span className="font-mono text-white">₹{selectedBookingForModal.compulsoryCharges?.guideChargeTotal || 0}</span>
                </div>
                <div className="flex justify-between text-slate-300 text-[11px]">
                  <span>Sea Link Toll ({selectedBookingForModal.compulsoryCharges?.seaLinkTollUnit || 10}/pax):</span>
                  <span className="font-mono text-white">₹{selectedBookingForModal.compulsoryCharges?.seaLinkTollTotal || 0}</span>
                </div>
                <div className="pt-1 border-t border-white/10 flex justify-between font-bold text-amber-300 text-xs">
                  <span>Total to Guide ({(selectedBookingForModal.compulsoryCharges?.guideChargeUnit || 50) + (selectedBookingForModal.compulsoryCharges?.seaLinkTollUnit || 10)}/pax):</span>
                  <span className="font-mono">
                    ₹{(selectedBookingForModal.compulsoryCharges?.guideChargeTotal || 0) + (selectedBookingForModal.compulsoryCharges?.seaLinkTollTotal || 0)}
                  </span>
                </div>
              </div>

              {/* Email Status & Retry */}
              <div className="p-3 rounded-xl bg-slate-900 border border-white/10 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-[11px] uppercase tracking-wider">Email Notifications</span>
                  <button
                    onClick={() => handleRetryEmail(selectedBookingForModal.id)}
                    className="px-2.5 py-1 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px] cursor-pointer"
                  >
                    Retry / Dispatch Email
                  </button>
                </div>
                <div className="space-y-1 text-slate-400 text-[11px]">
                  <div className="flex justify-between">
                    <span>Customer Email Status:</span>
                    <strong className="text-white">{selectedBookingForModal.customerEmailStatus || 'Queued (Deferred until owner approval)'}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Owner Notification:</span>
                    <strong className="text-white">{selectedBookingForModal.ownerEmailStatus || 'Queued (Deferred until owner approval)'}</strong>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
              <button
                onClick={() => setSelectedBookingForModal(null)}
                className="px-4 py-2 rounded-xl bg-white/10 text-xs font-semibold text-white cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
