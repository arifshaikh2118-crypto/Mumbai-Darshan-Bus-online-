import { readAdminSessionToken } from '../../services/adminSession';
import React, { useState } from 'react';
import { RefreshCw, Send } from 'lucide-react';

type NotificationRecord = { notification_id: string; booking_id: string; recipient: string; notification_type: string; message: string; status: string; created_at: string; sent_at: string };
export const AdminNotificationPanel: React.FC<{ records: NotificationRecord[]; onRefresh: () => void; showToast: (message: string) => void }> = ({ records, onRefresh, showToast }) => {
  const [retrying, setRetrying] = useState<string | null>(null);
  const retry = async (bookingId: string) => {
    const token = readAdminSessionToken();
    if (!token) { showToast('Admin session expired. Please login again.'); return; }
    setRetrying(bookingId);
    try {
      const response = await fetch('/api/admin/bookings/retry-emails', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ bookingId }) });
      const data = await response.json();
      if (!response.ok || !data.success) throw new Error(data.error || data.result?.message || 'Email retry failed');
      showToast(data.result?.message || 'Email retry complete.'); onRefresh();
    } catch (error: any) { showToast(error.message || 'Email retry failed.'); }
    finally { setRetrying(null); }
  };
  const bookingIds = Array.from(new Set(records.filter(record => record.notification_type.indexOf('BOOKING_CONFIRMED_') === 0 && !['Sent', 'Skipped (No valid customer email provided)'].includes(record.status)).map(record => record.booking_id).filter(Boolean)));
  return <section className="mt-6 rounded-xl border border-sky-500/20 bg-sky-500/5 p-4 space-y-3">
    <div><h3 className="text-sm font-bold text-white">Booking Email Notifications</h3><p className="text-[11px] text-slate-400">Only payment-verified bookings enter this workflow. Email retry requires live email setting to be enabled.</p></div>
    {records.length === 0 ? <p className="text-xs text-slate-500">No booking notification records yet.</p> : <>
      <div className="space-y-2">{records.slice(-12).reverse().map(record => <div key={record.notification_id} className="rounded-lg border border-white/10 bg-slate-950/60 p-3 text-[11px] flex flex-wrap justify-between gap-2"><div><p className="font-bold text-amber-300">{record.booking_id} · {record.notification_type}</p><p className="text-slate-400 break-all">{record.recipient}</p></div><span className="text-slate-200">{record.status}</span></div>)}</div>
      <div className="flex flex-wrap gap-2">{bookingIds.map(id => <button key={id} disabled={retrying === id} onClick={() => retry(id)} className="inline-flex items-center gap-1 rounded-lg bg-sky-500 px-3 py-2 text-xs font-bold text-slate-950 disabled:opacity-50"><Send className="h-3 w-3" />{retrying === id ? 'Retrying…' : `Retry ${id}`}</button>)}</div>
      <button onClick={onRefresh} className="inline-flex items-center gap-1 text-[11px] text-slate-300"><RefreshCw className="h-3 w-3" />Refresh records</button>
    </>}
  </section>;
};
