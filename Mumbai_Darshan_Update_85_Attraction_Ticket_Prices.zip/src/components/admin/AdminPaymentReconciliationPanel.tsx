import React from 'react';
import { AlertTriangle, CheckCircle2, RefreshCw, ShieldCheck } from 'lucide-react';

type ReconciliationFinding = {
  code: string;
  bookingId: string;
  detail: string;
  expectedAmount: number | null;
  recordedAmount: number | null;
};

type ReconciliationReport = {
  generatedAt: string;
  summary: {
    totalBookings: number;
    totalLedgerRows: number;
    matchedBookings: number;
    missingLedger: number;
    orphanLedgerRows: number;
    multipleLedgerBookings: number;
    bookingLedgerMismatches: number;
    invalidLedgerRows: number;
    duplicatePaymentReferences: number;
    verifiedAmountOverBooking: number;
    cleanBookings: number;
    issueCount: number;
    verifiedOnlineAmount: number;
  };
  findings: ReconciliationFinding[];
  findingsTruncated: boolean;
};

const rupees = (value: number | null) => value === null ? '—' : `₹${Number(value).toLocaleString('en-IN')}`;

export const AdminPaymentReconciliationPanel: React.FC<{ report?: ReconciliationReport | null; onRefresh: () => void }> = ({ report, onRefresh }) => {
  if (!report) return null;
  const s = report.summary;
  const hasIssues = s.issueCount > 0;
  return (
    <section className="rounded-xl border border-white/10 bg-[#12141c] p-4 space-y-3">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-2">
          {hasIssues ? <AlertTriangle className="h-5 w-5 text-amber-400 mt-0.5" /> : <CheckCircle2 className="h-5 w-5 text-emerald-400 mt-0.5" />}
          <div>
            <h3 className="text-sm font-bold text-white">Booking & Payment Ledger Reconciliation</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Read-only check of Bookings against booking_payments. No amounts or sheet rows are changed.</p>
          </div>
        </div>
        <button onClick={onRefresh} className="inline-flex items-center gap-1 rounded-lg bg-white/10 px-2.5 py-1.5 text-[11px] text-slate-200 hover:bg-white/15"><RefreshCw className="h-3 w-3" /> Refresh data</button>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="rounded-lg bg-slate-950/70 p-3"><p className="text-[10px] text-slate-400">Bookings checked</p><p className="text-lg font-bold text-white">{s.totalBookings}</p></div>
        <div className="rounded-lg bg-slate-950/70 p-3"><p className="text-[10px] text-slate-400">Ledger rows</p><p className="text-lg font-bold text-white">{s.totalLedgerRows}</p></div>
        <div className="rounded-lg bg-slate-950/70 p-3"><p className="text-[10px] text-slate-400">Verified online amount</p><p className="text-lg font-bold text-emerald-300">{rupees(s.verifiedOnlineAmount)}</p></div>
        <div className="rounded-lg bg-slate-950/70 p-3"><p className="text-[10px] text-slate-400">Findings</p><p className={`text-lg font-bold ${hasIssues ? 'text-amber-300' : 'text-emerald-300'}`}>{s.issueCount}</p></div>
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1 text-[10px] text-slate-400">
        <span>Missing ledger: <b className="text-white">{s.missingLedger}</b></span>
        <span>Orphan rows: <b className="text-white">{s.orphanLedgerRows}</b></span>
        <span>Multiple rows: <b className="text-white">{s.multipleLedgerBookings}</b></span>
        <span>Status/amount mismatch: <b className="text-white">{s.bookingLedgerMismatches}</b></span>
        <span>Invalid rows: <b className="text-white">{s.invalidLedgerRows}</b></span>
        <span>Duplicate payment IDs/references: <b className="text-white">{s.duplicatePaymentReferences}</b></span>
        <span>Over booking fare: <b className="text-white">{s.verifiedAmountOverBooking}</b></span>
      </div>
      {hasIssues ? (
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-300"><AlertTriangle className="h-3.5 w-3.5" /> Requires manual review — no automatic correction was applied</div>
          <div className="max-h-72 overflow-auto space-y-1.5 pr-1">
            {report.findings.map((finding, index) => (
              <div key={`${finding.code}-${finding.bookingId}-${index}`} className="rounded-lg border border-amber-500/15 bg-amber-500/5 px-3 py-2">
                <div className="flex flex-wrap items-center justify-between gap-2"><span className="font-mono text-[10px] font-bold text-amber-200">{finding.bookingId}</span><span className="text-[9px] uppercase tracking-wide text-amber-300">{finding.code.replace(/_/g, ' ')}</span></div>
                <p className="text-[10px] text-slate-300 mt-1">{finding.detail}</p>
                {(finding.expectedAmount !== null || finding.recordedAmount !== null) && <p className="text-[10px] text-slate-400 mt-1">Expected: {rupees(finding.expectedAmount)} · Recorded: {rupees(finding.recordedAmount)}</p>}
              </div>
            ))}
          </div>
          {report.findingsTruncated && <p className="text-[10px] text-amber-300">Showing first 250 findings. Review the full sheet data separately.</p>}
        </div>
      ) : (
        <div className="flex items-center gap-2 rounded-lg bg-emerald-500/5 px-3 py-2 text-[11px] text-emerald-200"><ShieldCheck className="h-4 w-4" /> No reconciliation issues found in the current snapshot.</div>
      )}
      <p className="text-[9px] text-slate-500">Snapshot: {new Date(report.generatedAt).toLocaleString('en-IN')} · Findings are flags for owner review, not automatic accounting adjustments.</p>
    </section>
  );
};
