import { readAdminSessionToken } from '../../services/adminSession';
import React, { useMemo, useState } from 'react';
import { Plus, Pencil, Trash2, Save, X, RefreshCw } from 'lucide-react';

type SheetKey = 'pickupPoints' | 'packageOptions' | 'bookingDates' | 'rentalVehicles' | 'websiteContent' | 'attractionPoints' | 'attractionTickets';
type SheetConfig = { key: SheetKey; label: string; headers: string[]; required: string[]; deleteKey: string[] };
const SHEETS: SheetConfig[] = [
  { key: 'pickupPoints', label: 'Pickup Points', headers: ['Route','Pickup Point','Sort Order','Active'], required: ['Route','Pickup Point'], deleteKey: ['Route','Pickup Point'] },
  { key: 'packageOptions', label: 'Package Options & Route Offers', headers: ['Package Key','Route Group','Label','Price INR','Offer Enabled','Offer Discount INR','Price Review Status'], required: ['Package Key'], deleteKey: ['Package Key'] },
  { key: 'bookingDates', label: 'Booking Date Controls', headers: ['Travel Date','Capacity Override','Closed','Close Time'], required: ['Travel Date'], deleteKey: ['Travel Date'] },
  { key: 'rentalVehicles', label: 'Rental Vehicles', headers: ['vehicle_id','vehicle_name','vehicle_type','seating_capacity','price_per_day','status','description'], required: ['vehicle_id'], deleteKey: ['vehicle_id'] },
  { key: 'websiteContent', label: 'Website Content', headers: ['content_id','section','title','content','image_url','status','display_order','updated_at'], required: ['content_id'], deleteKey: ['content_id'] },
  { key: 'attractionPoints', label: 'Attraction Points', headers: ['Point Number','Point Name','Description','Halt Status','Entry Fee','Fee Unit','Active','Sort Order'], required: ['Point Number'], deleteKey: ['Point Number'] },
  { key: 'attractionTickets', label: 'Attraction Tickets', headers: ['Icon','Attraction Name','Price INR','Unit','Active','Sort Order'], required: ['Attraction Name'], deleteKey: ['Attraction Name'] }
];
const isBoolean = (h: string) => ['Active','Offer Enabled','Closed'].includes(h);
const isNumber = (h: string) => ['Sort Order','Price INR','Offer Discount INR','Capacity Override','seating_capacity','price_per_day','display_order','Point Number','Entry Fee'].includes(h);
const isDate = (h: string) => h === 'Travel Date';

export const OperationalSheetsManager: React.FC<{ data: any; onRefresh: () => void; showToast: (message: string) => void }> = ({ data, onRefresh, showToast }) => {
  const [selected, setSelected] = useState<SheetKey>('pickupPoints');
  const [editing, setEditing] = useState<Record<string, any> | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const config = useMemo(() => SHEETS.find(s => s.key === selected)!, [selected]);
  const rows: Record<string, any>[] = Array.isArray(data?.[selected]) ? data[selected] : [];
  const startNew = () => { const blank: Record<string, any> = {}; config.headers.forEach(h => { blank[h] = isBoolean(h) ? false : ''; }); setEditing(blank); setIsCreating(true); setError(''); };
  const save = async () => {
    if (!editing) return;
    for (const key of config.required) if (String(editing[key] ?? '').trim() === '') { setError(`${key} is required.`); return; }
    const record: Record<string, any> = {};
    config.headers.forEach(h => {
      const value = editing[h];
      if (value === null || value === undefined) { record[h] = ''; return; }
      record[h] = isBoolean(h) ? value === true || value === 'true' : isNumber(h) ? (value === '' ? '' : Number(value)) : value;
    });
    if (Object.keys(record).some(k => isNumber(k) && !Number.isFinite(record[k]))) { setError('Please enter valid numeric values.'); return; }
    setBusy(true); setError('');
    try {
      const token = readAdminSessionToken();
      const response = await fetch('/api/admin/operational/upsert', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token || ''}` }, body: JSON.stringify({ sheetKey: selected, record }) });
      const body = await response.json();
      if (!response.ok || !body.success) throw new Error(body.error || 'Save failed.');
      setEditing(null); setIsCreating(false); showToast(body.result?.message || 'Record saved to Google Sheets.'); onRefresh();
    } catch (e: any) { setError(e.message || 'Save failed.'); }
    finally { setBusy(false); }
  };
  const remove = async (row: Record<string, any>) => {
    const key: Record<string, any> = {}; config.deleteKey.forEach(k => key[k] = row[k]);
    if (config.deleteKey.some(k => key[k] === undefined || String(key[k]).trim() === '')) { showToast('This row has no complete stable key and cannot be deleted.'); return; }
    if (!window.confirm(`Delete this ${config.label} record from Google Sheets?`)) return;
    setBusy(true);
    try {
      const token = readAdminSessionToken();
      const response = await fetch('/api/admin/operational/delete', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token || ''}` }, body: JSON.stringify({ sheetKey: selected, key }) });
      const body = await response.json();
      if (!response.ok || !body.success) throw new Error(body.error || 'Delete failed.');
      showToast(body.result?.message || 'Record deleted.'); onRefresh();
    } catch (e: any) { showToast(e.message || 'Delete failed.'); }
    finally { setBusy(false); }
  };
  const fieldInput = (header: string) => {
    const value = editing?.[header] ?? (isBoolean(header) ? false : '');
    if (isBoolean(header)) return <select value={String(value === true || String(value).toLowerCase() === 'true')} onChange={e => setEditing(prev => prev ? { ...prev, [header]: e.target.value === 'true' } : prev)} className="w-full rounded-lg bg-slate-950 border border-white/10 px-3 py-2 text-xs text-white"><option value="false">No / Inactive</option><option value="true">Yes / Active</option></select>;
    return <input type={isNumber(header) ? 'number' : isDate(header) ? 'date' : 'text'} step={isNumber(header) ? 'any' : undefined} value={isDate(header) ? String(value).slice(0, 10) : value} onChange={e => setEditing(prev => prev ? { ...prev, [header]: e.target.value } : prev)} className="w-full rounded-lg bg-slate-950 border border-white/10 px-3 py-2 text-xs text-white" />;
  };
  return <section className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-4">
    <div className="flex flex-wrap items-center justify-between gap-3"><div><h3 className="text-sm font-bold text-white">Operational Sheets – Add / Edit / Delete</h3><p className="text-[11px] text-slate-400">Changes are saved to Google Sheets through the authenticated Admin API.</p></div><button disabled={busy} onClick={onRefresh} className="px-3 py-2 rounded-lg bg-white/10 text-white text-xs inline-flex items-center gap-2"><RefreshCw className="w-3 h-3"/>Refresh</button></div>
    <div className="flex flex-wrap gap-2">{SHEETS.map(s => <button key={s.key} onClick={() => { setSelected(s.key); setEditing(null); setError(''); }} className={`px-3 py-2 rounded-lg text-[11px] font-semibold ${selected === s.key ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' : 'bg-slate-900 text-slate-300 border border-white/10'}`}>{s.label} ({Array.isArray(data?.[s.key]) ? data[s.key].length : 0})</button>)}</div>
    <div className="flex items-center justify-between"><h4 className="text-xs font-bold text-slate-200">{config.label}</h4><button disabled={busy || !!editing || selected === 'pickupPoints'} onClick={startNew} title={selected === 'pickupPoints' ? 'Pickup catalogue expansion requires a coordinated website catalogue update.' : 'Add record'} className="px-3 py-2 rounded-lg bg-emerald-500/15 text-emerald-300 text-xs inline-flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed"><Plus className="w-3 h-3"/>Add Record</button></div>{selected === 'pickupPoints' && <div className="rounded-lg border border-amber-500/25 bg-amber-500/10 p-3 text-[11px] leading-relaxed text-amber-100/90">PickupPoints currently supports only Active / Inactive changes from this panel. Do not add, delete, rename, move, or reorder pickup rows here: the public website requires an exact match with its approved 71-point catalogue. Pickup time, reporting time, landmark and Google Maps URL remain in the website catalogue and are not stored in this four-column Sheet.</div>}
    {editing && <div className="rounded-xl border border-emerald-400/25 bg-slate-900/70 p-3 space-y-3"><div className="flex justify-between items-center"><span className="text-xs font-bold text-white">{isCreating ? 'New Record' : 'Edit Record'}</span><button onClick={() => { setEditing(null); setIsCreating(false); }} className="text-slate-400"><X className="w-4 h-4"/></button></div><div className="grid grid-cols-1 sm:grid-cols-2 gap-3">{config.headers.map(h => <label key={h} className="text-[10px] text-slate-400">{h}{config.required.includes(h) && <span className="text-rose-400"> *</span>}<div className="mt-1">{selected === 'pickupPoints' ? (h === 'Active' ? fieldInput(h) : <input value={String(editing[h] ?? '')} disabled className="w-full rounded-lg bg-slate-950/60 border border-white/10 px-3 py-2 text-xs text-slate-500" />) : (isCreating || !config.required.includes(h) ? fieldInput(h) : <input value={String(editing[h] ?? '')} disabled className="w-full rounded-lg bg-slate-950/60 border border-white/10 px-3 py-2 text-xs text-slate-500" />)}</div></label>)}</div>{error && <p className="text-xs text-rose-300">{error}</p>}<div className="flex gap-2"><button disabled={busy} onClick={save} className="px-4 py-2 rounded-lg bg-emerald-500 text-slate-950 text-xs font-bold inline-flex items-center gap-1.5"><Save className="w-3 h-3"/>{busy ? 'Saving…' : 'Save to Sheets'}</button><button disabled={busy} onClick={() => { setEditing(null); setIsCreating(false); }} className="px-4 py-2 rounded-lg bg-white/10 text-white text-xs">Cancel</button></div></div>}
    <div className="overflow-x-auto rounded-lg border border-white/10"><table className="w-full text-left text-[10px]"><thead className="bg-slate-900 text-slate-400"><tr>{config.headers.map(h => <th key={h} className="p-2 whitespace-nowrap">{h}</th>)}<th className="p-2">Actions</th></tr></thead><tbody>{rows.map((row, i) => <tr key={config.required.map(k => row[k]).join('|') || i} className="border-t border-white/5 text-slate-300">{config.headers.map(h => <td key={h} className="p-2 max-w-48 truncate">{String(row[h] ?? '')}</td>)}<td className="p-2 whitespace-nowrap"><button disabled={busy || !!editing} title="Edit" onClick={() => { setEditing({ ...row }); setIsCreating(false); setError(''); }} className="p-1.5 text-sky-300"><Pencil className="w-3 h-3"/></button><button disabled={busy || !!editing || selected === 'pickupPoints'} title={selected === 'pickupPoints' ? 'Pickup rows are locked until coordinated catalogue expansion is implemented.' : 'Delete'} onClick={() => remove(row)} className="p-1.5 text-rose-300 disabled:opacity-30 disabled:cursor-not-allowed"><Trash2 className="w-3 h-3"/></button></td></tr>)}{rows.length === 0 && <tr><td colSpan={config.headers.length + 1} className="p-4 text-center text-slate-500">No records found in this sheet.</td></tr>}</tbody></table></div>
    <p className="text-[10px] text-slate-500">Only the approved columns are editable. AdminUsers, Settings, bookings, payments, rental enquiries and log sheets remain protected.</p>
  </section>;
};
