import React, { useState } from 'react';
import { Search, Printer, AlertCircle, X, CheckCircle2, Loader2 } from 'lucide-react';

type LookupBooking = {
  bookingId: string; customerName: string; travelDate: string; route: string;
  pickupPoint: string; packageName: string; passengers: number; amount: number;
  paymentStatus: string; bookingStatus: string;
};

export const BookingLookup: React.FC = () => {
  const [bookingId, setBookingId] = useState('');
  const [mobile, setMobile] = useState('');
  const [booking, setBooking] = useState<LookupBooking | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [reason, setReason] = useState('');
  const [cancelDone, setCancelDone] = useState(false);
  const [cancelLoading, setCancelLoading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setBooking(null); setCancelDone(false);
    const cleanMobile = mobile.replace(/\D/g, '').slice(-10);
    if (!bookingId.trim() || cleanMobile.length !== 10) { setError('Enter both your Booking ID and registered 10-digit mobile number.'); return; }
    setLoading(true);
    try {
      const response = await fetch('/api/bookings/lookup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ bookingId: bookingId.trim(), mobile: cleanMobile }) });
      const data = await response.json();
      if (!response.ok || data.status !== 'success') throw new Error(data.message || 'We could not verify your booking.');
      setBooking(data.booking as LookupBooking);
    } catch (err: any) { setError(err.message || 'The booking lookup service is currently unavailable.'); }
    finally { setLoading(false); }
  };

  const handleCancel = async (e: React.FormEvent) => {
    e.preventDefault(); setError('');
    if (!booking || reason.trim().length < 3) return;
    setCancelLoading(true);
    try {
      const response = await fetch('/api/bookings/cancellation-request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ bookingId: booking.bookingId, mobile: mobile.replace(/\D/g, '').slice(-10), reason: reason.trim() }) });
      const data = await response.json();
      if (!response.ok || !['success', 'duplicate'].includes(data.status)) throw new Error(data.message || 'The cancellation request could not be submitted.');
      setCancelDone(true); setCancelOpen(false); setReason('');
    } catch (err: any) { setError(err.message || 'The cancellation request service is currently unavailable.'); }
    finally { setCancelLoading(false); }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="shiny-dark-card rounded-2xl p-6 sm:p-8 border border-white/10 text-center space-y-4">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-400">Secure Ticket & Status Verification</span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Find Your Mumbai Darshan Booking</h1>
        <p className="text-xs text-slate-400 max-w-lg mx-auto">For security, enter your <strong>Booking ID</strong> provided when you made the booking, <strong>registered 10-digit mobile number</strong> as well. A lookup cannot be completed with only the Booking ID or mobile number.</p>
        <form onSubmit={handleSearch} className="max-w-md mx-auto grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
          <input value={bookingId} onChange={e => setBookingId(e.target.value)} maxLength={80} required placeholder="Booking ID (MDB-...)" className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400" />
          <input value={mobile} onChange={e => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))} inputMode="numeric" maxLength={10} required placeholder="Registered mobile number" className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400" />
          <button disabled={loading} type="submit" className="sm:col-span-2 px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-60 text-slate-950 font-bold text-xs cursor-pointer flex items-center justify-center gap-2">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />} Verify Booking
          </button>
        </form>
      </div>

      {error && <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2"><AlertCircle className="w-4 h-4 shrink-0" />{error}</div>}
      {cancelDone && <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2"><CheckCircle2 className="w-4 h-4 shrink-0" />Your cancellation request has been recorded for review by our team. This message does not mean that a refund has been processed.</div>}

      {booking && <div className="shiny-dark-card rounded-2xl p-6 border border-white/15 space-y-5 print-card">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-4 gap-2">
          <div><span className="text-xs uppercase font-bold text-amber-400">Booking Status</span><h2 className="text-xl font-black text-white font-mono">{booking.bookingId}</h2><p className="text-xs text-slate-400">Travel Date: <strong className="text-white">{booking.travelDate}</strong></p></div>
          <div className="flex gap-2 flex-wrap"><span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-300">{booking.bookingStatus}</span><span className="px-3 py-1 rounded-full text-xs font-semibold bg-white/5 border border-white/10 text-slate-300">{booking.paymentStatus}</span></div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
          <div><span className="text-slate-400 block">Passenger</span><strong className="text-white">{booking.customerName}</strong></div>
          <div><span className="text-slate-400 block">Route</span><strong className="text-white">{booking.route}</strong></div>
          <div><span className="text-slate-400 block">Pickup Point</span><strong className="text-white">{booking.pickupPoint}</strong></div>
          <div><span className="text-slate-400 block">Package</span><strong className="text-white">{booking.packageName}</strong></div>
          <div><span className="text-slate-400 block">Passengers</span><strong className="text-white">{booking.passengers}</strong></div>
          <div><span className="text-slate-400 block">Online Package Fare</span><strong className="text-amber-300">₹{booking.amount}</strong></div>
        </div>
        <p className="text-[11px] text-slate-400">For privacy, full mobile number, email address, special request and payment transaction details are not displayed here.</p>
        <div className="flex flex-wrap justify-between gap-3 no-print">
          <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 text-white text-xs"><Printer className="w-4 h-4" />Print Status</button>
          {booking.bookingStatus.toLowerCase() !== 'cancelled' && <button onClick={() => setCancelOpen(true)} className="text-xs text-rose-400 hover:underline">Request Cancellation</button>}
        </div>
      </div>}

      {cancelOpen && booking && <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"><div className="bg-[#12141c] border border-white/20 rounded-2xl p-6 max-w-md w-full space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3"><h3 className="text-sm font-bold text-white">Cancellation Request</h3><button onClick={() => setCancelOpen(false)} className="text-slate-400"><X className="w-4 h-4" /></button></div>
        <form onSubmit={handleCancel} className="space-y-3 text-xs"><p className="text-slate-300">Booking ID: <strong className="text-amber-400">{booking.bookingId}</strong></p><textarea required minLength={3} maxLength={500} rows={4} value={reason} onChange={e => setReason(e.target.value)} placeholder="Enter the reason for cancellation" className="w-full bg-slate-900 border border-white/10 rounded-xl p-3 text-white" /><p className="text-[11px] text-slate-400">Your request will be saved for review only. Refunds are not automatic. The owner will verify the payment record and applicable policy before taking manual action.</p><div className="flex justify-end gap-2"><button type="button" onClick={() => setCancelOpen(false)} className="px-3 py-2 rounded-lg bg-white/10 text-slate-300">Back</button><button disabled={cancelLoading} type="submit" className="px-4 py-2 rounded-lg bg-rose-500 text-white font-bold disabled:opacity-60">{cancelLoading ? 'Submitting…' : 'Submit Request'}</button></div></form>
      </div></div>}
    </div>
  );
};
