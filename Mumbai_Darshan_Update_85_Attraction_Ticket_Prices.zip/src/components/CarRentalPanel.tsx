import React, { useState, useMemo } from 'react';
import { Car, Users, CheckCircle2, Calendar, Phone, MapPin, ArrowRight, ShieldCheck, Fuel, Clock, Navigation, Calculator, MessageSquare } from 'lucide-react';
import { StorageService } from '../services/storage';
import { isTodayOrFutureLocalDate, toLocalDateInputValue } from '../services/date';
import { calculateBhayandarGarageRoute, calculateOutstationQuote, GarageRouteResult } from '../services/routeCalculator';
import { CarRentalEnquiry, LocalRentalPackage, OutstationVehicleRate } from '../types';

interface CarRentalPanelProps {
  onSuccess?: () => void;
  title?: string;
  subtitle?: string;
}

export const CarRentalPanel: React.FC<CarRentalPanelProps> = ({
  onSuccess,
  title = "Private Car, Tempo Traveller & Luxury Bus Rental",
  subtitle = "Doorstep private sightseeing and outstation rentals. Choose between 12-Hour/120-KM Mumbai Local packages or 300-KM/Day Outstation journeys."
}) => {
  // Rental Type: 'local_darshan' | 'outstation'
  const [rentalType, setRentalType] = useState<'local_darshan' | 'outstation'>('local_darshan');

  // Dynamic rates from Storage
  const localPackages = useMemo(() => StorageService.getLocalRentalPackages().filter(p => p.active && p.published), []);
  const outstationRates = useMemo(() => StorageService.getOutstationRates().filter(r => r.active && r.published), []);
  const settings = useMemo(() => StorageService.getSettings(), []);

  // Form State
  const [selectedLocalVehicleId, setSelectedLocalVehicleId] = useState<string>(localPackages[0]?.id || 'loc_dzire');
  const [selectedOutstationVehicleId, setSelectedOutstationVehicleId] = useState<string>(outstationRates[0]?.id || 'out_dzire');

  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');
  const [travelDate, setTravelDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 2);
    return toLocalDateInputValue(d);
  });
  const [passengerCount, setPassengerCount] = useState(4);
  const [pickupLocation, setPickupLocation] = useState('');
  const [destination, setDestination] = useState('');
  const [preferredPickupTime, setPreferredPickupTime] = useState('8:00 AM');
  const [daysCount, setDaysCount] = useState(1);
  const [routeResult, setRouteResult] = useState<GarageRouteResult | null>(null);
  const [isCalculatingRoute, setIsCalculatingRoute] = useState(false);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [nightCount, setNightCount] = useState(0);
  const [includeLocalTourGuide, setIncludeLocalTourGuide] = useState(false);
  const garageAddress = settings.rentalGarageAddress || 'Jai Mata Di Travels, Shop No. 12, Om Poonam Enclave, Near Old Golden Nest, Mira Bhayandar Road, Mira Road East, Maharashtra 401107, India';
  const [specialRequirements, setSpecialRequirements] = useState('');

  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [pendingEnquiry, setPendingEnquiry] = useState<CarRentalEnquiry | null>(null);
  const [isRestoredPendingEnquiry, setIsRestoredPendingEnquiry] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Recover the exact unsynced rental enquiry after a page refresh.
  React.useEffect(() => {
    const recoveredEnquiry = StorageService.getPendingRentalForRetry();
    if (recoveredEnquiry) {
      setPendingEnquiry(recoveredEnquiry);
      setIsRestoredPendingEnquiry(true);
      setErrorMsg(`Your earlier rental enquiry (${recoveredEnquiry.id}) is still awaiting Google Sheets confirmation. Retry the same enquiry; do not submit a duplicate.`);
    }
  }, []);

  // Active selected local package
  const activeLocalPkg = useMemo(() => {
    return localPackages.find(p => p.id === selectedLocalVehicleId) || localPackages[0];
  }, [localPackages, selectedLocalVehicleId]);

  // Active selected outstation rate
  const activeOutstationRate = useMemo(() => {
    return outstationRates.find(r => r.id === selectedOutstationVehicleId) || outstationRates[0];
  }, [outstationRates, selectedOutstationVehicleId]);

  // Transparent outstation quote breakdown (customer-facing rates only).
  const outstationBreakdown = useMemo(() => {
    if (!activeOutstationRate) return calculateOutstationQuote(0, daysCount, 0, 0, nightCount);
    return calculateOutstationQuote(routeResult?.distanceKm || 0, daysCount, activeOutstationRate.customerPerKm, activeOutstationRate.customerDaPerDay, nightCount);
  }, [activeOutstationRate, routeResult, daysCount, nightCount]);

  // Calculated estimates
  const estimatedQuotation = useMemo(() => {
    if (rentalType === 'local_darshan') {
      return (activeLocalPkg ? activeLocalPkg.customerPrice : 4500) + (includeLocalTourGuide ? 2000 : 0);
    } else {
      // The displayed quote, submitted enquiry and admin record must all use
      // the same automatic garage-to-garage route calculation.
      return outstationBreakdown.total;
    }
  }, [rentalType, activeLocalPkg, outstationBreakdown, includeLocalTourGuide]);

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setErrorMsg(null);

    if (!pendingEnquiry && (!customerName.trim() || customerName.trim().length < 3 || customerName.trim().length > 100)) {
      setErrorMsg('Please enter your full name (3 to 100 characters).');
      return;
    }
    const cleanPhone = customerMobile.replace(/\D/g, '');
    if (!pendingEnquiry && cleanPhone.length !== 10) {
      setErrorMsg('Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!pendingEnquiry && !isTodayOrFutureLocalDate(travelDate)) {
      setErrorMsg('Please select today or a future travel date.');
      return;
    }
    if (!pendingEnquiry && (!Number.isInteger(passengerCount) || passengerCount < 1 || passengerCount > 50)) {
      setErrorMsg('Please enter a whole-number passenger count between 1 and 50.');
      return;
    }
    if (!pendingEnquiry && rentalType === 'outstation' && (!Number.isInteger(daysCount) || daysCount < 1 || daysCount > 30)) {
      setErrorMsg('Please select a whole-number rental duration between 1 and 30 days.');
      return;
    }
    if (!pendingEnquiry && rentalType === 'outstation' && (!Number.isInteger(nightCount) || nightCount < 0 || nightCount > 30)) {
      setErrorMsg('Night DA count must be a whole number between 0 and 30.');
      return;
    }
    if (!pendingEnquiry && (!pickupLocation.trim() || pickupLocation.trim().length > 200)) {
      setErrorMsg('Please enter a pickup location (maximum 200 characters).');
      return;
    }
    if (!pendingEnquiry && rentalType === 'outstation' && (!destination.trim() || destination.trim().length > 200)) {
      setErrorMsg('Please enter an outstation destination (maximum 200 characters).');
      return;
    }
    if (!pendingEnquiry && !routeResult && rentalType === 'outstation') {
      setErrorMsg('Please calculate the automatic Bhayandar garage-to-garage road distance before submitting.');
      return;
    }

    setIsSubmitting(true);
    try {
      const selectedVehicleName = rentalType === 'local_darshan'
        ? activeLocalPkg?.vehicleName || 'Private AC Vehicle'
        : activeOutstationRate?.vehicleName || 'Outstation AC Vehicle';

      const enquiry = pendingEnquiry || StorageService.createCarRentalEnquiry({
        customerName: customerName.trim(),
        customerMobile: customerMobile.trim(),
        travelDate,
        rentalType,
        vehicleType: selectedVehicleName,
        preferredCarModel: selectedVehicleName,
        tempoTravellerSeatingCapacity: /tempo traveller/i.test(selectedVehicleName) ? (rentalType === 'local_darshan' ? activeLocalPkg?.seating : activeOutstationRate?.seating) : '',
        otherSeatingCapacity: /tempo traveller/i.test(selectedVehicleName) ? '' : (rentalType === 'local_darshan' ? activeLocalPkg?.seating : activeOutstationRate?.seating),
        acPreference: 'AC',
        tripType: rentalType === 'local_darshan' ? 'Local' : 'Outstation',
        rentalDuration: rentalType === 'local_darshan' ? '12 Hours / 120 KM' : `${daysCount} Days`,
        isAC: true,
        passengerCount,
        pickupLocation: pickupLocation.trim(),
        destination: rentalType === 'outstation' ? destination.trim() : 'Mumbai Sightseeing (120 KM Local)',
        preferredPickupTime,
        daysCount: rentalType === 'outstation' ? daysCount : 1,
        specialRequirements: [specialRequirements.trim(), rentalType === 'local_darshan' && includeLocalTourGuide ? 'Tour Guide requested: ₹2,000 flat per booking/vehicle' : '', rentalType === 'outstation' ? `Daily Driver Allowance / DA-Permit: ₹${activeOutstationRate?.customerDaPerDay || 0} per day; Night DA: ${nightCount} × ₹${activeOutstationRate?.customerDaPerDay || 0}` : ''].filter(Boolean).join(' | ') || undefined,
      });

      setPendingEnquiry(enquiry);
      const retryPointerSaved = StorageService.savePendingRentalRetryId(enquiry.id);
      if (!retryPointerSaved) {
        setErrorMsg('Your rental enquiry could not be safely prepared for retry on this device. No request was sent to Google Sheets. Please check browser site-storage permissions/free space and try again.');
        return;
      }

      const syncResult = await StorageService.syncRentalToGoogleSheets(enquiry);
      if (!syncResult.success) {
        setPendingEnquiry(enquiry);
        setErrorMsg(`Enquiry ${enquiry.id} has not yet been confirmed in Google Sheets. ${syncResult.message} Please retry using the same reference ID.`);
        return;
      }
      StorageService.clearPendingRentalRetryId(enquiry.id);
      setPendingEnquiry(null);
      setIsRestoredPendingEnquiry(false);
      setSubmittedId(enquiry.id);
      if (onSuccess) onSuccess();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to submit enquiry. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getWhatsAppEnquiryUrl = () => {
    const text = encodeURIComponent(
      `Hello Mumbai Darshan Bus Online! I submitted a rental enquiry with Ref ID: ${submittedId || 'NEW'}.\n\n` +
      `*Type:* ${rentalType === 'local_darshan' ? 'Mumbai Local Darshan (12 Hr / 120 KM)' : 'Outstation Rental'}\n` +
      `*Name:* ${customerName}\n*Phone:* ${customerMobile}\n*Date:* ${travelDate}\n` +
      `*Pickup:* ${pickupLocation}\n*Destination:* ${rentalType === 'outstation' ? destination : 'Mumbai Sightseeing'}\n` +
      `*Estimated Quote:* ₹${estimatedQuotation}\n` +
      (rentalType === 'local_darshan' && includeLocalTourGuide ? '*Tour Guide:* Requested — ₹2,000 flat per vehicle\n' : '') +
      (rentalType === 'outstation' ? '*Driver Allowance / DA-Permit:* Extra as shown in estimate\n*Parking, Toll, Border Tax & Entry:* Extra at actuals\n' : '') +
      '\nPlease confirm vehicle availability.'
    );
    return `https://wa.me/${settings.whatsappNumber}?text=${text}`;
  };

  return (
    <div className="shiny-dark-card rounded-2xl p-4 sm:p-7 border border-white/10 text-slate-100 w-full min-w-0 box-border">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5 mb-6">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
            Dedicated Doorstep Pickup & Fleet Services
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight mt-1">
            {title}
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            {subtitle}
          </p>
        </div>

        {/* Category Switcher Tabs */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-white/10 shrink-0">
          <button
            type="button"
            onClick={() => setRentalType('local_darshan')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              rentalType === 'local_darshan'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Mumbai Local (120 KM)
          </button>
          <button
            type="button"
            onClick={() => setRentalType('outstation')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              rentalType === 'outstation'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Outstation (300 KM/Day)
          </button>
        </div>
      </div>

      {submittedId ? (
        <div className="p-6 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-4">
          <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Rental Enquiry Received!</h3>
            <p className="text-xs text-slate-300 max-w-md mx-auto mt-1">
              Your Enquiry Reference is <strong className="text-amber-400 font-mono text-sm">{submittedId}</strong>.
            </p>
            <p className="text-xs text-slate-400 max-w-md mx-auto mt-0.5">
              Estimated Tariff: <strong className="text-white font-mono">₹{estimatedQuotation}</strong>. Final quotation and vehicle assignment will be confirmed by our transport coordinator.
            </p>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <a
              href={getWhatsAppEnquiryUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Instant WhatsApp Follow-up</span>
            </a>

            <button
              type="button"
              onClick={() => {
                setSubmittedId(null);
                setPendingEnquiry(null);
                setIsRestoredPendingEnquiry(false);
                StorageService.clearPendingRentalRetryId();
                setCustomerName('');
                setCustomerMobile('');
                setPickupLocation('');
                setDestination('');
              }}
              className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-white/5 rounded-xl border border-white/10"
            >
              Submit Another Enquiry
            </button>
          </div>
        </div>
      ) : isRestoredPendingEnquiry && pendingEnquiry ? (
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 sm:p-6 space-y-4">
          <div>
            <h3 className="text-lg font-bold text-white">Resume Your Pending Rental Enquiry</h3>
            <p className="text-xs text-slate-300 mt-1">This device has an enquiry that did not receive Google Sheets confirmation. Retry the same reference ID below; do not create another enquiry.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
            <p>Reference ID: <strong className="text-amber-300">{pendingEnquiry.id}</strong></p>
            <p>Name: <strong className="text-white">{pendingEnquiry.customerName}</strong></p>
            <p>Mobile: <strong className="text-white">{pendingEnquiry.customerMobile}</strong></p>
            <p>Travel Date: <strong className="text-white">{pendingEnquiry.travelDate}</strong></p>
            <p>Type: <strong className="text-white">{pendingEnquiry.rentalType === 'local_darshan' ? 'Mumbai Local Darshan' : 'Outstation Rental'}</strong></p>
            <p>Vehicle: <strong className="text-white">{pendingEnquiry.vehicleType}</strong></p>
            <p>Pickup: <strong className="text-white">{pendingEnquiry.pickupLocation}</strong></p>
            <p>Destination: <strong className="text-white">{pendingEnquiry.destination}</strong></p>
            <p>Passengers: <strong className="text-white">{pendingEnquiry.passengerCount}</strong></p>
          </div>
          {pendingEnquiry.specialRequirements && <p className="text-xs text-slate-300 border-t border-white/10 pt-3">Requirements: {pendingEnquiry.specialRequirements}</p>}
          {errorMsg && <p role="alert" className="text-xs text-amber-200 bg-amber-500/10 rounded-lg p-3">{errorMsg}</p>}
          <button type="button" onClick={() => void handleSubmit()} disabled={isSubmitting} className="w-full rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 px-4 py-3 text-sm font-extrabold text-slate-950 disabled:opacity-50">
            {isSubmitting ? 'Retrying same enquiry...' : `Retry Same Enquiry (${pendingEnquiry.id})`}
          </button>
          <p className="text-[11px] text-slate-400">Rental enquiries are inquiry-only, not confirmed bookings. This retry does not trigger email or payment.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-300">
              {errorMsg}
              {pendingEnquiry && <div className="mt-2 font-semibold">Reference: {pendingEnquiry.id} — click Submit again to retry safely.</div>}
            </div>
          )}

          {/* Policy Banner Based on Selection */}
          {rentalType === 'local_darshan' ? (
            <div className="p-3.5 rounded-xl bg-amber-500/5 border border-amber-500/20 text-xs space-y-1">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <Clock className="w-4 h-4" />
                <span>Mumbai Local Sightseeing Package Rules (12 Hours / 120 KM)</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Package ends when either 12 hours or 120 KM is reached (whichever occurs first). Vehicle, driver and parking included · Tour Guide optional at ₹2,000 flat per booking/vehicle · Toll and entry charges extra at actuals · Extra KM & hours charged separately.
              </p>
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-cyan-500/5 border border-cyan-500/20 text-xs space-y-1">
              <div className="flex items-center gap-2 text-cyan-400 font-bold">
                <Navigation className="w-4 h-4" />
                <span>Outstation Journey Billing Rules (300 KM / Day Minimum)</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Minimum 300 KM/day · Complete KM from Bhayandar garage departure to return to Bhayandar garage · Driver allowance / DA-Permit extra as shown in the estimate · Parking, Toll, Border Tax and Entry charges extra at actuals · Additional Night DA after 11:00 PM is charged at the same amount as the vehicle's regular daily DA.
              </p>
            </div>
          )}

          {/* Vehicle Selection Cards */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2.5">
              {rentalType === 'local_darshan' ? 'Select Local Sightseeing Package' : 'Select Outstation Vehicle Class'}
            </label>

            {rentalType === 'local_darshan' ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                {localPackages.map(pkg => {
                  const isSelected = selectedLocalVehicleId === pkg.id;
                  return (
                    <div
                      key={pkg.id}
                      onClick={() => setSelectedLocalVehicleId(pkg.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all text-xs flex flex-col justify-between ${
                        isSelected
                          ? 'bg-amber-500/15 border-amber-400 text-white shadow-sm ring-1 ring-amber-400'
                          : 'bg-[#12141c] border-white/5 hover:border-white/20 text-slate-300'
                      }`}
                    >
                      <div>
                        <strong className="block font-bold text-xs truncate">{pkg.vehicleName.split(' (')[0]}</strong>
                        <span className="text-[10px] text-amber-400 font-medium block mt-0.5">{pkg.seating}</span>
                      </div>
                      <div className="mt-2 pt-2 border-t border-white/5">
                        <span className="text-xs font-mono font-black text-amber-300 block">₹{pkg.customerPrice}</span>
                        <span className="text-[9px] text-slate-400 block">12 Hrs / 120 KM</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
                {outstationRates.map(rate => {
                  const isSelected = selectedOutstationVehicleId === rate.id;
                  return (
                    <div
                      key={rate.id}
                      onClick={() => setSelectedOutstationVehicleId(rate.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all text-xs flex flex-col justify-between ${
                        isSelected
                          ? 'bg-amber-500/15 border-amber-400 text-white shadow-sm ring-1 ring-amber-400'
                          : 'bg-[#12141c] border-white/5 hover:border-white/20 text-slate-300'
                      }`}
                    >
                      <div>
                        <strong className="block font-bold text-xs truncate">{rate.vehicleName}</strong>
                        <span className="text-[10px] text-amber-400 font-medium block mt-0.5">{rate.seating} ({rate.isAC ? 'AC' : 'Non-AC'})</span>
                      </div>
                      <div className="mt-2 pt-2 border-t border-white/5">
                        <span className="text-xs font-mono font-black text-amber-300 block">₹{rate.customerPerKm}/KM</span>
                        <span className="text-[9px] text-slate-400 block">+ ₹{rate.customerDaPerDay}/day DA/Permit</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {rentalType === 'local_darshan' && (
            <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeLocalTourGuide}
                  disabled={!!pendingEnquiry}
                  onChange={e => setIncludeLocalTourGuide(e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-amber-400"
                />
                <span className="space-y-1">
                  <strong className="block text-xs text-amber-300">Add Tour Guide (Optional)</strong>
                  <span className="block text-[11px] text-slate-300">Flat ₹2,000 per booking / vehicle. Not charged per passenger.</span>
                </span>
              </label>
            </div>
          )}

          {/* Travel Parameters */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                Date of Travel
              </label>
              <input
                type="date"
                required
                min={toLocalDateInputValue(new Date())}
                value={travelDate}
                onChange={e => setTravelDate(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            {rentalType === 'outstation' ? (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Number of Days
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={1}
                    max={30}
                    step={1}
                    value={daysCount}
                    onChange={e => setDaysCount(e.target.value === '' ? 1 : Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                  <span className="text-[11px] text-slate-400 shrink-0">({daysCount * 300} KM Min)</span>
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Preferred Pickup Time
                </label>
                <input
                  type="text"
                  placeholder="e.g. 7:30 AM"
                  value={preferredPickupTime}
                  onChange={e => setPreferredPickupTime(e.target.value)}
                  className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-amber-400" />
                Passenger Count
              </label>
              <input
                type="number"
                min={1}
                max={50}
                step={1}
                value={passengerCount}
                onChange={e => setPassengerCount(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
              />
            </div>
          </div>

          {rentalType === 'outstation' && (
            <div className="space-y-3 rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-4">
              <div className="flex flex-col sm:flex-row sm:items-end gap-3">
                <div className="flex-1">
                  <strong className="block text-sm text-cyan-300">Automatic Distance Calculation</strong>
                  <p className="text-[11px] text-slate-300 mt-1">Distance is calculated privately using the company's garage, your pickup location, destination and return journey. Garage address is not displayed to customers.</p>
                </div>
                <button type="button" disabled={isCalculatingRoute || !pickupLocation.trim() || !destination.trim()} onClick={async () => {
                  setIsCalculatingRoute(true); setRouteError(null); setRouteResult(null);
                  try {
                    const result = await calculateBhayandarGarageRoute(pickupLocation, destination, garageAddress);
                    setRouteResult(result);
                  } catch (error: any) { setRouteError(error?.message || 'Unable to calculate road distance.'); }
                  finally { setIsCalculatingRoute(false); }
                }} className="px-4 py-2 rounded-lg bg-cyan-400 text-slate-950 text-xs font-bold disabled:opacity-50">
                  {isCalculatingRoute ? 'Calculating Road Route…' : 'Calculate Automatic KM'}
                </button>
              </div>
              {routeError && <p role="alert" className="text-xs text-rose-300">{routeError}</p>}
              {routeResult && <div className="rounded-lg bg-slate-950/60 border border-cyan-400/20 p-3 text-xs space-y-1">
                <p className="text-white font-bold">Total Garage-to-Garage Distance: {routeResult.distanceKm} KM</p>
                <p className="text-slate-300">Estimated driving time: {Math.floor(routeResult.durationMinutes / 60)} hr {routeResult.durationMinutes % 60} min (route estimate, excluding stops/traffic).</p>
              </div>}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Night DA after 11:00 PM</label>
                  <input type="number" min={0} max={30} step={1} value={nightCount} onChange={e => setNightCount(Math.max(0, parseInt(e.target.value, 10) || 0))} className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white" />
                  <p className="text-[10px] text-slate-400 mt-1">Number of nights duty continues after 11 PM. Each extra Night DA equals the same vehicle's daily DA.</p>
                </div>
                <div className="rounded-lg bg-slate-950/50 p-3 text-[11px] text-slate-300">
                  Minimum billing: {daysCount * 300} KM ({daysCount} × 300). Driver allowance / DA-Permit extra as shown above. Parking, Toll, Border Tax and Entry extra at actuals.
                </div>
              </div>
            </div>
          )}

          {/* Locations */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                Exact Doorstep Pickup Location
              </label>
              <input
                type="text"
                placeholder="Enter customer pickup location"
                value={pickupLocation}
                onChange={e => { setPickupLocation(e.target.value); setRouteResult(null); }}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            {rentalType === 'outstation' ? (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <Navigation className="w-3.5 h-3.5 text-amber-400" />
                  Outstation Destination
                </label>
                <input
                  type="text"
                  maxLength={200}
                  placeholder="e.g., Shirdi / Lonavala / Mahabaleshwar / Nashik"
                  value={destination}
                  onChange={e => { setDestination(e.target.value); setRouteResult(null); }}
                  className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Sightseeing Focus / Custom Drops
                </label>
                <input
                  type="text"
                  maxLength={1000}
                  placeholder="e.g., South Mumbai temples, heritage buildings, shopping"
                  value={specialRequirements}
                  onChange={e => setSpecialRequirements(e.target.value)}
                  className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            )}
          </div>

          {/* Customer Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Full Name *
              </label>
              <input
                type="text"
                maxLength={100}
                placeholder="Your full name"
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Mobile Number *
              </label>
              <div className="flex">
                <span className="bg-slate-900 border border-r-0 border-white/10 rounded-l-xl px-2.5 py-2 text-xs text-slate-400 flex items-center">
                  +91
                </span>
                <input
                  type="tel"
                  maxLength={10}
                  placeholder="10-digit mobile number"
                  value={customerMobile}
                  onChange={e => setCustomerMobile(e.target.value.replace(/\D/g, ''))}
                  className="w-full bg-[#12141c] border border-white/10 rounded-r-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

          </div>

          {/* Quotation Estimate Box */}
          <div className="p-4 rounded-xl bg-slate-900 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
                <Calculator className="w-4 h-4" />
                <span>Estimated Rental Quotation</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {rentalType === 'local_darshan'
                  ? `Package: 12 Hours / 120 KM. Driver and parking included.${includeLocalTourGuide ? ' Tour Guide: ₹2,000 flat per vehicle.' : ''} Toll/entry charges extra at actuals.`
                  : `Outstation: ${outstationBreakdown.actualKm || 'Route not calculated'} actual KM; ${outstationBreakdown.billableKm} chargeable KM after ${daysCount * 300} KM minimum.`}
              </p>
              {rentalType === 'outstation' && <div className="mt-2 space-y-1 text-[11px] text-slate-300">
                <div className="flex justify-between gap-3"><span>Running ({outstationBreakdown.billableKm} KM × ₹{activeOutstationRate?.customerPerKm || 0})</span><strong>₹{outstationBreakdown.running.toLocaleString('en-IN')}</strong></div>
                <div className="flex justify-between gap-3"><span>Daily DA / Permit ({daysCount} days)</span><strong>₹{outstationBreakdown.dailyDa.toLocaleString('en-IN')}</strong></div>
                <div className="flex justify-between gap-3"><span>Night DA ({nightCount} × same daily DA)</span><strong>₹{outstationBreakdown.nightDa.toLocaleString('en-IN')}</strong></div>
                <div className="border-t border-white/10 pt-1 flex justify-between gap-3 text-white"><strong>Estimated Total</strong><strong>₹{outstationBreakdown.total.toLocaleString('en-IN')}</strong></div>
                <p className="text-[10px] text-slate-400">Driver allowance / DA-Permit is extra as shown above. Parking, Toll, Border Tax and Entry extra at actuals.</p>
              </div>}
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-2xl font-black text-amber-400 font-mono">₹{estimatedQuotation}</span>
                <span className="text-[10px] text-slate-400 block">Proposed Estimate</span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs hover:from-amber-300 hover:to-amber-400 cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 transition-all shrink-0"
              >
                {isSubmitting ? 'Saving enquiry...' : pendingEnquiry ? 'Retry Saving Enquiry' : 'Send Enquiry'}
              </button>
            </div>
          </div>
        </form>
      )}
      <div className="mt-5 pt-4 border-t border-white/10 flex flex-wrap gap-x-5 gap-y-2 text-xs text-slate-400">
        <a href={`tel:${settings.businessPhone}`} className="inline-flex items-center gap-1.5 hover:text-amber-300"><Phone className="w-3.5 h-3.5" /> +91 {settings.businessPhone}</a>
        <a href={`mailto:${settings.businessEmail}`} className="inline-flex items-center gap-1.5 hover:text-amber-300"><MessageSquare className="w-3.5 h-3.5" /> {settings.businessEmail}</a>
      </div>
    </div>
  );
};
