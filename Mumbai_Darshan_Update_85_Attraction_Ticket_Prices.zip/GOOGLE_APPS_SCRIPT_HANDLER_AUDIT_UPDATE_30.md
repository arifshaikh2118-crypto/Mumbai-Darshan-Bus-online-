# Google Apps Script Handler-to-Schema Audit — Update 30

**Scope:** Static source audit of `google-apps-script/Code.gs` and its visible server/Admin callers. No live Apps Script or Google Sheet was accessed.

## Action routing matrix

| Incoming action / path | Source handler | Sheet(s) involved | Static source finding | Runtime status |
|---|---|---|---|---|
| `NEW_BOOKING` | `handleNewBooking` | `booking`, `booking_payments` | Booking row + pending payment ledger path exists; booking must remain pending until trusted payment verification. | Not tested against staging |
| `NEW_RENTAL_ENQUIRY` / `CAR_RENTAL` | `handleRentalEnquiry` | `rental_enquiry` | Inquiry-only save path exists; no rental email dispatch in this handler. | Not tested against staging |
| `PAYMENT_VERIFIED` | `handleVerifiedPayment` | `booking_payments`, `booking` | Trusted secret/provider verification gate and payment-first update path exist in source. No provider checkout/callback integration is active. | Not tested; gateway deferred |
| `ADMIN_AUTH_CHECK` | `handleAdminApiAction_` | `AdminUsers`, `activity_log` | Requires server-to-server `ADMIN_API_SECRET`, active allowlisted email and permitted role. | Not tested against deployed Apps Script |
| `ADMIN_GET_DATA` | `handleAdminApiAction_` | booking, rental, payment, cancellation and operational/log/report sheets | Protected read returns multiple datasets; deliberately excludes `AdminUsers` and `Settings`. | Not tested against staging |
| `ADMIN_UPSERT_OPERATIONAL_RECORD` | `handleAdminApiAction_` | Seven approved operational tabs | Allowlist + approved header validation + required key + Activity Log. | Not tested against staging |
| `ADMIN_DELETE_OPERATIONAL_RECORD` | `handleAdminApiAction_` | Seven approved operational tabs | Allowlist + required key + Activity Log. | Not tested against staging |
| `ADMIN_UPDATE_BOOKING_STATUS` | `handleAdminApiAction_` | `booking`, `activity_log` | Status allowlist; prevents Confirmed/Completed unless payment status is Advance Paid/Fully Paid. | Not tested against staging |
| `ADMIN_UPDATE_RENTAL_STATUS` | `handleAdminApiAction_` | `rental_enquiry`, `activity_log` | Status allowlist; writes status only; no quotation/supplier cost/margin fields. | Not tested against staging |
| Public `UPDATE_BOOKING_STATUS` | `handleBookingStatusUpdate` | None | Explicitly disabled/fail-closed. Admin must use secure `/api/admin/bookings/status` server route. | Expected reject |
| Public `UPDATE_RENTAL_STATUS` | `handleRentalStatusUpdate` | None | Explicitly disabled/fail-closed. Admin must use secure `/api/admin/rentals/status` server route. | Expected reject |
| Public `RETRY_EMAILS` / `TEST_EMAIL` | `doPost` switch | None | Explicitly disabled on public webhook. A secure Admin-only email retry/test endpoint is not currently exposed in `server.ts`. | Expected reject |
| `OFFLINE_ATTRACTION_COLLECTION` | `doPost` switch | None | Explicitly disabled because it is not part of approved schema. | Expected reject |
| `PING_TEST` / health GET | `doPost` / `doGet` | None | Health response only. | Not tested against deployed endpoint |
| `lookup` GET | `lookupBooking` | `booking` | Looks up by booking ID or phone. This is a public GET path in current source; privacy/rate-limit/authorization review is required before public deployment. | Not tested; security review required |

## Sheet workflow coverage observed in Code.gs

| Approved sheet | Source usage found | Assessment |
|---|---|---|
| `booking` | create, payment confirmation, Admin status, lookup, protected read | Core paths implemented; staging verification pending |
| `rental_enquiry` | create, Admin status, protected read | Inquiry-only path implemented; staging verification pending |
| `booking_payments` | pending ledger creation, verified payment update, protected read | Core payment ledger path implemented; provider integration deferred |
| `booking_cancellations` | protected Admin read only | Cancellation creation/refund workflow not found in current Code.gs |
| `booking_notifications` | protected Admin read only | Notification write/dispatch workflow not found in current Code.gs |
| `EmailLog` | protected Admin read; email helper functions exist | Confirm that email helper functions append exact approved EmailLog rows; source audit found no obvious EmailLog append in current Code.gs |
| `activity_log` | Admin/system best-effort append | Write path exists; failures are swallowed by best-effort logger; staging verification and failure monitoring pending |
| `daily_reports` | protected Admin read; daily report function/trigger helpers exist | Need inspect/test whether report writes exact approved 8 columns and trigger is configured; not executed |
| `AdminUsers` | Admin roster authorization | Used server-side only; not returned to browser |
| `Settings` | schema/bootstrap only in inspected routes | Not returned to browser; settings read/write admin workflow not implemented here |
| `PickupPoints`, `PackageOptions`, `BookingDates`, `rental_vehicles`, `website_content`, `AttractionPoints`, `AttractionTickets` | protected read + generic Admin upsert/delete | Source implementation present; browser/staging CRUD tests pending |

## Findings requiring follow-up

1. **Cancellation/refund:** schema exists and Admin read includes cancellation rows, but no cancellation creation/refund handler was found in the inspected Apps Script source. Implement only after confirming exact owner workflow and payment provider/refund capabilities.
2. **Notifications:** `booking_notifications` is read but no append/dispatch path was found. Define events and delivery channel before implementing; do not create false “sent” statuses.
3. **EmailLog:** email sending/retry helpers exist, but this audit did not find an obvious write to the approved `EmailLog` tab. Cross-check helper functions and add exact-column logging if missing. Rental enquiries must remain excluded from email notifications.
4. **Daily reports:** scheduled report helper/trigger code exists, but trigger installation and exact `daily_reports` persistence need source-level test and staging verification. Do not execute trigger setup now.
5. **Public booking lookup:** GET lookup appears unauthenticated and returns customer contact/travel/payment details. Add an explicit privacy-safe access policy, authentication or minimal response + rate limit before public release.
6. **Public update actions:** `UPDATE_BOOKING_STATUS` and `UPDATE_RENTAL_STATUS` are disabled. Admin UI should use the authenticated `/api/admin/.../status` routes, never the generic public webhook. Confirm all UI entry points use these secure routes.
7. **No deployment proof:** all findings are from static code inspection. No Apps Script runtime, Sheet, email, trigger, payment or browser request was executed.

## Recommended next source tasks

1. Audit/fix public booking lookup privacy and rate limiting.
2. Complete EmailLog exact-column write path and tests.
3. Define/implement booking notification events and persistence without rental enquiry email.
4. Define cancellation/refund lifecycle; keep provider-dependent refund execution disabled until gateway support exists.
5. Validate daily report calculations and exact 8-column persistence with a fake Spreadsheet harness, then stage-test later.
6. Run full build/browser and real staging tests only after the deferred network runner and staging setup are approved.
