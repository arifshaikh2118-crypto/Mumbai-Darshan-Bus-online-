# Update 20 — Rental Enquiry-Only Workflow (19 Approved Columns)

Last updated: 11 November 2026

## Completed

- Kept the approved `rental_enquiry` sheet at exactly 19 columns. No tabs or headings were added, removed, or renamed.
- Replaced the legacy rental Admin quotation/margin interface with a customer-enquiry management view showing the approved request details, status, and WhatsApp follow-up.
- Status workflow is now exactly: `New`, `Contacted`, `Quote Sent`, `Follow-up`, `Confirmed`, `Not Interested`, `Cancelled`.
- Applied the same status allow-list in the browser UI, Express authenticated route, and Apps Script Admin action.
- New enquiries are written with status `New`. Existing legacy statuses are normalized for display (`New Enquiry` → `New`, old quotation/availability states → `Follow-up`/`Quote Sent`, `Completed` → `Confirmed`) without changing old sheet rows until an Admin explicitly saves a new status.
- Admin view now maps the complete 19-column data set: ID, customer, mobile, vehicle type, travel date, pickup, destination, trip type, persons, days, special request, status, created time, preferred model, Tempo Traveller seats, other seat capacity, AC preference, rental duration, and pickup time.
- Removed supplier-cost, supplier-rate, quote, and margin fields from the rental enquiry model and customer enquiry UI. Rental enquiry is not a supplier-rate or profit-management system.
- Removed legacy rental demo records from browser fallback. Existing browser-local rental drafts are scrubbed of unsupported financial/contact/garage-route fields when read.
- Removed the optional customer-email field from the rental form because it is not part of the approved 19-column schema. Rental enquiry sync sends only the approved 19-column field set.
- Rental enquiry remains inquiry-only. No owner/customer email is sent. WhatsApp is a manual follow-up action and contains no fabricated quotation.

## Verification

- `node google-apps-script/tests/test_schema_alignment.cjs`: PASS.
- `node google-apps-script/tests/test_admin_security.cjs`: PASS.
- Apps Script syntax check (`node --check` on a temporary `.js` copy): PASS.
- Static rental workflow checks: PASS — exact status list matches across UI/server/Apps Script; 19-column schema remains unchanged; no supplier/quotation/margin identifiers remain in browser `src`; no rental email dispatch added.
- TypeScript/TSX transpile syntax check: PASS (all source TS/TSX files).
- Full `tsc --noEmit` and Vite production build: NOT VERIFIED; dependencies are not installed in this working environment.
- No live Google Sheet writes, Apps Script deployment, GitHub commit, Preview update, or production deployment performed.

## Files changed

- `src/components/admin/AdminRentalsTab.tsx`
- `src/components/admin/AdminLayout.tsx`
- `src/components/admin/AdminReportsTab.tsx`
- `src/components/CarRentalPanel.tsx`
- `src/services/storage.ts`
- `src/types/index.ts`
- `src/data/initialData.ts`
- `server.ts`
- `google-apps-script/Code.gs`
- `google-apps-script/tests/test_schema_alignment.cjs`
- `UPDATE_20_RENTAL_ENQUIRY_ONLY_WORKFLOW.md`
- `PROJECT_INDEX.md`

## Remaining

- No supplier-rate, supplier-cost, margin, or supplier-quotation module is required or planned for this workflow. The existing outstation/local rental prices are final customer-facing rates only.
- Remaining Admin configuration tabs and the full build/live integration checks remain pending as recorded in the Master Progress Tracker.
