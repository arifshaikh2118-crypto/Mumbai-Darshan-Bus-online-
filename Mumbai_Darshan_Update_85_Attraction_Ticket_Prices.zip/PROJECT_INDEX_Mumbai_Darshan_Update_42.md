# Mumbai Darshan Bus Online — Master Progress Tracker

**Current package:** Update 42 — Admin Login Throttle & Upstream Request Resilience  
**Baseline:** Update 41 — Network Build Workflow Hardening  
**Date:** 20 November 2026

## Owner sequencing instruction

- [x] GitHub work must wait until the complete project files and remaining local work are finished.
- [x] Update 42 did not commit/push code, run GitHub Actions, refresh Preview or deploy.
- [ ] GitHub/network-enabled build phase only after local source and project files are complete.

## Completed source work

- [x] Approved 17-tab / 139-header schema manifest and bootstrap source retained.
- [x] Booking server-side pricing/advance calculation and duplicate partial-write reconciliation gate retained.
- [x] Rental enquiry remains inquiry-only; no owner/customer rental email.
- [x] Admin session, secret-gated Apps Script actions and active AdminUsers roster retained.
- [x] Public lookup/cancellation privacy and throttling retained.
- [x] EmailLog, notifications, cancellation/refund review and Daily Reports source retained.
- [x] Update 36 protected Admin dispatch, public mutation lockdown, proxy allowlist and server-configured webhook URL fixes retained.
- [x] Update 37 Firebase guide corrected to explain Express API hosting requirement.
- [x] Update 38 added dependency-free offline validation runner.
- [x] Update 39 public Express proxy requires explicit allowed action; Apps Script rejects missing/blank action.
- [x] Update 40 runtime tests reject missing, blank and non-string actions; lock release and explicit PING_TEST verified.
- [x] Update 41 hardened manual network build workflow definition; it remains unexecuted and is deferred until local files are complete.
- [x] Update 42 fixed expired Admin login lockout-window reset order.
- [x] Update 42 added 30-second timeout to all 3 Apps Script fetch paths.
- [x] Update 42 added regression coverage and updated README.
- [x] `npm run test:offline` PASS, 12/12.
- [x] TypeScript/TSX syntax transpilation PASS, 29 files / 0 syntax errors.
- [x] Key JSON manifests PASS, 4/4.

## Latest verification status

| Check | Result |
|---|---|
| Apps Script CJS regression suites | PASS, 9/9 |
| Apps Script `Code.gs` syntax | PASS |
| Runtime webhook explicit-action checks | PASS |
| Admin login throttle policy regression | PASS |
| Three upstream Apps Script timeout guards | PASS |
| CI workflow static safety test | PASS |
| Offline validation runner | PASS, 12/12 |
| TypeScript/TSX syntax transpilation | PASS, 29/29 |
| Key JSON manifests | PASS, 4/4 |
| npm registry access | BLOCKED — DNS `EAI_AGAIN` |
| npm cache | No usable package cache entries |
| `package-lock.json` | MISSING |
| `bun.lock` | EMPTY, unusable |
| `node_modules` | ABSENT |
| Full `npm run lint` | PENDING — dependencies/types unavailable |
| `npm run build` | PENDING — dependencies unavailable |
| GitHub Actions workflow | NOT RUN — deferred by owner |
| Browser E2E | PENDING |
| Hosting architecture / API runtime | PENDING owner/developer confirmation |
| Google Sheets staging | PENDING owner approval |

## Remaining local work before GitHub

- [ ] Continue local source audit and close remaining code/documentation gaps.
- [ ] Review every frontend API payload mapping against Apps Script handlers and approved schema.
- [ ] Expand offline regression tests when a real defect is found.
- [ ] Preserve current UI, pricing, booking rules and approved schema unless the owner approves a change.
- [ ] Complete source/package files before GitHub activity.

## Later — network build, browser E2E and staging

### P0 — Network-enabled build (only after local files are complete)
- [ ] Owner/developer commits/pushes project source to intended GitHub repository.
- [ ] Manually run **Mumbai Darshan Network Build Validation** workflow.
- [ ] Verify npm install generates a valid package-lock.
- [ ] Verify clean `npm ci` passes.
- [ ] Verify `npm run lint` passes.
- [ ] Verify `npm run build` passes.
- [ ] Review uploaded lockfile and dist artifacts; record workflow URL and commit SHA.

### P0 — Hosting architecture and browser E2E
- [ ] Confirm hosting target for Express server.
- [ ] If Firebase Hosting + Cloud Run is approved, confirm actual service ID and region, then configure `/api/**` rewrite before SPA fallback.
- [ ] Verify `/api/*` reaches Express and Admin routes reject unauthenticated calls.
- [ ] Run browser E2E for booking submit/retry, rental inquiry, lookup, cancellation, Admin login/session expiry, status updates, email retry, refunds, reports and seven operational CRUD tabs.
- [ ] Test mobile booking flow and rental enquiry panel immediately below booking form.

### P1 — Google Sheets / Apps Script staging (owner approval only)
- [ ] Run `setupDatabase()` once against isolated staging.
- [ ] Confirm exact 17 tabs / 139 headers and approved seed data.
- [ ] Configure private server environment and Apps Script Script Property secrets.
- [ ] Test booking/payment-pending ledger writes, duplicate retries, rental inquiry-only writes, lookup/cancellation, Admin reads/mutations, EmailLog, notifications and daily reports.
- [ ] Test concurrency and throttling.
- [ ] Owner-approved controlled email test; only then decide on trigger installation.

### P2 — Later separately approved delivery
- [ ] Preview refresh after build/tests and approval.
- [ ] PhonePe integration after merchant credentials and server-side signature/status verification.
- [ ] Production Apps Script deployment, email activation, DNS/domain changes and website deployment only with explicit approval.

## Preserved business and safety rules

- No changes to approved sheet tabs/columns without permission.
- No supplier cost/rate/margin/private garage information in customer-facing code.
- No extra ₹5 rental-rate markup; approved customer rates remain unchanged.
- ₹200 advance is per booking, not per person.
- No automatic refund; PhonePe remains deferred.
- No rental enquiry emails; follow up via WhatsApp.
- No live Sheet, Apps Script, GitHub, Preview or production action without explicit approval.

**Overall: INCOMPLETE. Update 42 fixes Admin login throttle-window reset and adds 30-second upstream timeouts. Offline tests pass 12/12 and 29 TypeScript/TSX files pass syntax transpilation. GitHub work is deferred by owner instruction until local project files are complete. Dependency installation, semantic type-check/build, browser E2E, hosting runtime and isolated live staging remain pending.**
