# Mumbai Darshan Bus Online — Master Progress Tracker
## Update 31 — Four critical backend workflows completed in source

**Date:** 11 November 2026  
**Source baseline:** Update 30  
**Current source package:** Update 31  
**Important:** Source implementation and local automated verification do not equal live deployment or real Google Sheets operation.

## 1. Four critical tasks requested by owner

| Task | Source status | Local verification | Live verification |
|---|---|---|---|
| Booking lookup privacy/security | Implemented | PASS | Pending |
| EmailLog six-column workflow | Implemented | PASS | Pending |
| Booking notifications and Admin retry | Implemented | PASS | Pending |
| Cancellation/refund workflow | Implemented | PASS | Pending |

### 1A. Booking lookup security — done in source
- Old GET lookup disabled.
- Requires exact Booking ID + registered 10-digit mobile.
- Rate limiting at server and Apps Script layers.
- Returns masked/minimal booking status projection only.
- Does not return email, full mobile, special request or payment transaction references.
- Customer lookup screen now uses backend API, not localStorage.

### 1B. EmailLog — done in source
- Exact six approved columns preserved: `Timestamp, Booking ID, Recipient Type, Recipient, Status, Error`.
- Customer and owner confirmation sends/retries, connection-test email, and daily report email attempts append Sent/Failed/Skipped outcomes.
- Live email remains OFF by default and requires owner setting.
- No rental enquiry emails.

### 1C. Notifications — done in source
- Exact eight approved columns preserved.
- Idempotent notification upsert for customer/owner booking confirmation after verified payment.
- Disabled email remains queued; send attempts update notification status and sent timestamp.
- Cancellation/refund events are recorded as internal Admin follow-up, not falsely represented as delivered email or WhatsApp.
- Authenticated Admin email retry route and UI added. Sent recipients are not resent on retry.

### 1D. Cancellation/refund — done in source
- Public cancellation request requires Booking ID + registered mobile + reason.
- Rate limiting and duplicate pending-request checks.
- Exact eight approved cancellation columns preserved.
- Refund review amount derives only from verified payment ledger entries.
- Admin session-protected review statuses: Pending Review, Approved, Refunded, Rejected.
- `Refunded` requires explicit confirmation of a completed manual refund.
- No gateway refund is sent. PhonePe remains deferred.
- Cancellation/refund controls added to Admin; customer lookup page submits real backend cancellation request.

## 2. Other source work already completed in earlier updates
- 17 approved Google Sheets tabs / 139 approved header cells represented in schema.
- Booking 21-column mapping; rental enquiry 19-column inquiry-only mapping.
- Payment ledger 9-column mapping and trusted payment verification gate.
- Secure Admin login/session, protected Admin data retrieval, booking/rental status updates.
- Seven operational tabs have Add/Edit/Delete UI and protected Apps Script APIs.
- Customer-facing rental rates preserved with the already-added ₹5; no supplier rate/cost/margin system.
- Activity Log writes exist for Admin operations and lifecycle actions.

## 3. Update 31 local verification results
- [x] Seven automated CJS test suites pass.
- [x] Schema harness validates lookup, EmailLog, notifications, cancellation/refund paths.
- [x] Apps Script syntax check passes.
- [x] TypeScript/TSX syntax transpile passes for 30 source files (syntax-only).
- [x] Existing schema remains 17 tabs / 139 headers.
- [x] No new tabs or columns added.
- [x] Rental enquiry remains 19 columns and inquiry-only.

## 4. Remaining work — exact list and order

### P0 — Build/browser validation (owner previously deferred GitHub runner work)
- [ ] Full `npm run lint` / `tsc --noEmit`; currently blocked by missing `vite/client` dependency.
- [ ] Vite production build.
- [ ] Browser E2E for booking lookup (valid/invalid ID/mobile, rate limit, no PII leakage).
- [ ] Browser E2E for cancellation request and duplicate prevention.
- [ ] Admin browser tests for EmailLog/notification view, retry, cancellation status and manual-refund confirmation.
- [ ] Verify all seven operational sheet CRUD screens in browser.

### P1 — Staging Apps Script / Google Sheets verification
- [ ] At approved staging stage, run `setupDatabase()` once; owner does not manually create the spreadsheet.
- [ ] Set server-only `ADMIN_API_SECRET`, `ADMIN_PASSCODE`, `ADMIN_SESSION_SECRET`, and Apps Script properties securely.
- [ ] Test actual lookup and cancellation writes against staging Sheets.
- [ ] Test EmailLog and notification rows against staging Sheets.
- [ ] Test Admin retry with a controlled email recipient after owner authorizes MailApp.
- [ ] Verify cancellation refund amount against verified payment ledger and owner policy.
- [ ] Confirm exact 17 tabs / 139 headers remain intact.

### P2 — Other pending backend workflows
- [ ] Daily Reports: exact eight-column `daily_reports` sheet write/aggregation and scheduled trigger verification.
- [ ] Review remaining handler coverage and failure recovery/idempotency.
- [ ] Complete any remaining Admin panels for reports/settings that are within approved schema.

### P3 — Later delivery milestones
- [ ] Network-enabled GitHub runner workflow (explicitly deferred for now by owner).
- [ ] GitHub source commit after approval/workflow step.
- [ ] Update the existing Preview URL only after successful build/browser validation.
- [ ] PhonePe integration after merchant credentials and secure provider verification are ready.
- [ ] Final deployment only after owner approval.

## 5. Safety / unchanged decisions
- Do not create or rename schema tabs/columns without owner approval.
- Do not run `setupDatabase()` or deploy Apps Script until owner-approved final/staging setup.
- No live email sending until owner enables it and MailApp is tested.
- No automatic refund; PhonePe remains deferred.
- Rental enquiries are inquiry-only; no customer/owner email.
- No supplier rate, cost, margin, profit or supplier-private data workflow.
- Keep existing customer rental prices; do not add another ₹5.
- Do not update GitHub, Preview or production as part of this update.

## 6. Current overall status

**Four critical audit findings are implemented in source and pass local automated tests.** The project is still not live-ready: full type-check/build, browser E2E, Apps Script/Google Sheets staging tests and authorized email delivery remain pending. Daily Reports and remaining backend audit are next after the four-item milestone.
