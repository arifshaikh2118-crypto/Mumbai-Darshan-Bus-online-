# Update 57 — Legacy booking-ID endpoint validation and throttling

**Date:** 20 November 2026  
**Scope:** Local server source and regression tests only. No external integrations or deployment.

## Finding

The legacy `/api/bookings/validate-and-create` endpoint was not referenced by the current frontend source, but it remained publicly reachable. It generated a booking ID without per-IP throttling, accepted weakly validated fields, used UTC for the date prefix, and used `Math.random()` for the suffix. Its response only generated an ID; it did not persist a booking.

## Changes

- Added `server/bookingRequestValidation.ts` to validate request shape, customer name length, exactly 10 mobile digits, strict `YYYY-MM-DD` date format, real calendar dates, local-today-or-future travel date, and bounded route/package identifiers.
- Added an independent per-IP limit of 8 calls per 10 minutes to the legacy ID-generation endpoint, using the existing bounded public rate-limiter store.
- Booking ID date prefix now uses the server's local calendar date rather than UTC.
- Booking ID suffix now uses `crypto.randomInt()` rather than `Math.random()`.
- Clarified in source comments that this legacy endpoint generates an ID only and does not persist a booking. The approved booking write flow remains `/api/sync-sheets`.
- Added `validation/test_booking_id_endpoint_hardening.cjs` with checks for valid data, past/impossible/malformed dates, invalid mobile, overlong fields, missing data, local date prefix, rate limit and cryptographic random suffix.

## Verification

- Offline validation runner: **27/27 PASS**.
- TypeScript/TSX/JS/JSX syntax transpilation: **34/34 PASS** (syntax-only; not a semantic type-check).
- JSON manifests: **6/6 PASS**.
- ZIP integrity: **PASS**.
- Full npm lint/build: **not run**; project dependencies are not installed locally.
- Browser E2E: **pending**.

## Scope and limitations

- The endpoint remains a legacy ID-generation endpoint and is not a booking persistence API. It was not found referenced in current frontend source, but it has been retained rather than removed to avoid breaking an unknown external caller.
- The rate limiter is process-local/in-memory, resets on restart and is not shared across multiple server instances.
- No booking UI, pricing, approved business rule, Google Sheets schema, Apps Script, payment, GitHub, live email or deployment change.

**Project status remains INCOMPLETE and NOT production-ready.**
