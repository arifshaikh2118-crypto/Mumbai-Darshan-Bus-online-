# Mumbai Darshan Bus Online — Master Progress Tracker

**Current package:** Update 40 — Runtime Webhook Validation & Dependency Network Diagnosis  
**Baseline:** Update 39 — Explicit Public Action Validation & Regression Hardening  
**Date:** 20 November 2026

## Completed source work

- [x] Approved 17-tab / 139-header schema manifest and bootstrap source retained.
- [x] Booking server-side pricing/advance calculation and duplicate partial-write reconciliation gate retained.
- [x] Rental enquiry remains inquiry-only; no owner/customer rental email.
- [x] Admin session, secret-gated Apps Script actions and active AdminUsers roster retained.
- [x] Public lookup/cancellation privacy and throttling retained.
- [x] EmailLog, notifications, cancellation/refund review and Daily Reports source retained.
- [x] Update 36 protected Admin dispatch, public mutation lockdown, proxy allowlist and server-configured webhook URL fixes retained.
- [x] Update 37 Firebase guide corrected to explain Express API hosting requirement.
- [x] Update 38 added dependency-free offline validation runner.
- [x] Update 39 public Express proxy requires explicit allowed action; missing/blank action no longer defaults to booking.
- [x] Update 39 Apps Script `doPost` rejects missing/blank action.
- [x] Update 40 added runtime webhook tests for missing, blank and non-string actions.
- [x] Update 40 verifies script lock is released for rejected payloads and explicit `PING_TEST` remains functional.
- [x] Update 40 `npm run test:offline` passes 10/10 checks.

## Latest verification status

| Check | Result |
|---|---|
| Apps Script CJS regression suites | PASS, 9/9 |
| Apps Script `Code.gs` syntax | PASS |
| Runtime webhook explicit-action checks | PASS |
| Offline validation runner | PASS, 10/10 |
| Key JSON manifests | PASS, 4/4 |
| Update 40 ZIP integrity | PASS |
| npm registry access | BLOCKED — DNS `EAI_AGAIN` |
| `package-lock.json` | MISSING |
| `bun.lock` | EMPTY, unusable |
| Dependency installation | BLOCKED — npm registry DNS/network failure |
| `npm run lint` / `tsc --noEmit` | BLOCKED — missing `vite/client` type definitions |
| `npm run build` | PENDING — dependencies unavailable |
| Browser E2E | PENDING |
| Hosting architecture / API runtime | PENDING owner/developer confirmation |
| Google Sheets staging | PENDING owner approval |
| Apps Script live concurrency | PENDING owner-approved staging |

## Remaining work before any external deployment

### P0 — Dependency installation and build
- [ ] Use a network-enabled runner with working DNS access to `registry.npmjs.org`.
- [ ] Generate and review a valid npm `package-lock.json`.
- [ ] Install dependencies reproducibly with `npm ci`.
- [ ] Pass `npm run lint` and `npm run build`.
- [ ] Resolve semantic TypeScript/build errors.
- [ ] Keep `npm run test:offline` as a fast regression check, not a replacement for build tests.

### P0 — Hosting architecture and browser E2E
- [ ] Confirm hosting target for Express server.
- [ ] If Firebase Hosting + Cloud Run is approved, confirm actual service ID and region, then configure `/api/**` rewrite before SPA fallback.
- [ ] Verify `/api/*` requests reach Express and Admin routes reject unauthenticated calls.
- [ ] Run browser E2E for booking submit/retry, rental inquiry, lookup, cancellation, Admin login/session expiry, status updates, email retry, refunds, reports and seven operational CRUD tabs.
- [ ] Test mobile booking flow and rental enquiry panel immediately below booking form.

### P1 — Google Sheets / Apps Script staging (owner approval only)
- [ ] Run `setupDatabase()` once against isolated staging.
- [ ] Confirm exact 17 tabs / 139 headers and approved seed data.
- [ ] Configure private server environment and Apps Script Script Property secrets.
- [ ] Test booking/payment-pending ledger writes, duplicate retries, rental inquiry-only writes, lookup/cancellation, Admin reads/mutations, EmailLog, notifications and daily reports.
- [ ] Test concurrency and throttling.
- [ ] Owner-approved controlled email test; only then decide on trigger installation.

### P2 — Later separately approved delivery
- [ ] GitHub source commit after build/tests and approval.
- [ ] Refresh existing Preview URL only after backend connectivity and browser E2E pass; do not create a new site.
- [ ] PhonePe integration after merchant credentials and server-side signature/status verification.
- [ ] Production Apps Script deployment, email activation, DNS/domain changes and website deployment only with explicit approval.

## Preserved rules

- No changes to approved sheet tabs/columns without permission.
- No supplier cost/rate/margin/private garage information in customer-facing code.
- No extra ₹5 rental-rate markup; approved customer rates remain unchanged.
- ₹200 advance is per booking, not per person.
- No automatic refund; PhonePe remains deferred.
- No rental enquiry emails; follow up via WhatsApp.
- No live Sheet, Apps Script, GitHub, Preview or production action without explicit approval.

**Overall: INCOMPLETE. Update 40 adds runtime-level webhook action tests and confirms the dependency blocker is npm registry DNS resolution (`EAI_AGAIN`). Dependency installation, full lint/build, browser E2E, hosting runtime and isolated live staging remain release blockers.**
