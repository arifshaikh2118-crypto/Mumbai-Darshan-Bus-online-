# Update 60 — Attraction selection moved to the bus only

**Date:** 20 November 2026  
**Scope:** Local customer booking UI, booking payload, Apps Script booking handler, and regression tests. No live spreadsheet, Apps Script deployment, or production deployment was performed.

## Owner clarification

Customers must **not select attraction points while making an online bus booking**. They will decide which attractions to visit only after boarding, in consultation with the Tour Guide.

## Changes made

- Removed all attraction checkbox/selection controls and per-person attraction price calculations from the customer booking flow.
- Replaced the booking-step attraction selector with a clear explanation: no attraction selection or payment is required online; the customer decides on the bus with the Tour Guide, and applicable ticket charges are collected there.
- Booking receipts now show the same on-bus decision instruction and explicitly state that no attraction was pre-selected.
- New booking objects keep the legacy type-compatible fields empty (`selectedOptionalAttractions: []`, `totalOptionalAmount: 0`); no attraction names, passenger counts, or attraction fees are sent to the booking backend.
- Removed attraction fields from the `NEW_BOOKING` payload.
- Apps Script now stores only the customer's own special request in the existing Special Request column. Any legacy/client-supplied `optionalAttractions` payload is ignored.
- No approved sheet tabs, columns, or headers were added, removed, or renamed. Attraction directory/ticket information pages and Admin operational configuration remain available; this change is specifically to customer booking selection.
- Package fare, ₹200 advance, guide charge, Sea Link toll, food selection, and payment status rules were not changed.

## Regression tests and verification

- Offline validation runner: **28/28 PASS**.
- TypeScript/TSX syntax transpilation: **35/35 PASS**, zero syntax diagnostics (syntax-only, not a semantic type-check).
- JSON manifests/configuration: **6/6 PASS**.
- Apps Script syntax/runtime tests: **PASS** as part of the offline suite.
- ZIP integrity: PASS after archive creation (all entries tested).
- Full npm lint/build: not run; dependencies are not installed locally.
- Browser E2E and live Google Sheets/Apps Script integration: pending.

## Scope boundaries

No Google Sheet creation, Apps Script execution/deployment, payment gateway, GitHub commit/push, Preview refresh, live email, or production deployment was performed. No live data was modified.

**Correction to Update 59:** Update 59's attraction selection persistence behavior is superseded. Attraction choices are not customer booking inputs and must not be recorded as pre-selections. The Special Request column remains reserved for the customer's actual special request.

**Overall status: INCOMPLETE / NOT production-ready.** Local source and offline tests reflect the clarified business rule; live integration and browser testing remain outstanding.
