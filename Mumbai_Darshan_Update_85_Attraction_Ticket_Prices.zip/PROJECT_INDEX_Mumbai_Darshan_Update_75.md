# Mumbai Darshan Bus Online — Master Progress Tracker

## Latest update — Update 75 (20 November 2026)

### English language guard expanded
- Expanded the English-only source guard from frontend files and `index.html` to include `PREVIEW.html`, `server.ts`, and `google-apps-script/Code.gs`.
- The scan now covers all frontend TS/TSX/JS/JSX source files (including Admin UI), initial data, page HTML, server API messages, Apps Script webhook responses, and email/report template source.
- Guard checks Devanagari text and known legacy Romanized Hindi/Hinglish phrases.
- English-copy guard: **35 source/HTML files PASS**; no additional non-English copy found in the newly included server/Apps Script/Preview targets.
- Offline validation: **40/40 PASS**.
- TypeScript/TSX/JS/JSX syntax transpilation: **32 files, 0 errors**; Apps Script syntax PASS; JSON **6/6 PASS**.
- Full semantic type-check/build and browser E2E remain pending because `node_modules` is absent. Live Sheets/Apps Script testing not run.
- Runtime-configured content stored in Google Sheets must still be reviewed separately; static source scan cannot guarantee future user-entered text is English.
- No UI layout, pricing, business rules, schema, booking/payment/cancellation behavior, PhonePe, live data, or production deployment changed.

**Overall status: INCOMPLETE / NOT production-ready.**

## Project safety rules
- No production deployment or live Google Sheets / Apps Script changes without explicit approval.
- Keep Supabase until migration is fully tested and removal is explicitly approved.
- Keep PhonePe/payment gateway deferred.
- Preserve approved schema, pricing, booking rules, and customer-facing flow unless explicitly authorized.
- Customer-facing website, Admin UI, booking messages, notifications, and project documentation should be in English. Conversation with the owner may remain Hindi/Hinglish.
