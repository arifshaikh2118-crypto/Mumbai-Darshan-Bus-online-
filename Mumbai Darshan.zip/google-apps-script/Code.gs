/**
 * =========================================================================
 * MUMBAI DARSHAN BUS ONLINE - AUTHORITATIVE GOOGLE APPS SCRIPT ENGINE
 * =========================================================================
 * Production Domain: https://mumbaidarshanbusonline.com
 * Official Business Phone: 9619975457 | Email: mumbaidarshanbooking@gmail.com
 * Registered Office: 110, Sai Krupa Chawl, Bansi Nagar, W. E. Highway,
 *                   Kulupwadi, Borivali East, Mumbai, Maharashtra 400066.
 * 
 * Strict alignment with "Google app script codegx.xlsx" schema:
 * - 21 exact columns for Bookings sheet
 * - Rental Enquiry sheet (Email suppressed, WhatsApp follow-up)
 * - booking_payments, booking_cancellations, booking_notifications
 * - vehicles, rental_pricing, booking_settings, activity_log
 * - Reliable Server-to-Server JSON synchronization (no fake success, no SIMULATED-SUCCESS)
 * - MailApp / GmailApp email integration with owner authorization
 * - Daily Operations Report at 10:00 PM IST
 */

var SPREADSHEET = SpreadsheetApp.getActiveSpreadsheet();

var BUSINESS_CONFIG = {
  NAME: 'Mumbai Darshan Bus Online',
  DOMAIN: 'https://mumbaidarshanbusonline.com',
  PHONE: '9619975457',
  EMAIL: 'mumbaidarshanbooking@gmail.com',
  ADDRESS: '110, Sai Krupa Chawl, Bansi Nagar, W. E. Highway, Kulupwadi, Borivali East, Mumbai, Maharashtra 400066.',
  HOURS: '6:00 AM – 10:30 PM (Daily)'
};

// SAFETY SWITCH:
// Live automated emails are kept disabled until the account owner explicitly
// enables them in the 'Settings' sheet under key 'ENABLE_LIVE_EMAILS' = true.
var DEFAULT_LIVE_EMAILS_ACTIVE = false;

var SHEET_NAMES = {
  SETTINGS: 'Settings',
  BOOKINGS: 'Bookings',
  RENTAL_ENQUIRY: 'Rental Enquiry',
  BOOKING_DATES: 'BookingDates',
  PACKAGE_OPTIONS: 'PackageOptions',
  PICKUP_POINTS: 'PickupPoints',
  ATTRACTION_POINTS: 'AttractionPoints',
  ATTRACTION_TICKETS: 'AttractionTickets',
  BOOKING_PAYMENTS: 'booking_payments',
  BOOKING_CANCELLATIONS: 'booking_cancellations',
  BOOKING_NOTIFICATIONS: 'booking_notifications',
  ACTIVITY_LOG: 'activity_log',
  BOOKING_SETTINGS: 'booking_settings',
  VEHICLES: 'vehicles',
  RENTAL_PRICING: 'rental_pricing',
  OFFLINE_COLLECTIONS: 'Offline_Attraction_Collections'
};

// Exact 21 columns mandated for 'Bookings' sheet
var BOOKINGS_COLUMNS = [
  'Timestamp',
  'Booking ID',
  'Name',
  'Phone',
  'Customer Email',
  'Travel Date',
  'Pickup Route',
  'Pickup Point',
  'Package Key',
  'Package Name',
  'Persons',
  'Veg Biryani Persons',
  'Butter Paneer Persons',
  'Veg Thali Persons',
  'Amount INR',
  'Special Request',
  'Payment Status',
  'Booking Status',
  'Customer Email Status',
  'Owner Email Status',
  'Last Error'
];

/**
 * Handle incoming Webhook POST requests
 */
function doPost(e) {
  var lock = LockService.getScriptLock();
  // Wait up to 15 seconds to acquire lock for safe concurrent operations
  var acquired = lock.tryLock(15000);
  if (!acquired) {
    return createJsonResponse({
      status: 'error',
      message: 'Server busy. Could not acquire lock for concurrent write.'
    }, 429);
  }

  try {
    if (!e || !e.postData || !e.postData.contents) {
      return createJsonResponse({ status: 'error', message: 'No payload received' }, 400);
    }

    var data = JSON.parse(e.postData.contents);
    var action = data.action || 'NEW_BOOKING';
    var result = {};

    switch (action) {
      case 'NEW_BOOKING':
        result = handleNewBooking(data);
        break;
      case 'NEW_RENTAL_ENQUIRY':
      case 'CAR_RENTAL':
        result = handleRentalEnquiry(data);
        break;
      case 'UPDATE_BOOKING_STATUS':
        result = handleBookingStatusUpdate(data);
        break;
      case 'UPDATE_RENTAL_STATUS':
        result = handleRentalStatusUpdate(data);
        break;
      case 'OFFLINE_ATTRACTION_COLLECTION':
        result = handleOfflineAttractionCollection(data);
        break;
      case 'RETRY_EMAILS':
        result = retryFailedEmails(data.bookingId);
        break;
      case 'PING_TEST':
        result = {
          status: 'success',
          message: 'Google Apps Script Webhook is active and healthy.',
          databaseName: 'Mumbai Darshan Bus Online - Database',
          timestamp: Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd HH:mm:ss')
        };
        break;
      default:
        result = { status: 'error', message: 'Unknown action: ' + action };
    }

    logActivity('WEBHOOK_' + action, data.id || data.bookingId || data.customerMobile || 'General', JSON.stringify(result));
    return createJsonResponse(result, 200);

  } catch (err) {
    logActivity('ERROR', 'System', err.toString());
    return createJsonResponse({ status: 'error', message: err.toString() }, 500);
  } finally {
    lock.releaseLock();
  }
}

/**
 * Handle GET requests for booking lookup or health check
 */
function doGet(e) {
  try {
    var params = e ? e.parameter : {};
    var action = params.action || 'health';

    if (action === 'lookup') {
      var query = params.query;
      if (!query) {
        return createJsonResponse({ status: 'error', message: 'Missing query parameter' });
      }
      var booking = lookupBooking(query);
      return createJsonResponse(booking ? { status: 'success', booking: booking } : { status: 'not_found' });
    }

    return createJsonResponse({
      status: 'active',
      business: BUSINESS_CONFIG.NAME,
      service: 'Google Sheets Database & Email Engine',
      version: '4.0.0',
      timestamp: Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd HH:mm:ss')
    });

  } catch (err) {
    return createJsonResponse({ status: 'error', message: err.toString() });
  }
}

/**
 * Inserts new bus booking into 'Bookings' sheet (Exact 21 columns)
 * and dispatches emails if enabled.
 */
function handleNewBooking(b) {
  var sheet = getOrCreateSheet(SHEET_NAMES.BOOKINGS, BOOKINGS_COLUMNS);

  var bId = b.bookingId || b.id;
  if (!bId) {
    bId = 'MDB-' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyyMMdd') + '-' + Math.floor(1000 + Math.random() * 9000);
  }

  // Duplicate Check
  var existingData = sheet.getDataRange().getValues();
  for (var i = 1; i < existingData.length; i++) {
    if (String(existingData[i][1]).trim().toLowerCase() === String(bId).trim().toLowerCase()) {
      return {
        status: 'duplicate',
        bookingId: bId,
        message: 'Booking ID already recorded in Google Sheets database.'
      };
    }
  }

  // Online booking fare is strictly the bus package fare (e.g. ₹1,500 for 3 pax)
  var onlineFare = Number(b.onlineBookingFare || b.grandTotal || b.amountInr || b.amount || 0);
  var persons = Number(b.passengerCount || b.passengers || b.persons || 1);
  var paymentStatus = b.paymentStatus || 'Pending Verification';
  var bookingStatus = b.bookingStatus || 'Confirmed';

  // Email status flags
  var liveEmailsActive = checkLiveEmailsActive();
  var custEmailStatus = 'Queued (Deferred until owner approval)';
  var ownerEmailStatus = 'Queued (Deferred until owner approval)';
  var lastError = '';

  if (liveEmailsActive) {
    // Attempt customer email dispatch
    var custRes = sendCustomerBookingEmail(b, bId);
    custEmailStatus = custRes.status;
    if (custRes.error) lastError += 'Customer Email: ' + custRes.error + '; ';

    // Attempt owner email notification
    var ownerRes = sendOwnerBookingNotification(b, bId);
    ownerEmailStatus = ownerRes.status;
    if (ownerRes.error) lastError += 'Owner Email: ' + ownerRes.error + '; ';
  }

  var row = [
    new Date(),                                                        // 1. Timestamp
    bId,                                                               // 2. Booking ID
    b.customerName || b.name || '',                                    // 3. Name
    "'" + String(b.customerMobile || b.phone || '').replace(/\D/g, '').slice(-10), // 4. Phone
    b.customerEmail || b.email || '',                                  // 5. Customer Email
    b.travelDate || '',                                                // 6. Travel Date
    b.routeName || b.route || '',                                      // 7. Pickup Route
    b.pickupPointName || b.pickupPoint || '',                          // 8. Pickup Point
    b.packageId || b.packageKey || '',                                 // 9. Package Key
    b.packageTitle || b.packageName || b.package || '',                // 10. Package Name
    persons,                                                           // 11. Persons
    Number((b.foodSelections && b.foodSelections.vegBiryani) || b.vegBiryani || 0),   // 12. Veg Biryani Persons
    Number((b.foodSelections && b.foodSelections.butterPaneer) || b.butterPaneer || 0), // 13. Butter Paneer Persons
    Number((b.foodSelections && b.foodSelections.vegThali) || b.vegThali || 0),       // 14. Veg Thali Persons
    onlineFare,                                                        // 15. Amount INR (Online Booking Fare)
    b.specialRequest || '',                                            // 16. Special Request
    paymentStatus,                                                     // 17. Payment Status
    bookingStatus,                                                     // 18. Booking Status
    custEmailStatus,                                                   // 19. Customer Email Status
    ownerEmailStatus,                                                  // 20. Owner Email Status
    lastError                                                          // 21. Last Error
  ];

  sheet.appendRow(row);

  // Also log into booking_payments sheet with NO fake success
  var paySheet = getOrCreateSheet(SHEET_NAMES.BOOKING_PAYMENTS, [
    'Timestamp', 'Payment ID', 'Booking ID', 'Customer Name', 'Amount INR',
    'Payment Type', 'Transaction Ref', 'Status', 'Collector'
  ]);

  var advancePayable = Number(b.advancePayable || (b.paymentMode === 'advance' ? 200 : onlineFare));
  var actualPaid = Number(b.amountPaid || 0);

  paySheet.appendRow([
    new Date(),
    'PAY-' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyyMMdd') + '-' + Math.floor(1000 + Math.random() * 9000),
    bId,
    b.customerName || b.name || '',
    actualPaid,
    b.paymentMode === 'full' ? 'Full Booking Amount' : 'Advance (₹200 per booking)',
    b.transactionRef || 'PENDING_VERIFICATION_ON_BUS',
    paymentStatus,
    'Tour Conductor (Cash / UPI QR on Bus)'
  ]);

  return {
    status: 'success',
    bookingId: bId,
    onlineBookingFare: onlineFare,
    advancePayable: advancePayable,
    customerEmailStatus: custEmailStatus,
    ownerEmailStatus: ownerEmailStatus,
    message: 'Booking successfully synchronized with Google Sheets.'
  };
}

/**
 * Handle new Rental Enquiry (Rental Enquiry sheet)
 * RULE 3E: Do NOT send customer or owner emails for Rental Enquiries.
 * Save in Google Sheets. Use WhatsApp for follow-up.
 */
function handleRentalEnquiry(d) {
  var sheet = getOrCreateSheet(SHEET_NAMES.RENTAL_ENQUIRY, [
    'Timestamp', 'Enquiry ID', 'Customer Name', 'Phone', 'Email',
    'Rental Type', 'Vehicle Type', 'Travel Date', 'Passengers',
    'Pickup Location', 'Destination', 'Duration Days', 'Estimated KM',
    'Quoted Price (₹)', 'Supplier Cost (₹)', 'Gross Margin (₹)',
    'Status', 'Special Requirements'
  ]);

  var enqId = d.id || ('REN-' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyyMMdd') + '-' + Math.floor(100 + Math.random() * 900));

  var quoted = Number(d.customerQuotation || d.quotedPrice || 0);
  var supplierCost = Number(d.supplierCost || 0);
  var margin = quoted > 0 && supplierCost > 0 ? (quoted - supplierCost) : 0;

  sheet.appendRow([
    new Date(),
    enqId,
    d.customerName || '',
    "'" + String(d.customerMobile || d.phone || '').replace(/\D/g, '').slice(-10),
    d.customerEmail || '',
    d.rentalType === 'local_darshan' ? 'Mumbai Local Darshan (12h/120km)' : 'Outstation Journey',
    d.vehicleType || '',
    d.travelDate || '',
    Number(d.passengerCount || 1),
    d.pickupLocation || '',
    d.destination || (d.rentalType === 'local_darshan' ? 'Mumbai Sightseeing' : ''),
    Number(d.daysCount || d.durationDays || 1),
    Number(d.estimatedKm || (d.rentalType === 'local_darshan' ? 120 : 300)),
    quoted,
    supplierCost,
    margin,
    d.status || 'New Enquiry',
    d.specialRequirements || ''
  ]);

  // Notice: Email notification explicitly suppressed for rental enquiries as per Rule 3E.
  return {
    status: 'success',
    enquiryId: enqId,
    message: 'Rental enquiry successfully saved to Rental Enquiry sheet. WhatsApp follow-up enabled.'
  };
}

/**
 * Customer Booking Email Dispatcher
 */
function sendCustomerBookingEmail(b, bId) {
  try {
    var recipient = String(b.customerEmail || b.email || '').trim();
    if (!recipient || recipient.indexOf('@') === -1 || recipient.indexOf('@mumbaidarshanbusonline.com') !== -1) {
      return { status: 'Skipped (No valid customer email provided)' };
    }

    var quota = MailApp.getRemainingDailyQuota();
    if (quota <= 0) {
      return { status: 'Failed', error: 'Daily MailApp quota exceeded' };
    }

    var pax = Number(b.passengerCount || b.passengers || b.persons || 1);
    var onlineFare = Number(b.onlineBookingFare || b.grandTotal || b.amountInr || b.amount || 0);
    var advanceAmount = Number(b.advancePayable || (b.paymentMode === 'advance' ? 200 : onlineFare));
    var balanceOnBus = Math.max(0, onlineFare - advanceAmount);

    var guideFee = pax * 50;
    var tollFee = pax * 10;
    var totalToGuide = guideFee + tollFee;

    var subject = 'Booking Confirmed: Mumbai Darshan Bus - ' + bId + ' (' + (b.travelDate || '') + ')';

    var htmlBody = ''
      + '<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;background:#090a0f;color:#e2e8f0;padding:24px;border-radius:12px;border:1px solid #334155;">'
      + '<div style="text-align:center;border-bottom:1px solid #1e293b;padding-bottom:16px;margin-bottom:20px;">'
      + '  <h2 style="color:#f59e0b;margin:0 0 6px 0;font-size:22px;">' + BUSINESS_CONFIG.NAME + '</h2>'
      + '  <span style="color:#94a3b8;font-size:12px;">Official Booking Voucher & Reservation Confirmation</span>'
      + '</div>'
      + '<p style="font-size:14px;color:#f8fafc;">Dear <strong>' + (b.customerName || b.name || 'Traveler') + '</strong>,</p>'
      + '<p style="font-size:13px;line-height:1.6;color:#cbd5e1;">Your Mumbai Darshan Bus tour has been reserved successfully. Please carry a valid Government ID proof on the day of travel.</p>'
      + '<table style="width:100%;font-size:13px;border-collapse:collapse;margin:16px 0;background:#0f172a;border-radius:8px;overflow:hidden;">'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Booking ID:</td><td style="padding:10px 14px;font-weight:bold;color:#f59e0b;font-family:monospace;">' + bId + '</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Travel Date:</td><td style="padding:10px 14px;font-weight:bold;color:#fff;">' + (b.travelDate || '') + '</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Pickup Route:</td><td style="padding:10px 14px;color:#fff;">' + (b.routeName || b.route || '') + '</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Boarding Point:</td><td style="padding:10px 14px;color:#fff;">' + (b.pickupPointName || b.pickupPoint || '') + ' at <strong>' + (b.pickupTime || '') + '</strong> (Please report 15 mins prior)</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Package:</td><td style="padding:10px 14px;color:#fff;">' + (b.packageTitle || b.packageName || b.package || '') + ' (' + pax + ' Passengers)</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Online Bus Booking Fare:</td><td style="padding:10px 14px;font-weight:bold;color:#f59e0b;font-size:15px;">₹' + onlineFare + '</td></tr>'
      + '  <tr style="border-bottom:1px solid #1e293b;"><td style="padding:10px 14px;color:#94a3b8;">Advance Payment Status:</td><td style="padding:10px 14px;color:#10b981;font-weight:bold;">₹200 per booking (' + (b.paymentStatus || 'Pending Verification') + ')</td></tr>'
      + '  <tr><td style="padding:10px 14px;color:#94a3b8;">Remaining Bus Balance (Payable on Bus):</td><td style="padding:10px 14px;font-weight:bold;color:#fcd34d;">₹' + balanceOnBus + '</td></tr>'
      + '</table>'
      + '<div style="background:#1e1b18;border:1px solid #78350f;border-radius:8px;padding:12px 14px;margin:16px 0;">'
      + '  <strong style="color:#f59e0b;font-size:13px;display:block;margin-bottom:6px;">PAYABLE DIRECTLY TO GUIDE INSIDE BUS (Mandatory Charges):</strong>'
      + '  <ul style="margin:0;padding-left:18px;font-size:12px;color:#e2e8f0;line-height:1.6;">'
      + '    <li>Guide Charge: ₹50/person — Payable directly to Guide inside the bus. (' + pax + ' × ₹50 = ₹' + guideFee + ')</li>'
      + '    <li>Sea Link Toll: ₹10/person — Payable directly to Guide inside the bus. (' + pax + ' × ₹10 = ₹' + tollFee + ')</li>'
      + '    <li><strong>Total payable directly to Guide: ₹60/person (' + pax + ' × ₹60 = ₹' + totalToGuide + ' inside bus).</strong></li>'
      + '  </ul>'
      + '  <span style="font-size:11px;color:#cbd5e1;display:block;margin-top:6px;">* Both charges will be collected directly by the Tour Guide inside the bus. They are NOT included in the online bus booking fare or the ₹200 advance.</span>'
      + '</div>'
      + '<div style="background:#064e3b;border:1px solid #059669;border-radius:8px;padding:12px 14px;margin:16px 0;font-size:12px;color:#d1fae5;line-height:1.5;">'
      + '  <strong>Meal Information:</strong> Breakfast and lunch are included in applicable packages. Breakfast will be served as Samosa or Kanda Poha, as decided by the operator. Drinking water bottles and juice are not included.'
      + '</div>'
      + '<div style="font-size:11px;color:#64748b;margin-top:20px;border-top:1px solid #1e293b;padding-top:12px;line-height:1.5;">'
      + '  <strong>Helpline:</strong> ' + BUSINESS_CONFIG.PHONE + ' | <strong>Email:</strong> ' + BUSINESS_CONFIG.EMAIL + '<br />'
      + '  <strong>Address:</strong> ' + BUSINESS_CONFIG.ADDRESS + '<br />'
      + '  Website: <a href="' + BUSINESS_CONFIG.DOMAIN + '" style="color:#f59e0b;">' + BUSINESS_CONFIG.DOMAIN + '</a>'
      + '</div>'
      + '</div>';

    var plainText = 'MUMBAI DARSHAN BUS ONLINE - BOOKING CONFIRMATION\n\n'
      + 'Booking ID: ' + bId + '\n'
      + 'Customer: ' + (b.customerName || b.name || '') + '\n'
      + 'Date of Travel: ' + (b.travelDate || '') + '\n'
      + 'Pickup: ' + (b.pickupPointName || b.pickupPoint || '') + ' (' + (b.pickupTime || '') + ')\n'
      + 'Package: ' + (b.packageTitle || b.packageName || b.package || '') + ' (' + pax + ' Persons)\n'
      + 'Online Bus Booking Fare: ₹' + onlineFare + '\n'
      + 'Advance Status: ₹200 per booking (' + (b.paymentStatus || 'Pending Verification') + ')\n'
      + 'Remaining Bus Balance: ₹' + balanceOnBus + ' (payable on bus)\n\n'
      + 'MANDATORY CHARGES (COLLECTED DIRECTLY BY GUIDE INSIDE BUS):\n'
      + '- Guide Charge: ₹50/person — Payable directly to Guide inside the bus.\n'
      + '- Sea Link Toll: ₹10/person — Payable directly to Guide inside the bus.\n'
      + '- Total payable directly to Guide: ₹60/person (₹' + totalToGuide + ' for ' + pax + ' passengers)\n'
      + 'These charges are collected separately inside the bus and are NOT included in the online fare.\n\n'
      + 'MEAL NOTICE:\n'
      + 'Breakfast and lunch are included in applicable packages. Breakfast will be served as Samosa or Kanda Poha, as decided by the operator. Drinking water bottles and juice are not included.\n\n'
      + 'Helpline: ' + BUSINESS_CONFIG.PHONE + ' | Email: ' + BUSINESS_CONFIG.EMAIL;

    MailApp.sendEmail({
      to: recipient,
      subject: subject,
      body: plainText,
      htmlBody: htmlBody,
      name: BUSINESS_CONFIG.NAME
    });

    return { status: 'Sent' };
  } catch (err) {
    return { status: 'Failed', error: err.toString() };
  }
}

/**
 * Owner Booking Notification Dispatcher
 */
function sendOwnerBookingNotification(b, bId) {
  try {
    var quota = MailApp.getRemainingDailyQuota();
    if (quota <= 0) {
      return { status: 'Failed', error: 'Daily MailApp quota exceeded' };
    }

    var pax = Number(b.passengerCount || b.passengers || b.persons || 1);
    var onlineFare = Number(b.onlineBookingFare || b.grandTotal || b.amountInr || b.amount || 0);
    var advanceAmount = Number(b.advancePayable || (b.paymentMode === 'advance' ? 200 : onlineFare));
    var balanceOnBus = Math.max(0, onlineFare - advanceAmount);

    var guideFee = pax * 50;
    var tollFee = pax * 10;
    var totalToGuide = guideFee + tollFee;

    var subject = 'New Booking Alert: ' + bId + ' - ' + (b.customerName || b.name || '') + ' (' + pax + ' Pax) - ' + (b.travelDate || '');

    var plainText = 'NEW BOOKING RECEIVED - MUMBAI DARSHAN BUS ONLINE\n\n'
      + 'Booking ID: ' + bId + '\n'
      + 'Customer: ' + (b.customerName || b.name || '') + '\n'
      + 'Phone: ' + (b.customerMobile || b.phone || '') + '\n'
      + 'Email: ' + (b.customerEmail || b.email || '') + '\n'
      + 'Travel Date: ' + (b.travelDate || '') + '\n'
      + 'Route: ' + (b.routeName || b.route || '') + '\n'
      + 'Pickup Point: ' + (b.pickupPointName || b.pickupPoint || '') + ' at ' + (b.pickupTime || '') + '\n'
      + 'Package: ' + (b.packageTitle || b.packageName || b.package || '') + ' (' + pax + ' Pax)\n\n'
      + 'Online Booking Fare: ₹' + onlineFare + '\n'
      + 'Advance Payable: ₹' + advanceAmount + ' (' + (b.paymentStatus || 'Pending Verification') + ')\n'
      + 'Remaining Balance to Collect on Bus: ₹' + balanceOnBus + '\n'
      + 'Guide & Sea Link to Collect on Bus: ₹' + totalToGuide + ' (Guide: ₹' + guideFee + ' + Toll: ₹' + tollFee + ')\n\n'
      + 'Special Requests: ' + (b.specialRequest || 'None') + '\n'
      + 'Timestamp: ' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd HH:mm:ss');

    MailApp.sendEmail({
      to: BUSINESS_CONFIG.EMAIL,
      subject: subject,
      body: plainText,
      name: 'MDB Online Booking Engine'
    });

    return { status: 'Sent' };
  } catch (err) {
    return { status: 'Failed', error: err.toString() };
  }
}

/**
 * Daily Operations Report (Scheduled for 10:00 PM IST)
 * Sends aggregated report of the day to mumbaidarshanbooking@gmail.com
 */
function sendDailyOwnerReport() {
  try {
    var todayStr = Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd');
    var sheet = SPREADSHEET.getSheetByName(SHEET_NAMES.BOOKINGS);
    if (!sheet) return;

    var data = sheet.getDataRange().getValues();
    var todayBookings = [];
    var totalPax = 0;
    var totalOnlineRevenue = 0;
    var totalAdvanceExpected = 0;
    var totalBusBalanceToCollect = 0;
    var totalGuideFeesExpected = 0;
    var routeBreakdown = { Western: 0, Central: 0, Harbour: 0, 'Kalyan-Dombivli': 0, Other: 0 };

    for (var i = 1; i < data.length; i++) {
      var rowDate = data[i][0];
      var rowDateStr = (rowDate instanceof Date) 
        ? Utilities.formatDate(rowDate, 'Asia/Kolkata', 'yyyy-MM-dd')
        : String(rowDate).slice(0, 10);

      if (rowDateStr === todayStr) {
        var pax = Number(data[i][10] || 1);
        var onlineAmt = Number(data[i][14] || 0);
        var route = String(data[i][6] || '');

        totalPax += pax;
        totalOnlineRevenue += onlineAmt;
        totalAdvanceExpected += 200;
        totalBusBalanceToCollect += Math.max(0, onlineAmt - 200);
        totalGuideFeesExpected += (pax * 60);

        if (route.toLowerCase().indexOf('west') !== -1) routeBreakdown.Western += pax;
        else if (route.toLowerCase().indexOf('cent') !== -1) routeBreakdown.Central += pax;
        else if (route.toLowerCase().indexOf('harb') !== -1) routeBreakdown.Harbour += pax;
        else if (route.toLowerCase().indexOf('kalyan') !== -1 || route.toLowerCase().indexOf('domb') !== -1) routeBreakdown['Kalyan-Dombivli'] += pax;
        else routeBreakdown.Other += pax;

        todayBookings.push({
          id: data[i][1],
          name: data[i][2],
          phone: data[i][3],
          travelDate: data[i][5],
          pax: pax,
          amount: onlineAmt
        });
      }
    }

    var subject = 'Daily Operations Report - Mumbai Darshan Bus (' + todayStr + ')';

    var reportText = 'MUMBAI DARSHAN BUS ONLINE - DAILY REPORT (10:00 PM IST)\n'
      + 'Date: ' + todayStr + '\n'
      + '===================================================\n\n'
      + 'SUMMARY METRICS:\n'
      + '- Total New Bookings Created Today: ' + todayBookings.length + '\n'
      + '- Total Passengers Booked: ' + totalPax + '\n'
      + '- Total Online Booking Value: ₹' + totalOnlineRevenue + '\n'
      + '- Expected Advance Online Collection: ₹' + totalAdvanceExpected + '\n'
      + '- Expected Bus Balance to Collect on Buses: ₹' + totalBusBalanceToCollect + '\n'
      + '- Total Guide Charges & Toll to Collect on Buses (₹60/pax): ₹' + totalGuideFeesExpected + '\n\n'
      + 'PASSENGER ROUTE DISTRIBUTION:\n'
      + '- Western Line: ' + routeBreakdown.Western + ' Passengers\n'
      + '- Central Line: ' + routeBreakdown.Central + ' Passengers\n'
      + '- Harbour Line: ' + routeBreakdown.Harbour + ' Passengers\n'
      + '- Kalyan-Dombivli Line: ' + routeBreakdown['Kalyan-Dombivli'] + ' Passengers\n\n'
      + 'INDIVIDUAL BOOKINGS LOGGED TODAY:\n';

    todayBookings.forEach(function(b, idx) {
      reportText += (idx + 1) + '. ' + b.id + ' | ' + b.name + ' (' + b.phone + ') | Travel Date: ' + b.travelDate + ' | Pax: ' + b.pax + ' | Fare: ₹' + b.amount + '\n';
    });

    if (todayBookings.length === 0) {
      reportText += 'No new bookings recorded today.\n';
    }

    reportText += '\nGenerated automatically by Mumbai Darshan Bus Online Engine.';

    MailApp.sendEmail({
      to: BUSINESS_CONFIG.EMAIL,
      subject: subject,
      body: reportText,
      name: 'MDB Daily Operations Reporter'
    });

    logActivity('DAILY_REPORT_DISPATCHED', todayStr, 'Sent report with ' + todayBookings.length + ' bookings to ' + BUSINESS_CONFIG.EMAIL);
  } catch (err) {
    logActivity('DAILY_REPORT_FAILED', 'System', err.toString());
  }
}

/**
 * Retry Failed Emails for a Specific Booking
 */
function retryFailedEmails(bookingId) {
  var sheet = SPREADSHEET.getSheetByName(SHEET_NAMES.BOOKINGS);
  if (!sheet) return { status: 'error', message: 'Bookings sheet not found' };

  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (String(data[i][1]).trim().toLowerCase() === String(bookingId).trim().toLowerCase()) {
      var bookingObj = {
        bookingId: data[i][1],
        customerName: data[i][2],
        customerMobile: data[i][3],
        customerEmail: data[i][4],
        travelDate: data[i][5],
        routeName: data[i][6],
        pickupPointName: data[i][7],
        packageTitle: data[i][9],
        passengerCount: data[i][10],
        onlineBookingFare: data[i][14],
        paymentStatus: data[i][16]
      };

      var custRes = sendCustomerBookingEmail(bookingObj, bookingObj.bookingId);
      var ownerRes = sendOwnerBookingNotification(bookingObj, bookingObj.bookingId);

      sheet.getRange(i + 1, 19).setValue(custRes.status);
      sheet.getRange(i + 1, 20).setValue(ownerRes.status);
      sheet.getRange(i + 1, 21).setValue((custRes.error || '') + ' ' + (ownerRes.error || ''));

      return {
        status: 'success',
        bookingId: bookingId,
        customerEmailStatus: custRes.status,
        ownerEmailStatus: ownerRes.status,
        message: 'Email retry complete.'
      };
    }
  }

  return { status: 'not_found', message: 'Booking ID not found' };
}

/**
 * Controlled Test Function for Owner
 * Run this function manually in Google Apps Script Editor to verify MailApp permissions safely.
 */
function testSendBookingEmail() {
  var sampleBooking = {
    customerName: 'Test Traveler (Rahul Sharma)',
    customerEmail: BUSINESS_CONFIG.EMAIL,
    customerMobile: '9619975457',
    travelDate: Utilities.formatDate(new Date(Date.now() + 86400000), 'Asia/Kolkata', 'yyyy-MM-dd'),
    routeName: 'Western Line',
    pickupPointName: 'Borivali East - National Park Gate',
    pickupTime: '6:30 AM',
    packageTitle: 'AC Bus + Lunch',
    passengerCount: 3,
    onlineBookingFare: 1500, // 3 × ₹500
    advancePayable: 200,     // ₹200 advance per booking
    balancePayable: 1300,    // Remaining bus package balance
    paymentStatus: 'Pending Verification',
    specialRequest: 'Test booking verification'
  };

  Logger.log('Running controlled email dispatch test to ' + BUSINESS_CONFIG.EMAIL + '...');
  var res = sendCustomerBookingEmail(sampleBooking, 'TEST-MDB-9999');
  Logger.log('Customer Email Result: ' + JSON.stringify(res));

  var ownerRes = sendOwnerBookingNotification(sampleBooking, 'TEST-MDB-9999');
  Logger.log('Owner Notification Result: ' + JSON.stringify(ownerRes));
}

/**
 * Installs daily 10:00 PM IST trigger for Daily Operations Report
 * Run this function once manually in Google Apps Script Editor when owner approves.
 */
function setupDailyReportTrigger() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'sendDailyOwnerReport') {
      ScriptApp.deleteTrigger(triggers[i]);
    }
  }

  ScriptApp.newTrigger('sendDailyOwnerReport')
    .timeBased()
    .everyDays(1)
    .atHour(22)
    .inTimezone('Asia/Kolkata')
    .create();

  Logger.log('Installed daily trigger for sendDailyOwnerReport at 10:00 PM IST.');
}

/**
 * Checks if live email dispatch is explicitly enabled in Settings sheet
 */
function checkLiveEmailsActive() {
  try {
    var sheet = SPREADSHEET.getSheetByName(SHEET_NAMES.SETTINGS);
    if (!sheet) return DEFAULT_LIVE_EMAILS_ACTIVE;
    var data = sheet.getDataRange().getValues();
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][0]).trim() === 'ENABLE_LIVE_EMAILS') {
        var val = String(data[i][1]).trim().toLowerCase();
        return val === 'true' || val === 'yes' || val === '1';
      }
    }
  } catch (e) {}
  return DEFAULT_LIVE_EMAILS_ACTIVE;
}

/**
 * Handle Offline Attraction Collection logging
 */
function handleOfflineAttractionCollection(data) {
  var sheet = getOrCreateSheet(SHEET_NAMES.OFFLINE_COLLECTIONS, [
    'Timestamp', 'Log ID', 'Tour Date', 'Guide Name', 'Bus Number',
    'Gateway Boat Pax', 'Gateway Boat Cash (₹)',
    'CSMVS Museum Pax', 'Museum Cash (₹)',
    'Orama 11D Pax', 'Orama 11D Cash (₹)',
    'Bollywood Museum Pax', 'Bollywood Cash (₹)',
    'Total Collected (₹)'
  ]);

  var logId = data.id || ('OFF-' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyyMMdd') + '-' + Math.floor(100 + Math.random() * 900));

  sheet.appendRow([
    new Date(),
    logId,
    data.date || '',
    data.guideName || '',
    data.busNumber || '',
    Number(data.gatewayBoatPax || 0),
    Number(data.gatewayBoatCollected || 0),
    Number(data.museumPax || 0),
    Number(data.museumCollected || 0),
    Number(data.oramaPax || 0),
    Number(data.oramaCollected || 0),
    Number(data.bollywoodMuseumPax || 0),
    Number(data.bollywoodCollected || 0),
    Number(data.totalCollected || 0)
  ]);

  return { status: 'success', logId: logId, message: 'Offline attraction collection logged.' };
}

/**
 * Update booking status
 */
function handleBookingStatusUpdate(d) {
  var sheet = SPREADSHEET.getSheetByName(SHEET_NAMES.BOOKINGS);
  if (!sheet) return { status: 'error', message: 'Bookings sheet not found' };

  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (String(data[i][1]).trim().toLowerCase() === String(d.bookingId).trim().toLowerCase()) {
      if (d.bookingStatus) sheet.getRange(i + 1, 18).setValue(d.bookingStatus);
      if (d.paymentStatus) sheet.getRange(i + 1, 17).setValue(d.paymentStatus);
      return { status: 'success', message: 'Booking status updated' };
    }
  }
  return { status: 'not_found' };
}

/**
 * Update rental status
 */
function handleRentalStatusUpdate(d) {
  var sheet = SPREADSHEET.getSheetByName(SHEET_NAMES.RENTAL_ENQUIRY);
  if (!sheet) return { status: 'error', message: 'Rental Enquiry sheet not found' };

  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (String(data[i][1]).trim().toLowerCase() === String(d.enquiryId).trim().toLowerCase()) {
      if (d.status) sheet.getRange(i + 1, 17).setValue(d.status);
      if (d.customerQuotation || d.quotedPrice) sheet.getRange(i + 1, 14).setValue(d.customerQuotation || d.quotedPrice);
      if (d.supplierCost) sheet.getRange(i + 1, 15).setValue(d.supplierCost);
      if (d.grossMargin) sheet.getRange(i + 1, 16).setValue(d.grossMargin);
      return { status: 'success', message: 'Rental enquiry updated' };
    }
  }
  return { status: 'not_found' };
}

/**
 * Lookup booking by ID or Mobile
 */
function lookupBooking(query) {
  var sheet = SPREADSHEET.getSheetByName(SHEET_NAMES.BOOKINGS);
  if (!sheet) return null;

  var data = sheet.getDataRange().getValues();
  if (data.length <= 1) return null;

  var cleanQuery = String(query).trim().toLowerCase();

  for (var i = 1; i < data.length; i++) {
    var bId = String(data[i][1]).trim().toLowerCase();
    var mobile = String(data[i][3]).replace(/\D/g, '').slice(-10);

    if (bId === cleanQuery || (cleanQuery.length >= 10 && mobile.includes(cleanQuery))) {
      return {
        bookingId: data[i][1],
        customerName: data[i][2],
        customerMobile: data[i][3],
        customerEmail: data[i][4],
        travelDate: data[i][5],
        route: data[i][6],
        pickupPoint: data[i][7],
        packageKey: data[i][8],
        packageName: data[i][9],
        passengers: data[i][10],
        grandTotal: data[i][14],
        paymentStatus: data[i][16],
        bookingStatus: data[i][17]
      };
    }
  }
  return null;
}

/**
 * Helper: Retrieve or create a Sheet with dark header row without duplicate tabs
 */
function getOrCreateSheet(sheetName, headers) {
  var sheet = SPREADSHEET.getSheetByName(sheetName);
  if (!sheet) {
    sheet = SPREADSHEET.insertSheet(sheetName);
    sheet.appendRow(headers);
    var headerRange = sheet.getRange(1, 1, 1, headers.length);
    headerRange.setBackground('#0b0d13');
    headerRange.setFontColor('#f59e0b');
    headerRange.setFontWeight('bold');
    sheet.setFrozenRows(1);
  }
  return sheet;
}

/**
 * Activity & Audit Logger
 */
function logActivity(action, ref, details) {
  try {
    var sheet = getOrCreateSheet(SHEET_NAMES.ACTIVITY_LOG, ['Timestamp', 'Action', 'Reference', 'Details']);
    sheet.appendRow([new Date(), action, ref, details]);
  } catch (e) {}
}

/**
 * Return JSON response
 */
function createJsonResponse(data, statusCode) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * MASTER BOOTSTRAP FUNCTION
 * Run this function once manually in Google Apps Script Editor
 * to provision all authoritative sheets with exact headers.
 */
function setupDatabase() {
  getOrCreateSheet(SHEET_NAMES.SETTINGS, ['Key', 'Value', 'Updated At']);
  getOrCreateSheet(SHEET_NAMES.BOOKINGS, BOOKINGS_COLUMNS);
  getOrCreateSheet(SHEET_NAMES.RENTAL_ENQUIRY, [
    'Timestamp', 'Enquiry ID', 'Customer Name', 'Phone', 'Email',
    'Rental Type', 'Vehicle Type', 'Travel Date', 'Passengers',
    'Pickup Location', 'Destination', 'Duration Days', 'Estimated KM',
    'Quoted Price (₹)', 'Supplier Cost (₹)', 'Gross Margin (₹)',
    'Status', 'Special Requirements'
  ]);
  getOrCreateSheet(SHEET_NAMES.BOOKING_DATES, ['Date', 'Available Buses', 'Total Capacity', 'Booked Pax', 'Status']);
  getOrCreateSheet(SHEET_NAMES.PACKAGE_OPTIONS, ['Package ID', 'Title', 'Category', 'Lunch Included', 'Active']);
  getOrCreateSheet(SHEET_NAMES.PICKUP_POINTS, ['Point ID', 'Route ID', 'Stop Name', 'Pickup Time', 'Reporting Time', 'Landmark', 'Google Maps Link', 'Active']);
  getOrCreateSheet(SHEET_NAMES.ATTRACTION_POINTS, ['Point #', 'Name', 'Halt Status', 'Can Get Down', 'Fee Status', 'Maps Link']);
  getOrCreateSheet(SHEET_NAMES.ATTRACTION_TICKETS, ['Ticket ID', 'Attraction Name', 'Customer Price (₹)', 'Payment Mode', 'Collection Rule']);
  getOrCreateSheet(SHEET_NAMES.BOOKING_PAYMENTS, ['Timestamp', 'Payment ID', 'Booking ID', 'Customer Name', 'Amount INR', 'Payment Type', 'Transaction Ref', 'Status', 'Collector']);
  getOrCreateSheet(SHEET_NAMES.BOOKING_CANCELLATIONS, ['Timestamp', 'Cancellation ID', 'Booking ID', 'Reason', 'Refund Eligible (₹)', 'Status']);
  getOrCreateSheet(SHEET_NAMES.BOOKING_NOTIFICATIONS, ['Timestamp', 'Booking ID', 'Channel', 'Recipient', 'Message Text', 'Status']);
  getOrCreateSheet(SHEET_NAMES.ACTIVITY_LOG, ['Timestamp', 'Action', 'Reference', 'Details']);
  getOrCreateSheet(SHEET_NAMES.BOOKING_SETTINGS, ['Setting Key', 'Value', 'Last Updated']);
  getOrCreateSheet(SHEET_NAMES.VEHICLES, ['Vehicle ID', 'Model', 'Category', 'Capacity', 'Active']);
  getOrCreateSheet(SHEET_NAMES.RENTAL_PRICING, ['Pricing ID', 'Vehicle ID', 'Service Type', 'Customer Rate (₹)', 'Supplier Cost (₹)', 'Margin (₹)']);
  getOrCreateSheet(SHEET_NAMES.OFFLINE_COLLECTIONS, [
    'Timestamp', 'Log ID', 'Tour Date', 'Guide Name', 'Bus Number',
    'Gateway Boat Pax', 'Gateway Boat Cash (₹)',
    'CSMVS Museum Pax', 'Museum Cash (₹)',
    'Orama 11D Pax', 'Orama 11D Cash (₹)',
    'Bollywood Museum Pax', 'Bollywood Cash (₹)',
    'Total Collected (₹)'
  ]);

  // Seed default settings row if missing
  var settingsSheet = SPREADSHEET.getSheetByName(SHEET_NAMES.SETTINGS);
  if (settingsSheet && settingsSheet.getLastRow() <= 1) {
    settingsSheet.appendRow(['BUSINESS_EMAIL', BUSINESS_CONFIG.EMAIL, new Date()]);
    settingsSheet.appendRow(['BUSINESS_PHONE', BUSINESS_CONFIG.PHONE, new Date()]);
    settingsSheet.appendRow(['ENABLE_LIVE_EMAILS', 'false', new Date()]);
    settingsSheet.appendRow(['ADVANCE_PER_BOOKING_INR', '200', new Date()]);
    settingsSheet.appendRow(['DAILY_REPORT_RECIPIENT', BUSINESS_CONFIG.EMAIL, new Date()]);
  }

  Logger.log('Mumbai Darshan Bus Online: Authoritative sheets and settings initialized successfully!');
}
