# Google Sheets Database & Apps Script Backend Deployment Guide
**Mumbai Darshan Bus Online** (`https://mumbaidarshanbusonline.com`)

This guide explains how to deploy the Google Sheets database and Google Apps Script backend engine for Mumbai Darshan Bus Online and the Private Car & Bus Rental Fleet.

---

### Step 1: Create a Google Sheet
1. Open [Google Sheets](https://sheets.new) in your web browser.
2. Rename the new spreadsheet to: **`Mumbai Darshan Bus Online - Database`**.

### Step 2: Open Google Apps Script Editor
1. In your Google Sheet top menu, click **Extensions** > **Apps Script**.
2. A new editor tab will open. Rename the project to: **`Mumbai Darshan Backend Engine`**.

### Step 3: Paste Backend Code
1. Delete any existing template code in `Code.gs`.
2. Copy the entire contents of `/google-apps-script/Code.gs` and paste it into the editor.
3. Click the disk **Save** icon (or press `Ctrl+S` / `Cmd+S`).

### Step 4: Run Initial Setup (Automatic Database Provisioning)
1. In the Apps Script toolbar dropdown, select the function **`setupDatabase`**.
2. Click **Run**.
3. Google will ask for initial authorization to manage your sheet. Click **Review Permissions**, choose your Google account, click **Advanced**, and then click **Go to Mumbai Darshan Backend Engine (unsafe)** and **Allow**.
4. The script will automatically create all **24 database sheets** with formatted headers and frozen top rows:
   - **Bus Operations (15 Sheets)**:
     1. `Bookings`
     2. `Routes`
     3. `PickupPoints`
     4. `PackageOptions`
     5. `BookingDates`
     6. `AttractionPoints`
     7. `AttractionTickets`
     8. `ExtraCharges`
     9. `BookingPayments`
     10. `BookingCancellations`
     11. `BookingNotifications`
     12. `EmailLog`
     13. `AdminUsers`
     14. `ActivityLog`
     15. `PriceHistory`
   - **Rental Fleet & Outstation (8 Sheets)**:
     16. `Rental_Vehicles`
     17. `Rental_Rates`
     18. `Rental_Enquiries`
     19. `Rental_Bookings`
     20. `Rental_Quotations`
     21. `Rental_Expenses`
     22. `Rental_Payment_Records`
     23. `Rental_Activity_Log`
   - **Operational Reconciliations (2 Sheets)**:
     24. `Offline_Attraction_Collections`
     25. `Settings`

### Step 5: Deploy as Web App
1. At the top right of the Apps Script window, click the blue **Deploy** button > **New deployment**.
2. Click the gear icon next to "Select type" and choose **Web app**.
3. Configure the deployment settings:
   - **Description**: `Mumbai Darshan Webhook v2.5`
   - **Execute as**: `Me (your email)`
   - **Who has access**: **`Anyone`** *(Crucial so the website can post customer bookings, rental enquiries, and offline logs securely)*
4. Click **Deploy**.
5. Copy the generated **Web App URL** (e.g. `https://script.google.com/macros/s/AKfycb.../exec`).

### Step 6: Connect to Admin Panel
1. Open the Mumbai Darshan Bus Online website.
2. Click the **Admin** shield icon in the header (or navigate to Admin Console).
3. If prompted, enter the passcode: **`mumbai2026`**.
4. Open the **Google Sheets & Backend** tab in the sidebar.
5. Paste your **Web App URL** into the input field.
6. Toggle **Auto-Sync On Booking Submission** to ON.
7. Click **Test Webhook Ping** to verify instant two-way communication.
8. Click **Save Webhook Settings**.

### Supported Endpoints & Actions
- **`POST` actions**:
  - `NEW_BOOKING`: Customer bus tour booking with passenger details, food selections, advance/full payments.
  - `NEW_RENTAL_ENQUIRY` / `CAR_RENTAL`: Mumbai Local 12h/120km and Outstation private fleet enquiries.
  - `GROUP_ENQUIRY`: Large group tour enquiries.
  - `OFFLINE_ATTRACTION_COLLECTION`: Tour Conductor log for optional attraction cash collections on the bus (Gateway Boat ₹210, CSMVS Museum ₹200, Orama 11D ₹220, Bollywood Museum ₹165).
  - `UPDATE_BOOKING_STATUS`: Update confirmed/completed/cancelled states.
  - `UPDATE_RENTAL_STATUS`: Update quotation, supplier costs, and booking status.
  - `PING_TEST`: Connectivity diagnostic.
- **`GET` actions**:
  - `lookup?query=<bookingId or mobile>`: Returns real-time booking dossier directly from the Google Sheet.
