# Firebase Hosting & Custom Domain Deployment Guide
**Production Domain:** `https://mumbaidarshanbusonline.com/`  
**Brand Identity:** Mumbai Darshan Bus Online  
**Business Phone:** 9619975457 | **Email:** mumbaidarshanbooking@gmail.com  
**Registered Office:** 110, Sai Krupa Chawl, Bansi Nagar, W. E. Highway, Kulupwadi, Borivali East, Mumbai, Maharashtra 400066.

---

## 1. Safety & Non-Disruption Policy
- **Existing Live Website:** Do not delete, overwrite or disconnect your existing live website until testing in preview is verified.
- **DNS Records:** Do not touch or modify your MX records or email routing. Only update the web `A` or `CNAME` records when you are ready to point traffic to the new build.
- **SSL Certificate:** Firebase Hosting automatically provisions a free, auto-renewing Google Trust Services SSL certificate for `https://mumbaidarshanbusonline.com/` as soon as DNS verification completes.

---

## 2. Pre-Deployment Build Verification
Before deploying, generate the optimized production assets:

```bash
# 1. Build the production bundle
npm run build

# 2. Verify that the 'dist' directory contains:
# - index.html
# - assets/ (optimized JS and CSS)
# - src/assets/images/ (verified landmark photos)
```

---

## 3. Firebase CLI Setup & Login
If deploying from your local development machine:

```bash
# 1. Install Firebase CLI globally (if not already installed)
npm install -g firebase-tools

# 2. Log in with your authorized Google Account (e.g. arishaikh7@gmail.com)
firebase login

# 3. Associate your existing Firebase Project ID
firebase use <YOUR_FIREBASE_PROJECT_ID>
```

---

## 4. Deploying to Firebase Hosting

```bash
# Deploy only hosting assets without touching existing Cloud Firestore or Functions
firebase deploy --only hosting
```

Once the upload completes, Firebase CLI will print your default project URL:  
`https://<YOUR_FIREBASE_PROJECT_ID>.web.app`

---

## 5. Connecting Your Existing Custom Domain
To connect `https://mumbaidarshanbusonline.com/`:

1. Open the [Firebase Console](https://console.firebase.google.com/).
2. Select your project.
3. In the left navigation, click **Build** > **Hosting**.
4. Click **Add custom domain** (or **Connect domain**).
5. Enter: `mumbaidarshanbusonline.com`.
6. (Optional) Check **Redirect mumbaidarshanbusonline.com to www.mumbaidarshanbusonline.com** (or keep root as canonical based on your existing setup).
7. Firebase will display the required DNS records:
   - **Type A:**
     - Point `@` (root) to the two IP addresses provided by Firebase (e.g. `199.36.158.100`).
   - **Type TXT (Domain Verification):**
     - Add the verification TXT token provided by Firebase in your domain registrar DNS panel (e.g. GoDaddy, Namecheap, Google Domains / Squarespace).
8. Wait for DNS propagation (typically 10 to 60 minutes).
9. Firebase Hosting will automatically issue the SSL certificate for `https://mumbaidarshanbusonline.com/`.

---

## 6. Zero-Downtime Rollback Mechanism
If you ever need to rollback to a previous version:
1. In the **Firebase Console** under **Hosting**, open the **Release history** tab.
2. Every deployment is versioned and archived.
3. Click the three dots next to any previous release and click **Rollback**. The change takes effect globally in under 5 seconds.
