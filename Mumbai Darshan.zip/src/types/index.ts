/**
 * Mumbai Darshan Bus Online - Core Types
 */

export type RouteId = 'western' | 'central' | 'harbour' | 'kalyan_dombivli';

export type PackageId = 'non_ac_no_lunch' | 'ac_no_lunch' | 'non_ac_lunch' | 'ac_lunch';

export interface RouteConfig {
  id: RouteId;
  name: string;
  description: string;
  displayOrder: number;
  active: boolean;
  color: string;
}

export interface PickupPoint {
  id: string;
  routeId: RouteId;
  name: string;
  time: string;
  landmark: string;
  reportingTime: string;
  sortOrder: number;
  active: boolean;
  googleMapsUrl?: string;
}

export interface PackagePricing {
  packageId: PackageId;
  title: string;
  isAC: boolean;
  hasLunch: boolean;
  description: string;
  basePrices: Record<RouteId, number>; // Route-wise price per person
  active: boolean;
}

export interface PriceHistoryRecord {
  id: string;
  timestamp: string;
  routeId: RouteId;
  packageId: PackageId;
  oldPrice: number;
  newPrice: number;
  updatedBy: string;
}

export interface RouteOffer {
  routeId: RouteId;
  enabled: boolean;
  discountType: 'flat' | 'percentage';
  discountValue: number;
  label: string;
  startDate?: string;
  endDate?: string;
}

export interface ExtraCharge {
  id: string;
  name: string;
  description: string;
  amount: number;
  type: 'compulsory' | 'optional';
  priceType: 'per_person' | 'per_booking' | 'fixed';
  active: boolean;
  includedInPackage: boolean;
  applicableRoutes?: RouteId[];
  effectiveDate?: string;
  collectorNotice?: string;
  exactPriceConfirmed: boolean;
}

export interface TourPoint {
  id: number;
  name: string;
  description: string;
  imageUrl: string;
  googleMapsUrl: string;
  haltStatus: 'BUS_HALT' | 'NO_HALT';
  canGetDown: boolean;
  feeStatus: 'FREE' | 'PAID' | 'OPTIONAL_PAID';
  entryFee?: number;
  priceType?: 'per_person' | 'per_vehicle' | 'fixed';
  includedInBusPackage: boolean;
  optionalActivityDetails?: string;
  estimatedDurationMinutes?: number;
  active: boolean;
  sortOrder: number;
  adminNotes?: string;
}

export interface FoodSelection {
  vegBiryani: number;
  butterPaneer: number;
  vegThali: number;
}

export interface Booking {
  id: string; // e.g. MDB-20261110-8472
  createdAt: string;
  travelDate: string;
  routeId: RouteId;
  routeName: string;
  pickupPointId: string;
  pickupPointName: string;
  pickupTime: string;
  reportingTime: string;
  packageId: PackageId;
  packageTitle: string;
  isAC: boolean;
  hasLunch: boolean;
  passengerCount: number;
  foodSelections?: FoodSelection;
  specialRequest?: string;
  
  // Customer details
  customerName: string;
  customerMobile: string;
  customerEmail: string;

  // Stored price breakdown (Frozen at time of booking)
  unitPackagePrice: number;
  totalPackageAmount: number;
  offerDiscountAmount: number;
  appliedOfferLabel?: string;
  onlineBookingFare?: number; // Strictly the bus package fare (e.g. ₹1,500 for 3 pax)
  
  // Mandatory On-Bus Charges (Collected directly by Tour Guide inside bus)
  compulsoryCharges: {
    guideChargeUnit: number; // ₹50/person
    guideChargeTotal: number; // e.g. ₹150 for 3 pax
    seaLinkTollUnit: number; // ₹10/person
    seaLinkTollTotal: number; // e.g. ₹30 for 3 pax
    totalCompulsoryAmount: number; // e.g. ₹180 for 3 pax
  };

  selectedOptionalAttractions: {
    id: string;
    name: string;
    unitPrice: number;
    passengerCount: number;
    totalPrice: number;
  }[];

  totalOptionalAmount: number;
  grandTotal: number; // Strictly the online booking fare (e.g. ₹1,500)
  
  // Payment Breakdown
  paymentMode: 'advance' | 'full';
  amountPayableNow: number; // ₹200 advance per booking or full package fare
  amountPaid: number;
  balancePayable: number; // Remaining bus package amount payable on bus (e.g. ₹1,300)
  paymentStatus: 'Pending Verification' | 'Advance Paid' | 'Fully Paid' | 'Balance Due' | 'Payment Pending' | 'Refunded';
  bookingStatus: 'Confirmed' | 'Pending Verification' | 'Completed' | 'Cancelled';
  
  // Email Dispatch Status
  customerEmailStatus?: 'Pending' | 'Sent' | 'Failed' | 'Queued';
  ownerEmailStatus?: 'Pending' | 'Sent' | 'Failed' | 'Queued';
  lastEmailError?: string;

  // Administrative
  adminNotes?: string;
  syncedToGoogleSheets?: boolean;
  lastUpdated?: string;
  historyLog?: {
    timestamp: string;
    action: string;
    notes?: string;
  }[];
}

export interface GalleryImage {
  id: string;
  title: string;
  attractionName: string;
  imageUrl: string;
  approved: boolean;
  published: boolean;
  sortOrder: number;
  uploadedAt: string;
  caption?: string;
}

export interface LocalRentalPackage {
  id: string;
  vehicleName: string;
  seating: string;
  durationHours: number; // 12 hrs
  includedKm: number; // 120 km
  proposedCustomerPrice: number; // e.g. Dzire ₹4,500
  supplierCost: number; // e.g. Dzire ₹3,500 (Admin only)
  extraKmRate: number; // per km
  extraHourRate: number; // per hr
  tollIncluded: boolean;
  parkingIncluded: boolean;
  driverBhattaIncluded: boolean; // included
  tourGuideIncluded: boolean; // false
  published: boolean;
  active: boolean;
}

export interface OutstationVehicleRate {
  id: string;
  vehicleName: string;
  category: 'Car' | '13-14 Seater' | '17 Seater' | '20 Seater' | '26 Seater' | '32-35 Seater' | '45-49 Seater';
  seating: string;
  isAC: boolean;
  supplierPerKm: number;
  proposedCustomerPerKm: number;
  supplierDaPerDay: number;
  proposedCustomerDaPerDay: number;
  minKmPerDay: number; // 300 km
  nightDaRate: number; // after 11 PM
  published: boolean;
  active: boolean;
}

export type RentalStatus =
  | 'New Enquiry'
  | 'Contacted'
  | 'Quotation Pending'
  | 'Quotation Sent'
  | 'Awaiting Customer Approval'
  | 'Supplier Availability Pending'
  | 'Confirmed'
  | 'Cancelled'
  | 'Completed';

export interface CarRentalEnquiry {
  id: string;
  createdAt: string;
  customerName: string;
  customerMobile: string;
  customerEmail?: string;
  travelDate: string;
  rentalType: 'local_darshan' | 'outstation';
  vehicleType: string;
  isAC?: boolean;
  passengerCount: number;
  pickupLocation: string;
  destination?: string;
  preferredPickupTime?: string;
  daysCount?: number;
  estimatedKm?: number;
  specialRequirements?: string;
  status: RentalStatus;
  
  // Quotation & Supplier metrics (Admin only)
  supplierCost?: number;
  customerQuotation?: number;
  grossMargin?: number; // Customer price - Supplier cost (Admin only, never shown to customer)
  daPermitAmount?: number;
  extraExpenses?: number;
  adminNotes?: string;
}

export interface OfflineAttractionRecord {
  id: string;
  bookingId: string;
  customerName: string;
  customerMobile: string;
  travelDate: string;
  attractionId: string;
  attractionName: string;
  unitPrice: number;
  passengerCount: number;
  totalCollected: number;
  collectedByGuide: string;
  collectionStatus: 'Confirmed Collected' | 'Declined on Bus' | 'Pending Verification';
  collectedAt: string;
  notes?: string;
}

export interface GroupBookingEnquiry {
  id: string;
  createdAt: string;
  organizationName?: string;
  contactPerson: string;
  mobile: string;
  email: string;
  tentativeDate: string;
  approximatePassengers: number;
  groupType: 'Corporate' | 'Family' | 'School/College' | 'Tour Group' | 'Senior Citizens';
  preferredBusType: 'AC 35-Seater' | 'AC 49-Seater' | 'Non-AC 49-Seater' | 'Multiple Buses';
  lunchRequired: boolean;
  customRequests?: string;
  status: 'New' | 'Quote Sent' | 'Follow Up' | 'Booked' | 'Cancelled';
  adminNotes?: string;
}

export interface CancellationRequest {
  id: string;
  bookingId: string;
  customerMobile: string;
  requestDate: string;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Refund Processed';
  refundAmount?: number;
  adminRemarks?: string;
}

export interface AppSettings {
  businessName: string;
  websiteDomain: string;
  businessPhone: string;
  businessEmail: string;
  registeredAddress: string;
  googleSheetsWebhookUrl?: string;
  autoSyncGoogleSheets: boolean;
  advanceDepositFixedAmount: number; // ₹200
  whatsappNumber: string;
  adminPasscode?: string;
}

