/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Phone,
  MessageCircle,
  MapPin,
  Calendar,
  Users,
  ShieldCheck,
  Check,
  Clock,
  ArrowRight,
  Sparkles,
  Ticket,
  Anchor,
  Compass,
  Car,
  Utensils
} from 'lucide-react';

import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { BookingForm } from './components/BookingForm';
import { CarRentalPanel } from './components/CarRentalPanel';
import { TourPointsGrid } from './components/TourPointsGrid';
import { PickupTimingsTable } from './components/PickupTimingsTable';
import { BookingLookup } from './components/BookingLookup';
import { PricingPackagesPage } from './components/PricingPackagesPage';
import { AttractionChargesPage } from './components/AttractionChargesPage';
import { GroupBookingPage } from './components/GroupBookingPage';
import { AboutUsPage } from './components/AboutUsPage';
import { ContactUsPage } from './components/ContactUsPage';
import { FAQPage } from './components/FAQPage';
import { LegalPoliciesPage } from './components/LegalPoliciesPage';
import { PhotoGallery } from './components/PhotoGallery';
import { AdminLayout } from './components/admin/AdminLayout';
import { StorageService } from './services/storage';
import { RouteId, PackageId } from './types';

export default function App() {
  const [activePage, setActivePage] = useState<string>('home');
  const [preselectedRoute, setPreselectedRoute] = useState<RouteId>('western');
  const [preselectedPickupId, setPreselectedPickupId] = useState<string>('');
  const [homepageRoute, setHomepageRoute] = useState<RouteId>('western');

  const settings = StorageService.getSettings();
  const routes = StorageService.getRoutes().filter(r => r.active);
  const packages = StorageService.getPackages().filter(p => p.active);

  // Scroll to top on page change
  const navigateTo = (page: string) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectPickupFromTable = (routeId: RouteId, pickupId: string) => {
    setPreselectedRoute(routeId);
    setPreselectedPickupId(pickupId);
    setActivePage('booking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // If Admin view is active, render full Admin console
  if (activePage === 'admin') {
    return <AdminLayout onExit={() => navigateTo('home')} />;
  }

  return (
    <div className="min-h-screen bg-[#08090d] text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Bar Navigation */}
      <Header activePage={activePage} setActivePage={navigateTo} />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* ================= PAGE 1: HOME ================= */}
        {activePage === 'home' && (
          <div className="space-y-16 sm:space-y-24 pb-16">
            
            {/* HERO SECTION */}
            <section className="relative pt-6 sm:pt-14 pb-10 sm:pb-20 overflow-hidden border-b border-white/10 subtle-grid w-full">
              <div className="max-w-7xl mx-auto px-3.5 sm:px-6 lg:px-8 w-full min-w-0">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-12 items-center w-full min-w-0">
                  
                  {/* Left Column: Headline & Value Prop */}
                  <div className="lg:col-span-7 space-y-4 sm:space-y-6 text-center lg:text-left min-w-0 w-full">
                    <div className="inline-flex items-center gap-1.5 sm:gap-2 px-3 py-1 sm:px-3.5 sm:py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] sm:text-xs font-semibold max-w-full">
                      <Sparkles className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">Official Mumbai City Sightseeing · 365 Days Guaranteed</span>
                    </div>

                    <h1 
                      className="text-white font-extrabold tracking-tight leading-[1.12] text-balance break-words text-2xl min-[360px]:text-3xl sm:text-4xl lg:text-5xl"
                    >
                      Experience All <span className="gold-gradient-text">44 Mumbai Landmarks</span> in Luxury Comfort
                    </h1>

                    <p className="text-xs sm:text-base text-slate-300 max-w-xl mx-auto lg:mx-0 leading-relaxed break-words">
                      Daily AC & Non-AC sightseeing coaches departing from <strong>Western, Central, Harbour & Kalyan-Dombivli lines</strong>. Includes Gateway of India, Bandra-Worli Sea Link crossing, Siddhivinayak Temple, Marine Drive & filmstar homes.
                    </p>

                    {/* Key Trust Signals */}
                    <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2.5 sm:gap-4 text-[11px] sm:text-xs text-slate-300 pt-1">
                      <span className="flex items-center gap-1.5 shrink-0">
                        <Check className="w-3.5 h-3.5 text-amber-400 stroke-[2.5] shrink-0" />
                        <span>Pay ₹200 Advance Only</span>
                      </span>
                      <span className="flex items-center gap-1.5 shrink-0">
                        <Check className="w-3.5 h-3.5 text-amber-400 stroke-[2.5] shrink-0" />
                        <span>71 Doorstep Pickup Stops</span>
                      </span>
                      <span className="flex items-center gap-1.5 shrink-0">
                        <Check className="w-3.5 h-3.5 text-amber-400 stroke-[2.5] shrink-0" />
                        <span>Pure Veg Breakfast & Lunch</span>
                      </span>
                    </div>

                    {/* CTAs */}
                    <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-2.5 sm:gap-3.5 pt-2 w-full max-w-md mx-auto lg:mx-0">
                      <button
                        onClick={() => navigateTo('booking')}
                        className="w-full sm:w-auto px-6 sm:px-7 py-3 sm:py-3.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-slate-950 font-extrabold text-xs sm:text-sm hover:from-amber-300 hover:to-amber-500 cursor-pointer shadow-xl shadow-amber-500/25 active:scale-95 transition-all flex items-center justify-center gap-2"
                      >
                        <span>Book Mumbai Darshan Tour</span>
                        <ArrowRight className="w-4 h-4 shrink-0" />
                      </button>

                      <a
                        href={`https://wa.me/${settings.whatsappNumber}?text=Hello%20Mumbai%20Darshan%20Bus,%20I%20want%20to%20know%20availability%20for%20tomorrow.`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full sm:w-auto px-4 sm:px-5 py-3 sm:py-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs border border-white/15 flex items-center justify-center gap-2 transition-colors"
                      >
                        <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>WhatsApp Quick Chat</span>
                      </a>
                    </div>
                  </div>

                  {/* Right Column: Hero Visual Asset */}
                  <div className="lg:col-span-5 relative w-full min-w-0">
                    <div className="relative rounded-2xl overflow-hidden border border-white/15 shadow-2xl bg-slate-900 group aspect-[16/10] sm:aspect-[16/9] lg:aspect-auto lg:h-[420px] w-full">
                      <img
                        src="/src/assets/images/hero_mumbai_darshan_bus_1794290247560.jpg"
                        alt="Mumbai Darshan Luxury Tour Bus at Gateway of India"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
                      
                      <div className="absolute bottom-3 left-3 right-3 sm:bottom-4 sm:left-4 sm:right-4 p-2.5 sm:p-3.5 rounded-xl bg-black/70 backdrop-blur-md border border-white/15 flex items-center justify-between text-xs">
                        <div className="min-w-0 pr-2">
                          <strong className="text-white block font-bold truncate">Gateway of India & Taj</strong>
                          <span className="text-amber-400 text-[10px] sm:text-[11px] block truncate">Bus Halt Stop · Disembarkation Allowed</span>
                        </div>
                        <span className="px-2 sm:px-2.5 py-1 rounded bg-amber-500 text-slate-950 font-black text-[10px] sm:text-[11px] shrink-0">
                          From ₹200
                        </span>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </section>

            {/* SECTION 2: PROMINENT 6-STEP BOOKING FORM */}
            <section id="booking-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center space-y-2 mb-8">
                <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                  Instant Online Seat Reservation
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Book Your Tour in 6 Easy Steps
                </h2>
                <p className="text-xs text-slate-400 max-w-lg mx-auto">
                  Select your date, pickup corridor, preferred bus class, and pay only ₹200 advance to reserve today.
                </p>
              </div>

              {/* The 6-Step Form Component */}
              <BookingForm initialRoute={preselectedRoute} />

              {/* SECTION 3: CAR RENTAL ENQUIRY PANEL IMMEDIATELY BELOW BOOKING FORM */}
              <div className="mt-10">
                <CarRentalPanel />
              </div>
            </section>

            {/* SECTION 4: ROUTE AND PACKAGE PRICING OVERVIEW (DYNAMIC PER SELECTED ROUTE) */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
                <div>
                  <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                    Transparent Daily Fares · Dynamic per Corridor
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
                    Bus Packages & Route Pricing
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Select a route to view exact per-person prices. No mixed rates or hidden surcharges.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => navigateTo('pricing')}
                  className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer shrink-0"
                >
                  <span>View Full 16-Combination Matrix</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Corridor Route Switcher */}
              <div className="bg-[#12141c] p-3 sm:p-4 rounded-2xl border border-white/10 mb-6 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-300">Select Boarding Route:</span>
                  <span className="text-amber-400 font-semibold">
                    Displaying rates for: <strong className="text-white underline">{routes.find(r => r.id === homepageRoute)?.name || 'Western Line'}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {routes.map(r => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => setHomepageRoute(r.id)}
                      className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                        homepageRoute === r.id
                          ? 'bg-amber-500/20 border-amber-400 text-white shadow-sm ring-1 ring-amber-400'
                          : 'bg-slate-900 border-white/5 hover:border-white/15 text-slate-400'
                      }`}
                    >
                      <strong className={`block text-xs font-bold ${homepageRoute === r.id ? 'text-amber-400' : 'text-slate-200'}`}>
                        {r.name}
                      </strong>
                      <span className="text-[10px] text-slate-400 block truncate mt-0.5">{r.description.split(',')[0]}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* 4 Package Cards displaying prices strictly for selected homepageRoute */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {packages.map(pkg => {
                  const unitPrice = pkg.basePrices[homepageRoute] ?? 0;
                  const isFeatured = pkg.packageId === 'ac_lunch';

                  return (
                    <div
                      key={pkg.packageId}
                      className={`shiny-dark-card p-5 rounded-2xl border flex flex-col justify-between space-y-3 relative transition-all duration-300 ${
                        isFeatured
                          ? 'border-amber-400/80 shadow-lg shadow-amber-500/10'
                          : 'border-white/10 hover:border-white/20'
                      }`}
                    >
                      {isFeatured && (
                        <div className="absolute -top-2.5 right-4 bg-amber-500 text-slate-950 font-black text-[9px] uppercase tracking-wider px-2.5 py-0.5 rounded-full shadow">
                          Most Popular
                        </div>
                      )}

                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between">
                          <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                            pkg.isAC ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-700 text-slate-300'
                          }`}>
                            {pkg.isAC ? 'Air Conditioned' : 'Non-AC Bus'}
                          </span>
                          <span className="text-xl font-black text-amber-400 font-mono">
                            ₹{unitPrice} <span className="text-[10px] text-slate-400 font-normal">/ person</span>
                          </span>
                        </div>

                        <h3 className="font-bold text-white text-base">{pkg.title}</h3>
                        <p className="text-xs text-slate-400 leading-relaxed">
                          {pkg.description}
                        </p>
                      </div>

                      <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-2">
                        <span className="text-[10px] text-slate-400">
                          {routes.find(r => r.id === homepageRoute)?.name}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setPreselectedRoute(homepageRoute);
                            const el = document.getElementById('booking-section');
                            if (el) el.scrollIntoView({ behavior: 'smooth' });
                          }}
                          className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <span>Book</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Compulsory charges pill banner */}
              <div className="mt-4 p-3.5 rounded-xl bg-white/5 border border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-300 gap-2">
                <span>
                  <strong>Guide Charge & Sea Link Toll:</strong> Guide (₹50/pax) + Sea Link Toll (₹10/pax) = ₹60 per person — Payable directly to Guide inside the bus. Not included in online booking fare or ₹200 advance.
                </span>
                <button
                  type="button"
                  onClick={() => navigateTo('charges')}
                  className="text-amber-400 font-semibold hover:underline shrink-0 cursor-pointer"
                >
                  View Extra Charges Breakdown &gt;
                </button>
              </div>
            </section>

            {/* SECTION 5: ALL 44 SIGHTSEEING POINTS SHOWCASE */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
                <div>
                  <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                    Comprehensive Sightseeing Circuit
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
                    All 44 Mumbai Tour Landmarks
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Featuring designated BUS HALT stops where passengers can disembark, plus panoramic drive-by heritage points.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => navigateTo('places')}
                  className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                >
                  <span>Explore All 44 Points in Detail</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Show text-only directory of points */}
              <TourPointsGrid onSelectBooking={() => navigateTo('booking')} />
            </section>

            {/* SECTION 5B: DEDICATED MUMBAI DARSHAN PHOTO GALLERY */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <PhotoGallery />
            </section>

            {/* SECTION 6: FOUR PICKUP ROUTES & TIMINGS PREVIEW */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
                <div>
                  <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                    Dedicated Morning Pickups
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
                    Pickup Corridors & Schedules (71 Stops)
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Board from your closest suburban landmark. Daily departures across all lines.
                  </p>
                </div>

                <button
                  onClick={() => navigateTo('pickups')}
                  className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                >
                  <span>Search All 71 Pickup Points</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <PickupTimingsTable onSelectPickup={handleSelectPickupFromTable} />
            </section>

            {/* SECTION 7: FREQUENTLY ASKED QUESTIONS PREVIEW */}
            <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center space-y-2 mb-8">
                <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                  Got Questions?
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Frequently Asked Questions
                </h2>
              </div>

              <FAQPage />
            </section>

            {/* SECTION 8: CONTACT & WHATSAPP BANNER */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="shiny-dark-card rounded-3xl p-8 sm:p-12 border border-white/10 relative overflow-hidden text-center sm:text-left flex flex-col sm:flex-row sm:items-center justify-between gap-6">
                <div className="space-y-2 max-w-xl">
                  <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                    Need Immediate Assistance?
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                    Call or WhatsApp Our Helpline
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    Our team is available 365 days from 6:00 AM to 10:30 PM to assist with pickup inquiries, special requests, and seat confirmations.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
                  <a
                    href={`tel:${settings.businessPhone}`}
                    className="w-full sm:w-auto px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center justify-center gap-2 border border-white/15 transition-colors"
                  >
                    <Phone className="w-4 h-4 text-amber-400" />
                    <span>Call {settings.businessPhone}</span>
                  </a>

                  <a
                    href={`https://wa.me/${settings.whatsappNumber}?text=Hello%20Mumbai%20Darshan%20Bus,%20I%20have%20an%20urgent%20query.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Chat on WhatsApp</span>
                  </a>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* ================= PAGE 2: BOOKING ================= */}
        {activePage === 'booking' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
            <div className="text-center space-y-2">
              <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                Official Booking Engine
              </span>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                Reserve Mumbai Darshan Bus
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 max-w-lg mx-auto">
                Step-by-step reservation. Real-time active prices from backend with instant printable voucher.
              </p>
            </div>

            <BookingForm initialRoute={preselectedRoute} />
          </div>
        )}

        {/* ================= PAGE 3: PRICING ================= */}
        {activePage === 'pricing' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <PricingPackagesPage onBookNow={() => navigateTo('booking')} />
          </div>
        )}

        {/* ================= PAGE 4: PICKUPS ================= */}
        {activePage === 'pickups' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
            <div className="text-center space-y-2">
              <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                71 Boarding Stops Across 4 Lines
              </span>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                Pickup Routes, Stops & Morning Timings
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
                Western Line (26 stops), Central Line (19 stops), Harbour Line (11 stops), and Kalyan–Dombivli Line (15 stops).
              </p>
            </div>

            <PickupTimingsTable onSelectPickup={handleSelectPickupFromTable} />
          </div>
        )}

        {/* ================= PAGE 5: PLACES COVERED (ALL 44) ================= */}
        {activePage === 'places' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
            <div className="text-center space-y-2">
              <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                Complete Itinerary
              </span>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                Places Covered — All 44 Sightseeing Landmarks
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
                Discover all 44 iconic destinations. Filter by BUS HALT (passengers can get down) versus NO HALT (panoramic window viewing).
              </p>
            </div>

            <TourPointsGrid onSelectBooking={() => navigateTo('booking')} />
          </div>
        )}

        {/* ================= PAGE 5B: PHOTO GALLERY ================= */}
        {activePage === 'gallery' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
            <PhotoGallery />
          </div>
        )}

        {/* ================= PAGE 6: ATTRACTION TICKETS & CHARGES ================= */}
        {activePage === 'charges' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <AttractionChargesPage onBookNow={() => navigateTo('booking')} />
          </div>
        )}

        {/* ================= PAGE 7: CAR RENTAL ENQUIRY ================= */}
        {activePage === 'car-rental' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
            <div className="text-center space-y-2">
              <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                Customized Private Charters
              </span>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                Car Rental & Private Bus Charters
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
                Hire private AC Sedans, Innova Crysta, or Tempo Travellers with dedicated doorstep pickup from anywhere in Mumbai, Navi Mumbai, or Thane.
              </p>
            </div>

            <CarRentalPanel />
          </div>
        )}

        {/* ================= PAGE 8: GROUP BOOKING ENQUIRY ================= */}
        {activePage === 'group-booking' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <GroupBookingPage />
          </div>
        )}

        {/* ================= PAGE 9: ABOUT US ================= */}
        {activePage === 'about' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <AboutUsPage />
          </div>
        )}

        {/* ================= PAGE 10: CONTACT US ================= */}
        {activePage === 'contact' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <ContactUsPage />
          </div>
        )}

        {/* ================= PAGE 11: FAQ ================= */}
        {activePage === 'faq' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <FAQPage />
          </div>
        )}

        {/* ================= PAGE 12: BOOKING STATUS / LOOKUP ================= */}
        {activePage === 'lookup' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <BookingLookup />
          </div>
        )}

        {/* ================= PAGE 13: CANCELLATION & REFUND POLICY ================= */}
        {activePage === 'cancellation-policy' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <LegalPoliciesPage initialTab="cancellation" />
          </div>
        )}

        {/* ================= PAGE 14: PRIVACY POLICY ================= */}
        {activePage === 'privacy-policy' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <LegalPoliciesPage initialTab="privacy" />
          </div>
        )}

        {/* ================= PAGE 15: TERMS AND CONDITIONS ================= */}
        {activePage === 'terms' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <LegalPoliciesPage initialTab="terms" />
          </div>
        )}
      </main>

      {/* Floating Bottom Action Bar on Mobile (<15% Mobile Sticky Cap) */}
      <aside
        aria-label="Mobile quick actions"
        className="sm:hidden sticky bottom-0 z-40 bg-[#090a0f]/95 backdrop-blur-md border-t border-white/10 px-2 py-2 pb-[max(0.6rem,env(safe-area-inset-bottom))] flex items-center justify-between gap-1.5 w-full max-w-full box-border no-print"
      >
        <a
          href={`tel:${settings.businessPhone}`}
          className="flex-1 min-w-0 py-2 px-1 rounded-lg bg-white/10 hover:bg-white/15 text-white font-semibold text-[11px] flex items-center justify-center gap-1 border border-white/5 transition-colors"
        >
          <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="truncate">Call Desk</span>
        </a>

        <a
          href={`https://wa.me/${settings.whatsappNumber}?text=Hello%20Mumbai%20Darshan%20Bus,%20I%20have%20an%20enquiry.`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 min-w-0 py-2 px-1 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/40 text-emerald-300 font-semibold text-[11px] flex items-center justify-center gap-1 border border-emerald-500/30 transition-colors"
        >
          <MessageCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="truncate">WhatsApp</span>
        </a>

        <button
          onClick={() => navigateTo('booking')}
          className="flex-1 min-w-0 py-2 px-1 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-[11px] flex items-center justify-center shadow-md shadow-amber-500/20 active:scale-95 transition-all"
        >
          <span className="truncate">Book Now</span>
        </button>
      </aside>

      {/* Footer Component */}
      <Footer setActivePage={navigateTo} />
    </div>
  );
}
