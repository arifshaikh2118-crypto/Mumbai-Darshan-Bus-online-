import {
  Booking,
  RouteConfig,
  PickupPoint,
  PackagePricing,
  RouteOffer,
  ExtraCharge,
  TourPoint,
  CarRentalEnquiry,
  GroupBookingEnquiry,
  CancellationRequest,
  AppSettings,
  PriceHistoryRecord,
  RouteId,
  PackageId,
  GalleryImage,
  LocalRentalPackage,
  OutstationVehicleRate,
  OfflineAttractionRecord
} from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_ROUTES,
  INITIAL_PACKAGES,
  INITIAL_OFFERS,
  INITIAL_EXTRA_CHARGES,
  INITIAL_PICKUP_POINTS,
  INITIAL_TOUR_POINTS,
  INITIAL_SAMPLE_BOOKINGS,
  INITIAL_GALLERY_IMAGES,
  INITIAL_LOCAL_RENTAL_PACKAGES,
  INITIAL_OUTSTATION_RATES,
  INITIAL_OFFLINE_ATTRACTIONS
} from '../data/initialData';

const KEYS = {
  SETTINGS: 'mdb_settings_v1',
  ROUTES: 'mdb_routes_v1',
  PACKAGES: 'mdb_packages_v1',
  OFFERS: 'mdb_offers_v1',
  EXTRA_CHARGES: 'mdb_extra_charges_v1',
  PICKUP_POINTS: 'mdb_pickup_points_v1',
  TOUR_POINTS: 'mdb_tour_points_v1',
  BOOKINGS: 'mdb_bookings_v1',
  CAR_RENTALS: 'mdb_car_rentals_v1',
  GROUP_ENQUIRIES: 'mdb_group_enquiries_v1',
  CANCELLATIONS: 'mdb_cancellations_v1',
  PRICE_HISTORY: 'mdb_price_history_v1',
  GALLERY: 'mdb_gallery_v2',
  LOCAL_RENTAL: 'mdb_local_rental_v1',
  OUTSTATION_RATES: 'mdb_outstation_rates_v1',
  OFFLINE_ATTRACTIONS: 'mdb_offline_attractions_v1'
};

function getItem<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.error(`Error reading ${key} from storage:`, e);
    return fallback;
  }
}

function setItem<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error(`Error writing ${key} to storage:`, e);
  }
}

export class StorageService {
  // Settings
  static getSettings(): AppSettings {
    return getItem<AppSettings>(KEYS.SETTINGS, INITIAL_SETTINGS);
  }

  static updateSettings(settings: Partial<AppSettings>): AppSettings {
    const current = this.getSettings();
    const updated = { ...current, ...settings };
    setItem(KEYS.SETTINGS, updated);
    return updated;
  }

  // Routes
  static getRoutes(): RouteConfig[] {
    return getItem<RouteConfig[]>(KEYS.ROUTES, INITIAL_ROUTES);
  }

  static saveRoutes(routes: RouteConfig[]): void {
    setItem(KEYS.ROUTES, routes);
  }

  static updateRoute(id: RouteId, changes: Partial<RouteConfig>): void {
    const routes = this.getRoutes();
    const idx = routes.findIndex(r => r.id === id);
    if (idx !== -1) {
      routes[idx] = { ...routes[idx], ...changes };
      this.saveRoutes(routes);
    }
  }

  // Packages & Pricing
  static getPackages(): PackagePricing[] {
    return getItem<PackagePricing[]>(KEYS.PACKAGES, INITIAL_PACKAGES);
  }

  static savePackages(packages: PackagePricing[]): void {
    setItem(KEYS.PACKAGES, packages);
  }

  static updatePackagePrice(
    packageId: PackageId,
    routeId: RouteId,
    newPrice: number,
    adminName: string = 'Admin'
  ): void {
    const packages = this.getPackages();
    const pkg = packages.find(p => p.packageId === packageId);
    if (pkg) {
      const oldPrice = pkg.basePrices[routeId] ?? 0;
      pkg.basePrices[routeId] = newPrice;
      this.savePackages(packages);

      // Record in price history
      const history = this.getPriceHistory();
      const record: PriceHistoryRecord = {
        id: 'PH-' + Date.now(),
        timestamp: new Date().toISOString(),
        routeId,
        packageId,
        oldPrice,
        newPrice,
        updatedBy: adminName
      };
      history.unshift(record);
      setItem(KEYS.PRICE_HISTORY, history);
    }
  }

  static getPriceHistory(): PriceHistoryRecord[] {
    return getItem<PriceHistoryRecord[]>(KEYS.PRICE_HISTORY, []);
  }

  // Offers
  static getOffers(): RouteOffer[] {
    return getItem<RouteOffer[]>(KEYS.OFFERS, INITIAL_OFFERS);
  }

  static saveOffers(offers: RouteOffer[]): void {
    setItem(KEYS.OFFERS, offers);
  }

  static updateRouteOffer(routeId: RouteId, offerChanges: Partial<RouteOffer>): void {
    const offers = this.getOffers();
    const idx = offers.findIndex(o => o.routeId === routeId);
    if (idx !== -1) {
      offers[idx] = { ...offers[idx], ...offerChanges };
    } else {
      offers.push({
        routeId,
        enabled: false,
        discountType: 'flat',
        discountValue: 0,
        label: `${routeId} Offer`,
        ...offerChanges
      });
    }
    this.saveOffers(offers);
  }

  // Extra Charges
  static getExtraCharges(): ExtraCharge[] {
    return getItem<ExtraCharge[]>(KEYS.EXTRA_CHARGES, INITIAL_EXTRA_CHARGES);
  }

  static saveExtraCharges(charges: ExtraCharge[]): void {
    setItem(KEYS.EXTRA_CHARGES, charges);
  }

  static updateExtraCharge(id: string, changes: Partial<ExtraCharge>): void {
    const charges = this.getExtraCharges();
    const idx = charges.findIndex(c => c.id === id);
    if (idx !== -1) {
      charges[idx] = { ...charges[idx], ...changes };
      this.saveExtraCharges(charges);
    }
  }

  // Pickup Points
  static getPickupPoints(): PickupPoint[] {
    return getItem<PickupPoint[]>(KEYS.PICKUP_POINTS, INITIAL_PICKUP_POINTS);
  }

  static savePickupPoints(points: PickupPoint[]): void {
    setItem(KEYS.PICKUP_POINTS, points);
  }

  static addPickupPoint(point: Omit<PickupPoint, 'id'>): PickupPoint {
    const points = this.getPickupPoints();
    const newPoint: PickupPoint = {
      ...point,
      id: `pt_${Date.now()}_${Math.floor(Math.random() * 1000)}`
    };
    points.push(newPoint);
    this.savePickupPoints(points);
    return newPoint;
  }

  static updatePickupPoint(id: string, changes: Partial<PickupPoint>): void {
    const points = this.getPickupPoints();
    const idx = points.findIndex(p => p.id === id);
    if (idx !== -1) {
      points[idx] = { ...points[idx], ...changes };
      this.savePickupPoints(points);
    }
  }

  static deletePickupPoint(id: string): void {
    const points = this.getPickupPoints().filter(p => p.id !== id);
    this.savePickupPoints(points);
  }

  // Tour Points (All 44)
  static getTourPoints(): TourPoint[] {
    return getItem<TourPoint[]>(KEYS.TOUR_POINTS, INITIAL_TOUR_POINTS);
  }

  static saveTourPoints(points: TourPoint[]): void {
    setItem(KEYS.TOUR_POINTS, points);
  }

  static updateTourPoint(id: number, changes: Partial<TourPoint>): void {
    const points = this.getTourPoints();
    const idx = points.findIndex(p => p.id === id);
    if (idx !== -1) {
      points[idx] = { ...points[idx], ...changes };
      this.saveTourPoints(points);
    }
  }

  // Bookings
  static getBookings(): Booking[] {
    return getItem<Booking[]>(KEYS.BOOKINGS, INITIAL_SAMPLE_BOOKINGS);
  }

  static saveBookings(bookings: Booking[]): void {
    setItem(KEYS.BOOKINGS, bookings);
  }

  static getBookingById(id: string): Booking | undefined {
    return this.getBookings().find(b => b.id.trim().toUpperCase() === id.trim().toUpperCase());
  }

  static getBookingsByMobile(mobile: string): Booking[] {
    const cleanMobile = mobile.replace(/\D/g, '').slice(-10);
    return this.getBookings().filter(b => b.customerMobile.replace(/\D/g, '').slice(-10) === cleanMobile);
  }

  static generateBookingId(): string {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    const rand = Math.floor(1000 + Math.random() * 9000);
    return `MDB-${yyyy}${mm}${dd}-${rand}`;
  }

  static createBooking(data: Omit<Booking, 'id' | 'createdAt' | 'historyLog'>): Booking {
    const bookings = this.getBookings();
    const newBooking: Booking = {
      ...data,
      id: this.generateBookingId(),
      createdAt: new Date().toISOString(),
      historyLog: [
        {
          timestamp: new Date().toISOString(),
          action: 'Booking Created',
          notes: `Customer created booking. Advance: ₹${data.amountPaid}, Balance: ₹${data.balancePayable}`
        }
      ]
    };

    bookings.unshift(newBooking);
    this.saveBookings(bookings);

    // Auto-sync to Google Sheets Webhook if configured
    const settings = this.getSettings();
    if (settings.autoSyncGoogleSheets && settings.googleSheetsWebhookUrl) {
      this.syncBookingToGoogleSheets(newBooking, settings.googleSheetsWebhookUrl);
    }

    return newBooking;
  }

  static updateBooking(id: string, changes: Partial<Booking>, noteAction?: string): Booking | null {
    const bookings = this.getBookings();
    const idx = bookings.findIndex(b => b.id === id);
    if (idx === -1) return null;

    const old = bookings[idx];
    const history = old.historyLog ? [...old.historyLog] : [];
    if (noteAction) {
      history.unshift({
        timestamp: new Date().toISOString(),
        action: noteAction,
        notes: changes.adminNotes || 'Status or detail modified by Admin'
      });
    }

    const updated: Booking = {
      ...old,
      ...changes,
      lastUpdated: new Date().toISOString(),
      historyLog: history
    };

    bookings[idx] = updated;
    this.saveBookings(bookings);
    return updated;
  }

  // Gallery Images (Strictly verified authentic Mumbai sightseeing images)
  static getGalleryImages(): GalleryImage[] {
    const images = getItem<GalleryImage[]>(KEYS.GALLERY, INITIAL_GALLERY_IMAGES);
    const verified = images.filter(img => !img.imageUrl.includes('images.unsplash.com'));
    if (verified.length === 0) return INITIAL_GALLERY_IMAGES;
    return verified;
  }

  static saveGalleryImages(images: GalleryImage[]): void {
    setItem(KEYS.GALLERY, images);
  }

  static addGalleryImage(img: Omit<GalleryImage, 'id' | 'uploadedAt'>): GalleryImage {
    const images = this.getGalleryImages();
    const newImg: GalleryImage = {
      ...img,
      id: `gal_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      uploadedAt: new Date().toISOString()
    };
    images.push(newImg);
    this.saveGalleryImages(images);
    return newImg;
  }

  static updateGalleryImage(id: string, changes: Partial<GalleryImage>): void {
    const images = this.getGalleryImages();
    const idx = images.findIndex(img => img.id === id);
    if (idx !== -1) {
      images[idx] = { ...images[idx], ...changes };
      this.saveGalleryImages(images);
    }
  }

  static deleteGalleryImage(id: string): void {
    const images = this.getGalleryImages().filter(img => img.id !== id);
    this.saveGalleryImages(images);
  }

  // Local Rental Packages (12 hr / 120 km)
  static getLocalRentalPackages(): LocalRentalPackage[] {
    return getItem<LocalRentalPackage[]>(KEYS.LOCAL_RENTAL, INITIAL_LOCAL_RENTAL_PACKAGES);
  }

  static saveLocalRentalPackages(packages: LocalRentalPackage[]): void {
    setItem(KEYS.LOCAL_RENTAL, packages);
  }

  static updateLocalRentalPackage(id: string, changes: Partial<LocalRentalPackage>): void {
    const packages = this.getLocalRentalPackages();
    const idx = packages.findIndex(p => p.id === id);
    if (idx !== -1) {
      packages[idx] = { ...packages[idx], ...changes };
      this.saveLocalRentalPackages(packages);
    }
  }

  // Outstation Vehicle Rates (300 km/day min)
  static getOutstationRates(): OutstationVehicleRate[] {
    return getItem<OutstationVehicleRate[]>(KEYS.OUTSTATION_RATES, INITIAL_OUTSTATION_RATES);
  }

  static saveOutstationRates(rates: OutstationVehicleRate[]): void {
    setItem(KEYS.OUTSTATION_RATES, rates);
  }

  static updateOutstationRate(id: string, changes: Partial<OutstationVehicleRate>): void {
    const rates = this.getOutstationRates();
    const idx = rates.findIndex(r => r.id === id);
    if (idx !== -1) {
      rates[idx] = { ...rates[idx], ...changes };
      this.saveOutstationRates(rates);
    }
  }

  // Offline Attraction Collections (Tour Guide Collected on Bus)
  static getOfflineAttractions(): OfflineAttractionRecord[] {
    return getItem<OfflineAttractionRecord[]>(KEYS.OFFLINE_ATTRACTIONS, INITIAL_OFFLINE_ATTRACTIONS);
  }

  static saveOfflineAttractions(records: OfflineAttractionRecord[]): void {
    setItem(KEYS.OFFLINE_ATTRACTIONS, records);
  }

  static recordOfflineCollection(data: Omit<OfflineAttractionRecord, 'id' | 'collectedAt'>): OfflineAttractionRecord {
    const records = this.getOfflineAttractions();
    const newRecord: OfflineAttractionRecord = {
      ...data,
      id: `off_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      collectedAt: new Date().toISOString()
    };
    records.unshift(newRecord);
    this.saveOfflineAttractions(records);
    return newRecord;
  }

  static updateOfflineAttraction(id: string, changes: Partial<OfflineAttractionRecord>): void {
    const records = this.getOfflineAttractions();
    const idx = records.findIndex(r => r.id === id);
    if (idx !== -1) {
      records[idx] = { ...records[idx], ...changes };
      this.saveOfflineAttractions(records);
    }
  }

  // Car Rental Enquiries
  static getCarRentals(): CarRentalEnquiry[] {
    return getItem<CarRentalEnquiry[]>(KEYS.CAR_RENTALS, [
      {
        id: 'CRE-20261109-101',
        createdAt: '2026-11-09T11:00:00Z',
        customerName: 'Sanjay Deshmukh',
        customerMobile: '9820011223',
        customerEmail: 'sanjay.d@example.com',
        travelDate: '2026-11-15',
        rentalType: 'local_darshan',
        vehicleType: 'Innova Crysta AC (7 Seater)',
        isAC: true,
        passengerCount: 6,
        pickupLocation: 'Bandra Kurla Complex (BKC)',
        destination: 'South Mumbai Sightseeing',
        preferredPickupTime: '8:00 AM',
        daysCount: 1,
        estimatedKm: 120,
        specialRequirements: 'Airport pickup at 8 AM, then full day city sightseeing.',
        status: 'Quotation Sent',
        supplierCost: 4500,
        customerQuotation: 5500,
        grossMargin: 1000,
        adminNotes: 'Proposed customer quote sent via WhatsApp.'
      }
    ]);
  }

  static createCarRentalEnquiry(data: Omit<CarRentalEnquiry, 'id' | 'createdAt' | 'status'>): CarRentalEnquiry {
    const rentals = this.getCarRentals();
    const newEnquiry: CarRentalEnquiry = {
      ...data,
      id: `CRE-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`,
      createdAt: new Date().toISOString(),
      status: 'New Enquiry'
    };
    rentals.unshift(newEnquiry);
    setItem(KEYS.CAR_RENTALS, rentals);

    // Auto-sync to Google Sheets Webhook if configured
    const settings = this.getSettings();
    if (settings.autoSyncGoogleSheets && settings.googleSheetsWebhookUrl) {
      this.syncRentalToGoogleSheets(newEnquiry);
    }

    return newEnquiry;
  }

  static updateCarRental(id: string, changes: Partial<CarRentalEnquiry>): void {
    const rentals = this.getCarRentals();
    const idx = rentals.findIndex(r => r.id === id);
    if (idx !== -1) {
      rentals[idx] = { ...rentals[idx], ...changes };
      setItem(KEYS.CAR_RENTALS, rentals);
    }
  }

  // Group Enquiries
  static getGroupEnquiries(): GroupBookingEnquiry[] {
    return getItem<GroupBookingEnquiry[]>(KEYS.GROUP_ENQUIRIES, [
      {
        id: 'GRP-20261109-201',
        createdAt: '2026-11-09T12:00:00Z',
        organizationName: 'Tata Consultancy Services - Cultural Club',
        contactPerson: 'Meera Iyer',
        mobile: '9819033445',
        email: 'meera.i@example.com',
        tentativeDate: '2026-11-20',
        approximatePassengers: 45,
        groupType: 'Corporate',
        preferredBusType: 'AC 49-Seater',
        lunchRequired: true,
        customRequests: 'Need morning breakfast and lunch packets for 45 employees. Customized pickup from Thane Hiranandani.',
        status: 'Quote Sent',
        adminNotes: 'Sent custom quote with veg thali lunch.'
      }
    ]);
  }

  static createGroupEnquiry(data: Omit<GroupBookingEnquiry, 'id' | 'createdAt' | 'status'>): GroupBookingEnquiry {
    const enquiries = this.getGroupEnquiries();
    const newEnquiry: GroupBookingEnquiry = {
      ...data,
      id: `GRP-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`,
      createdAt: new Date().toISOString(),
      status: 'New'
    };
    enquiries.unshift(newEnquiry);
    setItem(KEYS.GROUP_ENQUIRIES, enquiries);
    return newEnquiry;
  }

  static updateGroupEnquiry(id: string, changes: Partial<GroupBookingEnquiry>): void {
    const enquiries = this.getGroupEnquiries();
    const idx = enquiries.findIndex(g => g.id === id);
    if (idx !== -1) {
      enquiries[idx] = { ...enquiries[idx], ...changes };
      setItem(KEYS.GROUP_ENQUIRIES, enquiries);
    }
  }

  // Cancellation Requests
  static getCancellationRequests(): CancellationRequest[] {
    return getItem<CancellationRequest[]>(KEYS.CANCELLATIONS, []);
  }

  static requestCancellation(data: Omit<CancellationRequest, 'id' | 'requestDate' | 'status'>): CancellationRequest {
    const requests = this.getCancellationRequests();
    const newReq: CancellationRequest = {
      ...data,
      id: `CAN-${Date.now()}`,
      requestDate: new Date().toISOString(),
      status: 'Pending'
    };
    requests.unshift(newReq);
    setItem(KEYS.CANCELLATIONS, requests);
    return newReq;
  }

  static updateCancellationRequest(id: string, changes: Partial<CancellationRequest>): void {
    const requests = this.getCancellationRequests();
    const idx = requests.findIndex(r => r.id === id);
    if (idx !== -1) {
      requests[idx] = { ...requests[idx], ...changes };
      setItem(KEYS.CANCELLATIONS, requests);
    }
  }

  // Google Sheets Webhook Sync Helper
  static async syncBookingToGoogleSheets(booking: Booking, webhookUrl: string): Promise<{ success: boolean; message: string }> {
    try {
      const payload = {
        action: 'NEW_BOOKING',
        bookingId: booking.id,
        travelDate: booking.travelDate,
        createdAt: booking.createdAt,
        customerName: booking.customerName,
        customerMobile: booking.customerMobile,
        customerEmail: booking.customerEmail,
        route: booking.routeName,
        pickupPoint: booking.pickupPointName,
        pickupTime: booking.pickupTime,
        package: booking.packageTitle,
        passengers: booking.passengerCount,
        vegBiryani: booking.foodSelections?.vegBiryani || 0,
        butterPaneer: booking.foodSelections?.butterPaneer || 0,
        vegThali: booking.foodSelections?.vegThali || 0,
        unitPackagePrice: booking.unitPackagePrice,
        packageAmount: booking.totalPackageAmount,
        onlineBookingFare: booking.grandTotal, // e.g. ₹1,500
        advancePayable: booking.amountPayableNow, // ₹200 advance per booking
        balancePayable: booking.balancePayable, // e.g. ₹1,300 payable on bus
        guideChargeUnit: booking.compulsoryCharges.guideChargeUnit,
        guideCharge: booking.compulsoryCharges.guideChargeTotal, // e.g. ₹150 payable to Guide
        seaLinkTollUnit: booking.compulsoryCharges.seaLinkTollUnit,
        seaLinkToll: booking.compulsoryCharges.seaLinkTollTotal, // e.g. ₹30 payable to Guide
        totalPayableToGuide: (booking.compulsoryCharges.guideChargeTotal + booking.compulsoryCharges.seaLinkTollTotal), // e.g. ₹180 payable to Guide inside bus
        optionalAttractions: booking.selectedOptionalAttractions.map(a => `${a.name} (x${a.passengerCount})`).join('; ') || 'None',
        optionalAmount: booking.totalOptionalAmount,
        grandTotal: booking.grandTotal, // Online Booking Fare
        amountInr: booking.grandTotal, // Authoritative column 15
        paymentMode: booking.paymentMode,
        amountPaid: booking.amountPaid,
        paymentStatus: booking.paymentStatus,
        bookingStatus: booking.bookingStatus,
        specialRequest: booking.specialRequest || ''
      };

      // Try reliable server proxy first to avoid browser CORS/no-cors issues
      try {
        const proxyRes = await fetch('/api/sync-sheets', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ webhookUrl, payload })
        });
        if (proxyRes.ok) {
          this.updateBooking(booking.id, { syncedToGoogleSheets: true, customerEmailStatus: 'Queued', ownerEmailStatus: 'Queued' });
          return { success: true, message: 'Booking confirmed & synchronized with Google Sheets.' };
        }
      } catch (proxyErr) {
        // Fallback for purely client-side static preview
        await fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          mode: 'no-cors',
          body: JSON.stringify(payload)
        });
      }

      this.updateBooking(booking.id, { syncedToGoogleSheets: true });
      return { success: true, message: 'Booking synchronized with Google Sheets.' };
    } catch (err: any) {
      console.warn('Google Sheets sync notice:', err);
      return { success: false, message: err?.message || 'Sync failed' };
    }
  }

  // Retry failed or queued booking emails via Google Apps Script Webhook
  static async retryBookingEmail(bookingId: string): Promise<{ success: boolean; message: string }> {
    const settings = this.getSettings();
    const webhookUrl = settings.googleSheetsWebhookUrl?.trim();
    if (!webhookUrl) {
      return { success: false, message: 'No Google Sheets Webhook URL configured in Settings.' };
    }

    try {
      const response = await fetch('/api/sync-sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          webhookUrl,
          payload: {
            action: 'RETRY_EMAILS',
            bookingId: bookingId
          }
        })
      });

      if (response.ok) {
        this.updateBooking(bookingId, { customerEmailStatus: 'Sent', ownerEmailStatus: 'Sent' });
        return { success: true, message: 'Email retry dispatched successfully.' };
      } else {
        this.updateBooking(bookingId, { customerEmailStatus: 'Failed', ownerEmailStatus: 'Failed' });
        return { success: false, message: 'Failed to trigger email retry on Apps Script webhook.' };
      }
    } catch (e: any) {
      return { success: false, message: e.message || 'Network error triggering retry' };
    }
  }

  // Reliable sync for Rental Enquiries to Google Sheets
  static async syncRentalToGoogleSheets(rental: CarRentalEnquiry): Promise<{ success: boolean; message: string }> {
    const settings = this.getSettings();
    const webhookUrl = settings.googleSheetsWebhookUrl?.trim();
    if (!webhookUrl) {
      return { success: false, message: 'No Google Sheets Webhook URL configured' };
    }

    try {
      const payload = {
        action: 'NEW_RENTAL_ENQUIRY',
        id: rental.id,
        customerName: rental.customerName,
        customerMobile: rental.customerMobile,
        customerEmail: rental.customerEmail,
        rentalType: rental.rentalType,
        vehicleType: rental.vehicleType,
        travelDate: rental.travelDate,
        passengerCount: rental.passengerCount,
        pickupLocation: rental.pickupLocation,
        destination: rental.destination,
        daysCount: rental.daysCount,
        estimatedKm: rental.estimatedKm,
        customerQuotation: rental.customerQuotation,
        supplierCost: rental.supplierCost,
        status: rental.status,
        specialRequirements: rental.specialRequirements
      };

      try {
        await fetch('/api/sync-sheets', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ webhookUrl, payload })
        });
      } catch {
        await fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          mode: 'no-cors',
          body: JSON.stringify(payload)
        });
      }

      return { success: true, message: 'Rental enquiry synchronized with Google Sheets.' };
    } catch (err: any) {
      return { success: false, message: err?.message || 'Sync failed' };
    }
  }

  // CSV Export for Bookings
  static exportBookingsToCSV(): void {
    const bookings = this.getBookings();
    const headers = [
      'Booking ID',
      'Created At',
      'Travel Date',
      'Customer Name',
      'Mobile',
      'Email',
      'Route',
      'Pickup Point',
      'Pickup Time',
      'Package',
      'Passengers',
      'Biryani',
      'Paneer',
      'Thali',
      'Package Total (₹)',
      'Guide Charge (₹)',
      'Sea Link Toll (₹)',
      'Optional Extras (₹)',
      'Grand Total (₹)',
      'Paid Now (₹)',
      'Balance Payable (₹)',
      'Payment Status',
      'Booking Status',
      'Special Requests'
    ];

    const rows = bookings.map(b => [
      `"${b.id}"`,
      `"${b.createdAt.slice(0, 10)}"`,
      `"${b.travelDate}"`,
      `"${b.customerName.replace(/"/g, '""')}"`,
      `"${b.customerMobile}"`,
      `"${b.customerEmail}"`,
      `"${b.routeName}"`,
      `"${b.pickupPointName}"`,
      `"${b.pickupTime}"`,
      `"${b.packageTitle}"`,
      b.passengerCount,
      b.foodSelections?.vegBiryani || 0,
      b.foodSelections?.butterPaneer || 0,
      b.foodSelections?.vegThali || 0,
      b.totalPackageAmount,
      b.compulsoryCharges.guideChargeTotal,
      b.compulsoryCharges.seaLinkTollTotal,
      b.totalOptionalAmount,
      b.grandTotal,
      b.amountPaid,
      b.balancePayable,
      `"${b.paymentStatus}"`,
      `"${b.bookingStatus}"`,
      `"${(b.specialRequest || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Mumbai_Darshan_Bookings_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Reset to factory defaults
  static resetToDefaults(): void {
    localStorage.removeItem(KEYS.SETTINGS);
    localStorage.removeItem(KEYS.ROUTES);
    localStorage.removeItem(KEYS.PACKAGES);
    localStorage.removeItem(KEYS.OFFERS);
    localStorage.removeItem(KEYS.EXTRA_CHARGES);
    localStorage.removeItem(KEYS.PICKUP_POINTS);
    localStorage.removeItem(KEYS.TOUR_POINTS);
    localStorage.removeItem(KEYS.BOOKINGS);
    localStorage.removeItem(KEYS.CAR_RENTALS);
    localStorage.removeItem(KEYS.GROUP_ENQUIRIES);
    localStorage.removeItem(KEYS.CANCELLATIONS);
    localStorage.removeItem(KEYS.PRICE_HISTORY);
  }
}
