import React, { useState } from 'react';
import { Users, Bus, Calendar, Phone, Mail, CheckCircle2, ShieldCheck, ArrowRight, Building } from 'lucide-react';
import { StorageService } from '../services/storage';

export const GroupBookingPage: React.FC = () => {
  const [organizationName, setOrganizationName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [tentativeDate, setTentativeDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().slice(0, 10);
  });
  const [approximatePassengers, setApproximatePassengers] = useState(30);
  const [groupType, setGroupType] = useState<'Corporate' | 'Family' | 'School/College' | 'Tour Group' | 'Senior Citizens'>('Corporate');
  const [preferredBusType, setPreferredBusType] = useState<'AC 35-Seater' | 'AC 49-Seater' | 'Non-AC 49-Seater' | 'Multiple Buses'>('AC 49-Seater');
  const [lunchRequired, setLunchRequired] = useState(true);
  const [customRequests, setCustomRequests] = useState('');
  
  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!contactPerson.trim() || contactPerson.trim().length < 3) {
      setErrorMsg('Please enter the contact person name.');
      return;
    }
    const cleanPhone = mobile.replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setErrorMsg('Please enter a valid 10-digit mobile number.');
      return;
    }

    setIsSubmitting(true);
    try {
      const enquiry = StorageService.createGroupEnquiry({
        organizationName: organizationName.trim() || undefined,
        contactPerson: contactPerson.trim(),
        mobile: mobile.trim(),
        email: email.trim(),
        tentativeDate,
        approximatePassengers,
        groupType,
        preferredBusType,
        lunchRequired,
        customRequests: customRequests.trim() || undefined
      });

      setSubmittedId(enquiry.id);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to submit group quote request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      {/* Hero Intro */}
      <div className="text-center space-y-3">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
          Tailored Charter Solutions (10–500+ Passengers)
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Group Booking & Private Bus Charters
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          Planning a company outing, school educational tour, wedding guest sightseeing, or family reunion? We provide dedicated luxury AC buses with custom pickup and catering.
        </p>
      </div>

      {submittedId ? (
        <div className="shiny-dark-card rounded-2xl p-8 text-center space-y-4 border border-emerald-500/30 bg-emerald-500/5">
          <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white">Group Booking Request Submitted!</h2>
          <p className="text-xs text-slate-300 max-w-md mx-auto">
            Your Group Reference Number is <strong className="text-amber-400 font-mono text-sm">{submittedId}</strong>. Our senior group tour consultant will prepare an itemized corporate quotation and call you at <strong className="text-white">+91 {mobile}</strong> within 30 minutes.
          </p>
          <div className="pt-2">
            <button
              onClick={() => {
                setSubmittedId(null);
                setContactPerson('');
                setMobile('');
              }}
              className="text-xs font-semibold text-amber-400 hover:underline cursor-pointer"
            >
              Submit Another Group Request
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="shiny-dark-card rounded-2xl p-6 sm:p-8 border border-white/10 space-y-6">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-300">
              {errorMsg}
            </div>
          )}

          {/* Group details grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5 text-amber-400" />
                Company / School / Family Name
              </label>
              <input
                type="text"
                placeholder="e.g. TCS Mumbai / St. Xavier's High School"
                value={organizationName}
                onChange={e => setOrganizationName(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Contact Person Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Meera Iyer"
                value={contactPerson}
                onChange={e => setContactPerson(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                10-Digit Mobile Number <span className="text-rose-400">*</span>
              </label>
              <input
                type="tel"
                maxLength={10}
                placeholder="9819012345"
                value={mobile}
                onChange={e => setMobile(e.target.value.replace(/\D/g, ''))}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Official Email Address
              </label>
              <input
                type="email"
                placeholder="meera@company.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                Tentative Date
              </label>
              <input
                type="date"
                min={new Date().toISOString().slice(0, 10)}
                value={tentativeDate}
                onChange={e => setTentativeDate(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-amber-400" />
                Estimated Passengers
              </label>
              <input
                type="number"
                min={10}
                max={500}
                value={approximatePassengers}
                onChange={e => setApproximatePassengers(Number(e.target.value))}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Bus className="w-3.5 h-3.5 text-amber-400" />
                Bus Preference
              </label>
              <select
                value={preferredBusType}
                onChange={e => setPreferredBusType(e.target.value as any)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
              >
                <option value="AC 35-Seater">AC 35-Seater Coach</option>
                <option value="AC 49-Seater">AC 49-Seater Luxury</option>
                <option value="Non-AC 49-Seater">Non-AC 49-Seater</option>
                <option value="Multiple Buses">Multiple Fleet Coaches (50+ Pax)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/5">
            <input
              type="checkbox"
              id="lunchCheck"
              checked={lunchRequired}
              onChange={e => setLunchRequired(e.target.checked)}
              className="h-4 w-4 rounded text-amber-500 focus:ring-amber-400 cursor-pointer"
            />
            <label htmlFor="lunchCheck" className="text-xs text-slate-200 cursor-pointer">
              <strong>Include Morning Breakfast & Pure Veg Lunch Packets</strong> (Veg Biryani, Butter Paneer or Veg Thali)
            </label>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Custom Itinerary / Pickup Point / Special Requirements
            </label>
            <textarea
              rows={3}
              placeholder="e.g. Pickup from Hiranandani Estate Thane at 7:30 AM, drop back at BKC at 7:00 PM, senior citizen access needed..."
              value={customRequests}
              onChange={e => setCustomRequests(e.target.value)}
              className="w-full bg-[#12141c] border border-white/10 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Official GST Tax Invoice, corporate PO support & certified guides provided.</span>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs hover:from-amber-300 hover:to-amber-400 cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
            >
              <span>{isSubmitting ? 'Submitting...' : 'Request Corporate Group Quote'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
