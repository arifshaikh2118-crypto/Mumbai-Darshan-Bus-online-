import React, { useState, useMemo } from 'react';
import { Check, ShieldCheck, Utensils, Wind, Sparkles, ArrowRight, Info, MapPin } from 'lucide-react';
import { StorageService } from '../services/storage';
import { RouteId, PackageId } from '../types';

interface PricingPackagesPageProps {
  onBookNow: (routeId?: RouteId, packageId?: PackageId) => void;
}

export const PricingPackagesPage: React.FC<PricingPackagesPageProps> = ({ onBookNow }) => {
  const routes = useMemo(() => StorageService.getRoutes().filter(r => r.active), []);
  const packages = useMemo(() => StorageService.getPackages().filter(p => p.active), []);
  const extraCharges = useMemo(() => StorageService.getExtraCharges().filter(c => c.active), []);
  const offers = useMemo(() => StorageService.getOffers(), []);

  // Customer selects route
  const [selectedRouteId, setSelectedRouteId] = useState<RouteId>('western');

  const selectedRoute = useMemo(() => {
    return routes.find(r => r.id === selectedRouteId) || routes[0];
  }, [routes, selectedRouteId]);

  const currentOffer = useMemo(() => {
    return offers.find(o => o.routeId === selectedRouteId && o.enabled);
  }, [offers, selectedRouteId]);

  const guideCharge = extraCharges.find(c => c.id === 'guide_charge')?.amount || 50;
  const seaLinkToll = extraCharges.find(c => c.id === 'sealink_toll')?.amount || 10;

  return (
    <div className="space-y-12 max-w-6xl mx-auto w-full min-w-0">
      {/* Header */}
      <div className="text-center space-y-3">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
          Transparent Daily Rates · Approved Pricing
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Mumbai Darshan Bus Packages & Route Pricing
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          Select your departure route below to view the exact per-person prices for that route. All fares include transit across 44 tour points and dedicated corridor pickup.
        </p>
      </div>

      {/* STEP 1 FOR USER: SELECT ROUTE FIRST TO SEE ACCURATE PRICES */}
      <div className="bg-[#12141c] p-4 sm:p-6 rounded-2xl border border-white/10 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-amber-400" />
              Select Your Boarding Route
            </label>
            <p className="text-xs text-slate-300 mt-0.5">
              Prices update dynamically for your selected departure line. No mixed or misleading rates.
            </p>
          </div>
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 shrink-0">
            Current: {selectedRoute?.name}
          </span>
        </div>

        {/* 4 Route Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {routes.map(r => {
            const isSelected = selectedRouteId === r.id;
            return (
              <button
                key={r.id}
                type="button"
                onClick={() => setSelectedRouteId(r.id)}
                className={`p-3 sm:p-4 rounded-xl border text-left cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-amber-500/15 border-amber-400 shadow-md shadow-amber-500/10 ring-1 ring-amber-400'
                    : 'bg-slate-900/90 border-white/10 hover:border-white/20 text-slate-300'
                }`}
              >
                <strong className={`block text-xs sm:text-sm font-bold ${isSelected ? 'text-amber-400' : 'text-white'}`}>
                  {r.name}
                </strong>
                <span className="text-[11px] text-slate-400 block mt-1 line-clamp-1">
                  {r.description.split(',')[0]} to S. Mumbai
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Package Comparison Cards (Showing prices strictly for selectedRouteId) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
            <span>Packages for</span>
            <span className="text-amber-400">{selectedRoute?.name}</span>
          </h2>
          <span className="text-xs text-slate-400">All prices shown per person</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {packages.map(pkg => {
            const basePrice = pkg.basePrices[selectedRouteId] ?? 0;
            let displayPrice = basePrice;
            if (currentOffer?.enabled) {
              if (currentOffer.discountType === 'flat') {
                displayPrice = Math.max(0, basePrice - currentOffer.discountValue);
              } else {
                displayPrice = Math.round(basePrice * (1 - currentOffer.discountValue / 100));
              }
            }

            const isFeatured = pkg.packageId === 'ac_lunch';

            return (
              <div
                key={pkg.packageId}
                className={`shiny-dark-card rounded-2xl p-5 border flex flex-col justify-between relative transition-all duration-300 ${
                  isFeatured
                    ? 'border-amber-400/80 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400/40'
                    : 'border-white/10 hover:border-white/20'
                }`}
              >
                {isFeatured && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-[10px] uppercase tracking-wider px-3 py-0.5 rounded-full shadow-md">
                    Most Popular Choice
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        pkg.isAC ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-700 text-slate-300'
                      }`}>
                        {pkg.isAC ? 'Air Conditioned' : 'Non-AC Bus'}
                      </span>
                      {pkg.hasLunch && (
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 flex items-center gap-1">
                          <Utensils className="w-2.5 h-2.5" />
                          + Lunch
                        </span>
                      )}
                    </div>

                    <h3 className="text-lg font-bold text-white">{pkg.title}</h3>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      {pkg.description}
                    </p>
                  </div>

                  {/* Clear Per-Person Price Display for Selected Route */}
                  <div className="bg-slate-900 rounded-xl p-3 border border-white/5 space-y-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                      {selectedRoute?.name} Price:
                    </span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-3xl font-extrabold text-amber-400 font-mono">
                        ₹{displayPrice}
                      </span>
                      <span className="text-xs text-slate-400 font-medium">
                        / person
                      </span>
                    </div>
                    {currentOffer?.enabled && (
                      <span className="text-[10px] text-emerald-400 font-semibold block">
                        Offer applied (Save ₹{basePrice - displayPrice})
                      </span>
                    )}
                  </div>

                  {/* Features list */}
                  <ul className="space-y-2 text-xs text-slate-300">
                    <li className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                      <span>Complete tour of 44 Mumbai points</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                      <span>Bandra–Worli Sea Link crossing</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                      <span>Live Hindi & English tour commentary</span>
                    </li>
                    {pkg.hasLunch ? (
                      <>
                        <li className="flex items-start gap-2 text-emerald-300 font-semibold">
                          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>Morning Breakfast (Samosa/Poha + Tea)</span>
                        </li>
                        <li className="flex items-start gap-2 text-emerald-300 font-semibold">
                          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>Pure Veg Lunch (Biryani / Paneer / Thali)</span>
                        </li>
                      </>
                    ) : (
                      <li className="flex items-start gap-2 text-slate-400">
                        <span>·</span>
                        <span>Meals not included (Restaurant halt provided)</span>
                      </li>
                    )}
                  </ul>
                </div>

                <div className="pt-6">
                  <button
                    type="button"
                    onClick={() => onBookNow(selectedRouteId, pkg.packageId)}
                    className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-95 ${
                      isFeatured
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/20 hover:from-amber-300 hover:to-amber-400'
                        : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                  >
                    <span>Book on {selectedRoute?.name}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* FULL 16-COMBINATION ALL-ROUTES COMPARISON TABLE */}
      <div className="space-y-4">
        <div className="text-center sm:text-left">
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Complete 4-Route Comparison Matrix (All 16 Combinations)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Exact per-person fare across all four corridors. Fixed transparent pricing configured in backend database.
          </p>
        </div>

        <div className="shiny-dark-card rounded-2xl border border-white/10 overflow-hidden w-full max-w-full">
          <div className="w-full max-w-full overflow-x-auto block">
            <table className="w-full min-w-[640px] text-left text-xs">
              <thead className="bg-slate-900 text-slate-300 border-b border-white/10 uppercase tracking-wider text-[11px] font-semibold">
                <tr>
                  <th className="py-3.5 px-4 font-bold text-amber-400">Route Line</th>
                  <th className="py-3.5 px-4 text-center">Non-AC (Without Lunch)</th>
                  <th className="py-3.5 px-4 text-center">AC Luxury (Without Lunch)</th>
                  <th className="py-3.5 px-4 text-center">Non-AC (+ Lunch)</th>
                  <th className="py-3.5 px-4 text-center">AC Luxury (+ Lunch)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-200">
                {routes.map(r => {
                  const pNonAcNoLunch = packages.find(p => p.packageId === 'non_ac_no_lunch')?.basePrices[r.id] ?? 0;
                  const pAcNoLunch = packages.find(p => p.packageId === 'ac_no_lunch')?.basePrices[r.id] ?? 0;
                  const pNonAcLunch = packages.find(p => p.packageId === 'non_ac_lunch')?.basePrices[r.id] ?? 0;
                  const pAcLunch = packages.find(p => p.packageId === 'ac_lunch')?.basePrices[r.id] ?? 0;

                  const isCurrent = selectedRouteId === r.id;

                  return (
                    <tr
                      key={r.id}
                      onClick={() => setSelectedRouteId(r.id)}
                      className={`cursor-pointer transition-colors ${isCurrent ? 'bg-amber-500/10 font-medium' : 'hover:bg-white/5'}`}
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <strong className={isCurrent ? "text-amber-400" : "text-white"}>{r.name}</strong>
                          {isCurrent && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 font-bold">
                              Selected
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-400 block mt-0.5">{r.description}</span>
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono font-bold text-sm text-slate-100">
                        ₹{pNonAcNoLunch} <span className="text-[10px] text-slate-400 font-normal">/ person</span>
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono font-bold text-sm text-cyan-300">
                        ₹{pAcNoLunch} <span className="text-[10px] text-slate-400 font-normal">/ person</span>
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono font-bold text-sm text-emerald-300">
                        ₹{pNonAcLunch} <span className="text-[10px] text-slate-400 font-normal">/ person</span>
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono font-bold text-sm text-amber-400">
                        ₹{pAcLunch} <span className="text-[10px] text-slate-400 font-normal">/ person</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Mandatory & Optional Extra Charges Clarification */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="shiny-dark-card rounded-2xl p-5 border border-white/10 space-y-3">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
            <ShieldCheck className="w-4 h-4" />
            <span>Payable Directly to Guide Inside Bus</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Both statutory tour charges are collected directly by the Tour Guide inside the bus and are NOT included in the online bus booking fare or the ₹200 advance:
          </p>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between p-2.5 rounded-lg bg-slate-900 border border-white/5">
              <span>Licensed Tour Guide Service:</span>
              <strong className="text-white font-mono">₹{guideCharge} / person</strong>
            </div>
            <div className="flex justify-between p-2.5 rounded-lg bg-slate-900 border border-white/5">
              <span>Bandra–Worli Sea Link Bridge Toll:</span>
              <strong className="text-white font-mono">₹{seaLinkToll} / person</strong>
            </div>
            <div className="flex justify-between pt-1 font-bold text-amber-300">
              <span>Total Payable Directly to Guide:</span>
              <span className="font-mono">₹{guideCharge + seaLinkToll} / person</span>
            </div>
          </div>
        </div>

        <div className="shiny-dark-card rounded-2xl p-5 border border-white/10 space-y-3">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
            <Info className="w-4 h-4" />
            <span>Optional Sightseeing Excursions</span>
          </div>
          <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 leading-relaxed">
            All attraction visits are optional. Attraction ticket charges are not included in your online bus booking. If you choose to visit an attraction, the Tour Guide will collect the applicable amount on the bus. If you do not wish to visit, you do not have to pay.
          </div>
          <div className="space-y-1.5 text-xs text-slate-300">
            <div className="flex justify-between">
              <span>Gateway of India Boat Cruise:</span>
              <strong className="text-white font-mono">₹210 / person (Optional)</strong>
            </div>
            <div className="flex justify-between">
              <span>Prince of Wales Museum:</span>
              <strong className="text-white font-mono">₹200 / person (Optional)</strong>
            </div>
            <div className="flex justify-between">
              <span>Orama 11D Magic Experience Show:</span>
              <strong className="text-white font-mono">₹220 / person (Optional)</strong>
            </div>
            <div className="flex justify-between">
              <span>Bollywood Museum:</span>
              <strong className="text-white font-mono">₹165 / person (Optional)</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
