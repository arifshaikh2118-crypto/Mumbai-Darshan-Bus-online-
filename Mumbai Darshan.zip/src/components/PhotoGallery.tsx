import React, { useState, useMemo } from 'react';
import { Camera, Sparkles, X, ChevronLeft, ChevronRight, Eye, ShieldCheck, MapPin } from 'lucide-react';
import { StorageService } from '../services/storage';
import { GalleryImage } from '../types';

export const PhotoGallery: React.FC = () => {
  const allImages = useMemo(() => StorageService.getGalleryImages(), []);
  
  // Only approved and published photos are visible publicly (Max 10 per Part 5 rules)
  const publishedImages = useMemo(() => {
    return allImages
      .filter(img => img.approved && img.published)
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .slice(0, 10);
  }, [allImages]);

  const [activeModalIndex, setActiveModalIndex] = useState<number | null>(null);

  const activeImage = activeModalIndex !== null ? publishedImages[activeModalIndex] : null;

  const nextImage = () => {
    if (activeModalIndex !== null) {
      setActiveModalIndex((activeModalIndex + 1) % publishedImages.length);
    }
  };

  const prevImage = () => {
    if (activeModalIndex !== null) {
      setActiveModalIndex((activeModalIndex - 1 + publishedImages.length) % publishedImages.length);
    }
  };

  return (
    <section id="gallery-section" className="space-y-6 w-full min-w-0">
      <div className="text-center space-y-2 mb-6">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
          <Camera className="w-3.5 h-3.5 text-amber-400" />
          <span>Curated Heritage Photography</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Mumbai Darshan Photo Gallery
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          Authentic visual showcase of Mumbai iconic coastal promenades, colonial architecture, and sacred shrines visited on the tour.
        </p>
      </div>

      {/* Gallery Grid (Up to 10 photos) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {publishedImages.map((image, index) => (
          <div
            key={image.id}
            onClick={() => setActiveModalIndex(index)}
            className="shiny-dark-card rounded-2xl overflow-hidden border border-white/10 group cursor-pointer hover:border-amber-400/50 transition-all duration-300 flex flex-col justify-between"
          >
            {/* Real Photograph with high-contrast frame */}
            <div className="relative aspect-[4/3] w-full bg-slate-900 overflow-hidden">
              <img
                src={image.imageUrl}
                alt={image.title}
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                onError={e => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20 opacity-80 group-hover:opacity-60 transition-opacity" />

              <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-black/75 backdrop-blur-md border border-white/20 text-white font-mono text-[11px] font-bold">
                Photo {index + 1} of {publishedImages.length}
              </div>

              <div className="absolute bottom-3 right-3 p-1.5 rounded-lg bg-black/60 text-white/90 backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity">
                <Eye className="w-4 h-4 text-amber-400" />
              </div>
            </div>

            {/* Accurate Landmark Caption underneath each photo */}
            <div className="p-4 space-y-1 bg-[#12141c]">
              <div className="flex items-center gap-1.5 text-amber-400 font-bold text-sm">
                <MapPin className="w-3.5 h-3.5 shrink-0" />
                <h3 className="truncate">{image.title}</h3>
              </div>
              <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                {image.caption || `Verified sightseeing landmark: ${image.attractionName}`}
              </p>
            </div>
          </div>
        ))}
      </div>

      {publishedImages.length === 0 && (
        <div className="p-8 text-center text-slate-400 bg-white/5 rounded-2xl border border-white/10">
          <p className="text-sm">Verified gallery photos being curated by Admin.</p>
        </div>
      )}

      {/* Lightbox Modal */}
      {activeImage && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-4xl w-full bg-slate-950 border border-white/20 rounded-2xl overflow-hidden shadow-2xl flex flex-col">
            {/* Modal Header */}
            <div className="p-4 bg-slate-900 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2 min-w-0 pr-4">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
                <h3 className="text-base font-bold text-white truncate">
                  {activeImage.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveModalIndex(null)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer transition-colors shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Image Display */}
            <div className="relative w-full aspect-[16/9] sm:aspect-[16/10] bg-black flex items-center justify-center overflow-hidden">
              <img
                src={activeImage.imageUrl}
                alt={activeImage.title}
                className="max-h-full max-w-full object-contain"
              />

              {publishedImages.length > 1 && (
                <>
                  <button
                    type="button"
                    onClick={prevImage}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/70 hover:bg-black text-white flex items-center justify-center cursor-pointer border border-white/20 transition-all"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    type="button"
                    onClick={nextImage}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/70 hover:bg-black text-white flex items-center justify-center cursor-pointer border border-white/20 transition-all"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}
            </div>

            {/* Modal Footer Caption */}
            <div className="p-4 bg-slate-900 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="text-slate-300">
                <span className="font-semibold text-amber-400 mr-2">Official Landmark:</span>
                <span>{activeImage.attractionName}</span>
                {activeImage.caption && <p className="text-slate-400 mt-0.5">{activeImage.caption}</p>}
              </div>
              <span className="text-slate-500 font-mono shrink-0">
                {(activeModalIndex || 0) + 1} / {publishedImages.length}
              </span>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
