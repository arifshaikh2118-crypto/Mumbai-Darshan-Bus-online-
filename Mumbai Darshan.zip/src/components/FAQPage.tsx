import React, { useState } from 'react';
import { ChevronDown, HelpCircle, Phone, MessageCircle } from 'lucide-react';
import { StorageService } from '../services/storage';

interface FAQItem {
  q: string;
  a: string;
  category: 'General' | 'Booking & Payments' | 'Sightseeing & Attractions' | 'Food & Comfort';
}

export const FAQPage: React.FC = () => {
  const settings = StorageService.getSettings();
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const faqs: FAQItem[] = [
    {
      category: 'General',
      q: 'What is Mumbai Darshan Bus Online?',
      a: 'Mumbai Darshan Bus Online is the official daily city sightseeing tour operating across 4 major pickup corridors: Western Line, Central Line, Harbour Line, and Kalyan-Dombivli Line. We cover 44 iconic Mumbai landmarks from South Mumbai heritage quarters to coastal drives and famous temples in a single comfortable day tour.'
    },
    {
      category: 'General',
      q: 'What are the pickup and drop timings?',
      a: 'Buses begin pickups between 6:15 AM and 8:00 AM depending on your chosen boarding stop (e.g., Bhayandar East starts at 6:15 AM; Borivali at 7:00 AM; Thane at 7:00 AM; Panvel at 6:30 AM). The tour sightseeing concludes around 7:00 PM – 8:00 PM at Juhu Beach / Bandra, after which passengers are dropped back along their respective return corridors.'
    },
    {
      category: 'Booking & Payments',
      q: 'How does the ₹200 advance payment mode work?',
      a: 'To make booking simple and risk-free, you can pay a fixed advance deposit of only ₹200 per booking (regardless of how many passengers are in your party). This confirms your reserved seats. The remaining balance amount is payable on the day of travel directly on the bus via cash or UPI to the bus conductor.'
    },
    {
      category: 'Booking & Payments',
      q: 'What are the Guide and Sea Link charges?',
      a: 'Tour Guide Charge is ₹50 per passenger and Sea Link Toll is ₹10 per passenger (Total: ₹60 per passenger). Both charges will be collected directly by the Tour Guide inside the bus. They are NOT included in the online bus booking fare, NOT included in the ₹200 advance payment, and NOT collected through the website payment gateway.'
    },
    {
      category: 'Booking & Payments',
      q: 'What is the child ticket policy?',
      a: 'Children up to 3 years of age can travel free of charge sitting on an adult lap without a separate seat. Children aged 3 years and above require a full seat ticket to comply with transport department safety regulations.'
    },
    {
      category: 'Food & Comfort',
      q: 'What is included in the Lunch & Breakfast package?',
      a: 'Breakfast and lunch are included in applicable packages. Breakfast will be served as Samosa or Kanda Poha, as decided by the operator. Customer is not given a breakfast selection option. Drinking water bottles and juice are not included. Passengers customize their hot pure vegetarian lunch choice (Veg Biryani, Butter Paneer, or Veg Thali).'
    },
    {
      category: 'Food & Comfort',
      q: 'Can passengers on "Without Lunch" packages buy food?',
      a: 'Yes, absolutely. When the bus stops at the designated lunch restaurant for 45–60 minutes, passengers without lunch packages are free to purchase meals à la carte at the restaurant or visit nearby food outlets of their choice.'
    },
    {
      category: 'Sightseeing & Attractions',
      q: 'What is the difference between BUS HALT and NO HALT landmarks?',
      a: 'BUS HALT means the bus parks at a designated stop and passengers are allowed to get down to explore, photograph, and visit (e.g. Gateway of India, Shree Mahalaxmi Temple, Siddhivinayak Temple, Marine Drive, Juhu Beach). NO HALT means the landmark is viewed from the bus window as the bus drives by slowly while the guide narrates its history (e.g. Bombay High Court, Reserve Bank of India, CST Station, Antilia).'
    },
    {
      category: 'Sightseeing & Attractions',
      q: 'Is the Gateway of India Boat Ride compulsory?',
      a: 'No! The Gateway Harbor Boat Cruise is 100% optional. The initial ticket price is ₹210 per person (not ₹220). You can choose to add it during Step 5 of your online booking or decide on the spot at Gateway of India. We never force or automatically add boat tickets to customer bookings.'
    },
    {
      category: 'Sightseeing & Attractions',
      q: 'Are temple entry tickets included?',
      a: 'General darshan at both Shree Siddhivinayak Temple and Shree Mahalaxmi Temple is completely free of cost for all devotees. If you wish to avail special VIP priority darshan passes offered by temple trusts, those can be purchased individually at official temple trust counters.'
    },
    {
      category: 'Food & Comfort',
      q: 'Can we store luggage or suitcases on the bus?',
      a: 'Yes. Our buses have spacious under-carriage luggage compartments as well as overhead cabin racks. You can safely store suitcases, baby strollers, or shopping bags on board throughout the day under the driver’s supervision.'
    },
    {
      category: 'Food & Comfort',
      q: 'Are the buses comfortable for senior citizens?',
      a: 'Yes. Our AC luxury buses have low-entry steps, air suspension, and push-back cushioned seats. Our tour guide and assistant assist senior citizens during boarding and disembarkation. If you require front-row seating, please mention it in the special requests field during booking.'
    },
    {
      category: 'Booking & Payments',
      q: 'What is the cancellation and refund policy?',
      a: 'Cancellations made 24 hours or more before scheduled departure receive a full refund minus a nominal ₹50 administrative fee. Rescheduling to a new date is free of charge up to 24 hours prior. Cancellations within 12–24 hours receive a 50% refund. Cancellations made less than 12 hours before tour departure are non-refundable.'
    },
    {
      category: 'General',
      q: 'What happens in case of heavy Mumbai monsoon rains?',
      a: 'Mumbai Darshan operates all 365 days. In the event of extraordinary civic monsoon alerts or localized traffic diversions issued by Mumbai Traffic Police, our experienced drivers take alternative flyovers to ensure safety while covering as many landmarks as possible.'
    },
    {
      category: 'General',
      q: 'How do I identify my bus at the pickup point?',
      a: 'Your bus coordinator will call your registered 10-digit mobile number 20 to 30 minutes before reaching your boarding landmark. The bus has prominent "MUMBAI DARSHAN" signage displayed on the front windshield and sides.'
    }
  ];

  const categories = ['All', 'General', 'Booking & Payments', 'Sightseeing & Attractions', 'Food & Comfort'];

  const filteredFaqs = faqs.filter(
    item => activeCategory === 'All' || item.category === activeCategory
  );

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      {/* Header */}
      <div className="text-center space-y-3">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
          Frequently Asked Questions
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Everything You Need to Know
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
          Clear answers about routes, pickup points, meal choices, pricing transparency, and boarding guidelines.
        </p>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => {
              setActiveCategory(cat);
              setOpenIndex(null);
            }}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              activeCategory === cat
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* FAQ Accordion */}
      <div className="space-y-3">
        {filteredFaqs.map((faq, idx) => {
          const isOpen = openIndex === idx;

          return (
            <div
              key={idx}
              className="shiny-dark-card rounded-2xl border border-white/10 overflow-hidden transition-colors"
            >
              <button
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full p-4 sm:p-5 flex items-center justify-between text-left gap-4 cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <HelpCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="font-bold text-sm sm:text-base text-white">
                    {faq.q}
                  </span>
                </div>
                <ChevronDown
                  className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-300 ${
                    isOpen ? 'rotate-180 text-amber-400' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-white/5">
                  <p>{faq.a}</p>
                  <span className="inline-block mt-3 text-[11px] font-mono text-slate-500">
                    Category: {faq.category}
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Help Desk Banner */}
      <div className="shiny-dark-card rounded-2xl p-6 sm:p-7 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-white text-base">Still Have a Question?</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Our passenger support desk is active every morning and evening.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <a
            href={`tel:${settings.businessPhone}`}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs cursor-pointer"
          >
            <Phone className="w-3.5 h-3.5 text-amber-400" />
            <span>Call {settings.businessPhone}</span>
          </a>

          <a
            href={`https://wa.me/${settings.whatsappNumber}?text=Hello%20Mumbai%20Darshan%20Bus,%20I%20have%20a%20question.`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp Us</span>
          </a>
        </div>
      </div>
    </div>
  );
};
