import React, { useState, useMemo } from 'react';
import { Car, Users, CheckCircle2, Calendar, Phone, MapPin, ArrowRight, ShieldCheck, Fuel, Clock, Navigation, Calculator, MessageSquare } from 'lucide-react';
import { StorageService } from '../services/storage';
import { LocalRentalPackage, OutstationVehicleRate, RentalStatus } from '../types';

interface CarRentalPanelProps {
  onSuccess?: () => void;
  title?: string;
  subtitle?: string;
}

export const CarRentalPanel: React.FC<CarRentalPanelProps> = ({
  onSuccess,
  title = "Private Car, Tempo Traveller & Luxury Bus Rental",
  subtitle = "Doorstep private sightseeing and outstation rentals. Choose between 12-Hour/120-KM Mumbai Local packages or 300-KM/Day Outstation journeys."
}) => {
  // Rental Type: 'local_darshan' | 'outstation'
  const [rentalType, setRentalType] = useState<'local_darshan' | 'outstation'>('local_darshan');

  // Dynamic rates from Storage
  const localPackages = useMemo(() => StorageService.getLocalRentalPackages().filter(p => p.active), []);
  const outstationRates = useMemo(() => StorageService.getOutstationRates().filter(r => r.active), []);
  const settings = useMemo(() => StorageService.getSettings(), []);

  // Form State
  const [selectedLocalVehicleId, setSelectedLocalVehicleId] = useState<string>(localPackages[0]?.id || 'loc_dzire');
  const [selectedOutstationVehicleId, setSelectedOutstationVehicleId] = useState<string>(outstationRates[0]?.id || 'out_dzire');

  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [travelDate, setTravelDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 2);
    return d.toISOString().slice(0, 10);
  });
  const [passengerCount, setPassengerCount] = useState(4);
  const [pickupLocation, setPickupLocation] = useState('');
  const [destination, setDestination] = useState('');
  const [preferredPickupTime, setPreferredPickupTime] = useState('8:00 AM');
  const [daysCount, setDaysCount] = useState(1);
  const [estimatedKmInput, setEstimatedKmInput] = useState<number>(300);
  const [specialRequirements, setSpecialRequirements] = useState('');

  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Active selected local package
  const activeLocalPkg = useMemo(() => {
    return localPackages.find(p => p.id === selectedLocalVehicleId) || localPackages[0];
  }, [localPackages, selectedLocalVehicleId]);

  // Active selected outstation rate
  const activeOutstationRate = useMemo(() => {
    return outstationRates.find(r => r.id === selectedOutstationVehicleId) || outstationRates[0];
  }, [outstationRates, selectedOutstationVehicleId]);

  // Calculated estimates
  const estimatedQuotation = useMemo(() => {
    if (rentalType === 'local_darshan') {
      return activeLocalPkg ? activeLocalPkg.proposedCustomerPrice : 4500;
    } else {
      if (!activeOutstationRate) return 5100;
      const minKmRequired = daysCount * activeOutstationRate.minKmPerDay;
      const effectiveKm = Math.max(minKmRequired, estimatedKmInput);
      const runningCharge = effectiveKm * activeOutstationRate.proposedCustomerPerKm;
      const daPermitCharge = daysCount * activeOutstationRate.proposedCustomerDaPerDay;
      return runningCharge + daPermitCharge;
    }
  }, [rentalType, activeLocalPkg, activeOutstationRate, daysCount, estimatedKmInput]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!customerName.trim() || customerName.trim().length < 3) {
      setErrorMsg('Please enter your full name (at least 3 characters).');
      return;
    }
    const cleanPhone = customerMobile.replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setErrorMsg('Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!pickupLocation.trim()) {
      setErrorMsg('Please enter your pickup location (e.g., Borivali, Dadar, Thane, Airport).');
      return;
    }
    if (rentalType === 'outstation' && !destination.trim()) {
      setErrorMsg('Please enter your outstation destination (e.g., Lonavala, Shirdi, Mahabaleshwar, Alibaug).');
      return;
    }

    setIsSubmitting(true);
    try {
      const selectedVehicleName = rentalType === 'local_darshan'
        ? activeLocalPkg?.vehicleName || 'Private AC Vehicle'
        : activeOutstationRate?.vehicleName || 'Outstation AC Vehicle';

      const enquiry = StorageService.createCarRentalEnquiry({
        customerName: customerName.trim(),
        customerMobile: customerMobile.trim(),
        customerEmail: customerEmail.trim() || undefined,
        travelDate,
        rentalType,
        vehicleType: selectedVehicleName,
        isAC: true,
        passengerCount,
        pickupLocation: pickupLocation.trim(),
        destination: rentalType === 'outstation' ? destination.trim() : 'Mumbai Sightseeing (120 KM Local)',
        preferredPickupTime,
        daysCount: rentalType === 'outstation' ? daysCount : 1,
        estimatedKm: rentalType === 'outstation' ? Math.max(daysCount * 300, estimatedKmInput) : 120,
        specialRequirements: specialRequirements.trim() || undefined,
        customerQuotation: estimatedQuotation,
        supplierCost: rentalType === 'local_darshan' ? activeLocalPkg?.supplierCost : undefined
      });

      setSubmittedId(enquiry.id);
      if (onSuccess) onSuccess();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to submit enquiry. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getWhatsAppEnquiryUrl = () => {
    const text = encodeURIComponent(
      `Hello Mumbai Darshan Bus Online! I submitted a rental enquiry with Ref ID: ${submittedId || 'NEW'}.\n\n` +
      `*Type:* ${rentalType === 'local_darshan' ? 'Mumbai Local Darshan (12 Hr / 120 KM)' : 'Outstation Rental'}\n` +
      `*Name:* ${customerName}\n*Phone:* ${customerMobile}\n*Date:* ${travelDate}\n` +
      `*Pickup:* ${pickupLocation}\n*Destination:* ${rentalType === 'outstation' ? destination : 'Mumbai Sightseeing'}\n` +
      `*Estimated Quote:* ₹${estimatedQuotation}\n\nPlease confirm vehicle availability.`
    );
    return `https://wa.me/${settings.whatsappNumber}?text=${text}`;
  };

  return (
    <div className="shiny-dark-card rounded-2xl p-4 sm:p-7 border border-white/10 text-slate-100 w-full min-w-0 box-border">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5 mb-6">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
            Dedicated Doorstep Pickup & Fleet Services
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight mt-1">
            {title}
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            {subtitle}
          </p>
        </div>

        {/* Category Switcher Tabs */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-white/10 shrink-0">
          <button
            type="button"
            onClick={() => setRentalType('local_darshan')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              rentalType === 'local_darshan'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Mumbai Local (120 KM)
          </button>
          <button
            type="button"
            onClick={() => setRentalType('outstation')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              rentalType === 'outstation'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Outstation (300 KM/Day)
          </button>
        </div>
      </div>

      {submittedId ? (
        <div className="p-6 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-4">
          <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Rental Enquiry Received!</h3>
            <p className="text-xs text-slate-300 max-w-md mx-auto mt-1">
              Your Enquiry Reference is <strong className="text-amber-400 font-mono text-sm">{submittedId}</strong>.
            </p>
            <p className="text-xs text-slate-400 max-w-md mx-auto mt-0.5">
              Estimated Tariff: <strong className="text-white font-mono">₹{estimatedQuotation}</strong>. Final quotation and vehicle assignment will be confirmed by our transport coordinator.
            </p>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <a
              href={getWhatsAppEnquiryUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Instant WhatsApp Follow-up</span>
            </a>

            <button
              type="button"
              onClick={() => {
                setSubmittedId(null);
                setCustomerName('');
                setCustomerMobile('');
                setPickupLocation('');
                setDestination('');
              }}
              className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-white/5 rounded-xl border border-white/10"
            >
              Submit Another Enquiry
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-300">
              {errorMsg}
            </div>
          )}

          {/* Policy Banner Based on Selection */}
          {rentalType === 'local_darshan' ? (
            <div className="p-3.5 rounded-xl bg-amber-500/5 border border-amber-500/20 text-xs space-y-1">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <Clock className="w-4 h-4" />
                <span>Mumbai Local Sightseeing Package Rules (12 Hours / 120 KM)</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Package ends when either 12 hours or 120 KM is reached (whichever occurs first). Driver and vehicle included · Driver Bhatta included · Parking extra on actual basis · Tour Guide not included · Toll extra on actuals unless explicitly booked · Extra KM & hours charged separately.
              </p>
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-cyan-500/5 border border-cyan-500/20 text-xs space-y-1">
              <div className="flex items-center gap-2 text-cyan-400 font-bold">
                <Navigation className="w-4 h-4" />
                <span>Outstation Journey Billing Rules (300 KM / Day Minimum)</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Minimum average running 300 KM per calendar day · Kilometre calculated Garage to Garage · Toll, State Border Tax, Parking and Entry fees extra on actual basis · Driver DA & Interstate Permit included as configured · Additional night DA applies for travel after 11:00 PM.
              </p>
            </div>
          )}

          {/* Vehicle Selection Cards */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2.5">
              {rentalType === 'local_darshan' ? 'Select Local Sightseeing Package' : 'Select Outstation Vehicle Class'}
            </label>

            {rentalType === 'local_darshan' ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                {localPackages.map(pkg => {
                  const isSelected = selectedLocalVehicleId === pkg.id;
                  return (
                    <div
                      key={pkg.id}
                      onClick={() => setSelectedLocalVehicleId(pkg.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all text-xs flex flex-col justify-between ${
                        isSelected
                          ? 'bg-amber-500/15 border-amber-400 text-white shadow-sm ring-1 ring-amber-400'
                          : 'bg-[#12141c] border-white/5 hover:border-white/20 text-slate-300'
                      }`}
                    >
                      <div>
                        <strong className="block font-bold text-xs truncate">{pkg.vehicleName.split(' (')[0]}</strong>
                        <span className="text-[10px] text-amber-400 font-medium block mt-0.5">{pkg.seating}</span>
                      </div>
                      <div className="mt-2 pt-2 border-t border-white/5">
                        <span className="text-xs font-mono font-black text-amber-300 block">₹{pkg.proposedCustomerPrice}</span>
                        <span className="text-[9px] text-slate-400 block">12 Hrs / 120 KM</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
                {outstationRates.map(rate => {
                  const isSelected = selectedOutstationVehicleId === rate.id;
                  return (
                    <div
                      key={rate.id}
                      onClick={() => setSelectedOutstationVehicleId(rate.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all text-xs flex flex-col justify-between ${
                        isSelected
                          ? 'bg-amber-500/15 border-amber-400 text-white shadow-sm ring-1 ring-amber-400'
                          : 'bg-[#12141c] border-white/5 hover:border-white/20 text-slate-300'
                      }`}
                    >
                      <div>
                        <strong className="block font-bold text-xs truncate">{rate.vehicleName}</strong>
                        <span className="text-[10px] text-amber-400 font-medium block mt-0.5">{rate.seating} ({rate.isAC ? 'AC' : 'Non-AC'})</span>
                      </div>
                      <div className="mt-2 pt-2 border-t border-white/5">
                        <span className="text-xs font-mono font-black text-amber-300 block">₹{rate.proposedCustomerPerKm}/KM</span>
                        <span className="text-[9px] text-slate-400 block">+ ₹{rate.proposedCustomerDaPerDay}/day DA/Permit</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Travel Parameters */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                Date of Travel
              </label>
              <input
                type="date"
                min={new Date().toISOString().slice(0, 10)}
                value={travelDate}
                onChange={e => setTravelDate(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            {rentalType === 'outstation' ? (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Number of Days
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={1}
                    max={30}
                    value={daysCount}
                    onChange={e => setDaysCount(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                  <span className="text-[11px] text-slate-400 shrink-0">({daysCount * 300} KM Min)</span>
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Preferred Pickup Time
                </label>
                <input
                  type="text"
                  placeholder="e.g. 7:30 AM"
                  value={preferredPickupTime}
                  onChange={e => setPreferredPickupTime(e.target.value)}
                  className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-amber-400" />
                Passenger Count
              </label>
              <input
                type="number"
                min={1}
                max={50}
                value={passengerCount}
                onChange={e => setPassengerCount(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
              />
            </div>
          </div>

          {/* Locations */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                Exact Doorstep Pickup Location
              </label>
              <input
                type="text"
                placeholder="e.g., Borivali West / Dadar TT / Airport Terminal 2"
                value={pickupLocation}
                onChange={e => setPickupLocation(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            {rentalType === 'outstation' ? (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <Navigation className="w-3.5 h-3.5 text-amber-400" />
                  Outstation Destination
                </label>
                <input
                  type="text"
                  placeholder="e.g., Shirdi / Lonavala / Mahabaleshwar / Nashik"
                  value={destination}
                  onChange={e => setDestination(e.target.value)}
                  className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Sightseeing Focus / Custom Drops
                </label>
                <input
                  type="text"
                  placeholder="e.g., South Mumbai temples, heritage buildings, shopping"
                  value={specialRequirements}
                  onChange={e => setSpecialRequirements(e.target.value)}
                  className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            )}
          </div>

          {/* Customer Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Full Name *
              </label>
              <input
                type="text"
                placeholder="Your full name"
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Mobile Number *
              </label>
              <div className="flex">
                <span className="bg-slate-900 border border-r-0 border-white/10 rounded-l-xl px-2.5 py-2 text-xs text-slate-400 flex items-center">
                  +91
                </span>
                <input
                  type="tel"
                  maxLength={10}
                  placeholder="9820012345"
                  value={customerMobile}
                  onChange={e => setCustomerMobile(e.target.value.replace(/\D/g, ''))}
                  className="w-full bg-[#12141c] border border-white/10 rounded-r-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Email Address (Optional)
              </label>
              <input
                type="email"
                placeholder="you@example.com"
                value={customerEmail}
                onChange={e => setCustomerEmail(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Quotation Estimate Box */}
          <div className="p-4 rounded-xl bg-slate-900 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
                <Calculator className="w-4 h-4" />
                <span>Estimated Rental Quotation</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {rentalType === 'local_darshan'
                  ? `Package: 12 Hours / 120 KM included. Fuel & Driver Bhatta included.`
                  : `Outstation: ${daysCount} Days (${daysCount * 300} KM min). Garage to garage calculation.`}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-2xl font-black text-amber-400 font-mono">₹{estimatedQuotation}</span>
                <span className="text-[10px] text-slate-400 block">Proposed Estimate</span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs hover:from-amber-300 hover:to-amber-400 cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 transition-all shrink-0"
              >
                {isSubmitting ? 'Submitting...' : 'Send Enquiry'}
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};
