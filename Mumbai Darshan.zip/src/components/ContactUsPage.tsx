import React, { useState } from 'react';
import { Phone, Mail, MapPin, MessageCircle, Clock, Send, CheckCircle2, ShieldCheck } from 'lucide-react';
import { StorageService } from '../services/storage';

export const ContactUsPage: React.FC = () => {
  const settings = StorageService.getSettings();

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('Booking Query');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !message.trim()) return;

    setSubmitted(true);
    setName('');
    setPhone('');
    setEmail('');
    setMessage('');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      {/* Header */}
      <div className="text-center space-y-3">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
          Dedicated Tour Support 365 Days
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Contact Customer Care Desk
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
          Have questions about your pickup spot, bus timings, luggage assistance, or large group charters? Reach out directly via call, WhatsApp, or email.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
        {/* Contact Info Card */}
        <div className="md:col-span-2 shiny-dark-card rounded-2xl p-6 sm:p-7 border border-white/10 space-y-6 flex flex-col justify-between">
          <div className="space-y-6">
            <h2 className="text-base font-bold text-white uppercase tracking-wider text-xs">
              Official Contact Channels
            </h2>

            <div className="space-y-4 text-xs">
              {/* Phone */}
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Primary Booking Helpline:</span>
                  <a
                    href={`tel:${settings.businessPhone}`}
                    className="text-white hover:text-amber-400 font-bold font-mono text-sm"
                  >
                    +91 {settings.businessPhone}
                  </a>
                  <span className="text-[10px] text-slate-500 block">Available 6:00 AM – 10:30 PM daily</span>
                </div>
              </div>

              {/* WhatsApp */}
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Instant WhatsApp Chat:</span>
                  <a
                    href={`https://wa.me/${settings.whatsappNumber}?text=Hello%20Mumbai%20Darshan%20Bus,%20I%20have%20an%20enquiry.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-emerald-400 hover:text-emerald-300 font-bold font-mono text-sm"
                  >
                    +91 {settings.whatsappNumber}
                  </a>
                  <span className="text-[10px] text-slate-500 block">Quick reply within 5 minutes</span>
                </div>
              </div>

              {/* Email */}
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Support Email:</span>
                  <a
                    href={`mailto:${settings.businessEmail}`}
                    className="text-white hover:text-amber-400 font-medium break-all"
                  >
                    {settings.businessEmail}
                  </a>
                </div>
              </div>

              {/* Address */}
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Registered Office Address:</span>
                  <p className="text-slate-300 leading-relaxed mt-0.5">
                    {settings.registeredAddress}
                  </p>
                </div>
              </div>

              {/* Working Hours */}
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Operating Hours:</span>
                  <p className="text-slate-300">
                    Tour buses depart 6:15 AM – 8:00 AM daily.<br />
                    Tours conclude around 7:30 PM – 8:30 PM.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-white/10">
            <a
              href={`https://maps.google.com/?q=${encodeURIComponent(settings.registeredAddress)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white font-semibold text-xs border border-white/10 transition-colors"
            >
              <MapPin className="w-4 h-4 text-amber-400" />
              <span>Open Office in Google Maps</span>
            </a>
          </div>
        </div>

        {/* Message Form */}
        <div className="md:col-span-3 shiny-dark-card rounded-2xl p-6 sm:p-8 border border-white/10">
          <h2 className="text-lg font-bold text-white tracking-tight mb-1">
            Send an Online Message
          </h2>
          <p className="text-xs text-slate-400 mb-6">
            Fill in the form below and our operations coordinator will get back to you immediately.
          </p>

          {submitted ? (
            <div className="p-6 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Message Dispatched!</h3>
              <p className="text-xs text-slate-300 max-w-sm mx-auto">
                Thank you for contacting Mumbai Darshan Bus Online. One of our coordinators will reply via phone or email shortly.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="text-xs font-semibold text-amber-400 hover:underline cursor-pointer pt-2 block mx-auto"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ramesh Patel"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Mobile Number (10 Digits) *</label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="9820012345"
                    value={phone}
                    onChange={e => setPhone(e.target.value.replace(/\D/g, ''))}
                    className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Email Address</label>
                  <input
                    type="email"
                    placeholder="ramesh@example.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Inquiry Subject</label>
                  <select
                    value={subject}
                    onChange={e => setSubject(e.target.value)}
                    className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="Booking Query">Booking / Availability Query</option>
                    <option value="Pickup Point Assistance">Pickup Point & Timing Assistance</option>
                    <option value="Group Charter">Group / Corporate Bus Charter</option>
                    <option value="Car Rental">Private Car Rental Enquiry</option>
                    <option value="Refund / Cancellation">Cancellation or Date Change</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Your Message or Question *</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Tell us your travel date, pickup location, or questions..."
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  className="w-full bg-[#12141c] border border-white/10 rounded-xl p-3 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              <button
                type="submit"
                className="w-full sm:w-auto px-7 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs hover:from-amber-300 hover:to-amber-400 cursor-pointer shadow-md shadow-amber-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Submit Message</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
