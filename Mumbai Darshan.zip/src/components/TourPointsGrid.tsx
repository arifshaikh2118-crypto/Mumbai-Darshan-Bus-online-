import React, { useState, useMemo } from 'react';
import { MapPin, ExternalLink, Search, CheckCircle2, Eye, Compass, Ticket, Info, AlertCircle } from 'lucide-react';
import { StorageService } from '../services/storage';
import { TourPoint } from '../types';

interface TourPointsGridProps {
  onSelectBooking?: () => void;
  showFilterControls?: boolean;
}

export const TourPointsGrid: React.FC<TourPointsGridProps> = ({
  onSelectBooking,
  showFilterControls = true
}) => {
  const [filterMode, setFilterMode] = useState<'ALL' | 'BUS_HALT' | 'NO_HALT' | 'OPTIONAL_PAID'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const points = useMemo(() => {
    return StorageService.getTourPoints().filter(p => p.active);
  }, []);

  const haltCount = useMemo(() => points.filter(p => p.haltStatus === 'BUS_HALT').length, [points]);
  const noHaltCount = useMemo(() => points.filter(p => p.haltStatus === 'NO_HALT').length, [points]);
  const optionalPaidCount = useMemo(() => points.filter(p => p.feeStatus === 'OPTIONAL_PAID' || (p.entryFee && p.entryFee > 0)).length, [points]);

  const filteredPoints = useMemo(() => {
    return points.filter(pt => {
      let matchesFilter = true;
      if (filterMode === 'BUS_HALT') matchesFilter = pt.haltStatus === 'BUS_HALT';
      else if (filterMode === 'NO_HALT') matchesFilter = pt.haltStatus === 'NO_HALT';
      else if (filterMode === 'OPTIONAL_PAID') matchesFilter = pt.feeStatus === 'OPTIONAL_PAID' || (!!pt.entryFee && pt.entryFee > 0);

      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q ||
        pt.name.toLowerCase().includes(q) ||
        pt.description.toLowerCase().includes(q) ||
        String(pt.id) === q;

      return matchesFilter && matchesSearch;
    });
  }, [points, filterMode, searchQuery]);

  return (
    <div className="space-y-6 w-full min-w-0">
      {/* Section Header Notice */}
      <div className="text-center space-y-2 mb-2">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
          Official Sightseeing Directory
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Places Covered — All 44 Mumbai Tour Points
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          Complete verified itinerary of South and Central Mumbai landmarks. Comprises <strong className="text-emerald-400">10 dedicated halt stops</strong> where disembarkation is allowed and <strong className="text-cyan-400">34 scenic drive-by viewing points</strong> enjoyed from your bus window.
        </p>
      </div>

      {/* Controls & Search */}
      {showFilterControls && (
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 bg-[#12141c] p-3 sm:p-4 rounded-2xl border border-white/10 w-full min-w-0 box-border">
          {/* Segmented Filter Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 bg-slate-900 rounded-xl border border-white/5 w-full md:w-auto min-w-0 box-border text-xs">
            <button
              type="button"
              onClick={() => setFilterMode('ALL')}
              className={`px-3 py-2 rounded-lg font-semibold transition-all cursor-pointer truncate text-center ${
                filterMode === 'ALL'
                  ? 'bg-amber-500 text-slate-950 shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All (44)
            </button>
            <button
              type="button"
              onClick={() => setFilterMode('BUS_HALT')}
              className={`px-3 py-2 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-1 truncate text-center ${
                filterMode === 'BUS_HALT'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Halt ({haltCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setFilterMode('NO_HALT')}
              className={`px-3 py-2 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-1 truncate text-center ${
                filterMode === 'NO_HALT'
                  ? 'bg-cyan-500 text-slate-950 shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Eye className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Drive ({noHaltCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setFilterMode('OPTIONAL_PAID')}
              className={`px-3 py-2 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-1 truncate text-center ${
                filterMode === 'OPTIONAL_PAID'
                  ? 'bg-purple-500 text-white shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Ticket className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Optional ({optionalPaidCount})</span>
            </button>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72 min-w-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by landmark name, area..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-white/10 rounded-xl pl-9 pr-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 box-border"
            />
          </div>
        </div>
      )}

      {/* Directory Cards - STRICT RULE: NO PHOTOGRAPHS IN THESE 44 ATTRACTION CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
        {filteredPoints.map(point => {
          const isHalt = point.haltStatus === 'BUS_HALT';
          const isOptionalPaid = point.feeStatus === 'OPTIONAL_PAID' || (point.entryFee && point.entryFee > 0);

          return (
            <div
              key={point.id}
              className="shiny-dark-card rounded-2xl p-4 sm:p-5 border border-white/10 flex flex-col justify-between hover:border-amber-500/40 transition-all duration-300 w-full min-w-0 box-border"
            >
              <div className="space-y-3">
                {/* Header row with Serial Number and Halt Status Badges */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-extrabold text-xs flex items-center justify-center font-mono shrink-0">
                      #{point.id}
                    </span>
                    <h3 className="font-bold text-sm sm:text-base text-white truncate">
                      {point.name}
                    </h3>
                  </div>

                  {/* Halt Status Badge */}
                  <div className="shrink-0">
                    {isHalt ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-bold text-[10px] sm:text-[11px]">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                        BUS HALT
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-semibold text-[10px] sm:text-[11px]">
                        <Eye className="w-3 h-3 text-cyan-400 shrink-0" />
                        NO HALT
                      </span>
                    )}
                  </div>
                </div>

                {/* Disembarkation & View Status Notice */}
                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-white/5 space-y-1 text-xs">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Passenger Access:</span>
                    <strong className={isHalt ? "text-emerald-300 font-semibold" : "text-cyan-300 font-normal"}>
                      {isHalt
                        ? 'Passengers may get down, subject to operational conditions'
                        : 'View from Bus — No Stop'}
                    </strong>
                  </div>

                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/5">
                    <span className="text-slate-400">Entry / Ticket Status:</span>
                    <span className="font-medium text-slate-200">
                      {!isHalt
                        ? 'View from Bus — No Stop'
                        : isOptionalPaid
                        ? `Optional Paid Excursion (₹${point.entryFee || 'Pay on bus to guide'})`
                        : point.feeStatus === 'FREE'
                        ? 'Free Public Entry'
                        : point.entryFee
                        ? `Paid Entry (₹${point.entryFee})`
                        : 'Free Public Area'}
                    </span>
                  </div>
                </div>

                {/* Detailed Landmark Description */}
                <p className="text-xs text-slate-300 leading-relaxed">
                  {point.description}
                </p>

                {/* Optional Activity Information */}
                {point.optionalActivityDetails && (
                  <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 flex items-start gap-1.5">
                    <Info className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                    <span>{point.optionalActivityDetails}</span>
                  </div>
                )}
              </div>

              {/* Bottom Metadata & Maps Link */}
              <div className="pt-3 mt-3 border-t border-white/5 flex items-center justify-between text-xs gap-2">
                <div>
                  {point.googleMapsUrl && point.googleMapsUrl.trim() ? (
                    <a
                      href={point.googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-amber-400 hover:text-amber-300 font-semibold transition-colors"
                    >
                      <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>View on Google Maps</span>
                      <ExternalLink className="w-3 h-3 shrink-0" />
                    </a>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 text-slate-500 italic text-[11px]">
                      <MapPin className="w-3 h-3 text-slate-600 shrink-0" />
                      Map link coming soon
                    </span>
                  )}
                </div>

                <div className="text-[11px] text-slate-400 font-mono">
                  Point {point.id} of 44
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredPoints.length === 0 && (
        <div className="p-10 text-center text-slate-400 bg-white/5 rounded-2xl border border-white/10">
          <p className="text-sm">No landmarks match your search query.</p>
          <button
            type="button"
            onClick={() => {
              setFilterMode('ALL');
              setSearchQuery('');
            }}
            className="mt-2 text-xs font-semibold text-amber-400 hover:underline cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
};
