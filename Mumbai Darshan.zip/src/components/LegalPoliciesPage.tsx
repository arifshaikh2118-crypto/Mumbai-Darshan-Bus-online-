import React, { useState } from 'react';
import { ShieldCheck, FileText, Lock, Clock, AlertTriangle } from 'lucide-react';
import { StorageService } from '../services/storage';

interface LegalPoliciesPageProps {
  initialTab?: 'cancellation' | 'privacy' | 'terms';
}

export const LegalPoliciesPage: React.FC<LegalPoliciesPageProps> = ({ initialTab = 'cancellation' }) => {
  const [activeTab, setActiveTab] = useState<'cancellation' | 'privacy' | 'terms'>(initialTab);
  const settings = StorageService.getSettings();

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Tab Switcher */}
      <div className="flex items-center justify-center gap-2 p-1 bg-slate-900 border border-white/10 rounded-2xl max-w-md mx-auto">
        <button
          onClick={() => setActiveTab('cancellation')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
            activeTab === 'cancellation'
              ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Cancellation & Refund
        </button>
        <button
          onClick={() => setActiveTab('privacy')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
            activeTab === 'privacy'
              ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Privacy Policy
        </button>
        <button
          onClick={() => setActiveTab('terms')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
            activeTab === 'terms'
              ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Terms & Conditions
        </button>
      </div>

      {/* CONTENT: Cancellation and Refund Policy */}
      {activeTab === 'cancellation' && (
        <div className="shiny-dark-card rounded-2xl p-6 sm:p-8 border border-white/10 space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <div className="border-b border-white/10 pb-4">
            <span className="text-xs uppercase font-bold text-amber-400 tracking-wider">Customer Assurance</span>
            <h1 className="text-2xl font-extrabold text-white mt-1">Cancellation and Refund Policy</h1>
            <p className="text-xs text-slate-400 mt-1">
              Effective from November 2026 for all online and advance bookings made on {settings.websiteDomain}.
            </p>
          </div>

          <div className="space-y-4">
            <h2 className="text-base font-bold text-white">1. Cancellation Timelines & Refund Slabs</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 space-y-1">
                <span className="font-bold text-emerald-400 block">24+ Hours Notice</span>
                <p className="text-white font-semibold">Full Refund (Less ₹50 Admin Fee)</p>
                <p className="text-slate-400 text-[11px]">Cancellations requested 24 hours prior to scheduled boarding time.</p>
              </div>

              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 space-y-1">
                <span className="font-bold text-amber-400 block">12 to 24 Hours Notice</span>
                <p className="text-white font-semibold">50% Refund of Paid Amount</p>
                <p className="text-slate-400 text-[11px]">Due to limited short-notice seat re-allocation windows.</p>
              </div>

              <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 space-y-1">
                <span className="font-bold text-rose-400 block">&lt; 12 Hours / No-Show</span>
                <p className="text-white font-semibold">No Refund</p>
                <p className="text-slate-400 text-[11px]">Buses depart on strict schedule. Missing the bus forfeits the advance deposit.</p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">2. Free Rescheduling Policy</h2>
            <p>
              We understand plans change. Customers can reschedule their tour date free of charge up to 24 hours prior to travel, subject to seat availability on the desired new date. Please call or WhatsApp our helpline at <strong>+91 {settings.businessPhone}</strong> with your Booking ID to reschedule.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">3. Refund Processing Timeline</h2>
            <p>
              Approved refunds are processed back to the original payment source (UPI, Debit/Credit Card, or Net Banking) within <strong>3 to 5 business days</strong>. A confirmation SMS/email is dispatched once the credit batch is executed.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">4. Force Majeure & Severe Weather Cancellations</h2>
            <p>
              If a tour is officially cancelled by Mumbai Darshan Bus Online due to severe weather alerts issued by the Indian Meteorological Department (IMD) or government highway closures, customers will be offered a choice of 100% full refund or free rescheduling to any date within 6 months.
            </p>
          </div>
        </div>
      )}

      {/* CONTENT: Privacy Policy */}
      {activeTab === 'privacy' && (
        <div className="shiny-dark-card rounded-2xl p-6 sm:p-8 border border-white/10 space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <div className="border-b border-white/10 pb-4">
            <span className="text-xs uppercase font-bold text-amber-400 tracking-wider">Data Protection</span>
            <h1 className="text-2xl font-extrabold text-white mt-1">Privacy Policy</h1>
            <p className="text-xs text-slate-400 mt-1">
              Your personal information is handled with confidentiality and care.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">1. Information We Collect</h2>
            <p>
              When reserving a ticket or inquiring about charters on {settings.websiteDomain}, we collect your full name, 10-digit mobile phone number, optional email address, chosen pickup stop, passenger counts, and catering preferences.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">2. How We Use Your Information</h2>
            <ul className="list-disc list-inside space-y-1 text-slate-300">
              <li>Issuing your unique Booking ID and printable digital ticket receipt.</li>
              <li>Enabling the designated bus coordinator/driver to contact you 20 minutes before pickup arrival.</li>
              <li>Arranging accurate pure vegetarian breakfast and lunch counts.</li>
              <li>Processing online payment confirmations and advance verification receipts.</li>
            </ul>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">3. Zero Third-Party Spam & Data Selling</h2>
            <p>
              We firmly prohibit the sharing, selling, or leasing of customer contact details to third-party marketing companies, telemarketers, or loan agencies. Your phone number is strictly restricted to operations and trip coordination.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">4. Data Security</h2>
            <p>
              Our database infrastructure complies with strict industry safety standards. For questions regarding data erasure or updates, reach out to our grievance officer at <strong>{settings.businessEmail}</strong>.
            </p>
          </div>
        </div>
      )}

      {/* CONTENT: Terms & Conditions */}
      {activeTab === 'terms' && (
        <div className="shiny-dark-card rounded-2xl p-6 sm:p-8 border border-white/10 space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <div className="border-b border-white/10 pb-4">
            <span className="text-xs uppercase font-bold text-amber-400 tracking-wider">Operational Guidelines</span>
            <h1 className="text-2xl font-extrabold text-white mt-1">Terms and Conditions</h1>
            <p className="text-xs text-slate-400 mt-1">
              Please read carefully before finalizing your Mumbai Darshan tour reservation.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">1. Boarding & Reporting Time</h2>
            <p>
              Passengers must arrive at their designated boarding stop at least <strong>15 minutes prior</strong> to the scheduled departure time. Due to Mumbai municipal highway regulations, buses cannot hold traffic or wait beyond scheduled departure times.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">2. Seat Allocation & Bus Comfort</h2>
            <p>
              Seats are assigned systematically. While we make every effort to accommodate family groupings and senior citizen front-row requests, seats are not guaranteed by individual seat number unless chartered exclusively.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">3. Sightseeing Stops (HALT vs NO HALT)</h2>
            <p>
              The tour includes 44 sightseeing points. At <strong>BUS HALT</strong> stops, passengers may disembark for the specified stop duration. At <strong>NO HALT</strong> points, landmarks are viewed from the bus as the coach moves slowly. All passengers must re-board the bus promptly when called by the guide.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">4. Temple & Monument Etiquette</h2>
            <p>
              During visits to Shree Mahalaxmi Temple and Shree Siddhivinayak Temple, devotees must follow temple trust regulations regarding attire and photography. Leather goods, large backpacks, and cameras may need to be deposited at temple cloakrooms or left on the bus.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-base font-bold text-white">5. Balance Payments</h2>
            <p>
              If the ₹200 advance payment mode was chosen during booking, the remaining balance amount must be settled directly on the bus upon boarding via cash or UPI.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
