import React, { useState, useMemo } from 'react';
import { Clock, MapPin, Search, ExternalLink, Calendar, ArrowRight, Info, CheckCircle2 } from 'lucide-react';
import { StorageService } from '../services/storage';
import { RouteId } from '../types';

interface PickupTimingsTableProps {
  onSelectPickup?: (routeId: RouteId, pickupId: string) => void;
}

export const PickupTimingsTable: React.FC<PickupTimingsTableProps> = ({ onSelectPickup }) => {
  const routes = useMemo(() => StorageService.getRoutes().filter(r => r.active), []);
  const allPickups = useMemo(() => StorageService.getPickupPoints().filter(p => p.active), []);

  const [activeRouteId, setActiveRouteId] = useState<RouteId>('western');
  const [searchFilter, setSearchFilter] = useState('');

  // Active pickups for the selected route, sorted by sortOrder/pickup time
  const currentPickups = useMemo(() => {
    return allPickups
      .filter(p => p.routeId === activeRouteId)
      .filter(p => {
        if (!searchFilter.trim()) return true;
        const q = searchFilter.toLowerCase().trim();
        return (
          p.name.toLowerCase().includes(q) ||
          p.landmark.toLowerCase().includes(q) ||
          p.time.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }, [allPickups, activeRouteId, searchFilter]);

  const activeRoute = routes.find(r => r.id === activeRouteId) || routes[0];
  const totalVerifiedStops = allPickups.length; // 71 active records

  const handleBookFromPickup = (routeId: RouteId, pickupId: string) => {
    if (onSelectPickup) {
      onSelectPickup(routeId, pickupId);
    } else {
      const el = document.getElementById('booking-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <div className="space-y-6 w-full min-w-0">
      {/* Route Switcher Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5 w-full min-w-0">
        {routes.map(r => {
          const isSelected = activeRouteId === r.id;
          const count = allPickups.filter(p => p.routeId === r.id).length;

          return (
            <button
              key={r.id}
              type="button"
              onClick={() => {
                setActiveRouteId(r.id);
                setSearchFilter('');
              }}
              className={`p-2.5 sm:p-3.5 rounded-xl border text-left transition-all cursor-pointer min-w-0 ${
                isSelected
                  ? 'bg-amber-500/15 border-amber-400 shadow-md shadow-amber-500/10 ring-1 ring-amber-400'
                  : 'bg-[#12141c] border-white/10 hover:border-white/20'
              }`}
            >
              <div className="flex items-center justify-between gap-1">
                <span className={`text-[11px] sm:text-xs font-bold truncate ${isSelected ? 'text-amber-400' : 'text-white'}`}>
                  {r.name}
                </span>
                <span className="text-[9px] sm:text-[10px] font-mono px-1.5 py-0.5 rounded bg-white/10 text-slate-300 shrink-0 font-bold">
                  {count} Stops
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 mt-1 line-clamp-1">
                {r.description.split(',')[0]} corridor
              </p>
            </button>
          );
        })}
      </div>

      {/* Route Info & Search Header */}
      <div className="bg-[#12141c] p-3 sm:p-4 rounded-2xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4 w-full min-w-0 box-border">
        <div className="min-w-0">
          <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-1.5 sm:gap-2">
            <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="truncate">{activeRoute.name} Pickup Timings ({currentPickups.length} of {totalVerifiedStops} Mumbai Stops)</span>
          </h3>
          <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5">
            Daily morning departures. Driver and tour manager contact details are shared 20 minutes prior to boarding.
          </p>
        </div>

        <div className="relative w-full sm:w-64 min-w-0">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Optional search (stop, landmark)..."
            value={searchFilter}
            onChange={e => setSearchFilter(e.target.value)}
            className="w-full bg-slate-900 border border-white/10 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 box-border"
          />
        </div>
      </div>

      {/* MOBILE DISPLAY: Compact Vertical Pickup Cards (No horizontal scroll, continuous list) */}
      <div className="block md:hidden space-y-3 w-full">
        {currentPickups.map((point, index) => (
          <div
            key={point.id}
            className="shiny-dark-card rounded-xl p-3.5 border border-white/10 space-y-2.5 w-full min-w-0 box-border"
          >
            {/* Top row: Serial badge, Area name & Pickup Time */}
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-6 h-6 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-400 font-bold font-mono text-[11px] flex items-center justify-center shrink-0">
                  #{index + 1}
                </span>
                <strong className="text-sm font-bold text-white truncate">
                  {point.name}
                </strong>
              </div>
              <div className="text-right shrink-0">
                <span className="px-2 py-0.5 rounded bg-amber-500/15 border border-amber-500/30 text-amber-300 font-mono font-bold text-xs inline-flex items-center gap-1">
                  <Clock className="w-3 h-3 text-amber-400" />
                  {point.time || 'Time to be confirmed'}
                </span>
              </div>
            </div>

            {/* Landmark & Reporting Details */}
            <div className="bg-slate-900/80 p-2.5 rounded-lg border border-white/5 space-y-1 text-xs">
              <div className="flex items-start gap-1.5 text-slate-300">
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <p className="leading-snug">
                  <span className="text-slate-400">Boarding Landmark:</span> <strong className="text-white">{point.landmark}</strong>
                </p>
              </div>

              {point.reportingTime && (
                <div className="text-[11px] text-slate-400 pl-5">
                  Reporting Time: <span className="text-slate-200 font-medium">{point.reportingTime}</span>
                </div>
              )}
            </div>

            {/* Bottom Actions: Maps Link + Direct Booking */}
            <div className="flex items-center justify-between gap-2 pt-1">
              <div>
                {point.googleMapsUrl && point.googleMapsUrl.trim() ? (
                  <a
                    href={point.googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 font-medium"
                  >
                    <span>View Map</span>
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                ) : (
                  <span className="text-[10px] text-slate-500 italic">
                    Map link coming soon
                  </span>
                )}
              </div>

              <button
                type="button"
                onClick={() => handleBookFromPickup(point.routeId, point.id)}
                className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-sm active:scale-95 transition-all cursor-pointer"
              >
                <span>Book from this Stop</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* DESKTOP DISPLAY: Clean Table View */}
      <div className="hidden md:block shiny-dark-card rounded-2xl border border-white/10 overflow-hidden w-full max-w-full">
        <div className="w-full max-w-full overflow-x-auto block">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/90 text-slate-300 border-b border-white/10 uppercase tracking-wider text-[11px] font-semibold">
              <tr>
                <th className="py-3 px-4 w-12 text-center">#</th>
                <th className="py-3 px-4">Pickup Point & Area</th>
                <th className="py-3 px-4">Boarding Landmark</th>
                <th className="py-3 px-4">Pickup Time</th>
                <th className="py-3 px-4">Reporting Time</th>
                <th className="py-3 px-4 text-center">Map</th>
                <th className="py-3 px-4 text-right">Booking Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-200">
              {currentPickups.map((point, index) => (
                <tr key={point.id} className="hover:bg-white/5 transition-colors">
                  <td className="py-3 px-4 text-center font-mono text-slate-400 text-xs">
                    {index + 1}
                  </td>
                  <td className="py-3 px-4 font-bold text-white whitespace-nowrap">
                    {point.name}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    <span>{point.landmark}</span>
                  </td>
                  <td className="py-3 px-4 font-bold text-amber-400 font-mono tabular-nums whitespace-nowrap">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      {point.time || 'Time to be confirmed'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                    {point.reportingTime || '15 mins prior'}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {point.googleMapsUrl && point.googleMapsUrl.trim() ? (
                      <a
                        href={point.googleMapsUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-amber-400 hover:text-amber-300 inline-flex items-center gap-1 text-[11px]"
                        title="Open Landmark in Maps"
                      >
                        <span>Open</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    ) : (
                      <span className="text-[10px] text-slate-500 italic">Coming soon</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      type="button"
                      onClick={() => handleBookFromPickup(point.routeId, point.id)}
                      className="px-3 py-1.5 rounded-lg bg-amber-500/15 border border-amber-400/40 text-amber-300 hover:bg-amber-400 hover:text-slate-950 font-bold text-xs inline-flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <span>Book Stop</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {currentPickups.length === 0 && (
        <div className="p-8 text-center text-slate-400 bg-white/5 rounded-2xl border border-white/10">
          <p className="text-sm">No pickup points match your search filter.</p>
          <button
            type="button"
            onClick={() => setSearchFilter('')}
            className="mt-2 text-xs font-semibold text-amber-400 hover:underline cursor-pointer"
          >
            Clear search
          </button>
        </div>
      )}
    </div>
  );
};
