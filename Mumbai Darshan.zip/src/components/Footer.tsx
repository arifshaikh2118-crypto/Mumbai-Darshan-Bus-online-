import React from 'react';
import { Phone, Mail, MapPin, MessageCircle, Shield, Clock } from 'lucide-react';
import { StorageService } from '../services/storage';

interface FooterProps {
  setActivePage: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActivePage }) => {
  const settings = StorageService.getSettings();

  const handleNav = (page: string) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#06070a] border-t border-white/10 text-slate-400 text-sm no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          
          {/* Col 1: Brand & Contact Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center font-bold text-slate-950 text-lg">
                M
              </div>
              <span className="text-lg font-bold text-white tracking-tight">
                Mumbai Darshan <span className="text-amber-400">Bus Online</span>
              </span>
            </div>
            
            <p className="text-xs text-slate-400 leading-relaxed">
              Official daily Mumbai sightseeing tour bus service. Exploring 44 iconic heritage landmarks across South Mumbai, coastal highways, temples, and Bollywood enclaves.
            </p>

            <div className="space-y-2.5 text-xs">
              <a
                href={`tel:${settings.businessPhone}`}
                className="flex items-center gap-2.5 text-slate-300 hover:text-amber-400 transition-colors"
              >
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="font-semibold">{settings.businessPhone}</span>
              </a>

              <a
                href={`mailto:${settings.businessEmail}`}
                className="flex items-center gap-2.5 text-slate-300 hover:text-amber-400 transition-colors break-all"
              >
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{settings.businessEmail}</span>
              </a>

              <div className="flex items-start gap-2.5 text-slate-300">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span className="leading-snug">{settings.registeredAddress}</span>
              </div>

              <div className="flex items-center gap-2.5 text-slate-400">
                <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Booking Desk: 6:00 AM – 10:30 PM (Daily)</span>
              </div>
            </div>

            <div className="pt-2">
              <a
                href={`https://wa.me/${settings.whatsappNumber}?text=Hello%20Mumbai%20Darshan%20Bus,%20I%20have%20an%20enquiry%20regarding%20booking.`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-emerald-600/20 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-600/30 font-medium text-xs transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>Chat on WhatsApp ({settings.businessPhone})</span>
              </a>
            </div>
          </div>

          {/* Col 2: Tours & Routes */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white mb-4">
              Tour Routes & Packages
            </h3>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => handleNav('booking')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Book Mumbai Darshan Tour
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('pricing')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  AC & Non-AC Bus Packages
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('pickups')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Western Line Pickups (26 Points)
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('pickups')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Central Line Pickups (19 Points)
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('pickups')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Harbour Line Pickups (11 Points)
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('pickups')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Kalyan–Dombivli Line (15 Points)
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('charges')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Guide Charge & Sea Link Tolls
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Sightseeing & Private Charters */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white mb-4">
              Explore & Hire
            </h3>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => handleNav('places')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  All 44 Sightseeing Landmarks
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('charges')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Gateway Boat Ride (₹210)
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('charges')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Prince of Wales Museum (₹200)
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('car-rental')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Car Rental (Sedan, Innova, Crysta)
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('car-rental')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Tempo Traveller & Mini-Bus Rental
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('group-booking')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Corporate & School Group Bookings
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('lookup')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Check Booking Status / Print Ticket
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Customer Help & Legal */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white mb-4">
              Assistance & Policies
            </h3>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  About Mumbai Darshan Bus
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Contact Customer Care
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('faq')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Frequently Asked Questions
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('cancellation-policy')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Cancellation & Refund Policy
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('privacy-policy')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('terms')} className="hover:text-amber-400 transition-colors text-left cursor-pointer">
                  Terms and Conditions
                </button>
              </li>
              <li className="pt-2">
                <button
                  onClick={() => handleNav('admin')}
                  className="flex items-center gap-1.5 text-slate-500 hover:text-amber-400 transition-colors cursor-pointer"
                >
                  <Shield className="w-3.5 h-3.5 text-amber-500" />
                  <span>Admin Management Console</span>
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            © {new Date().getFullYear()} Mumbai Darshan Bus Online. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <span>Official Booking Helpline: +91 9619975457</span>
            <span>·</span>
            <button onClick={() => handleNav('terms')} className="hover:underline">Terms</button>
            <span>·</span>
            <button onClick={() => handleNav('privacy-policy')} className="hover:underline">Privacy</button>
          </div>
        </div>
      </div>
    </footer>
  );
};
