import React, { useState } from 'react';
import { Phone, MessageCircle, Menu, X, Shield, Calendar, MapPin, Tag, Camera } from 'lucide-react';
import { StorageService } from '../services/storage';

interface HeaderProps {
  activePage: string;
  setActivePage: (page: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ activePage, setActivePage }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const settings = StorageService.getSettings();

  const handleNav = (page: string) => {
    setActivePage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 bg-[#090a0f]/95 backdrop-blur-md border-b border-white/10 no-print w-full">
      {/* Top Bar Contract: Zone 1 (Brand) - Zone 2 (4-5 Nav Links) - Zone 3 (1 Primary Action) */}
      <div className="max-w-7xl mx-auto px-2.5 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between gap-1.5 sm:gap-6 lg:gap-8 w-full">
        
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => handleNav('home')}
          className="text-left flex items-center gap-1.5 sm:gap-2.5 group cursor-pointer shrink min-w-0"
        >
          <div className="w-7 h-7 min-[360px]:w-8 min-[360px]:h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center font-bold text-slate-950 text-sm sm:text-xl shadow-md sm:shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform shrink-0">
            M
          </div>
          <div className="min-w-0">
            <span className="text-xs min-[360px]:text-sm sm:text-lg lg:text-xl font-bold tracking-tight text-white whitespace-nowrap block">
              Mumbai Darshan <span className="text-amber-400">Bus</span>
            </span>
            <span className="text-[9px] sm:text-[11px] text-slate-400 block -mt-0.5 sm:-mt-1 tracking-wide truncate hidden min-[370px]:block">
              Daily Sightseeing & City Tours
            </span>
          </div>
        </button>

        {/* Zone 2: 4-5 clean single-line text navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-300">
          <button
            onClick={() => handleNav('home')}
            className={`cursor-pointer whitespace-nowrap transition-colors hover:text-white ${
              activePage === 'home' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Home
          </button>
          <button
            onClick={() => handleNav('booking')}
            className={`cursor-pointer whitespace-nowrap transition-colors hover:text-white ${
              activePage === 'booking' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Book Tour
          </button>
          <button
            onClick={() => handleNav('pricing')}
            className={`cursor-pointer whitespace-nowrap transition-colors hover:text-white ${
              activePage === 'pricing' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Packages & Pricing
          </button>
          <button
            onClick={() => handleNav('places')}
            className={`cursor-pointer whitespace-nowrap transition-colors hover:text-white ${
              activePage === 'places' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            44 Sightseeing Points
          </button>
          <button
            onClick={() => handleNav('gallery')}
            className={`cursor-pointer whitespace-nowrap transition-colors hover:text-white ${
              activePage === 'gallery' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Photo Gallery
          </button>
          <button
            onClick={() => handleNav('pickups')}
            className={`cursor-pointer whitespace-nowrap transition-colors hover:text-white ${
              activePage === 'pickups' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Pickup Timings
          </button>
          <button
            onClick={() => handleNav('lookup')}
            className={`cursor-pointer whitespace-nowrap transition-colors hover:text-white ${
              activePage === 'lookup' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Booking Lookup
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action + Utility items */}
        <div className="flex items-center gap-1 sm:gap-2 lg:gap-3 shrink-0">
          <a
            href={`tel:${settings.businessPhone}`}
            className="hidden sm:inline-flex items-center gap-2 text-xs font-semibold px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-slate-300 hover:text-white hover:bg-white/10 transition-colors whitespace-nowrap"
          >
            <Phone className="w-3.5 h-3.5 text-amber-400" />
            <span>{settings.businessPhone}</span>
          </a>

          <button
            onClick={() => handleNav('booking')}
            className="px-2 py-1.5 min-[360px]:px-2.5 sm:px-4 sm:py-2 text-[11px] sm:text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 rounded-lg hover:from-amber-300 hover:to-amber-400 transition-all shadow-sm sm:shadow-md shadow-amber-500/20 active:scale-95 whitespace-nowrap cursor-pointer"
          >
            Book Now
          </button>

          <button
            onClick={() => handleNav('admin')}
            className={`p-1.5 sm:p-2 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${
              activePage === 'admin'
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
            }`}
            title="Admin Portal"
            aria-label="Admin Portal"
          >
            <Shield className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 sm:p-2 text-slate-400 hover:text-white cursor-pointer"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5 sm:w-6 sm:h-6" /> : <Menu className="w-5 h-5 sm:w-6 sm:h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0e1017] border-b border-white/10 px-4 pt-3 pb-6 space-y-3">
          <div className="grid grid-cols-2 gap-2 text-xs font-medium text-slate-300">
            <button
              onClick={() => handleNav('home')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              Home
            </button>
            <button
              onClick={() => handleNav('booking')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-amber-500/10 text-amber-300 font-semibold text-left"
            >
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              Book Mumbai Darshan
            </button>
            <button
              onClick={() => handleNav('pricing')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              <Tag className="w-3.5 h-3.5 text-amber-400" />
              Prices & Packages
            </button>
            <button
              onClick={() => handleNav('pickups')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              4 Pickup Routes
            </button>
            <button
              onClick={() => handleNav('places')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              All 44 Sightseeing Points
            </button>
            <button
              onClick={() => handleNav('gallery')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              <Camera className="w-3.5 h-3.5 text-amber-400" />
              Photo Gallery
            </button>
            <button
              onClick={() => handleNav('charges')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              Attraction Tickets & Extra
            </button>
            <button
              onClick={() => handleNav('car-rental')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              Car Rental Enquiry
            </button>
            <button
              onClick={() => handleNav('group-booking')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              Group Booking (10+)
            </button>
            <button
              onClick={() => handleNav('lookup')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              Booking Status Lookup
            </button>
            <button
              onClick={() => handleNav('faq')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              FAQs
            </button>
            <button
              onClick={() => handleNav('about')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              About Us
            </button>
            <button
              onClick={() => handleNav('contact')}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-left"
            >
              Contact Us
            </button>
          </div>

          <div className="pt-2 flex items-center justify-between border-t border-white/10 text-xs">
            <a
              href={`https://wa.me/${settings.whatsappNumber}?text=Hello%20Mumbai%20Darshan%20Bus%20Online,%20I%20want%20to%20enquire%20about%20tour%20booking`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-emerald-400 hover:text-emerald-300 font-semibold"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp: {settings.businessPhone}
            </a>
            <button
              onClick={() => handleNav('admin')}
              className="text-slate-400 hover:text-amber-400 flex items-center gap-1.5"
            >
              <Shield className="w-3.5 h-3.5" />
              Admin Access
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
