import React from 'react';
import { ShieldAlert, Ticket, Anchor, Landmark, Film, Glasses, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';
import { StorageService } from '../services/storage';

interface AttractionChargesPageProps {
  onBookNow: () => void;
}

export const AttractionChargesPage: React.FC<AttractionChargesPageProps> = ({ onBookNow }) => {
  const extraCharges = StorageService.getExtraCharges().filter(c => c.active);

  const compulsoryCharges = extraCharges.filter(c => c.type === 'compulsory');
  const optionalCharges = extraCharges.filter(c => c.type === 'optional');

  return (
    <div className="space-y-12 max-w-5xl mx-auto">
      {/* Header */}
      <div className="text-center space-y-3">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
          Transparent Fee Policy
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Attraction Tickets & Extra Charges Breakdown
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          We believe in complete fee clarity with zero hidden surprises. Understand the difference between bus package fare, mandatory toll/guide fees, and optional sightseeing excursions.
        </p>
      </div>

      {/* SECTION 1: Compulsory Charges */}
      <div className="shiny-dark-card rounded-2xl p-6 sm:p-8 border border-rose-500/30 space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Compulsory Extra Charges (Total: ₹60 per person)</h2>
            <p className="text-xs text-slate-400">
              Mandatory operational regulatory fees charged per person across all tour lines.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {compulsoryCharges.map(charge => (
            <div key={charge.id} className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-2">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="font-bold text-white text-sm">{charge.name}</span>
                <span className="text-base font-extrabold text-rose-400 font-mono">
                  ₹{charge.amount} <span className="text-xs text-slate-400 font-normal">/ person</span>
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {charge.description}
              </p>
              <div className="p-2 rounded bg-white/5 text-[11px] text-slate-400">
                {charge.collectorNotice}
              </div>
            </div>
          ))}
        </div>

        <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 leading-relaxed">
          <strong>Mandatory On-Bus Collection:</strong> Tour Guide Charge (₹50/person) and Sea Link Toll (₹10/person) total ₹60 per passenger. Both charges are collected directly by the Tour Guide inside the bus. They are NOT included in the online bus booking fare, NOT included in the ₹200 advance payment, and NOT collected through the website payment gateway.
        </div>
      </div>

      {/* SECTION 2: Optional Attractions */}
      <div className="shiny-dark-card rounded-2xl p-6 sm:p-8 border border-white/10 space-y-6">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
            Never Automatically Charged
          </span>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Optional Sightseeing Tickets & Activities
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Customers explicitly decide whether to participate. You can choose them in Step 5 of the online booking form or purchase on spot at venue ticket counters.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Gateway Boat Ride */}
          <div className="bg-[#12141c] p-5 rounded-xl border border-white/10 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <Anchor className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-white text-sm">Gateway Harbor Boat Cruise</h3>
              </div>
              <span className="text-base font-extrabold text-amber-400 font-mono">₹210 / person</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              45-minute Arabian Sea motorboat cruise departing directly from Gateway of India pier. Stunning maritime view of Hotel Taj, naval warships, and Mumbai coastline.
            </p>
            <div className="text-[11px] text-slate-400 bg-white/5 p-2.5 rounded-lg space-y-1">
              <div>Type: <strong>100% Optional</strong> (Initial standard price: ₹210, not ₹220)</div>
              <div>Collected by: Authorized jetty operators / bus tour coordinator</div>
              <div>Subject to: Maritime weather clearance and naval authority schedules</div>
            </div>
          </div>

          {/* Prince of Wales Museum */}
          <div className="bg-[#12141c] p-5 rounded-xl border border-white/10 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <Landmark className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-white text-sm">Prince of Wales Museum (CSMVS)</h3>
              </div>
              <span className="text-base font-extrabold text-amber-400 font-mono">₹200 / person</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Grade I Indo-Saracenic heritage museum housing 70,000 antiquities, stone sculptures, miniature paintings, and historical weapons.
            </p>
            <div className="text-[11px] text-slate-400 bg-white/5 p-2.5 rounded-lg space-y-1">
              <div>Type: <strong>Optional Entry Pass</strong> (Initial reference price: ₹200)</div>
              <div>Collected by: Museum ticketing counter at Kala Ghoda</div>
              <div>Note: Free audio guide or camera permits extra as per venue policy</div>
            </div>
          </div>

          {/* Bollywood Museum */}
          <div className="bg-[#12141c] p-5 rounded-xl border border-white/10 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <Film className="w-5 h-5 text-purple-400" />
                <h3 className="font-bold text-white text-sm">Bollywood Museum & Studio Gallery</h3>
              </div>
              <span className="text-base font-extrabold text-amber-400 font-mono">₹165 / person</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Wax statues of Amitabh Bachchan, Salman Khan, Shah Rukh Khan, and iconic Hindi cinema set replicas with interactive photography zones.
            </p>
            <div className="text-[11px] text-slate-400 bg-white/5 p-2.5 rounded-lg space-y-1">
              <div>Type: <strong>Optional Stop Pass</strong> (Reference tariff ₹165)</div>
              <div>Collected by: Studio admissions desk</div>
            </div>
          </div>

          {/* Jehangir Art Gallery & Orama 11D */}
          <div className="bg-[#12141c] p-5 rounded-xl border border-white/10 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <Glasses className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-white text-sm">Jehangir Gallery & Orama 11D</h3>
              </div>
              <span className="text-xs text-slate-400 italic">Price to be confirmed</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Jehangir Art Gallery general halls are frequently free; special private exhibits charge counter fees. Orama 11D motion show has dynamic ticket rates configured by the Admin.
            </p>
            <div className="text-[11px] text-slate-400 bg-white/5 p-2.5 rounded-lg space-y-1">
              <div>Policy: Exact prices published only after formal venue confirmation</div>
              <div>Notice: No invented or inflated prices are ever shown on our site</div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center pt-4">
          <button
            onClick={onBookNow}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-extrabold text-xs cursor-pointer shadow-lg shadow-amber-500/20 hover:from-amber-300 hover:to-amber-400 active:scale-95 transition-all inline-flex items-center gap-2"
          >
            <span>Proceed to Tour Booking</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
