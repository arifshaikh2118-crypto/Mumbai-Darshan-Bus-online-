import React, { useState, useMemo } from 'react';
import { Camera, Plus, Check, X, Eye, EyeOff, Trash2, Edit2, ShieldCheck, Image as ImageIcon, MapPin } from 'lucide-react';
import { StorageService } from '../../services/storage';
import { GalleryImage } from '../../types';

interface AdminGalleryTabProps {
  onRefresh: () => void;
  showToast: (msg: string) => void;
}

export const AdminGalleryTab: React.FC<AdminGalleryTabProps> = ({ onRefresh, showToast }) => {
  const images = useMemo(() => StorageService.getGalleryImages(), [onRefresh]);
  const tourPoints = useMemo(() => StorageService.getTourPoints(), []);

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingImage, setEditingImage] = useState<GalleryImage | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [attractionName, setAttractionName] = useState('Gateway of India');
  const [imageUrl, setImageUrl] = useState('');
  const [caption, setCaption] = useState('');
  const [sortOrder, setSortOrder] = useState(1);
  const [approved, setApproved] = useState(true);
  const [published, setPublished] = useState(true);

  const publishedCount = images.filter(i => i.approved && i.published).length;

  const handleOpenAdd = () => {
    setTitle('');
    setAttractionName(tourPoints[0]?.name || 'Gateway of India');
    setImageUrl('');
    setCaption('');
    setSortOrder(images.length + 1);
    setApproved(true);
    setPublished(true);
    setEditingImage(null);
    setShowAddModal(true);
  };

  const handleOpenEdit = (img: GalleryImage) => {
    setEditingImage(img);
    setTitle(img.title);
    setAttractionName(img.attractionName);
    setImageUrl(img.imageUrl);
    setCaption(img.caption || '');
    setSortOrder(img.sortOrder);
    setApproved(img.approved);
    setPublished(img.published);
    setShowAddModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !imageUrl.trim()) {
      alert('Please provide title and image URL');
      return;
    }

    if (editingImage) {
      StorageService.updateGalleryImage(editingImage.id, {
        title: title.trim(),
        attractionName: attractionName.trim(),
        imageUrl: imageUrl.trim(),
        caption: caption.trim() || undefined,
        sortOrder,
        approved,
        published
      });
      showToast('Gallery image updated successfully!');
    } else {
      StorageService.addGalleryImage({
        title: title.trim(),
        attractionName: attractionName.trim(),
        imageUrl: imageUrl.trim(),
        caption: caption.trim() || undefined,
        sortOrder,
        approved,
        published
      });
      showToast('New photograph added to gallery!');
    }

    setShowAddModal(false);
    onRefresh();
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to remove "${name}" from the gallery?`)) {
      StorageService.deleteGalleryImage(id);
      showToast('Photograph removed from gallery.');
      onRefresh();
    }
  };

  const toggleApproved = (img: GalleryImage) => {
    StorageService.updateGalleryImage(img.id, { approved: !img.approved });
    showToast(`Image ${!img.approved ? 'Approved' : 'Moved to Pending'}`);
    onRefresh();
  };

  const togglePublished = (img: GalleryImage) => {
    if (!img.published && publishedCount >= 10) {
      alert('Maximum 10 photographs can be published on the website at once as per Part 5 guidelines. Please unpublish an existing photo first.');
      return;
    }
    StorageService.updateGalleryImage(img.id, { published: !img.published });
    showToast(`Image ${!img.published ? 'Published to website' : 'Unpublished'}`);
    onRefresh();
  };

  return (
    <div className="space-y-6">
      {/* Header with Part 5 compliance notice */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Camera className="w-5 h-5 text-amber-400" />
            <span>Mumbai Darshan Photo Gallery Management</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Publish maximum 10 real, approved photographs. Only approved and published photos appear in the public gallery.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-white/10 text-xs text-slate-300">
            Published: <strong className="text-amber-400 font-mono">{publishedCount}</strong> / 10 Max
          </div>
          <button
            type="button"
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs hover:from-amber-300 hover:to-amber-400 cursor-pointer shadow-md shadow-amber-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>Add Photograph</span>
          </button>
        </div>
      </div>

      {/* Grid of gallery management cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {images.map(img => (
          <div
            key={img.id}
            className="shiny-dark-card rounded-2xl border border-white/10 overflow-hidden flex flex-col justify-between"
          >
            <div className="relative aspect-[16/10] bg-slate-900 overflow-hidden">
              <img
                src={img.imageUrl}
                alt={img.title}
                className="w-full h-full object-cover"
                onError={e => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="absolute top-2.5 left-2.5 flex items-center gap-1">
                <span className="px-2 py-0.5 rounded bg-black/75 backdrop-blur-md text-[10px] font-mono text-white font-bold">
                  Order: #{img.sortOrder}
                </span>
                {img.approved ? (
                  <span className="px-2 py-0.5 rounded bg-emerald-500/80 text-slate-950 text-[10px] font-bold">
                    Approved
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded bg-rose-500/80 text-white text-[10px] font-bold">
                    Pending Approval
                  </span>
                )}
                {img.published && (
                  <span className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 text-[10px] font-bold">
                    Live
                  </span>
                )}
              </div>
            </div>

            <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
              <div>
                <strong className="text-sm font-bold text-white block truncate">{img.title}</strong>
                <span className="text-xs text-amber-400 flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3 h-3" />
                  <span>{img.attractionName}</span>
                </span>
                {img.caption && (
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {img.caption}
                  </p>
                )}
              </div>

              {/* Action buttons */}
              <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-1 text-xs">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => toggleApproved(img)}
                    className={`px-2 py-1 rounded text-[11px] font-semibold cursor-pointer ${
                      img.approved ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                    }`}
                    title={img.approved ? 'Approved' : 'Click to approve'}
                  >
                    {img.approved ? 'Approved' : 'Approve'}
                  </button>
                  <button
                    type="button"
                    onClick={() => togglePublished(img)}
                    className={`px-2 py-1 rounded text-[11px] font-semibold cursor-pointer ${
                      img.published ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-800 text-slate-400'
                    }`}
                    title={img.published ? 'Published' : 'Click to publish'}
                  >
                    {img.published ? 'Published' : 'Publish'}
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(img)}
                    className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 cursor-pointer"
                    title="Edit"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(img.id, img.title)}
                    className="p-1.5 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 cursor-pointer"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0f1118] border border-white/20 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Camera className="w-4 h-4 text-amber-400" />
                <span>{editingImage ? 'Edit Photograph' : 'Add New Photograph'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Photograph Title *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Gateway of India Arch & Promenade"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Assign to Official Landmark *
                </label>
                <select
                  value={attractionName}
                  onChange={e => setAttractionName(e.target.value)}
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="Gateway of India">Gateway of India</option>
                  <option value="Marine Drive">Marine Drive</option>
                  <option value="Chhatrapati Shivaji Maharaj Terminus">Chhatrapati Shivaji Maharaj Terminus</option>
                  <option value="Haji Ali Dargah">Haji Ali Dargah</option>
                  <option value="Mahalaxmi Temple">Mahalaxmi Temple</option>
                  <option value="Siddhivinayak Temple">Siddhivinayak Temple</option>
                  <option value="Bandra–Worli Sea Link">Bandra–Worli Sea Link</option>
                  <option value="Juhu Beach">Juhu Beach</option>
                  <option value="Bandra Bandstand">Bandra Bandstand</option>
                  <option value="Hotel Taj Mahal Palace">Hotel Taj Mahal Palace</option>
                  {tourPoints.map(tp => (
                    <option key={tp.id} value={tp.name}>{tp.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Image URL / Asset Path *
                </label>
                <input
                  type="text"
                  placeholder="https://... or /src/assets/images/..."
                  value={imageUrl}
                  onChange={e => setImageUrl(e.target.value)}
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Caption / Historical Information
                </label>
                <textarea
                  rows={2}
                  placeholder="Informative tourist description for the photo lightbox"
                  value={caption}
                  onChange={e => setCaption(e.target.value)}
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Display Order
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={sortOrder}
                    onChange={e => setSortOrder(parseInt(e.target.value) || 1)}
                    className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Approved
                  </label>
                  <select
                    value={approved ? 'yes' : 'no'}
                    onChange={e => setApproved(e.target.value === 'yes')}
                    className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="yes">Approved</option>
                    <option value="no">Pending</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Published
                  </label>
                  <select
                    value={published ? 'yes' : 'no'}
                    onChange={e => setPublished(e.target.value === 'yes')}
                    className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="yes">Published</option>
                    <option value="no">Unpublished</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold hover:from-amber-300 hover:to-amber-400"
                >
                  {editingImage ? 'Save Changes' : 'Add to Gallery'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
