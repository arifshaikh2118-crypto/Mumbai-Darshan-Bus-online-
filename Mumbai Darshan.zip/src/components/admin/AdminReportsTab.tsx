import React, { useState } from 'react';
import {
  FileText,
  Download,
  Printer,
  DollarSign,
  Users,
  Utensils,
  MapPin,
  Compass,
  Car,
  CheckCircle2,
  Calendar,
  Layers,
  Save,
  Plus
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { Booking, CarRentalEnquiry, RouteConfig } from '../../types';

export interface GuideTourCollectionLog {
  id: string;
  date: string;
  guideName: string;
  busNumber: string;
  gatewayBoatPax: number;
  gatewayBoatCollected: number;
  museumPax: number;
  museumCollected: number;
  oramaPax: number;
  oramaCollected: number;
  bollywoodMuseumPax: number;
  bollywoodCollected: number;
  totalCollected: number;
  submittedAt: string;
}

interface AdminReportsTabProps {
  bookings: Booking[];
  routes: RouteConfig[];
  rentals: CarRentalEnquiry[];
  showToast: (msg: string) => void;
}

export const AdminReportsTab: React.FC<AdminReportsTabProps> = ({
  bookings,
  routes,
  rentals,
  showToast
}) => {
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [offlineRecords, setOfflineRecords] = useState<GuideTourCollectionLog[]>(() => {
    try {
      const stored = localStorage.getItem('mdb_offline_attraction_records');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Tour Guide offline collection recorder form
  const [showGuideRecorder, setShowGuideRecorder] = useState(false);
  const [recDate, setRecDate] = useState(new Date().toISOString().slice(0, 10));
  const [recGuideName, setRecGuideName] = useState('');
  const [recBusNumber, setRecBusNumber] = useState('');
  const [recBoatPax, setRecBoatPax] = useState(0);
  const [recMuseumPax, setRecMuseumPax] = useState(0);
  const [recOramaPax, setRecOramaPax] = useState(0);
  const [recBollywoodPax, setRecBollywoodPax] = useState(0);

  // Filter bookings by date if selected
  const activeBookings = bookings.filter(b => {
    if (b.bookingStatus === 'Cancelled') return false;
    if (selectedDate && b.travelDate !== selectedDate) return false;
    return true;
  });

  // Metrics
  const totalPax = activeBookings.reduce((acc, b) => acc + b.passengerCount, 0);
  const acPax = activeBookings.filter(b => b.isAC).reduce((acc, b) => acc + b.passengerCount, 0);
  const nonAcPax = activeBookings.filter(b => !b.isAC).reduce((acc, b) => acc + b.passengerCount, 0);

  const totalAdvanceCollected = activeBookings.reduce((acc, b) => acc + (b.amountPaid || 0), 0);
  const totalBalanceDueOnBus = activeBookings.reduce((acc, b) => acc + (b.balancePayable || 0), 0);
  const totalGrossBookingValue = activeBookings.reduce((acc, b) => acc + (b.grandTotal || 0), 0);

  // Meals
  const vegBiryaniTotal = activeBookings.reduce((acc, b) => acc + (b.foodSelections?.vegBiryani || 0), 0);
  const butterPaneerTotal = activeBookings.reduce((acc, b) => acc + (b.foodSelections?.butterPaneer || 0), 0);
  const vegThaliTotal = activeBookings.reduce((acc, b) => acc + (b.foodSelections?.vegThali || 0), 0);
  const totalMeals = vegBiryaniTotal + butterPaneerTotal + vegThaliTotal;

  // Pickup volume
  const pickupVolumeMap: Record<string, number> = {};
  activeBookings.forEach(b => {
    const key = `${b.pickupPointName} (${b.routeName})`;
    pickupVolumeMap[key] = (pickupVolumeMap[key] || 0) + b.passengerCount;
  });
  const topPickups = Object.entries(pickupVolumeMap).sort((a, b) => b[1] - a[1]);

  // Rentals Financial Summary
  const confirmedRentals = rentals.filter(r => r.status === 'Confirmed' || r.status === 'Completed');
  const rentalQuotedTotal = confirmedRentals.reduce((acc, r) => acc + (r.customerQuotation || 0), 0);
  const rentalSupplierCostTotal = confirmedRentals.reduce((acc, r) => acc + (r.supplierCost || 0), 0);
  const rentalGrossMarginTotal = rentalQuotedTotal - rentalSupplierCostTotal;

  // Handle Guide Offline Recording save
  const handleSaveGuideRecord = () => {
    if (!recGuideName.trim() || !recBusNumber.trim()) {
      alert('Please enter Guide Name and Bus Number');
      return;
    }
    const newRecord: GuideTourCollectionLog = {
      id: `OFF-${Date.now().toString().slice(-4)}`,
      date: recDate,
      guideName: recGuideName.trim(),
      busNumber: recBusNumber.trim(),
      gatewayBoatPax: recBoatPax,
      gatewayBoatCollected: recBoatPax * 210,
      museumPax: recMuseumPax,
      museumCollected: recMuseumPax * 200,
      oramaPax: recOramaPax,
      oramaCollected: recOramaPax * 220,
      bollywoodMuseumPax: recBollywoodPax,
      bollywoodCollected: recBollywoodPax * 165,
      totalCollected: recBoatPax * 210 + recMuseumPax * 200 + recOramaPax * 220 + recBollywoodPax * 165,
      submittedAt: new Date().toISOString()
    };

    const updated = [newRecord, ...offlineRecords];
    setOfflineRecords(updated);
    localStorage.setItem('mdb_offline_attraction_records', JSON.stringify(updated));
    setShowGuideRecorder(false);
    showToast(`Offline collection recorded for ${recGuideName} (₹${newRecord.totalCollected})`);

    // Reset form
    setRecBoatPax(0);
    setRecMuseumPax(0);
    setRecOramaPax(0);
    setRecBollywoodPax(0);
    setRecGuideName('');
    setRecBusNumber('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <span>Operational & Financial Reports</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Passenger manifests, meal requirements, bus balances, offline attraction reconciliations, and rental profitability.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="date"
            value={selectedDate}
            onChange={e => setSelectedDate(e.target.value)}
            className="bg-slate-900 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400 cursor-pointer"
          />
          {selectedDate && (
            <button
              onClick={() => setSelectedDate('')}
              className="px-2.5 py-1.5 rounded-xl bg-white/10 text-xs text-slate-300 hover:text-white"
            >
              Clear Date
            </button>
          )}

          <button
            onClick={() => StorageService.exportBookingsToCSV()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-semibold cursor-pointer shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Manifest CSV</span>
          </button>
        </div>
      </div>

      {/* KPI Cards: Revenue & Collections */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-1">
          <span className="text-slate-400 text-xs flex items-center justify-between">
            <span>Online Advance Collected</span>
            <span className="text-[10px] text-emerald-400 font-mono">Paid Online</span>
          </span>
          <div className="text-2xl font-black text-emerald-400 font-mono">
            ₹{totalAdvanceCollected.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400 block">
            From {activeBookings.length} confirmed bookings
          </span>
        </div>

        <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-1">
          <span className="text-slate-400 text-xs flex items-center justify-between">
            <span>Balance Due on Bus</span>
            <span className="text-[10px] text-amber-400 font-mono">Cash / UPI</span>
          </span>
          <div className="text-2xl font-black text-amber-400 font-mono">
            ₹{totalBalanceDueOnBus.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400 block">
            To be collected by Tour Conductor
          </span>
        </div>

        <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-1">
          <span className="text-slate-400 text-xs flex items-center justify-between">
            <span>Total Bus Tour Gross</span>
            <span className="text-[10px] text-cyan-400 font-mono">Full Value</span>
          </span>
          <div className="text-2xl font-black text-white font-mono">
            ₹{totalGrossBookingValue.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400 block">
            {totalPax} Total Passengers
          </span>
        </div>

        <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-1">
          <span className="text-slate-400 text-xs flex items-center justify-between">
            <span>Rental Fleet Gross Margin</span>
            <span className="text-[10px] text-amber-300 font-mono">Profit</span>
          </span>
          <div className="text-2xl font-black text-amber-400 font-mono">
            ₹{rentalGrossMarginTotal.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400 block">
            Revenue ₹{rentalQuotedTotal} - Cost ₹{rentalSupplierCostTotal}
          </span>
        </div>
      </div>

      {/* Grid: Fleet Breakdown & Catering */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Passenger & Fleet Split */}
        <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-3">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" />
              <span>Passenger Category Distribution</span>
            </h3>
            <span className="text-xs font-mono text-cyan-300 font-bold">{totalPax} Total Pax</span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between items-center bg-white/5 p-2 rounded-lg">
              <span className="text-slate-300 font-medium">Luxury AC Coach:</span>
              <span className="font-mono font-bold text-cyan-300">{acPax} Passengers</span>
            </div>
            <div className="flex justify-between items-center bg-white/5 p-2 rounded-lg">
              <span className="text-slate-300 font-medium">Standard Non-AC Bus:</span>
              <span className="font-mono font-bold text-slate-300">{nonAcPax} Passengers</span>
            </div>
          </div>

          <div className="pt-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
              Line Passengers Split
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {routes.map(r => {
                const count = activeBookings
                  .filter(b => b.routeId === r.id)
                  .reduce((acc, b) => acc + b.passengerCount, 0);
                return (
                  <div key={r.id} className="p-2 rounded bg-black/40 border border-white/5">
                    <span className="text-slate-400 block text-[10px] truncate">{r.name}</span>
                    <strong className="text-white font-mono text-sm">{count} Pax</strong>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Catering & Meals Order */}
        <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-3">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Utensils className="w-4 h-4 text-amber-400" />
              <span>Catering & Lunch Orders</span>
            </h3>
            <span className="text-xs font-mono text-amber-400 font-bold">{totalMeals} Meals Total</span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between items-center bg-white/5 p-2.5 rounded-lg">
              <div>
                <strong className="text-white block">Veg Biryani + Raita</strong>
                <span className="text-[10px] text-slate-400">Fresh vegetable biryani with spiced curd</span>
              </div>
              <span className="font-mono font-bold text-amber-400 text-sm">{vegBiryaniTotal}</span>
            </div>

            <div className="flex justify-between items-center bg-white/5 p-2.5 rounded-lg">
              <div>
                <strong className="text-white block">Paneer Butter Masala + Chapati</strong>
                <span className="text-[10px] text-slate-400">Rich paneer gravy with soft tawa rotis</span>
              </div>
              <span className="font-mono font-bold text-amber-400 text-sm">{butterPaneerTotal}</span>
            </div>

            <div className="flex justify-between items-center bg-white/5 p-2.5 rounded-lg">
              <div>
                <strong className="text-white block">Special Veg Thali Meal</strong>
                <span className="text-[10px] text-slate-400">Complete lunch with dal, sabzi, rice & sweets</span>
              </div>
              <span className="font-mono font-bold text-amber-400 text-sm">{vegThaliTotal}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Top Boarding Stops Volume */}
      <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-3">
        <h3 className="font-bold text-white text-sm flex items-center gap-2">
          <MapPin className="w-4 h-4 text-emerald-400" />
          <span>Top Boarding Stops by Passenger Volume</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 text-xs">
          {topPickups.slice(0, 8).map(([stop, count]) => (
            <div key={stop} className="p-2.5 rounded-lg bg-white/5 border border-white/5 space-y-0.5">
              <span className="text-slate-300 font-medium block truncate text-[11px]">{stop}</span>
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500">Boardings</span>
                <span className="font-mono font-bold text-emerald-400">{count} Pax</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* PART 6: OFFLINE ATTRACTION RECONCILIATION */}
      <div className="bg-[#12141c] p-5 rounded-xl border border-white/10 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
          <div>
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Compass className="w-5 h-5 text-amber-400" />
              <span>Tour Guide Offline Attraction Fee Reconciliation (Part 6)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Optional fees collected on the bus in cash by Tour Guides: Gateway Boat (₹210), CSMVS Museum (₹200), Orama 11D (₹220), Bollywood Museum (₹165).
            </p>
          </div>

          <button
            onClick={() => setShowGuideRecorder(!showGuideRecorder)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{showGuideRecorder ? 'Close Recorder' : 'Record Tour Collection'}</span>
          </button>
        </div>

        {/* Guide Collection Recorder Form */}
        {showGuideRecorder && (
          <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-3">
            <h4 className="font-bold text-sm text-amber-300">New Tour Bus Attraction Cash Log</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Tour Date</label>
                <input
                  type="date"
                  value={recDate}
                  onChange={e => setRecDate(e.target.value)}
                  className="w-full bg-slate-900 border border-white/15 rounded-lg p-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">Tour Guide Name</label>
                <input
                  type="text"
                  placeholder="e.g. Ramesh Sharma"
                  value={recGuideName}
                  onChange={e => setRecGuideName(e.target.value)}
                  className="w-full bg-slate-900 border border-white/15 rounded-lg p-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">Bus Reg. / Route No.</label>
                <input
                  type="text"
                  placeholder="e.g. MH-02-CR-8821 (Western)"
                  value={recBusNumber}
                  onChange={e => setRecBusNumber(e.target.value)}
                  className="w-full bg-slate-900 border border-white/15 rounded-lg p-2 text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1">
              <div className="p-2.5 rounded bg-black/40 border border-white/10 space-y-1">
                <span className="text-slate-300 font-semibold block">Gateway Boat (₹210)</span>
                <input
                  type="number"
                  min="0"
                  placeholder="Pax"
                  value={recBoatPax || ''}
                  onChange={e => setRecBoatPax(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-white/15 rounded p-1.5 text-white font-mono"
                />
                <span className="text-[10px] text-amber-400 block font-mono">
                  Total: ₹{recBoatPax * 210}
                </span>
              </div>

              <div className="p-2.5 rounded bg-black/40 border border-white/10 space-y-1">
                <span className="text-slate-300 font-semibold block">CSMVS Museum (₹200)</span>
                <input
                  type="number"
                  min="0"
                  placeholder="Pax"
                  value={recMuseumPax || ''}
                  onChange={e => setRecMuseumPax(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-white/15 rounded p-1.5 text-white font-mono"
                />
                <span className="text-[10px] text-amber-400 block font-mono">
                  Total: ₹{recMuseumPax * 200}
                </span>
              </div>

              <div className="p-2.5 rounded bg-black/40 border border-white/10 space-y-1">
                <span className="text-slate-300 font-semibold block">Orama 11D (₹220)</span>
                <input
                  type="number"
                  min="0"
                  placeholder="Pax"
                  value={recOramaPax || ''}
                  onChange={e => setRecOramaPax(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-white/15 rounded p-1.5 text-white font-mono"
                />
                <span className="text-[10px] text-amber-400 block font-mono">
                  Total: ₹{recOramaPax * 220}
                </span>
              </div>

              <div className="p-2.5 rounded bg-black/40 border border-white/10 space-y-1">
                <span className="text-slate-300 font-semibold block">Bollywood Museum (₹165)</span>
                <input
                  type="number"
                  min="0"
                  placeholder="Pax"
                  value={recBollywoodPax || ''}
                  onChange={e => setRecBollywoodPax(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-white/15 rounded p-1.5 text-white font-mono"
                />
                <span className="text-[10px] text-amber-400 block font-mono">
                  Total: ₹{recBollywoodPax * 165}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-white/10">
              <div className="text-xs font-mono">
                <span className="text-slate-400">Total Cash Collected on Bus: </span>
                <strong className="text-emerald-400 font-bold text-sm">
                  ₹{recBoatPax * 210 + recMuseumPax * 200 + recOramaPax * 220 + recBollywoodPax * 165}
                </strong>
              </div>

              <button
                onClick={handleSaveGuideRecord}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md"
              >
                Save Tour Log
              </button>
            </div>
          </div>
        )}

        {/* Existing Offline Records Table */}
        <div className="shiny-dark-card rounded-xl border border-white/10 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 text-slate-400 border-b border-white/10 text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Guide / Bus</th>
                <th className="py-2.5 px-3">Boat (₹210)</th>
                <th className="py-2.5 px-3">Museum (₹200)</th>
                <th className="py-2.5 px-3">Orama (₹220)</th>
                <th className="py-2.5 px-3">Bollywood (₹165)</th>
                <th className="py-2.5 px-3 text-right">Total Cash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-mono">
              {offlineRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-xs text-slate-500 font-sans">
                    No offline attraction tour logs recorded yet. Use the "Record Tour Collection" button above.
                  </td>
                </tr>
              ) : (
                offlineRecords.map(rec => (
                  <tr key={rec.id} className="hover:bg-white/5 font-sans">
                    <td className="py-2.5 px-3 whitespace-nowrap font-mono text-white">{rec.date}</td>
                    <td className="py-2.5 px-3">
                      <strong className="text-white block">{rec.guideName}</strong>
                      <span className="text-[10px] text-slate-400 font-mono">{rec.busNumber}</span>
                    </td>
                    <td className="py-2.5 px-3 font-mono">{rec.gatewayBoatPax}p (₹{rec.gatewayBoatCollected})</td>
                    <td className="py-2.5 px-3 font-mono">{rec.museumPax}p (₹{rec.museumCollected})</td>
                    <td className="py-2.5 px-3 font-mono">{rec.oramaPax}p (₹{rec.oramaCollected})</td>
                    <td className="py-2.5 px-3 font-mono">{rec.bollywoodMuseumPax}p (₹{rec.bollywoodCollected})</td>
                    <td className="py-2.5 px-3 text-right font-mono text-emerald-400 font-bold whitespace-nowrap">
                      ₹{rec.totalCollected.toLocaleString('en-IN')}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
