import React, { useState } from 'react';
import {
  Car,
  DollarSign,
  TrendingUp,
  ShieldAlert,
  Send,
  MessageCircle,
  Clock,
  MapPin,
  Users,
  CheckCircle2,
  Calendar,
  Eye,
  Edit,
  Save,
  X
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import {
  CarRentalEnquiry,
  LocalRentalPackage,
  OutstationVehicleRate,
  RentalStatus
} from '../../types';

interface AdminRentalsTabProps {
  enquiries: CarRentalEnquiry[];
  onRefresh: () => void;
  showToast: (msg: string) => void;
}

export const AdminRentalsTab: React.FC<AdminRentalsTabProps> = ({
  enquiries,
  onRefresh,
  showToast
}) => {
  const [subTab, setSubTab] = useState<'enquiries' | 'local_packages' | 'outstation_tariffs'>('enquiries');
  const [localPackages, setLocalPackages] = useState<LocalRentalPackage[]>(StorageService.getLocalRentalPackages());
  const [outstationRates, setOutstationRates] = useState<OutstationVehicleRate[]>(StorageService.getOutstationRates());

  // Editing package state
  const [editingPkgId, setEditingPkgId] = useState<string | null>(null);
  const [tempPkgRate, setTempPkgRate] = useState<number>(0);
  const [tempPkgCost, setTempPkgCost] = useState<number>(0);

  // Selected Enquiry for quotation modal
  const [selectedEnquiry, setSelectedEnquiry] = useState<CarRentalEnquiry | null>(null);
  const [quoteAmount, setQuoteAmount] = useState<number>(0);
  const [quoteSupplierCost, setQuoteSupplierCost] = useState<number>(0);
  const [quoteNotes, setQuoteNotes] = useState<string>('');

  // Status Filter
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const filteredEnquiries = enquiries.filter(e => {
    if (statusFilter === 'ALL') return true;
    return e.status === statusFilter;
  });

  const handleUpdateStatus = (id: string, newStatus: RentalStatus) => {
    StorageService.updateCarRental(id, { status: newStatus });
    onRefresh();
    showToast(`Enquiry ${id} updated to ${newStatus}`);
  };

  const handleSaveQuotation = (enquiryId: string) => {
    const margin = quoteAmount - quoteSupplierCost;
    StorageService.updateCarRental(enquiryId, {
      customerQuotation: quoteAmount,
      supplierCost: quoteSupplierCost,
      grossMargin: margin,
      specialRequirements: quoteNotes ? `[Quotation Note: ${quoteNotes}]` : undefined,
      status: 'Quotation Sent'
    });
    setSelectedEnquiry(null);
    onRefresh();
    showToast(`Quotation saved & gross margin calculated (₹${margin})`);
  };

  const generateWhatsAppQuoteLink = (enquiry: CarRentalEnquiry) => {
    const cleanPhone = enquiry.customerMobile.replace(/\D/g, '');
    const phoneWithCountry = cleanPhone.startsWith('91') ? cleanPhone : `91${cleanPhone}`;
    const text = encodeURIComponent(
      `Hello ${enquiry.customerName},\n\nThank you for your enquiry with Mumbai Darshan Bus Online!\n\n` +
      `*Trip Details:*\n` +
      `• Rental Type: ${enquiry.rentalType === 'local_darshan' ? 'Mumbai Local Darshan (12 Hrs / 120 KM)' : 'Outstation Journey'}\n` +
      `• Vehicle: ${enquiry.vehicleType}\n` +
      `• Travel Date: ${enquiry.travelDate}\n` +
      `• Passengers: ${enquiry.passengerCount}\n` +
      `• Pickup: ${enquiry.pickupLocation}\n\n` +
      `*Quoted Price:* ₹${enquiry.customerQuotation || 'Available on request'}\n` +
      `*Inclusions:* Driver bhatta, vehicle hire, fuel.\n` +
      `*Exclusions:* Parking & toll at actuals.\n\n` +
      `Please reply with CONFIRM to proceed with the booking.\n\nWarm regards,\nMumbai Darshan Bus Online Desk\n📞 9619975457`
    );
    return `https://wa.me/${phoneWithCountry}?text=${text}`;
  };

  return (
    <div className="space-y-6">
      {/* Tab Header & Sub-Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Car className="w-5 h-5 text-amber-400" />
            <span>Private Car, Tempo Traveller & Bus Rental Fleet</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage customer quotations, local 12h/120km packages, outstation tariffs, supplier costs, and gross margins.
          </p>
        </div>

        {/* Sub-tab Pills */}
        <div className="flex items-center gap-1.5 p-1 bg-black/40 border border-white/10 rounded-xl">
          <button
            onClick={() => setSubTab('enquiries')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              subTab === 'enquiries'
                ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Enquiries ({enquiries.length})
          </button>
          <button
            onClick={() => setSubTab('local_packages')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              subTab === 'local_packages'
                ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Local Darshan Rates
          </button>
          <button
            onClick={() => setSubTab('outstation_tariffs')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              subTab === 'outstation_tariffs'
                ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Outstation Rates
          </button>
        </div>
      </div>

      {/* CONFIDENTIAL BANNER */}
      <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 flex items-start gap-2.5">
        <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <p className="text-xs text-amber-200/90 leading-relaxed">
          <strong>Confidential Pricing & Margin Controls:</strong> Supplier costs and Gross Margin calculations are visible strictly inside this Admin Panel. Public customers only see proposed package rates and official quotations.
        </p>
      </div>

      {/* SUB-TAB 1: ENQUIRIES */}
      {subTab === 'enquiries' && (
        <div className="space-y-4">
          {/* Status Filter */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-[#12141c] p-3 rounded-xl border border-white/10">
            <span className="text-xs text-slate-400">Filter by Workflow Status:</span>
            <div className="flex flex-wrap gap-1.5">
              {[
                'ALL',
                'New Enquiry',
                'Contacted',
                'Quotation Pending',
                'Quotation Sent',
                'Awaiting Customer Approval',
                'Supplier Availability Pending',
                'Confirmed',
                'Completed',
                'Cancelled'
              ].map(st => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer transition-colors ${
                    statusFilter === st
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {/* List of Enquiries */}
          <div className="space-y-3">
            {filteredEnquiries.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 bg-[#12141c] rounded-xl border border-white/10">
                No rental enquiries found for status "{statusFilter}".
              </div>
            ) : (
              filteredEnquiries.map(enq => {
                const margin = (enq.customerQuotation || 0) - (enq.supplierCost || 0);
                return (
                  <div
                    key={enq.id}
                    className="bg-[#12141c] p-4 rounded-xl border border-white/10 hover:border-amber-500/30 transition-all space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5">
                      <div className="flex items-center gap-2.5">
                        <span className="font-mono text-amber-400 font-bold text-xs">{enq.id}</span>
                        <span className="text-slate-500">•</span>
                        <span className="font-bold text-white text-sm">{enq.vehicleType}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-white/10 text-slate-300 font-medium">
                          {enq.rentalType === 'local_darshan' ? 'Mumbai Local 12h/120km' : 'Outstation Journey'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <select
                          value={enq.status}
                          onChange={e => handleUpdateStatus(enq.id, e.target.value as RentalStatus)}
                          className="bg-slate-900 border border-white/10 rounded-lg px-2.5 py-1 text-xs text-amber-300 font-semibold focus:outline-none focus:border-amber-400 cursor-pointer"
                        >
                          <option value="New Enquiry">New Enquiry</option>
                          <option value="Contacted">Contacted</option>
                          <option value="Quotation Pending">Quotation Pending</option>
                          <option value="Quotation Sent">Quotation Sent</option>
                          <option value="Awaiting Customer Approval">Awaiting Customer Approval</option>
                          <option value="Supplier Availability Pending">Supplier Availability Pending</option>
                          <option value="Confirmed">Confirmed</option>
                          <option value="Completed">Completed</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>

                    {/* Customer & Trip Details */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-slate-300">
                      <div>
                        <span className="text-slate-500 block text-[10px]">Customer Name</span>
                        <strong className="text-white">{enq.customerName}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Mobile Contact</span>
                        <strong className="text-amber-400 font-mono">{enq.customerMobile}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Travel Date</span>
                        <strong className="text-white">{enq.travelDate}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Passengers</span>
                        <strong className="text-white">{enq.passengerCount} Pax</strong>
                      </div>
                    </div>

                    <div className="text-xs text-slate-300 flex flex-wrap items-center gap-x-6 gap-y-1 bg-white/5 p-2.5 rounded-lg">
                      <div>
                        <span className="text-slate-500 text-[10px]">Pickup Location: </span>
                        <span className="text-white font-medium">{enq.pickupLocation}</span>
                      </div>
                      {enq.rentalType === 'outstation' && enq.destination && (
                        <div>
                          <span className="text-slate-500 text-[10px]">Destination: </span>
                          <span className="text-white font-medium">{enq.destination} ({enq.daysCount || 1} Days)</span>
                        </div>
                      )}
                      {enq.estimatedKm && (
                        <div>
                          <span className="text-slate-500 text-[10px]">Est. Distance: </span>
                          <span className="text-amber-400 font-mono font-medium">{enq.estimatedKm} KM</span>
                        </div>
                      )}
                    </div>

                    {/* Financial & Gross Margin Strip (Admin Only) */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-white/5">
                      <div className="flex items-center gap-4 text-xs font-mono">
                        <div>
                          <span className="text-slate-500 text-[10px] block">Customer Quoted</span>
                          <span className="text-emerald-400 font-bold">
                            {enq.customerQuotation ? `₹${enq.customerQuotation.toLocaleString('en-IN')}` : 'Not Quoted Yet'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Supplier Cost</span>
                          <span className="text-rose-400 font-bold">
                            {enq.supplierCost ? `₹${enq.supplierCost.toLocaleString('en-IN')}` : '—'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 text-[10px] block">Gross Margin</span>
                          <span className={`font-bold ${margin >= 0 ? 'text-amber-400' : 'text-rose-500'}`}>
                            {enq.customerQuotation && enq.supplierCost ? `₹${margin.toLocaleString('en-IN')}` : '—'}
                          </span>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setSelectedEnquiry(enq);
                            setQuoteAmount(enq.customerQuotation || 0);
                            setQuoteSupplierCost(enq.supplierCost || 0);
                            setQuoteNotes('');
                          }}
                          className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-semibold text-xs cursor-pointer flex items-center gap-1.5"
                        >
                          <Edit className="w-3.5 h-3.5" />
                          <span>Set Quotation</span>
                        </button>

                        <a
                          href={generateWhatsAppQuoteLink(enq)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer flex items-center gap-1.5 shadow-md shadow-emerald-900/30"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>Send WhatsApp Quote</span>
                        </a>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: LOCAL DARSHAN PACKAGES (12H / 120KM) */}
      {subTab === 'local_packages' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Mumbai Local Darshan (12 Hours / 120 KM Flat Package)</h3>
            <span className="text-xs text-amber-400 font-mono">Terms: Parking extra, Driver Bhatta included</span>
          </div>

          <div className="shiny-dark-card rounded-xl border border-white/10 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/80 text-slate-400 border-b border-white/10 text-[11px]">
                <tr>
                  <th className="py-3 px-3">Vehicle Model</th>
                  <th className="py-3 px-3">Capacity</th>
                  <th className="py-3 px-3">Customer Rate (12h/120km)</th>
                  <th className="py-3 px-3 text-rose-300">Supplier Cost (Confidential)</th>
                  <th className="py-3 px-3 text-amber-300">Gross Margin</th>
                  <th className="py-3 px-3">Extra /KM</th>
                  <th className="py-3 px-3">Extra /HR</th>
                  <th className="py-3 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {localPackages.map(pkg => {
                  const isEditing = editingPkgId === pkg.id;
                  const margin = pkg.proposedCustomerPrice - pkg.supplierCost;

                  return (
                    <tr key={pkg.id} className="hover:bg-white/5 font-sans">
                      <td className="py-3 px-3">
                        <strong className="text-white block">{pkg.vehicleName}</strong>
                        <span className="text-[10px] text-slate-400">12 Hours / 120 KM Package</span>
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-300">{pkg.seating}</td>
                      <td className="py-3 px-3 font-mono">
                        {isEditing ? (
                          <input
                            type="number"
                            value={tempPkgRate}
                            onChange={e => setTempPkgRate(Number(e.target.value))}
                            className="w-24 bg-slate-900 border border-amber-400/50 rounded px-2 py-1 text-white text-xs"
                          />
                        ) : (
                          <span className="text-emerald-400 font-bold">₹{pkg.proposedCustomerPrice.toLocaleString('en-IN')}</span>
                        )}
                      </td>
                      <td className="py-3 px-3 font-mono text-rose-300">
                        {isEditing ? (
                          <input
                            type="number"
                            value={tempPkgCost}
                            onChange={e => setTempPkgCost(Number(e.target.value))}
                            className="w-24 bg-slate-900 border border-rose-400/50 rounded px-2 py-1 text-white text-xs"
                          />
                        ) : (
                          <span>₹{pkg.supplierCost.toLocaleString('en-IN')}</span>
                        )}
                      </td>
                      <td className="py-3 px-3 font-mono text-amber-400 font-bold">
                        ₹{margin.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-300">₹{pkg.extraKmRate}/km</td>
                      <td className="py-3 px-3 font-mono text-slate-300">₹{pkg.extraHourRate}/hr</td>
                      <td className="py-3 px-3 text-right">
                        {isEditing ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                StorageService.updateLocalRentalPackage(pkg.id, {
                                  proposedCustomerPrice: tempPkgRate,
                                  supplierCost: tempPkgCost
                                });
                                setLocalPackages(StorageService.getLocalRentalPackages());
                                setEditingPkgId(null);
                                showToast(`Rates updated for ${pkg.vehicleName}`);
                              }}
                              className="px-2.5 py-1 rounded bg-amber-500 text-slate-950 font-bold text-xs"
                            >
                              Save
                            </button>
                            <button
                              onClick={() => setEditingPkgId(null)}
                              className="px-2 py-1 rounded bg-white/10 text-white text-xs"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              setEditingPkgId(pkg.id);
                              setTempPkgRate(pkg.proposedCustomerPrice);
                              setTempPkgCost(pkg.supplierCost);
                            }}
                            className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-white text-xs cursor-pointer"
                          >
                            Edit Rates
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: OUTSTATION TARIFFS */}
      {subTab === 'outstation_tariffs' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Outstation Rental Tariffs (300 KM/Day Minimum)</h3>
            <span className="text-xs text-amber-400 font-mono">Toll, Parking, Border Tax at actuals</span>
          </div>

          <div className="shiny-dark-card rounded-xl border border-white/10 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/80 text-slate-400 border-b border-white/10 text-[11px]">
                <tr>
                  <th className="py-3 px-3">Vehicle Category</th>
                  <th className="py-3 px-3">Seats</th>
                  <th className="py-3 px-3">Customer Rate / KM</th>
                  <th className="py-3 px-3 text-rose-300">Supplier Cost / KM</th>
                  <th className="py-3 px-3">Driver DA / Day</th>
                  <th className="py-3 px-3">Night DA</th>
                  <th className="py-3 px-3">Min Daily KM</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {outstationRates.map(rate => (
                  <tr key={rate.id} className="hover:bg-white/5 font-sans">
                    <td className="py-3 px-3 font-semibold text-white">{rate.vehicleName}</td>
                    <td className="py-3 px-3 font-mono text-slate-300">{rate.seating}</td>
                    <td className="py-3 px-3 font-mono text-emerald-400 font-bold">₹{rate.proposedCustomerPerKm}/km</td>
                    <td className="py-3 px-3 font-mono text-rose-300">₹{rate.supplierPerKm}/km</td>
                    <td className="py-3 px-3 font-mono text-slate-300">₹{rate.proposedCustomerDaPerDay}</td>
                    <td className="py-3 px-3 font-mono text-slate-300">₹{rate.nightDaRate}</td>
                    <td className="py-3 px-3 font-mono text-amber-400">{rate.minKmPerDay} KM</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Quotation Modal */}
      {selectedEnquiry && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12141c] border border-white/20 rounded-2xl p-6 max-w-lg w-full space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <span className="text-[11px] uppercase tracking-wider text-amber-400 font-bold">Prepare Quotation</span>
                <h3 className="text-base font-bold text-white">{selectedEnquiry.customerName} ({selectedEnquiry.vehicleType})</h3>
              </div>
              <button
                onClick={() => setSelectedEnquiry(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Quoted Customer Amount (₹)</label>
                <input
                  type="number"
                  value={quoteAmount}
                  onChange={e => setQuoteAmount(Number(e.target.value))}
                  placeholder="e.g. 5500"
                  className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold text-rose-300">
                  Supplier / Vendor Cost (₹) <span className="text-[10px] text-slate-400">(Admin Confidential)</span>
                </label>
                <input
                  type="number"
                  value={quoteSupplierCost}
                  onChange={e => setQuoteSupplierCost(Number(e.target.value))}
                  placeholder="e.g. 4500"
                  className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-rose-400"
                />
              </div>

              {quoteAmount > 0 && quoteSupplierCost > 0 && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex justify-between items-center text-xs">
                  <span className="text-amber-300 font-medium">Estimated Gross Margin:</span>
                  <span className="font-mono font-bold text-emerald-400 text-sm">
                    ₹{(quoteAmount - quoteSupplierCost).toLocaleString('en-IN')}
                  </span>
                </div>
              )}

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Special Notes / Driver Assignment</label>
                <textarea
                  rows={2}
                  value={quoteNotes}
                  onChange={e => setQuoteNotes(e.target.value)}
                  placeholder="e.g. Driver Ramesh assigned, AC Dzire white plate"
                  className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
              <button
                onClick={() => setSelectedEnquiry(null)}
                className="px-4 py-2 rounded-xl bg-white/10 text-xs font-semibold text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSaveQuotation(selectedEnquiry.id)}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md"
              >
                Save & Update Status
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
