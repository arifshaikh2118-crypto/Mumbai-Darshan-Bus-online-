import React, { useState } from 'react';
import { Search, Printer, CheckCircle2, Clock, AlertCircle, Phone, X, RefreshCw } from 'lucide-react';
import { StorageService } from '../services/storage';
import { Booking } from '../types';

export const BookingLookup: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Booking[] | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [cancellationBookingId, setCancellationBookingId] = useState<string | null>(null);
  const [cancellationReason, setCancellationReason] = useState('');
  const [cancellationSuccess, setCancellationSuccess] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setHasSearched(true);
    setCancellationSuccess(false);

    // If query is an ID
    const single = StorageService.getBookingById(query.trim());
    if (single) {
      setResults([single]);
      return;
    }

    // Check if query is 10 digit mobile
    const byMobile = StorageService.getBookingsByMobile(query.trim());
    setResults(byMobile);
  };

  const handleCancelRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cancellationBookingId || !cancellationReason.trim()) return;

    StorageService.requestCancellation({
      bookingId: cancellationBookingId,
      customerMobile: results?.find(b => b.id === cancellationBookingId)?.customerMobile || '',
      reason: cancellationReason.trim()
    });

    setCancellationSuccess(true);
    setCancellationBookingId(null);
    setCancellationReason('');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Search Bar Box */}
      <div className="shiny-dark-card rounded-2xl p-6 sm:p-8 border border-white/10 text-center space-y-4">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
          Instant Ticket & Status Verification
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Find Your Mumbai Darshan Booking
        </h1>
        <p className="text-xs text-slate-400 max-w-lg mx-auto">
          Enter your <strong>Booking ID</strong> (e.g., <code className="text-amber-300 font-mono">MDB-20261110-1042</code>) or your <strong>10-digit registered mobile number</strong>.
        </p>

        <form onSubmit={handleSearch} className="max-w-md mx-auto flex gap-2 pt-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="e.g. MDB-20261110-1042 or 9820012345"
              value={query}
              onChange={e => setQuery(e.target.value)}
              className="w-full bg-[#12141c] border border-white/10 rounded-xl pl-10 pr-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md shadow-amber-500/20 active:scale-95 transition-all"
          >
            Lookup
          </button>
        </form>
      </div>

      {cancellationSuccess && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>Your cancellation/rescheduling request has been logged. Our helpdesk team (+91 9619975457) will contact you shortly.</span>
        </div>
      )}

      {/* Results View */}
      {hasSearched && results && results.length > 0 && (
        <div className="space-y-6">
          <h2 className="text-lg font-bold text-white">
            Matching Bookings ({results.length})
          </h2>

          {results.map(booking => (
            <div
              key={booking.id}
              className="shiny-dark-card rounded-2xl p-6 border border-white/15 space-y-4 print-card"
            >
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-4 gap-2">
                <div>
                  <span className="text-xs uppercase font-bold text-amber-400">Official Bus Ticket</span>
                  <h3 className="text-xl font-black text-white font-mono mt-0.5">
                    {booking.id}
                  </h3>
                  <span className="text-xs text-slate-400">
                    Travel Date: <strong className="text-white">{booking.travelDate}</strong>
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    booking.bookingStatus === 'Confirmed'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}>
                    {booking.bookingStatus}
                  </span>
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-white/5 border border-white/10 text-slate-300">
                    {booking.paymentStatus}
                  </span>
                </div>
              </div>

              {/* Grid info */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs border-b border-white/10 pb-4">
                <div>
                  <span className="text-slate-400 block text-[11px]">Passenger Name</span>
                  <strong className="text-white text-sm">{booking.customerName}</strong>
                  <span className="text-[11px] text-slate-400 block font-mono">{booking.customerMobile}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Selected Line</span>
                  <strong className="text-white text-sm">{booking.routeName}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Pickup Timing</span>
                  <strong className="text-amber-400 text-sm font-mono">{booking.pickupTime}</strong>
                  <span className="text-[10px] text-slate-400 block">{booking.reportingTime}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Party Size</span>
                  <strong className="text-white text-sm">{booking.passengerCount} Passengers</strong>
                </div>
              </div>

              {/* Boarding Point Details */}
              <div className="p-3 rounded-xl bg-white/5 text-xs space-y-1">
                <span className="text-amber-400 font-semibold block">Designated Boarding Stop:</span>
                <p className="text-white font-medium">{booking.pickupPointName}</p>
                <p className="text-[11px] text-slate-400">
                  Please be at the pickup landmark at least 15 minutes before {booking.pickupTime}. Driver coordinator contacts you prior to arrival.
                </p>
              </div>

              {/* Food Details if present */}
              {booking.foodSelections && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs">
                  <span className="text-emerald-400 font-bold block mb-1">Catering Selections (Included in Package):</span>
                  <div className="flex flex-wrap gap-4 text-slate-300">
                    {booking.foodSelections.vegBiryani > 0 && <div>Veg Biryani: <strong className="text-white">{booking.foodSelections.vegBiryani}</strong></div>}
                    {booking.foodSelections.butterPaneer > 0 && <div>Butter Paneer: <strong className="text-white">{booking.foodSelections.butterPaneer}</strong></div>}
                    {booking.foodSelections.vegThali > 0 && <div>Veg Thali: <strong className="text-white">{booking.foodSelections.vegThali}</strong></div>}
                  </div>
                </div>
              )}

              {/* Financial Breakdown */}
              <div className="bg-[#12141c] p-4 rounded-xl border border-white/10 space-y-3 text-xs">
                <div className="space-y-1.5 border-b border-white/10 pb-2.5">
                  <div className="flex justify-between text-slate-300">
                    <span>Online Bus Package Fare ({booking.packageTitle}):</span>
                    <span className="font-mono tabular-nums text-white font-bold">₹{booking.totalPackageAmount}</span>
                  </div>
                  <div className="flex justify-between text-emerald-400 font-semibold">
                    <span>Payment Status:</span>
                    <span className="font-mono tabular-nums">{booking.paymentStatus}</span>
                  </div>
                  <div className="flex justify-between font-bold text-amber-300 bg-amber-500/10 p-2 rounded-lg mt-1">
                    <span>Remaining Bus Package Amount (Payable on Bus):</span>
                    <span className="font-mono tabular-nums text-sm">₹{booking.balancePayable}</span>
                  </div>
                </div>

                {/* Payable directly to Guide inside bus */}
                <div className="p-2.5 rounded-lg bg-amber-500/5 border border-amber-500/20 space-y-1 text-[11px]">
                  <span className="font-bold text-amber-400 block text-xs uppercase tracking-wider">
                    Payable Directly to Guide Inside Bus:
                  </span>
                  <div className="flex justify-between text-slate-300">
                    <span>Guide Charge: ₹50/person ({booking.passengerCount} × ₹{booking.compulsoryCharges?.guideChargeUnit || 50})</span>
                    <span className="font-mono tabular-nums text-white">₹{booking.compulsoryCharges?.guideChargeTotal || 0}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Sea Link Toll: ₹10/person ({booking.passengerCount} × ₹{booking.compulsoryCharges?.seaLinkTollUnit || 10})</span>
                    <span className="font-mono tabular-nums text-white">₹{booking.compulsoryCharges?.seaLinkTollTotal || 0}</span>
                  </div>
                  <div className="pt-1 border-t border-white/10 flex justify-between font-bold text-amber-300">
                    <span>Total Payable Directly to Guide:</span>
                    <span className="font-mono tabular-nums">
                      ₹{(booking.compulsoryCharges?.guideChargeTotal || 0) + (booking.compulsoryCharges?.seaLinkTollTotal || 0)} (₹60/person)
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    * Collected directly by the Tour Guide inside the bus. NOT included in the online fare or the ₹200 advance.
                  </p>
                </div>

                {booking.totalOptionalAmount > 0 && (
                  <div className="flex justify-between text-amber-300 text-xs">
                    <span>Optional Attractions ({booking.selectedOptionalAttractions?.map(o => o.name).join(', ') || 'Selected'}):</span>
                    <span className="font-mono tabular-nums font-bold">₹{booking.totalOptionalAmount} (Collected by Guide if visiting)</span>
                  </div>
                )}
              </div>

              {/* Actions footer */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 no-print">
                <button
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs cursor-pointer transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Ticket Receipt</span>
                </button>

                <button
                  onClick={() => setCancellationBookingId(booking.id)}
                  className="text-xs text-rose-400 hover:underline cursor-pointer"
                >
                  Need to cancel or reschedule this booking?
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {hasSearched && results && results.length === 0 && (
        <div className="shiny-dark-card rounded-2xl p-8 text-center text-slate-400 border border-white/10 space-y-2">
          <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
          <h3 className="text-base font-bold text-white">No Booking Found</h3>
          <p className="text-xs max-w-sm mx-auto">
            We couldn't locate any booking matching "{query}". Please verify your Booking ID or the 10-digit phone number entered during booking.
          </p>
          <p className="text-[11px] text-slate-500 pt-1">
            Need urgent help? Call customer care at <strong>+91 9619975457</strong>.
          </p>
        </div>
      )}

      {/* Cancellation / Reschedule Request Modal */}
      {cancellationBookingId && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12141c] border border-white/20 rounded-2xl p-6 max-w-md w-full space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-sm font-bold text-white">Request Cancellation / Reschedule</h3>
              <button
                onClick={() => setCancellationBookingId(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCancelRequest} className="space-y-3 text-xs">
              <p className="text-slate-300">
                Booking ID: <strong className="text-amber-400 font-mono">{cancellationBookingId}</strong>
              </p>

              <div>
                <label className="block text-slate-300 mb-1">Reason for Cancellation or Date Change</label>
                <textarea
                  required
                  rows={3}
                  placeholder="e.g. Flight delayed, want to change date to Nov 15th, unexpected work..."
                  value={cancellationReason}
                  onChange={e => setCancellationReason(e.target.value)}
                  className="w-full bg-slate-900 border border-white/10 rounded-xl p-3 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="p-3 rounded-lg bg-white/5 text-[11px] text-slate-400">
                Free reschedule permitted up to 24 hours prior to travel. Cancellations made 24+ hours in advance receive a full refund less ₹50 processing fee.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCancellationBookingId(null)}
                  className="px-3 py-1.5 rounded-lg bg-white/10 text-slate-300"
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-rose-500 text-white font-bold"
                >
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
