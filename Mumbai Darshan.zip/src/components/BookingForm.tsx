import React, { useState, useMemo, useRef } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Users,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Utensils,
  Sparkles,
  CreditCard,
  Printer,
  ChevronRight,
  ShieldCheck,
  Info
} from 'lucide-react';
import { StorageService } from '../services/storage';
import { RouteId, PackageId, Booking, FoodSelection } from '../types';

interface BookingFormProps {
  initialRoute?: RouteId;
  onBookingComplete?: (booking: Booking) => void;
  compact?: boolean;
}

export const BookingForm: React.FC<BookingFormProps> = ({
  initialRoute = 'western',
  onBookingComplete,
  compact = false
}) => {
  // Wizard Step (1 to 6, plus 7 for Success Receipt)
  const [currentStep, setCurrentStep] = useState<number>(1);
  const formRef = useRef<HTMLDivElement>(null);

  // Dynamic configuration loaded from Storage (Admin-editable)
  const routes = useMemo(() => StorageService.getRoutes().filter(r => r.active), []);
  const allPickupPoints = useMemo(() => StorageService.getPickupPoints().filter(p => p.active), []);
  const packages = useMemo(() => StorageService.getPackages().filter(p => p.active), []);
  const offers = useMemo(() => StorageService.getOffers(), []);
  const extraCharges = useMemo(() => StorageService.getExtraCharges().filter(c => c.active), []);

  // Form State
  const tomorrow = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  }, []);

  const [travelDate, setTravelDate] = useState<string>(tomorrow);
  const [selectedRouteId, setSelectedRouteId] = useState<RouteId>(initialRoute);
  const [selectedPickupPointId, setSelectedPickupPointId] = useState<string>('');
  
  // Package selection
  const [selectedPackageId, setSelectedPackageId] = useState<PackageId>('ac_lunch');

  // Passenger & Food state
  const [passengerCount, setPassengerCount] = useState<number>(2);
  const [foodSelection, setFoodSelection] = useState<FoodSelection>({
    vegBiryani: 1,
    butterPaneer: 1,
    vegThali: 0
  });
  const [specialRequest, setSpecialRequest] = useState<string>('');

  // Customer contact state
  const [customerName, setCustomerName] = useState<string>('');
  const [customerMobile, setCustomerMobile] = useState<string>('');
  const [customerEmail, setCustomerEmail] = useState<string>('');

  // Optional attractions state (record of chargeId -> selected boolean)
  const [selectedOptionalExtras, setSelectedOptionalExtras] = useState<Record<string, boolean>>({
    gateway_boat_ride: false,
    museum_entry: false,
    bollywood_museum: false
  });

  // Payment mode: 'advance' (₹200 per booking) or 'full'
  const [paymentMode, setPaymentMode] = useState<'advance' | 'full'>('advance');

  // Completed booking state for receipt
  const [completedBooking, setCompletedBooking] = useState<Booking | null>(null);
  const [submissionError, setSubmissionError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Filter pickup points for the selected route
  const availablePickupPoints = useMemo(() => {
    return allPickupPoints
      .filter(p => p.routeId === selectedRouteId)
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }, [allPickupPoints, selectedRouteId]);

  // Ensure valid pickup point is selected when route changes
  React.useEffect(() => {
    if (availablePickupPoints.length > 0 && !availablePickupPoints.some(p => p.id === selectedPickupPointId)) {
      setSelectedPickupPointId(availablePickupPoints[0].id);
    }
  }, [availablePickupPoints, selectedPickupPointId]);

  const selectedPickup = useMemo(() => {
    return availablePickupPoints.find(p => p.id === selectedPickupPointId) || availablePickupPoints[0];
  }, [availablePickupPoints, selectedPickupPointId]);

  const selectedRoute = useMemo(() => {
    return routes.find(r => r.id === selectedRouteId) || routes[0];
  }, [routes, selectedRouteId]);

  const selectedPackage = useMemo(() => {
    return packages.find(p => p.packageId === selectedPackageId) || packages[0];
  }, [packages, selectedPackageId]);

  // Check if an offer applies to the selected route
  const currentOffer = useMemo(() => {
    return offers.find(o => o.routeId === selectedRouteId && o.enabled);
  }, [offers, selectedRouteId]);

  // Calculate prices strictly from backend storage values
  const baseUnitFare = selectedPackage?.basePrices[selectedRouteId] ?? 0;
  
  // Calculate discount per person if active offer exists
  const discountPerPerson = useMemo(() => {
    if (!currentOffer || !currentOffer.enabled) return 0;
    if (currentOffer.discountType === 'flat') {
      return currentOffer.discountValue;
    } else {
      return Math.round((baseUnitFare * currentOffer.discountValue) / 100);
    }
  }, [currentOffer, baseUnitFare]);

  const effectiveUnitFare = Math.max(0, baseUnitFare - discountPerPerson);
  const totalPackageAmount = effectiveUnitFare * passengerCount;
  const totalDiscountAmount = discountPerPerson * passengerCount;

  // Compulsory Charges (Guide ₹50 + Sea Link Toll ₹10 = ₹60 per person)
  const guideChargeObj = extraCharges.find(c => c.id === 'guide_charge');
  const seaLinkObj = extraCharges.find(c => c.id === 'sealink_toll');

  const guideUnit = guideChargeObj?.amount ?? 50;
  const seaLinkUnit = seaLinkObj?.amount ?? 10;
  const guideTotal = guideUnit * passengerCount;
  const seaLinkTotal = seaLinkUnit * passengerCount;
  const totalCompulsoryAmount = guideTotal + seaLinkTotal;

  // Optional Charges
  const optionalChargesList = useMemo(() => {
    return extraCharges.filter(c => c.type === 'optional');
  }, [extraCharges]);

  const chosenOptionalList = useMemo(() => {
    const list: { id: string; name: string; unitPrice: number; passengerCount: number; totalPrice: number }[] = [];
    optionalChargesList.forEach(charge => {
      if (selectedOptionalExtras[charge.id] && charge.amount > 0) {
        list.push({
          id: charge.id,
          name: charge.name,
          unitPrice: charge.amount,
          passengerCount: passengerCount,
          totalPrice: charge.amount * passengerCount
        });
      }
    });
    return list;
  }, [optionalChargesList, selectedOptionalExtras, passengerCount]);

  const totalOptionalAmount = chosenOptionalList.reduce((acc, curr) => acc + curr.totalPrice, 0);

  // Online Booking Fare (Strictly the Bus Package Fare - NOT including Guide Charge or Sea Link Toll)
  // Mandatory Business Rule: Guide Charge (₹50/pax) and Sea Link Toll (₹10/pax) are collected directly by Tour Guide inside bus.
  const totalOnlinePayable = totalPackageAmount;
  const grandTotal = totalOnlinePayable; // Total online booking fare (e.g. ₹1,500 for 3 pax)

  // Advance Mode calculation: ₹200 fixed advance per booking (not per person)
  const advanceFixed = 200;
  const amountPayableNow = paymentMode === 'advance' ? Math.min(advanceFixed, totalOnlinePayable) : totalOnlinePayable;
  const balancePayable = Math.max(0, totalOnlinePayable - amountPayableNow); // Remaining bus package amount payable on bus (e.g. ₹1,300)
  const totalPayableToGuide = totalCompulsoryAmount; // Payable directly to Guide inside the bus (e.g. ₹180 for 3 pax)

  // Auto-adjust food selections when passenger count changes
  React.useEffect(() => {
    if (selectedPackage?.hasLunch) {
      const currentSum = foodSelection.vegBiryani + foodSelection.butterPaneer + foodSelection.vegThali;
      if (currentSum !== passengerCount) {
        setFoodSelection({
          vegBiryani: Math.ceil(passengerCount / 2),
          butterPaneer: Math.floor(passengerCount / 2),
          vegThali: 0
        });
      }
    }
  }, [passengerCount, selectedPackage?.hasLunch]);

  // Validation rules for each step
  const validateStep = (step: number): boolean => {
    setSubmissionError(null);
    if (step === 1) {
      if (!travelDate) {
        setSubmissionError('Please select a valid travel date.');
        return false;
      }
      if (!selectedPickupPointId) {
        setSubmissionError('Please select a pickup point.');
        return false;
      }
      return true;
    }
    if (step === 2) {
      if (!selectedPackageId) {
        setSubmissionError('Please select a package.');
        return false;
      }
      return true;
    }
    if (step === 3) {
      if (passengerCount < 1 || passengerCount > 50) {
        setSubmissionError('Please enter between 1 and 50 passengers.');
        return false;
      }
      if (selectedPackage?.hasLunch) {
        const sum = (foodSelection.vegBiryani || 0) + (foodSelection.butterPaneer || 0) + (foodSelection.vegThali || 0);
        if (sum !== passengerCount) {
          setSubmissionError(`Meal selections sum (${sum}) must exactly equal the number of passengers (${passengerCount}).`);
          return false;
        }
      }
      return true;
    }
    if (step === 4) {
      if (!customerName.trim() || customerName.trim().length < 3) {
        setSubmissionError('Please enter the customer full name (at least 3 characters).');
        return false;
      }
      const cleanMobile = customerMobile.replace(/\D/g, '');
      if (cleanMobile.length !== 10) {
        setSubmissionError('Please enter a valid 10-digit mobile number.');
        return false;
      }
      if (customerEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail)) {
        setSubmissionError('Please enter a valid email address.');
        return false;
      }
      return true;
    }
    return true;
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
      setTimeout(() => {
        if (formRef.current) {
          formRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 40);
    }
  };

  const prevStep = () => {
    setSubmissionError(null);
    setCurrentStep(prev => Math.max(1, prev - 1));
    setTimeout(() => {
      if (formRef.current) {
        formRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 40);
  };

  // Final submission
  const handleSubmitBooking = async () => {
    if (!validateStep(4)) return;
    setIsSubmitting(true);
    setSubmissionError(null);

    try {
      const bookingData: Omit<Booking, 'id' | 'createdAt' | 'historyLog'> = {
        travelDate,
        routeId: selectedRouteId,
        routeName: selectedRoute?.name || 'Western Line',
        pickupPointId: selectedPickup?.id || '',
        pickupPointName: selectedPickup ? `${selectedPickup.name} (${selectedPickup.landmark})` : '',
        pickupTime: selectedPickup?.time || '6:30 AM',
        reportingTime: selectedPickup?.reportingTime || '15 minutes prior',
        packageId: selectedPackageId,
        packageTitle: selectedPackage?.title || 'AC Bus + Lunch',
        isAC: selectedPackage?.isAC ?? true,
        hasLunch: selectedPackage?.hasLunch ?? true,
        passengerCount,
        foodSelections: selectedPackage?.hasLunch ? foodSelection : undefined,
        specialRequest: specialRequest.trim() || undefined,
        customerName: customerName.trim(),
        customerMobile: customerMobile.trim(),
        customerEmail: customerEmail.trim() || `${customerMobile.trim()}@mumbaidarshanbusonline.com`,
        unitPackagePrice: baseUnitFare,
        totalPackageAmount,
        offerDiscountAmount: totalDiscountAmount,
        appliedOfferLabel: currentOffer?.label,
        compulsoryCharges: {
          guideChargeUnit: guideUnit,
          guideChargeTotal: guideTotal,
          seaLinkTollUnit: seaLinkUnit,
          seaLinkTollTotal: seaLinkTotal,
          totalCompulsoryAmount
        },
        selectedOptionalAttractions: chosenOptionalList,
        totalOptionalAmount,
        onlineBookingFare: grandTotal,
        grandTotal,
        paymentMode,
        amountPayableNow,
        amountPaid: 0, // Recorded as 0 until verified by payment gateway or Admin
        balancePayable,
        paymentStatus: 'Pending Verification',
        bookingStatus: 'Confirmed',
        customerEmailStatus: 'Queued',
        ownerEmailStatus: 'Queued',
        adminNotes: paymentMode === 'advance' 
          ? `Online Booking Fare: ₹${grandTotal}. ₹200 advance per booking pending verification. Remaining bus package balance: ₹${balancePayable} payable on bus. Tour Guide separately collects ₹${totalCompulsoryAmount} inside bus.`
          : `Full online booking fare of ₹${grandTotal} pending verification. Tour Guide separately collects ₹${totalCompulsoryAmount} inside bus.`
      };

      const savedBooking = StorageService.createBooking(bookingData);
      setCompletedBooking(savedBooking);
      setCurrentStep(7); // Show receipt
      if (onBookingComplete) {
        onBookingComplete(savedBooking);
      }
    } catch (err: any) {
      setSubmissionError(err?.message || 'Failed to process booking. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      ref={formRef}
      id="booking-form-container"
      className={`shiny-dark-card rounded-2xl p-3.5 min-[360px]:p-5 sm:p-7 text-slate-100 ${compact ? 'max-w-2xl' : 'max-w-4xl'} mx-auto shadow-2xl border border-white/10 w-full min-w-0 box-border scroll-mt-24`}
    >
      {/* Step Indicator Header (Steps 1 to 6) */}
      {currentStep <= 6 && (
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2 font-medium">
            <span>Step {currentStep} of 6</span>
            <span className="text-amber-400 font-semibold">
              {currentStep === 1 && '1. Travel & Pickup Route'}
              {currentStep === 2 && '2. Bus Package Selection'}
              {currentStep === 3 && '3. Passengers & Meals'}
              {currentStep === 4 && '4. Customer Information'}
              {currentStep === 5 && '5. Payment Choice'}
              {currentStep === 6 && '6. Review & Confirmation'}
            </span>
          </div>
          
          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden flex">
            {[1, 2, 3, 4, 5, 6].map(st => (
              <div
                key={st}
                className={`h-full flex-1 transition-all duration-300 ${
                  st < currentStep
                    ? 'bg-amber-400'
                    : st === currentStep
                    ? 'bg-amber-500 shadow-sm shadow-amber-500'
                    : 'bg-white/5'
                }`}
              />
            ))}
          </div>
        </div>
      )}

      {/* Error notification banner */}
      {submissionError && (
        <div className="mb-5 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
          <span>{submissionError}</span>
        </div>
      )}

      {/* STEP 1: Travel Details & Pickup Route */}
      {currentStep === 1 && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Select Travel Date & Pickup Route
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Choose your tour date and one of the 4 dedicated Mumbai pickup lines.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Travel Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                Date of Travel
              </label>
              <input
                type="date"
                min={new Date().toISOString().slice(0, 10)}
                value={travelDate}
                onChange={e => setTravelDate(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Buses operate 365 days a year including public holidays.
              </span>
            </div>

            {/* Route Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                Select Pickup Line
              </label>
              <select
                value={selectedRouteId}
                onChange={e => setSelectedRouteId(e.target.value as RouteId)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
              >
                {routes.map(r => (
                  <option key={r.id} value={r.id} className="bg-slate-900 text-white">
                    {r.name} ({r.id === 'western' ? 'Bhayandar to Colaba' : r.id === 'central' ? 'Kalwa to CSMT' : r.id === 'harbour' ? 'Panvel to Koparkhairane' : 'Kalyan to Airoli'})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Pickup Point Selection */}
          <div className="bg-[#12141c] border border-white/10 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-400" />
                Your Boarding Stop on {selectedRoute?.name}
              </label>
              <span className="text-[11px] text-amber-400/90 font-medium">
                {availablePickupPoints.length} pickup spots on this route
              </span>
            </div>

            <select
              value={selectedPickupPointId}
              onChange={e => setSelectedPickupPointId(e.target.value)}
              className="w-full bg-slate-900 border border-white/10 rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
            >
              {availablePickupPoints.map(p => (
                <option key={p.id} value={p.id} className="bg-slate-900 text-white">
                  {p.time} — {p.name} ({p.landmark})
                </option>
              ))}
            </select>

            {selectedPickup && (
              <div className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20 text-xs space-y-1">
                <div className="flex items-center justify-between font-semibold text-amber-300">
                  <span>Pickup Time: {selectedPickup.time}</span>
                  <span>Reporting: {selectedPickup.reportingTime}</span>
                </div>
                <p className="text-slate-300">
                  Boarding Landmark: <strong className="text-white">{selectedPickup.landmark}</strong>, {selectedPickup.name}
                </p>
                <p className="text-[11px] text-slate-400">
                  Please report 15 minutes prior to departure. The bus driver / guide will contact your registered mobile.
                </p>
              </div>
            )}
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="button"
              onClick={nextStep}
              className="w-full sm:w-auto justify-center flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-sm hover:from-amber-300 hover:to-amber-400 cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
            >
              <span>Continue to Packages</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Bus and Package Selection */}
      {currentStep === 2 && (
        <div className="space-y-6">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Choose Bus & Package Type
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Prices for <span className="text-amber-400 font-semibold">{selectedRoute?.name}</span>. Real-time active rates from backend.
              </p>
            </div>
            {currentOffer?.enabled && (
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{currentOffer.label} Active</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {packages.map(pkg => {
              const basePrice = pkg.basePrices[selectedRouteId] ?? 0;
              const isSelected = selectedPackageId === pkg.packageId;
              let finalPrice = basePrice;
              if (currentOffer?.enabled) {
                if (currentOffer.discountType === 'flat') {
                  finalPrice = Math.max(0, basePrice - currentOffer.discountValue);
                } else {
                  finalPrice = Math.round(basePrice * (1 - currentOffer.discountValue / 100));
                }
              }

              return (
                <div
                  key={pkg.packageId}
                  onClick={() => setSelectedPackageId(pkg.packageId)}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-400 shadow-md shadow-amber-500/10'
                      : 'bg-[#12141c] border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded ${pkg.isAC ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-700 text-slate-300'}`}>
                          {pkg.isAC ? 'AC Luxury' : 'Non-AC Standard'}
                        </span>
                        {pkg.hasLunch && (
                          <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 flex items-center gap-1">
                            <Utensils className="w-2.5 h-2.5" />
                            + Lunch
                          </span>
                        )}
                      </div>
                      <h3 className="font-bold text-white text-base mt-2">{pkg.title}</h3>
                    </div>
                    <div className="text-right">
                      {finalPrice < basePrice ? (
                        <>
                          <span className="text-xs text-slate-500 line-through block">₹{basePrice}</span>
                          <span className="text-lg font-extrabold text-amber-400">₹{finalPrice}</span>
                        </>
                      ) : (
                        <span className="text-lg font-extrabold text-white">₹{basePrice}</span>
                      )}
                      <span className="text-[10px] text-slate-400 block">/ person</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    {pkg.description}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-300 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-white">Transparent Pricing Transparency:</p>
              <p className="text-slate-400 mt-0.5">
                Bus package fare covers your seat, guide coordination, and transit across all 44 tour points. Compulsory guide (₹50) and Sea Link bridge toll (₹10) are itemized separately in Step 5 as regulatory charges.
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between gap-2 pt-2">
            <button
              type="button"
              onClick={prevStep}
              className="shrink-0 flex items-center gap-1 px-3 sm:px-4 py-2 rounded-xl bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 text-xs font-semibold cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>

            <button
              type="button"
              onClick={nextStep}
              className="shrink min-w-0 flex items-center justify-center gap-1.5 px-3.5 sm:px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs sm:text-sm hover:from-amber-300 hover:to-amber-400 cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
            >
              <span className="truncate">Next: Passenger & Food</span>
              <ArrowRight className="w-4 h-4 shrink-0" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: Passengers & Food Selection */}
      {currentStep === 3 && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Passenger Count & Meal Choices
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Select passenger count. For lunch packages, customize choices per person.
            </p>
          </div>

          {/* Passenger Counter */}
          <div className="bg-[#12141c] border border-white/10 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <label className="text-sm font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-400" />
                Total Passengers Traveling
              </label>
              <p className="text-xs text-slate-400 mt-0.5">
                Children above 3 years require a seat ticket.
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setPassengerCount(prev => Math.max(1, prev - 1))}
                className="w-9 h-9 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold flex items-center justify-center cursor-pointer active:scale-95"
              >
                -
              </button>
              <span className="text-xl font-extrabold text-amber-400 w-10 text-center">
                {passengerCount}
              </span>
              <button
                type="button"
                onClick={() => setPassengerCount(prev => Math.min(50, prev + 1))}
                className="w-9 h-9 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold flex items-center justify-center cursor-pointer active:scale-95"
              >
                +
              </button>
            </div>
          </div>

          {/* Lunch & Breakfast Options (Only if lunch package selected) */}
          {selectedPackage?.hasLunch ? (
            <div className="bg-[#12141c] border border-white/10 rounded-xl p-4 space-y-4">
              <div className="border-b border-white/10 pb-3">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                  <Utensils className="w-4 h-4" />
                  <span>Breakfast & Pure Veg Lunch Included</span>
                </div>
                <div className="mt-2.5 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-200 leading-relaxed">
                  Breakfast and lunch are included in applicable packages. Breakfast will be served as Samosa or Kanda Poha, as decided by the operator. Drinking water bottles and juice are not included.
                </div>
                <p className="text-xs text-slate-400 mt-2">
                  Select your hot vegetarian lunch choice for each passenger (Sum must equal <span className="text-amber-400 font-bold">{passengerCount}</span>):
                </p>
              </div>

              <div className="space-y-3">
                {/* Veg Biryani */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/5">
                  <div>
                    <span className="font-semibold text-white text-xs block">1. Veg Biryani + Cooling Raita</span>
                    <span className="text-[11px] text-slate-400">Aromatic spiced basmati rice with mixed vegetables</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setFoodSelection(prev => ({ ...prev, vegBiryani: Math.max(0, prev.vegBiryani - 1) }))}
                      className="w-7 h-7 rounded bg-white/10 hover:bg-white/20 text-white text-xs cursor-pointer"
                    >
                      -
                    </button>
                    <span className="w-6 text-center text-sm font-bold text-white">{foodSelection.vegBiryani}</span>
                    <button
                      type="button"
                      onClick={() => setFoodSelection(prev => ({ ...prev, vegBiryani: prev.vegBiryani + 1 }))}
                      className="w-7 h-7 rounded bg-white/10 hover:bg-white/20 text-white text-xs cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Butter Paneer */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/5">
                  <div>
                    <span className="font-semibold text-white text-xs block">2. Butter Paneer Masala + 3 Chapati</span>
                    <span className="text-[11px] text-slate-400">Creamy paneer curry served with fresh soft wheat chapatis</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setFoodSelection(prev => ({ ...prev, butterPaneer: Math.max(0, prev.butterPaneer - 1) }))}
                      className="w-7 h-7 rounded bg-white/10 hover:bg-white/20 text-white text-xs cursor-pointer"
                    >
                      -
                    </button>
                    <span className="w-6 text-center text-sm font-bold text-white">{foodSelection.butterPaneer}</span>
                    <button
                      type="button"
                      onClick={() => setFoodSelection(prev => ({ ...prev, butterPaneer: prev.butterPaneer + 1 }))}
                      className="w-7 h-7 rounded bg-white/10 hover:bg-white/20 text-white text-xs cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Veg Thali */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/5">
                  <div>
                    <span className="font-semibold text-white text-xs block">3. Veg Thali (2 Bhaji, Dal, Rice, Puri)</span>
                    <span className="text-[11px] text-slate-400">Complete traditional meal with seasonal vegetables, dal tadka, rice & puris</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setFoodSelection(prev => ({ ...prev, vegThali: Math.max(0, prev.vegThali - 1) }))}
                      className="w-7 h-7 rounded bg-white/10 hover:bg-white/20 text-white text-xs cursor-pointer"
                    >
                      -
                    </button>
                    <span className="w-6 text-center text-sm font-bold text-white">{foodSelection.vegThali}</span>
                    <button
                      type="button"
                      onClick={() => setFoodSelection(prev => ({ ...prev, vegThali: prev.vegThali + 1 }))}
                      className="w-7 h-7 rounded bg-white/10 hover:bg-white/20 text-white text-xs cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Validation summary */}
                <div className="text-right text-xs pt-1">
                  <span className={`font-semibold ${
                    (foodSelection.vegBiryani + foodSelection.butterPaneer + foodSelection.vegThali) === passengerCount
                      ? 'text-emerald-400'
                      : 'text-amber-400'
                  }`}>
                    Selected: {foodSelection.vegBiryani + foodSelection.butterPaneer + foodSelection.vegThali} / {passengerCount} meals
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-400">
              You selected <strong>Without Lunch</strong> package. Passengers can purchase lunch at designated AC restaurant stops or bring their own refreshments.
            </div>
          )}

          {/* Special Requests */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Special Requests or Seating Preferences (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g., Senior citizen traveling, front row requested, language preference"
              value={specialRequest}
              onChange={e => setSpecialRequest(e.target.value)}
              className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="flex items-center justify-between gap-2 pt-2">
            <button
              type="button"
              onClick={prevStep}
              className="shrink-0 flex items-center gap-1 px-3 sm:px-4 py-2 rounded-xl bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 text-xs font-semibold cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>

            <button
              type="button"
              onClick={nextStep}
              className="shrink min-w-0 flex items-center justify-center gap-1.5 px-3.5 sm:px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs sm:text-sm hover:from-amber-300 hover:to-amber-400 cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
            >
              <span className="truncate">Next: Customer Details</span>
              <ArrowRight className="w-4 h-4 shrink-0" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Customer Details */}
      {currentStep === 4 && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Customer Contact Information
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Your Booking ID and pickup coordinator contact will be sent to this number.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Full Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g., Rajesh Sharma"
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
                className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  10-Digit Mobile Number <span className="text-rose-400">*</span>
                </label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 rounded-l-xl border border-r-0 border-white/10 bg-slate-900 text-xs font-semibold text-slate-300">
                    +91
                  </span>
                  <input
                    type="tel"
                    maxLength={10}
                    placeholder="9820012345"
                    value={customerMobile}
                    onChange={e => setCustomerMobile(e.target.value.replace(/\D/g, ''))}
                    className="w-full bg-[#12141c] border border-white/10 rounded-r-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Bus guide calls 20 mins prior to pickup stop.
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Email Address (Optional)
                </label>
                <input
                  type="email"
                  placeholder="rajesh@example.com"
                  value={customerEmail}
                  onChange={e => setCustomerEmail(e.target.value)}
                  className="w-full bg-[#12141c] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  For automated ticket PDF receipt and itinerary.
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between gap-2 pt-2">
            <button
              type="button"
              onClick={prevStep}
              className="shrink-0 flex items-center gap-1 px-3 sm:px-4 py-2 rounded-xl bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 text-xs font-semibold cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>

            <button
              type="button"
              onClick={nextStep}
              className="shrink min-w-0 flex items-center justify-center gap-1.5 px-3.5 sm:px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs sm:text-sm hover:from-amber-300 hover:to-amber-400 cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
            >
              <span className="truncate">Next: Charges & Payment</span>
              <ArrowRight className="w-4 h-4 shrink-0" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 5: Payment Selection & Optional Attraction Extras */}
      {currentStep === 5 && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Charges Breakdown & Payment Mode
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Select optional attractions (if any) and choose between ₹200 advance or full payment.
            </p>
          </div>

          {/* Optional Attractions Selection */}
          <div className="bg-[#12141c] border border-white/10 rounded-xl p-4 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Optional Attraction Tickets — Pay Offline to Tour Guide
                </h3>
                <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 font-semibold text-[10px]">
                  Optional • Offline Payment • Collected by Tour Guide
                </span>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20 text-xs text-amber-200/90 leading-relaxed">
              <p>
                <strong>Notice:</strong> All attraction visits are optional. Attraction ticket charges are not included in your online bus booking. If you choose to visit an attraction, the Tour Guide will collect the applicable amount on the bus. If you do not wish to visit, you do not have to pay.
              </p>
            </div>

            <div className="space-y-2.5">
              {optionalChargesList.map(extra => (
                <label
                  key={extra.id}
                  className={`flex items-start justify-between p-3 rounded-lg border cursor-pointer transition-all ${
                    selectedOptionalExtras[extra.id]
                      ? 'bg-amber-500/10 border-amber-400/50'
                      : 'bg-white/5 border-white/5 hover:border-white/15'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={!!selectedOptionalExtras[extra.id]}
                      onChange={e => setSelectedOptionalExtras(prev => ({ ...prev, [extra.id]: e.target.checked }))}
                      className="mt-1 h-4 w-4 rounded border-white/20 text-amber-500 focus:ring-amber-400 cursor-pointer"
                    />
                    <div>
                      <span className="font-semibold text-white text-xs block">{extra.name}</span>
                      <span className="text-[11px] text-slate-400 block mt-0.5">{extra.description}</span>
                      <span className="text-[10px] text-amber-300/80 block mt-0.5">
                        Offline on bus: {extra.collectorNotice || 'Collected by Tour Guide only if visited.'}
                      </span>
                    </div>
                  </div>
                  <div className="text-right shrink-0 ml-3">
                    {extra.amount > 0 ? (
                      <>
                        <span className="text-sm font-bold text-white">₹{extra.amount}</span>
                        <span className="text-[10px] text-slate-400 block">/ person</span>
                        {selectedOptionalExtras[extra.id] && (
                          <span className="text-[10px] text-amber-400 font-semibold block mt-0.5">
                            ₹{extra.amount * passengerCount} offline
                          </span>
                        )}
                      </>
                    ) : (
                      <span className="text-xs text-slate-400 italic">Price to be confirmed</span>
                    )}
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Payment Mode Options */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Choose Payment Option
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Option 1: ₹200 advance per booking */}
              <div
                onClick={() => setPaymentMode('advance')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMode === 'advance'
                    ? 'bg-amber-500/10 border-amber-400 shadow-md shadow-amber-500/10'
                    : 'bg-[#12141c] border-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    Advance Payment Mode
                  </span>
                  <span className="text-lg font-black text-white">₹200</span>
                </div>
                <p className="text-xs font-semibold text-white mt-1">
                  Pay only ₹200 Advance per booking now
                </p>
                <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                  Remaining balance of <strong className="text-amber-300">₹{balancePayable}</strong> payable in cash or UPI directly on the bus.
                </p>
              </div>

              {/* Option 2: Full payment */}
              <div
                onClick={() => setPaymentMode('full')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMode === 'full'
                    ? 'bg-amber-500/10 border-amber-400 shadow-md shadow-amber-500/10'
                    : 'bg-[#12141c] border-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                    Full Payment
                  </span>
                  <span className="text-lg font-black text-white">₹{grandTotal}</span>
                </div>
                <p className="text-xs font-semibold text-white mt-1">
                  Pay 100% in full today
                </p>
                <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                  Zero balance due on the bus. Immediate verified priority boarding voucher issued.
                </p>
              </div>
            </div>
          </div>

          {/* Transparent Live Calculation Box */}
          <div className="bg-[#12141c] border border-white/10 rounded-xl p-4 text-xs space-y-3">
            <h4 className="font-bold text-white text-xs border-b border-white/10 pb-2 flex items-center justify-between">
              <span>Online Bus Booking Fare ({passengerCount} Passengers)</span>
              <span className="text-slate-400 font-normal">{selectedRoute?.name}</span>
            </h4>

            <div className="flex justify-between text-slate-300">
              <span>Bus Package: {selectedPackage?.title} ({passengerCount} × ₹{effectiveUnitFare})</span>
              <span className="font-mono tabular-nums text-white font-semibold">₹{totalPackageAmount}</span>
            </div>

            <div className="border-t border-white/10 pt-2 flex justify-between font-bold text-sm text-white">
              <span>Total Online Booking Fare:</span>
              <span className="text-amber-400 font-mono tabular-nums text-base">₹{totalOnlinePayable}</span>
            </div>

            <div className="flex justify-between text-xs font-semibold pt-1">
              <span className="text-emerald-400">Amount Payable Today ({paymentMode === 'advance' ? '₹200 Advance per booking' : 'Full Payment'}):</span>
              <span className="text-emerald-400 font-mono tabular-nums font-bold">₹{amountPayableNow}</span>
            </div>

            {paymentMode === 'advance' && (
              <div className="flex justify-between text-xs text-amber-300 bg-amber-500/10 p-2 rounded-lg">
                <span>Remaining Bus Package Amount (Payable on Bus):</span>
                <span className="font-mono tabular-nums font-bold">₹{balancePayable}</span>
              </div>
            )}

            {/* MANDATORY ON-BUS CHARGES (COLLECTED DIRECTLY BY GUIDE INSIDE BUS) */}
            <div className="mt-3 p-3 rounded-xl bg-amber-500/5 border border-amber-500/20 space-y-2 text-xs">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>Payable Directly to Guide Inside Bus</span>
              </div>
              <div className="space-y-1.5 text-slate-300 text-[11px]">
                <div className="flex justify-between">
                  <span>Guide Charge: ₹50/person — Payable directly to Guide inside the bus. ({passengerCount} × ₹{guideUnit})</span>
                  <span className="font-mono tabular-nums text-white font-semibold">₹{guideTotal}</span>
                </div>
                <div className="flex justify-between">
                  <span>Sea Link Toll: ₹10/person — Payable directly to Guide inside the bus. ({passengerCount} × ₹{seaLinkUnit})</span>
                  <span className="font-mono tabular-nums text-white font-semibold">₹{seaLinkTotal}</span>
                </div>
                <div className="pt-1.5 border-t border-white/10 flex justify-between font-bold text-white text-xs">
                  <span className="text-amber-300">Total payable directly to Guide: ₹60/person ({passengerCount} × ₹60)</span>
                  <span className="text-amber-400 font-mono tabular-nums">₹{totalPayableToGuide}</span>
                </div>
              </div>
              <p className="text-[10px] text-slate-400 leading-tight">
                * Note: Both charges will be collected directly by the Tour Guide inside the bus. They are NOT included in the online bus booking fare or the ₹200 advance.
              </p>
            </div>

            {totalOptionalAmount > 0 && (
              <div className="mt-2 pt-2 border-t border-dashed border-amber-500/30 text-[11px] text-amber-300/90 flex justify-between items-center bg-amber-500/5 p-2 rounded-lg">
                <div>
                  <span className="font-bold block">Optional Attraction Tickets (Offline on Bus):</span>
                  <span className="text-[10px] text-slate-400">Paid directly to Tour Guide only if you choose to enter</span>
                </div>
                <span className="font-mono font-bold text-amber-300 text-xs">₹{totalOptionalAmount}</span>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between gap-2 pt-2">
            <button
              type="button"
              onClick={prevStep}
              className="shrink-0 flex items-center gap-1 px-3 sm:px-4 py-2 rounded-xl bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 text-xs font-semibold cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>

            <button
              type="button"
              onClick={nextStep}
              className="shrink min-w-0 flex items-center justify-center gap-1.5 px-3.5 sm:px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs sm:text-sm hover:from-amber-300 hover:to-amber-400 cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
            >
              <span className="truncate">Review Booking (Step 6)</span>
              <ArrowRight className="w-4 h-4 shrink-0" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 6: Review and Confirmation */}
      {currentStep === 6 && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Final Review & Submission
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Please double check all boarding and passenger details before confirming.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Tour & Route Review */}
            <div className="bg-[#12141c] border border-white/10 rounded-xl p-4 space-y-2.5 text-xs">
              <h3 className="font-bold text-amber-400 uppercase tracking-wider text-[11px]">
                Travel & Boarding Details
              </h3>
              <div className="space-y-1 text-slate-300">
                <p>Date: <strong className="text-white">{travelDate}</strong></p>
                <p>Route: <strong className="text-white">{selectedRoute?.name}</strong></p>
                <p>Pickup Stop: <strong className="text-white">{selectedPickup?.name}</strong></p>
                <p>Landmark: <span className="text-white">{selectedPickup?.landmark}</span></p>
                <p>Pickup Time: <strong className="text-amber-400">{selectedPickup?.time}</strong></p>
                <p>Reporting: <span className="text-slate-400">{selectedPickup?.reportingTime}</span></p>
                <p>Package: <strong className="text-white">{selectedPackage?.title}</strong></p>
                <p>Total Passengers: <strong className="text-white">{passengerCount}</strong></p>
              </div>

              {selectedPackage?.hasLunch && (
                <div className="pt-2 border-t border-white/10">
                  <p className="font-semibold text-emerald-400 mb-1">Meal Selections ({passengerCount}):</p>
                  <ul className="list-disc list-inside text-slate-300 space-y-0.5">
                    {foodSelection.vegBiryani > 0 && <li>Veg Biryani + Raita: {foodSelection.vegBiryani}</li>}
                    {foodSelection.butterPaneer > 0 && <li>Butter Paneer + 3 Chapati: {foodSelection.butterPaneer}</li>}
                    {foodSelection.vegThali > 0 && <li>Veg Thali: {foodSelection.vegThali}</li>}
                  </ul>
                </div>
              )}
            </div>

            {/* Customer & Pricing Review */}
            <div className="bg-[#12141c] border border-white/10 rounded-xl p-4 space-y-2.5 text-xs">
              <h3 className="font-bold text-amber-400 uppercase tracking-wider text-[11px]">
                Customer & Fare Breakdown
              </h3>
              <div className="space-y-1 text-slate-300">
                <p>Name: <strong className="text-white">{customerName}</strong></p>
                <p>Mobile: <strong className="text-white">+91 {customerMobile}</strong></p>
                {customerEmail && <p>Email: <span className="text-white">{customerEmail}</span></p>}
                {specialRequest && <p>Note: <span className="text-amber-300 italic">{specialRequest}</span></p>}
              </div>

              <div className="pt-2 border-t border-white/10 space-y-2">
                <div className="flex justify-between">
                  <span>Online Bus Package Fare:</span>
                  <span className="font-mono tabular-nums text-white font-bold">₹{totalOnlinePayable}</span>
                </div>
                <div className="flex justify-between text-emerald-400 font-semibold text-xs">
                  <span>Advance Payable Today:</span>
                  <span className="font-mono tabular-nums">₹{amountPayableNow} ({paymentMode === 'advance' ? '₹200 Advance per booking' : '100% Full Payment'})</span>
                </div>
                {paymentMode === 'advance' && (
                  <div className="flex justify-between text-amber-300 text-xs bg-amber-500/10 p-1.5 rounded">
                    <span>Remaining Bus Package Balance:</span>
                    <span className="font-mono tabular-nums font-bold">₹{balancePayable} (Payable on bus)</span>
                  </div>
                )}

                {/* Separate Guide & Toll Breakdown */}
                <div className="pt-2 border-t border-dashed border-amber-500/30 text-[11px] space-y-1 bg-amber-500/5 p-2 rounded-lg">
                  <span className="font-bold text-amber-400 block text-xs">Payable Directly to Guide Inside Bus:</span>
                  <div className="flex justify-between text-slate-300">
                    <span>Guide Charge (₹{guideUnit}/person):</span>
                    <span className="font-mono tabular-nums text-white">₹{guideTotal}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Sea Link Toll (₹{seaLinkUnit}/person):</span>
                    <span className="font-mono tabular-nums text-white">₹{seaLinkTotal}</span>
                  </div>
                  <div className="pt-1 border-t border-white/10 flex justify-between font-bold text-amber-300">
                    <span>Total to Guide Inside Bus:</span>
                    <span className="font-mono tabular-nums">₹{totalPayableToGuide} (₹60/person)</span>
                  </div>
                </div>

                {totalOptionalAmount > 0 && (
                  <div className="pt-1.5 border-t border-dashed border-amber-500/30 text-[11px] text-amber-300">
                    <div className="flex justify-between">
                      <span>Optional Attractions (Offline on Bus):</span>
                      <span className="font-mono tabular-nums font-semibold">₹{totalOptionalAmount}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 block">Collected by Tour Guide only if you choose to visit on the tour</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Terms checkbox */}
          <div className="p-3.5 rounded-xl bg-amber-500/5 border border-amber-500/20 text-xs text-slate-300 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p>
              By confirming this booking, you agree to report 15 minutes before pickup time. Advance of ₹200 confirms your reserved seat. Balance is collected on board via cash or UPI. Free rescheduling up to 24 hours prior to travel.
            </p>
          </div>

          <div className="flex items-center justify-between gap-2 pt-2">
            <button
              type="button"
              onClick={prevStep}
              disabled={isSubmitting}
              className="shrink-0 flex items-center gap-1 px-3 sm:px-4 py-2 rounded-xl bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 text-xs font-semibold cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span className="hidden min-[360px]:inline">Back & Edit</span>
              <span className="min-[360px]:hidden">Back</span>
            </button>

            <button
              type="button"
              onClick={handleSubmitBooking}
              disabled={isSubmitting}
              className="shrink min-w-0 flex items-center justify-center gap-1.5 px-3.5 sm:px-8 py-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-slate-950 font-extrabold text-xs sm:text-sm hover:from-amber-300 hover:to-amber-500 cursor-pointer shadow-xl shadow-amber-500/25 active:scale-95 transition-all"
            >
              {isSubmitting ? (
                <span>Confirming...</span>
              ) : (
                <>
                  <CreditCard className="w-4 h-4 shrink-0" />
                  <span className="truncate">Confirm (Pay ₹{amountPayableNow})</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* STEP 7: Booking Success & Printable Receipt Modal View */}
      {currentStep === 7 && completedBooking && (
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <div className="w-14 h-14 bg-emerald-500/20 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto text-emerald-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Booking Confirmed!
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              Thank you, <strong className="text-white">{completedBooking.customerName}</strong>. Your Mumbai Darshan tour has been reserved.
            </p>
          </div>

          {/* Printable Ticket Receipt */}
          <div className="bg-[#12141c] border border-white/20 rounded-2xl p-5 sm:p-7 space-y-4 print-card">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-4 gap-2">
              <div>
                <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                  Official Travel Voucher
                </span>
                <h3 className="text-xl font-black text-white">
                  Booking ID: <span className="font-mono text-amber-400">{completedBooking.id}</span>
                </h3>
                <span className="text-xs text-slate-400">
                  Booked on: {new Date(completedBooking.createdAt).toLocaleDateString()}
                </span>
              </div>
              <div className="text-left sm:text-right">
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${
                  completedBooking.paymentStatus === 'Fully Paid'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}>
                  {completedBooking.paymentStatus}
                </span>
              </div>
            </div>

            {/* Travel Summary Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs border-b border-white/10 pb-4">
              <div>
                <span className="text-slate-400 block text-[11px]">Travel Date</span>
                <strong className="text-white text-sm">{completedBooking.travelDate}</strong>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Pickup Route</span>
                <strong className="text-white text-sm">{completedBooking.routeName}</strong>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Pickup Time</span>
                <strong className="text-amber-400 text-sm">{completedBooking.pickupTime}</strong>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Passengers</span>
                <strong className="text-white text-sm">{completedBooking.passengerCount} Persons</strong>
              </div>
            </div>

            {/* Boarding Stop & Landmark */}
            <div className="bg-white/5 rounded-xl p-3.5 text-xs space-y-1">
              <span className="text-amber-400 font-semibold block">Boarding Point:</span>
              <p className="text-white font-medium text-sm">
                {completedBooking.pickupPointName}
              </p>
              <p className="text-slate-400 text-[11px]">
                Reporting Guideline: <strong>{completedBooking.reportingTime}</strong>. Please carry valid Govt ID proof.
              </p>
            </div>

            {/* Fare & Payments Breakdown */}
            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-xl bg-white/5 space-y-1.5">
                <div className="flex justify-between text-slate-300">
                  <span>Online Bus Package Fare ({completedBooking.packageTitle}):</span>
                  <span className="font-mono tabular-nums text-white font-bold">₹{completedBooking.totalPackageAmount}</span>
                </div>
                <div className="flex justify-between text-emerald-400 font-semibold">
                  <span>Advance Payment Status:</span>
                  <span className="font-mono tabular-nums">
                    {completedBooking.paymentStatus === 'Pending Verification' 
                      ? 'Pending Verification (₹200 Advance per booking)'
                      : completedBooking.paymentStatus}
                  </span>
                </div>
                <div className="flex justify-between font-bold text-amber-300 bg-amber-500/10 p-2 rounded-lg mt-1">
                  <span>Remaining Bus Package Amount (Payable on Bus):</span>
                  <span className="font-mono tabular-nums text-sm">₹{completedBooking.balancePayable}</span>
                </div>
              </div>

              {/* Mandatory Guide & Sea Link Toll (Collected Directly by Guide Inside Bus) */}
              <div className="p-3 rounded-xl bg-amber-500/5 border border-amber-500/20 space-y-1.5">
                <span className="font-bold text-amber-400 block text-xs uppercase tracking-wider">
                  Payable Directly to Guide Inside Bus:
                </span>
                <div className="flex justify-between text-slate-300 text-[11px]">
                  <span>Guide Charge: ₹50/person ({completedBooking.passengerCount} × ₹{completedBooking.compulsoryCharges.guideChargeUnit})</span>
                  <span className="font-mono tabular-nums text-white">₹{completedBooking.compulsoryCharges.guideChargeTotal}</span>
                </div>
                <div className="flex justify-between text-slate-300 text-[11px]">
                  <span>Sea Link Toll: ₹10/person ({completedBooking.passengerCount} × ₹{completedBooking.compulsoryCharges.seaLinkTollUnit})</span>
                  <span className="font-mono tabular-nums text-white">₹{completedBooking.compulsoryCharges.seaLinkTollTotal}</span>
                </div>
                <div className="pt-1 border-t border-white/10 flex justify-between font-bold text-amber-300 text-xs">
                  <span>Total Payable Directly to Guide:</span>
                  <span className="font-mono tabular-nums">₹{completedBooking.compulsoryCharges.totalCompulsoryAmount} (₹60/person)</span>
                </div>
                <p className="text-[10px] text-slate-400">
                  * Note: Collected directly by the Tour Guide inside the bus. NOT included in the online fare or the ₹200 advance.
                </p>
              </div>

              {completedBooking.totalOptionalAmount > 0 && (
                <div className="flex justify-between text-amber-300 text-xs p-2 rounded bg-white/5">
                  <span>Optional Attractions ({completedBooking.selectedOptionalAttractions.map(o => o.name).join(', ')}):</span>
                  <span className="font-mono tabular-nums font-bold">₹{completedBooking.totalOptionalAmount} (Collected by Guide if visiting)</span>
                </div>
              )}

              {/* Breakfast and Lunch Note */}
              {completedBooking.hasLunch && (
                <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-[11px] text-emerald-200 leading-relaxed">
                  <strong>Meal Information:</strong> Breakfast and lunch are included in applicable packages. Breakfast will be served as Samosa or Kanda Poha, as decided by the operator. Drinking water bottles and juice are not included.
                </div>
              )}
            </div>

            <div className="border-t border-white/10 pt-3 text-[11px] text-slate-400 leading-relaxed">
              Official Helpline: <strong>+91 9619975457</strong> | Email: <strong>mumbaidarshanbooking@gmail.com</strong>
              <br />
              Address: 110, Sai Krupa Chawl, Bansi Nagar, W. E. Highway, Kulupwadi, Borivali East, Mumbai 400066.
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 no-print">
            <button
              onClick={() => window.print()}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs cursor-pointer transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Download Receipt PDF</span>
            </button>

            <button
              onClick={() => {
                setCurrentStep(1);
                setCompletedBooking(null);
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer transition-colors"
            >
              <span>Book Another Ticket</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
