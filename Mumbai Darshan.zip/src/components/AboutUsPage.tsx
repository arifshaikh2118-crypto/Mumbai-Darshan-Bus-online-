import React from 'react';
import { ShieldCheck, Award, Users, HeartHandshake, MapPin, Bus, CheckCircle2 } from 'lucide-react';
import { StorageService } from '../services/storage';

export const AboutUsPage: React.FC = () => {
  const settings = StorageService.getSettings();

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      {/* Hero Intro */}
      <div className="text-center space-y-3">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
          Showing Mumbai With Pride For Over 15 Years
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          About Mumbai Darshan Bus Online
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          We are Mumbai's premier daily city sightseeing operator, welcoming travelers from across India and worldwide to experience the spirit, architecture, and legends of the City of Dreams.
        </p>
      </div>

      {/* Story & Philosophy */}
      <div className="shiny-dark-card rounded-2xl p-6 sm:p-8 border border-white/10 space-y-5">
        <h2 className="text-xl font-bold text-white tracking-tight">Our Heritage & Mission</h2>
        <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <p>
            Established with a vision to make Mumbai sightseeing accessible, transparent, and comfortable for every family, <strong>Mumbai Darshan Bus Online</strong> has grown into the city’s most trusted daily tour network.
          </p>
          <p>
            Mumbai is a sprawling metropolis of 20+ million people where navigating traffic, finding parking, and coordinating monument tickets can overwhelm even experienced travelers. Our curated 44-point sightseeing route eliminates the chaos, taking you seamlessly from northern suburban pickup points across Western, Central, Harbour, and Kalyan corridors into the historic heart of South Mumbai.
          </p>
          <p>
            From the gothic majesty of Chhatrapati Shivaji Maharaj Terminus (CSMT) and the seaside aura of Gateway of India to the serene spirituality of Shree Siddhivinayak Temple and the glamorous coastal drive along Bandra Bandstand, we ensure you don't miss a single heartbeat of this magnificent city.
          </p>
        </div>

        {/* 4 Core Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-white/10">
          <div className="p-4 rounded-xl bg-white/5 space-y-1.5">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
              <Bus className="w-4 h-4" />
              <span>Modern Verified Fleet</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Equipped with high-performance climate control, wide panoramic glass windows, push-back executive seating, and air suspension for maximum comfort.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-white/5 space-y-1.5">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
              <Award className="w-4 h-4" />
              <span>Certified Storytelling Guides</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Our guides are licensed heritage experts who narrate historical anecdotes, Bollywood trivia, and colonial tales in Hindi, English, and Marathi.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-white/5 space-y-1.5">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
              <ShieldCheck className="w-4 h-4" />
              <span>Zero Hidden Costs</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Transparent itemized pricing with clear separation between bus fares, compulsory tolls, and optional attraction tickets.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-white/5 space-y-1.5">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
              <HeartHandshake className="w-4 h-4" />
              <span>Passenger First Support</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              365-day phone and WhatsApp coordination (+91 9619975457), dedicated pickup assistance, senior citizen support, and pure vegetarian meal hygiene.
            </p>
          </div>
        </div>
      </div>

      {/* Official Business Identity Card */}
      <div className="shiny-dark-card rounded-2xl p-6 sm:p-8 border border-white/10 space-y-4">
        <h3 className="text-base font-bold text-white">Registered Business Identity</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-300">
          <div>
            <span className="text-slate-500 block text-[11px]">Commercial Brand:</span>
            <strong className="text-white text-sm">{settings.businessName}</strong>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Official Domain:</span>
            <span className="text-amber-400 font-mono">{settings.websiteDomain}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Helpline Phone:</span>
            <strong className="text-white font-mono text-sm">{settings.businessPhone}</strong>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Official Email:</span>
            <span className="text-white">{settings.businessEmail}</span>
          </div>
          <div className="sm:col-span-2">
            <span className="text-slate-500 block text-[11px]">Headquarters & Registered Office:</span>
            <span className="text-slate-300">{settings.registeredAddress}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
