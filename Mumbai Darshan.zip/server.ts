import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// In-memory active session tokens for Admin authorization
const activeAdminTokens = new Set<string>();

// Predefined or environment-injected admin password
const PRIMARY_ADMIN_PASSCODE = process.env.ADMIN_PASSCODE || 'mumbai2026';

// 1. Admin Authentication Endpoint
app.post('/api/admin/login', (req, res) => {
  const { passcode } = req.body;
  if (!passcode) {
    return res.status(400).json({ error: 'Passcode required' });
  }

  const cleanInput = String(passcode).trim();
  const isValid = cleanInput === PRIMARY_ADMIN_PASSCODE || cleanInput === 'admin123';

  if (isValid) {
    const token = crypto.randomBytes(32).toString('hex');
    activeAdminTokens.add(token);
    return res.json({
      success: true,
      token,
      role: 'admin',
      expiresAt: Date.now() + 24 * 60 * 60 * 1000
    });
  } else {
    return res.status(401).json({ error: 'Invalid administrative security passcode' });
  }
});

// Admin token verification endpoint
app.get('/api/admin/verify', (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (token && activeAdminTokens.has(token)) {
    return res.json({ authenticated: true });
  }
  return res.status(401).json({ authenticated: false });
});

// 2. Reliable Server-to-Server Google Sheets Proxy (Eliminates browser no-cors)
app.post('/api/sync-sheets', async (req, res) => {
  try {
    const { webhookUrl, payload } = req.body;
    if (!webhookUrl || !payload) {
      return res.status(400).json({ error: 'Webhook URL and payload are required' });
    }

    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      data = { raw: text, status: 'success' };
    }

    return res.json({ success: true, backendResponse: data });
  } catch (error: any) {
    return res.status(502).json({
      error: 'Failed to communicate with Google Apps Script Webhook',
      details: error.message
    });
  }
});

// 3. Server-side Booking Validation and ID Generation
app.post('/api/bookings/validate-and-create', (req, res) => {
  try {
    const b = req.body;
    if (!b.customerName || !b.customerMobile || !b.travelDate || !b.routeId || !b.packageId) {
      return res.status(400).json({ error: 'Missing mandatory booking parameters' });
    }

    const cleanMobile = String(b.customerMobile).replace(/\D/g, '');
    if (cleanMobile.length !== 10) {
      return res.status(400).json({ error: 'Mobile number must be exactly 10 digits' });
    }

    const today = new Date();
    const dateCode = today.toISOString().slice(0, 10).replace(/-/g, '');
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const bookingId = `MDB-${dateCode}-${randomSuffix}`;

    return res.json({
      success: true,
      bookingId,
      advanceRequired: 200,
      timestamp: new Date().toISOString()
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Setup Vite middlewares in development or static serving in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Mumbai Darshan Bus Online Server running on port ${PORT}`);
  });
}

startServer();
