# Google Apps Script Setup & Email Authorization Guide
**Mumbai Darshan Bus Online**  
**Configured Business Email:** `mumbaidarshanbooking@gmail.com`  
**Official Business Phone:** `9619975457`  
**Registered Office:** 110, Sai Krupa Chawl, Bansi Nagar, W. E. Highway, Kulupwadi, Borivali East, Mumbai, Maharashtra 400066.

---

## 1. Overview & Safety Architecture

The Google Apps Script engine (`google-apps-script/Code.gs`) handles:
1. **Google Sheets Database Synchronization:** Exact 21 columns for `Bookings`, separate `Rental Enquiry` sheet, and operational logs.
2. **Customer & Owner Email Notifications:** Sent via Google's native `MailApp` service using the authorized business account `mumbaidarshanbooking@gmail.com`.
3. **Daily Operations Report:** Automatically compiled and emailed at **10:00 PM IST**.
4. **Safety Disablement:** Live automated emails are kept **disabled by default** (`ENABLE_LIVE_EMAILS = false`) until the business owner explicitly authorizes the script and activates live sending.
5. **No Password Storage:** The application **never** asks for, receives, or stores your Gmail password, App Password, or OTP. Authorization occurs entirely through Google's official OAuth consent screen.

---

## 2. Step-by-Step Installation

### Step A: Open Your Google Sheet
1. Open your master Google Sheet (or create a new blank Google Sheet named `Mumbai Darshan Bus Online - Database`).
2. In the top menu, click **Extensions** > **Apps Script**.

### Step B: Paste the Script Code
1. In the Apps Script editor, open `Code.gs` (or delete any default boilerplate text).
2. Copy the entire contents of `google-apps-script/Code.gs` from this project repository and paste it into the editor.
3. Click the **Save** icon (diskette icon) or press `Ctrl + S` / `Cmd + S`.

### Step C: Initialize the Database Sheets
1. In the function dropdown menu at the top of the editor, select **`setupDatabase`**.
2. Click **Run**.
3. Google will ask for permission on the first run:
   - Click **Review Permissions**.
   - Select your business Google Account (`mumbaidarshanbooking@gmail.com`).
   - Click **Advanced** > **Go to Untitled project (unsafe)** (standard Google Apps Script prompt for custom private scripts).
   - Click **Allow**.
4. Return to your Google Sheet: All 16 authoritative sheets (including `Bookings`, `Rental Enquiry`, `Settings`, etc.) will have been created with bold dark headers.

---

## 3. Controlled Email Testing (Zero Customer Impact)

Before enabling live emails for real customers, test the email service in a controlled environment:

1. In the function dropdown, select **`testSendBookingEmail`**.
2. Click **Run**.
3. Check the Execution Log at the bottom of the editor. You should see:
   ```
   Running controlled email dispatch test to mumbaidarshanbooking@gmail.com...
   Customer Email Result: {"status":"Sent"}
   Owner Notification Result: {"status":"Sent"}
   ```
4. Open the Gmail inbox for `mumbaidarshanbooking@gmail.com`. You will find:
   - A sample **Customer Booking Voucher** email.
   - A sample **Owner Notification Alert** email.
5. Inspect the test emails to verify that:
   - Online Booking Fare shows ₹1,500.
   - Advance Status shows ₹200.
   - Remaining Bus Balance shows ₹1,300 payable on the bus.
   - Guide Charge (₹150) and Sea Link Toll (₹30) are clearly itemized as payable directly to the Tour Guide inside the bus.
   - Meal Notice confirms breakfast (Samosa or Kanda Poha) and hot veg lunch, explicitly stating drinking water and juice are not included.

---

## 4. Setting Up the Daily 10:00 PM IST Report Trigger

1. In the Apps Script function dropdown, select **`setupDailyReportTrigger`**.
2. Click **Run**.
3. The script will automatically schedule a time-driven trigger that fires every night between 10:00 PM and 11:00 PM IST, summarizing all bookings, passenger counts, route distributions, expected cash collections, and guide fees.

---

## 5. Deploying the Webhook for Live Website Sync

1. In the top right corner of Apps Script, click the blue **Deploy** button > **New deployment**.
2. Click the gear icon next to "Select type" and choose **Web app**.
3. Configure the deployment settings:
   - **Description:** `Mumbai Darshan Bus Online Sync Engine v4.0`
   - **Execute as:** `Me (mumbaidarshanbooking@gmail.com)`
   - **Who has access:** `Anyone` (required so your website backend can post booking data).
4. Click **Deploy**.
5. Copy the **Web App URL** (e.g., `https://script.google.com/macros/s/AKfycbx.../exec`).
6. Open your Mumbai Darshan Bus Online Admin Panel:
   - Go to **Settings & Webhooks**.
   - Paste the Web App URL into the **Google Sheets Webhook URL** field.
   - Click **Save Webhook Settings**.
   - Click **Test Webhook Ping** to verify connectivity.

---

## 6. Activating Live Customer Emails

When the owner is ready to start sending automated emails for all newly placed bookings:

1. Open your master Google Sheet.
2. Go to the **`Settings`** tab.
3. Locate row `ENABLE_LIVE_EMAILS`.
4. Change its value from `false` to **`true`**.
5. From this moment on, every newly confirmed booking will automatically send an acknowledgement email to the customer and an instant notification to `mumbaidarshanbooking@gmail.com`.
6. If email sending fails (e.g., invalid customer email format or daily Gmail quota limit reached), the booking is **never rejected or lost**; it is saved with `Customer Email Status = Failed`, and the Admin can retry delivery from the Admin Panel.
